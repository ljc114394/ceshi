package com.boe.bank.mapper.userNatureInfoMapper;

import com.boe.bank.common.bean.userNature.*;
import org.apache.ibatis.annotations.Insert;

import com.boe.bank.common.entity.userNatureInfo.UserNatureInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface UserNatureInfoMapper {
	
	@Insert({ "insert into user_nature_info(face_id, face_feature, reco_age, reco_sex, first_visit, create_time)"
			+ " values(#{faceId}, #{faceFeature}, #{recoAge}, #{recoSex}, #{firstVisit}, #{createTime, jdbcType=TIMESTAMP})" })
    public int insert(UserNatureInfo userNatureInfo);

	@Select("select count(id) from user_nature_info where face_id = #{faceId}")
	public int select(String faceId);

	@Update("update user_nature_info set face_feature=#{faceFeature}, reco_age=#{recoAge}, reco_sex=#{recoSex}, " +
			"first_visit=#{firstVisit}, update_time=#{updateTime, jdbcType=TIMESTAMP} where face_id = #{faceId}")
	public int update(UserNatureInfo userNatureInfo);

	List<UserNatureDTO> userNaturePage(UserNatureSearchDTO userNatureSearchDTO);

	List<UserActionDTO> userActionPage(UserActionSearchDTO userActionSearchDTO);

	List<UserActionHeadDTO> buriedPointData(Integer type);


}

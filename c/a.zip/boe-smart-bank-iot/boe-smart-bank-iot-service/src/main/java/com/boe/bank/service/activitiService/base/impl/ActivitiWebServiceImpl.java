package com.boe.bank.service.activitiService.base.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.boe.bank.common.bean.activiti.ActivitiCandidateDto;
import com.boe.bank.common.bean.activiti.ActivitiUserTaskDto;
import com.boe.bank.common.bean.activiti.UserTaskBo;
import com.boe.bank.common.bean.user.OrgAncestorDo;
import com.boe.bank.common.bean.user.UserOrgDo;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.utils.StringUtil;
import com.boe.bank.mapper.activiti.UserOrgRelationMapper;
import com.boe.bank.service.activitiService.base.ActivitiWebService;
import com.boe.bank.service.activitiService.org.impl.ActivitiProcessOrgServiceImpl;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

/**
 * activiti 
 * 1. 前端流程图存储 
 * 2. 前端<-->后端 类型相互转化
 * @author caoxuhao
 */
@Service
@Slf4j
public class ActivitiWebServiceImpl implements ActivitiWebService {
	
	@Value("${spring.activiti.auto-pass-user-id:-1}")
	private Long autoPassUserId;
	
	@Autowired
	private UserOrgRelationMapper userOrgRelationMapper;
	
	/**
	 * 这段转化逻辑建立在以下几个条件成立情况下
	 * 1. 每个用户有且仅有一个部门
	 * 2. 每个部门有且仅有一个组织
	 * 3. 用户表org_id存的一定是部门 
	 */
	@Override
	public List<UserTaskBo> convertActivitiUserTaskDto2UserTaskBo(List<ActivitiUserTaskDto> userTaskList) {

		List<UserTaskBo> modelList = new ArrayList<>();

		for (ActivitiUserTaskDto activitiUserTaskDto : userTaskList) {
			
			if(activitiUserTaskDto.getReviewerType() == ActivitiConstants.ReviewerType.userOrGroup) {
				//通过组织架构决定候选者
				Integer passType = activitiUserTaskDto.getPassType();
				if (passType == ActivitiConstants.PassType.department) {
					// 按部门的
					Map<Long, Set<Long>> map = getDepartmentAndUserFromActivitiUserTaskDto(activitiUserTaskDto);
					modelList.add(new UserTaskBo(activitiUserTaskDto.getName(), map.size(), ActivitiConstants.PassType.any,
							ActivitiConstants.PassType.department, map));
				} else {
					// 其他
					Map<Long, Set<Long>> map = getUserFromActivitiUserTaskDto(activitiUserTaskDto);
					modelList.add(new UserTaskBo(activitiUserTaskDto.getName(), 1, passType, map));
				}
			}else if(activitiUserTaskDto.getReviewerType() == ActivitiConstants.ReviewerType.role){
				//通过角色决定候选者,具体审核人物，要到用户提交审批单时候才能确定。此处只封装条件
				Integer passType = activitiUserTaskDto.getPassType();
				List<Integer> roles = activitiUserTaskDto.getRoles();
				Integer roleAdditional = activitiUserTaskDto.getRoleAdditional();
				modelList.add(new UserTaskBo(activitiUserTaskDto.getName(), 1, passType, roles, roleAdditional));
			}

			
		}

		return modelList;
	}
	
	/**
	 * 设置各节点审批人 到 审批流参数map
	 * @param map			审批流参数map
	 * @param modelList		节点描述列表
	 * @param creator		审批单提交者
	 * @throws Exception 
	 */
	@Override
	public void putAssignee(Map<String, Object> map, List<UserTaskBo> modelList, Long creator) {
		
		// 创建者所在部门组织架构id(目前就byRole时候用)
		Long creatorOrgId = getOrgFromUser(creator);
		if(creatorOrgId == null)
			throw new RuntimeException("提交者没有对应的组织架构，无法按照角色创建流程单");
		
		int taskIndex = 1;
		for (UserTaskBo userTaskModel : modelList) {
			
			List<Integer> roles = userTaskModel.getRoles();
			if(CollectionUtils.isEmpty(roles)) {
				//通过组织架构
				Map<Long, Set<Long>> depMap = userTaskModel.getMap();
				
				for (Long key : depMap.keySet()) {
					Set<Long> userIds = depMap.get(key);
					// map的key要与MultiInstanceLoopCharacteristics的InputDataItem相同
					putUserInMap(map, taskIndex, new ArrayList<>(userIds));
					taskIndex++;
				}
				
			}else {
				//通过角色决定候选人
				
				// 1. 有创建者部门权限的角色
				List<Integer> eligibleRoles = userOrgRelationMapper.selectRoleByRolesAndOrg(creatorOrgId.intValue(), roles);
				if(CollectionUtils.isEmpty(eligibleRoles)) {
					//没有符合条件的角色，审核人列表置空
					putEmptyUserInMap(map, taskIndex);
					taskIndex++;
					continue;
				}
				
				// 2. 获取符合角色的用户
				List<Long> eligibleUserIds = userOrgRelationMapper.selectUserIdByRoles(eligibleRoles);
				if(CollectionUtils.isEmpty(eligibleUserIds)) {
					//没有符合条件的候选人，则审核人列表置空
					putEmptyUserInMap(map, taskIndex);
					taskIndex++;
					continue;
				}else {
					//删除自己
					eligibleUserIds.remove(creator);
					if(CollectionUtils.isEmpty(eligibleUserIds)) {
						//没有符合条件的候选人，则审核人列表置空
						putEmptyUserInMap(map, taskIndex);
						taskIndex++;
						continue;
					}
				}
				
				// 3. 附加条件
				List<Long> userIds = new ArrayList<>();
				boolean shouldPutEmpty = true;
				
				Integer roleAdditional = userTaskModel.getRoleAdditional();
				
				if(roleAdditional != null) {
					List<Long> orgIds = new ArrayList<>();
					if(roleAdditional == ActivitiConstants.RoleAdditional.sameDep) {
						orgIds.add(creatorOrgId);
						userIds = userOrgRelationMapper.selectUserIdByOrgAndUserIds(orgIds, eligibleUserIds);
						if(!CollectionUtils.isEmpty(userIds)) {
							shouldPutEmpty = false;
							putUserInMap(map, taskIndex, userIds);
						}
					
					}else if(roleAdditional == ActivitiConstants.RoleAdditional.sameOrg) {
						//获取同机构的部门
						orgIds = userOrgRelationMapper.selectDepBySameOrg(creatorOrgId);
						if(!CollectionUtils.isEmpty(orgIds)) {
							userIds = userOrgRelationMapper.selectUserIdByOrgAndUserIds(orgIds, eligibleUserIds);
							if(!CollectionUtils.isEmpty(userIds)) {
								shouldPutEmpty = false;
								putUserInMap(map, taskIndex, userIds);
							}
						}							
					}else if(roleAdditional == ActivitiConstants.RoleAdditional.allDown) {
						//获取下级,即祖先=自己的
						List<Long> depIds = getDepartmentFromOrg(creatorOrgId);
						if(!CollectionUtils.isEmpty(depIds)) {
							userIds = userOrgRelationMapper.selectUserIdByOrgAndUserIds(depIds, eligibleUserIds);
							if(!CollectionUtils.isEmpty(userIds)) {
								shouldPutEmpty = false;
								putUserInMap(map, taskIndex, userIds);
							}
						}
						
					}else if(roleAdditional == ActivitiConstants.RoleAdditional.allUp) {
						//获取祖先
						List<Long> depIds = getAllUpDeps(creatorOrgId);
						if(!CollectionUtils.isEmpty(depIds)) {
							userIds = userOrgRelationMapper.selectUserIdByOrgAndUserIds(depIds, eligibleUserIds);
							if(!CollectionUtils.isEmpty(userIds)) {
								shouldPutEmpty = false;
								putUserInMap(map, taskIndex, userIds);
							}
						}
						
					}else {
						shouldPutEmpty = false;
						putUserInMap(map, taskIndex, eligibleUserIds);
					}
					
					if(shouldPutEmpty)
						putEmptyUserInMap(map, taskIndex);
					
				}else {
					putUserInMap(map, taskIndex, eligibleUserIds);
				}
				
				taskIndex++;
			}
		}
	}
	
	/**
	 * 添加无审核人标记，即设置审核人为自动通过的审核人
	 * @param map
	 * @param taskIndex
	 */
	private void putEmptyUserInMap(Map<String, Object> map, int taskIndex) {
		List<Long> l = Lists.newArrayList();
		l.add(autoPassUserId);
		putUserInMap(map, taskIndex, l);
	}
	
	private void putUserInMap(Map<String, Object> map, int taskIndex, List<Long> userIds) {
		map.put(ActivitiProcessOrgServiceImpl.ASSIGNEE_NAME_PREFIX + taskIndex + "List", userIds);
	}
	
	/*******************************************************************************************************************
	 * 通过组织架构决定候选者
	 *******************************************************************************************************************/

	/**
	 * 获取部门和人员关系（去重）
	 * @return key:deparmentId value:userIds
	 */
	private Map<Long, Set<Long>> getDepartmentAndUserFromActivitiUserTaskDto(
			ActivitiUserTaskDto activitiUserTaskBo) {

		Map<Long, Set<Long>> map = new HashMap<>();

		Set<Long> deps = new HashSet<>();

		List<Long> organizations = activitiUserTaskBo.getOrganizations();
		// 从机构取部门
		if (!CollectionUtils.isEmpty(organizations)) {
			for (Long orgId : organizations) {
				List<Long> depIds = getDepartmentFromOrg(orgId);
				deps.addAll(depIds);
			}
		}

		List<Long> departments = activitiUserTaskBo.getDepartments();
		if (!CollectionUtils.isEmpty(departments)) {
			deps.addAll(departments);
		}

		// 从部门取个人
		if (!CollectionUtils.isEmpty(deps)) {
			for (Long depId : deps) {
				// 根据depId获取所有人
				Set<Long> userList = map.get(depId);
				if (userList == null) {
					userList = new HashSet<>();
					map.put(depId, userList);
				}

				List<Long> tmp = getUserIdsFromDepartment(depId);
				if (!CollectionUtils.isEmpty(tmp))
					userList.addAll(tmp);
			}
		}

		// 通过人员找部门，然后加入map
		List<ActivitiCandidateDto> candidateList = activitiUserTaskBo.getCandidates();
		if(!CollectionUtils.isEmpty(candidateList)) {
			List<Long> candidates = candidateList.stream().map(ActivitiCandidateDto::getId).collect(Collectors.toList());
		
			Map<Long, Long> userDepMap = getDepartmentFromUsers(candidates);
			for (Long userId : userDepMap.keySet()) {
				Long depId = userDepMap.get(userId);

				Set<Long> userList = map.get(depId);
				if (userList == null) {
					userList = new HashSet<>();
					map.put(depId, userList);
				}

				userList.add(userId);
			}
		}

		return map;
	}

	/**
	 * 获取候选人员（去重）
	 * @return key:deparmentId value:userIds
	 */
	private Map<Long, Set<Long>> getUserFromActivitiUserTaskDto(ActivitiUserTaskDto activitiUserTaskBo) {

		Set<Long> depSet = new HashSet<>();
		Set<Long> result = new HashSet<>();

		Long depId = -1L;
		Map<Long, Set<Long>> map = new HashMap<>();
		map.put(depId, result);

		//set通过组织找到并加入部门
		List<Long> organizations = activitiUserTaskBo.getOrganizations();
		if (!CollectionUtils.isEmpty(organizations)) {
			for (Long org : organizations) {
				List<Long> deps = getDepartmentFromOrg(org);
				if(!CollectionUtils.isEmpty(deps))
					depSet.addAll(deps);
			}
		}
		
		//set加入用户指定部门
		List<Long> departments = activitiUserTaskBo.getDepartments();
		if (!CollectionUtils.isEmpty(departments))
			depSet.addAll(departments);
		
		//部门所有人加入候选人
		if (!CollectionUtils.isEmpty(depSet)) {
			for (Long dep : depSet) {
				List<Long> userIds = getUserIdsFromDepartment(dep);
				result.addAll(userIds);
			}
		}
		
		List<ActivitiCandidateDto> candidateList = activitiUserTaskBo.getCandidates();
		if(!CollectionUtils.isEmpty(candidateList)) {
			List<Long> candidates = candidateList.stream().map(ActivitiCandidateDto::getId).collect(Collectors.toList());
			result.addAll(candidates);
		}

		return map;
	}

	//通过部门获取到人员ids
	private List<Long> getUserIdsFromDepartment(Long depId) {
		return userOrgRelationMapper.selectUserIdByDep(depId);
	}

	//通过机构找到部门
	private List<Long> getDepartmentFromOrg(Long orgId) {
		return userOrgRelationMapper.selectDepIdByOrg(orgId.toString());
	}

	//通过人员找到部门(批量)
	private Map<Long,Long> getDepartmentFromUsers(List<Long> userIds) {
		List<UserOrgDo> list = userOrgRelationMapper.selectDepByUserIds(userIds);
		return list.stream().collect(Collectors.toMap(UserOrgDo::getUserId, UserOrgDo::getOrgId));
	}
	
	//通过人员找到部门
	private Long getOrgFromUser(Long userId) {
		List<Long> userIds = new ArrayList<>();
		userIds.add(userId);
		List<UserOrgDo> list = userOrgRelationMapper.selectDepByUserIds(userIds);
		if(!CollectionUtils.isEmpty(list)) {
			return list.get(0).getOrgId();
		}
		
		return null;
	}
	
	/*******************************************************************************************************************
	 * 通过角色决定候选者
	 *******************************************************************************************************************/
	/***
	 * 1. 角色下所有用户
	 * 2. 这些用户有
	 */
	
	/**
	 * 获取所有上级机构的部门
	 * @param orgId
	 * @return
	 */
	private List<Long> getAllUpDeps(Long orgId){
		
		//获取祖先
		OrgAncestorDo orgAncestorDo = userOrgRelationMapper.selectAncestorByOrg(orgId);
		
		String ancestor = orgAncestorDo.getAncestor();
		List<Long> ancestors = StringUtil.str2List(ancestor, Long.class);
		if(CollectionUtils.isEmpty(ancestors))
			return Lists.newArrayList();
		
		//去除本部门
		Long parent = orgAncestorDo.getParent();
		ancestors.remove(parent);
		if(CollectionUtils.isEmpty(ancestors))
			return Lists.newArrayList();
		
		//获取祖先的直属部门
		List<Long> deps = userOrgRelationMapper.selectChildDepIdByOrg(ancestors);
		if(CollectionUtils.isEmpty(deps))
			return Lists.newArrayList();
		
		return deps;
	}
}

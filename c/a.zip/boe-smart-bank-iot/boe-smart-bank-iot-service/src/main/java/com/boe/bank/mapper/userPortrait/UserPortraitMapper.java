package com.boe.bank.mapper.userPortrait;

import com.boe.bank.common.bean.userPortrait.*;
import com.boe.bank.common.entity.userPortrait.MarketLogs;
import com.boe.bank.common.entity.userPortrait.UserPortrait;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Description:mapper
 * @Author: lijianglong
 * @Data:2020/10/21
 */
public interface UserPortraitMapper {

    List<UserPortrait> queryUserPortraitList(UserPortraitSearchBean userPortraitSearchBean);

    List<UserPortrait> weightSort(UserPortraitSearchBean userPortraitSearchBean);

    List<UserPortraitExportDTO> userPortraitExport(UserPortraitExportBean userPortraitExportBean);

    UserPortraitInfoBean selectUserPortrait(Integer id);

    List<UserActionInfoBean> queryUserActionInfoCondition(String faceId);

    Integer queryUserActionInfoConditionNums(String faceId);

    Integer isHasUserPortrait(String portraitName);

    Integer isHasUserPortraitLabel(Integer id);

    Integer addUserPortrait(UserPortrait userPortrait);

    Integer addUserPortraitLabel(@Param("id") Integer id,
                                 @Param("createBy") String createBy,
                                 @Param("createById") Long createById,
                                 @Param("now") LocalDateTime now,
                                 @Param("portraitLabels") List<UserPortraitLabelInfoBean> userPortraitLabelInfoBeans);

    Integer updateUserPortraitById(UserPortrait userPortrait);

    Integer deleteUserPortraitByIds(Integer id);

    Integer addUserPortraitLabels(@Param("id") Integer id,
                                  @Param("createBy") String createBy,
                                  @Param("createById") Long createById,
                                  @Param("now") LocalDateTime now,
                                  @Param("userPortraitLabelBeanList") List<UserPortraitLabelBean> userPortraitLabelBeanList);

    Integer deleteUserPortraitById(Integer id);

    Integer deleteUserPortraitLabelById(Integer id);

    Integer addMarketLogs(MarketLogs marketLogs);

    Integer updateUserPortraitPersonNums(Integer id);

    List<UserPortrait> queryProductCPortraitList(Integer id);

    Integer productWeigthEdit(ProductWeigthDTO productWeigthDTO);

    ProductWeigthVO productWeigthEditCheck(ProductWeigthDTO productWeigthDTO);

}

package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.boe.bank.common.bean.equipment.EquipmentQO;
import com.boe.bank.common.bean.equipment.EquipmentVO;
import com.boe.bank.common.entity.equipment.Equipment;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 设备 Mapper
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentMapper extends BaseMapper<Equipment> {

    @Select("select * from t_equipment where id = #{id}")
    Equipment selectById(@Param("id") Integer id);

    IPage<EquipmentVO> selectPageVO(Page<Object> objectPage, @Param("qo") EquipmentQO qo);

    List<EquipmentVO> selectPageVO(@Param("qo") EquipmentQO qo);

}

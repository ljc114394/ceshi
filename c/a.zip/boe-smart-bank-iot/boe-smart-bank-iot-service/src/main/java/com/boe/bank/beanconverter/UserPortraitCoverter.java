package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.userPortrait.UserPortraitBean;
import com.boe.bank.common.bean.userPortrait.UserPortraitInfoBean;
import com.boe.bank.common.bean.userPortrait.UserPortraitLabelDTO;
import com.boe.bank.common.entity.userPortrait.UserPortrait;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * @Description:转义
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Mapper(componentModel = "spring")
public interface UserPortraitCoverter {

    UserPortrait getUserPortrait(UserPortraitInfoBean userPortraitInfoBean);

    UserPortrait getUserPortrait(UserPortraitLabelDTO userPortraitLabelDTO);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(userPortrait.getCreateTime()))")
    })
    UserPortraitBean getUserPortraitBean(UserPortrait userPortrait);

    List<UserPortraitBean> getUserPortraitBeanList(List<UserPortrait> userPortraitList);

}

package com.boe.bank.service.appliedbizmanege;

import com.boe.bank.beanconverter.AppliedBizManegeCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.appliedbizmanege.*;
import com.boe.bank.common.constant.AppliedBizConstants;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.appliedbizmanege.AppliedBizManege;
import com.boe.bank.mapper.appliedbizmanege.AppliedBizManegeMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Stream;

import static com.boe.bank.common.constant.AppliedBizConstants.*;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Service
@Slf4j
public class AppliedBizManegeService {

    @Resource
    private AppliedBizManegeMapper appliedBizManegeMapper;
    @Resource
    private AppliedBizManegeCoverter appliedBizManegeCoverter;
    @Resource
    private ObjectMapper objectMapper;

    private ReentrantLock lock = new ReentrantLock();

    @Value("${spring.datasource.url}")
    private String dataSourceUrl;


    /**
     * 详情
     *
     * @param id
     * @return
     */
    public AppliedBizManegeInfoBean getAppliedBizInfoById(Integer id) throws JsonProcessingException {
        log.info("应用配置管理-详情");

        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(id);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        log.info("应用配置管理-详情查询结果：result={}", result);
        AppliedBizManegeInfoBean infoBean = appliedBizManegeCoverter.model2InforVO(result);
        //json转换为Java
        String[] bizComponents = objectMapper.readValue(result.getBizComponents(), new TypeReference<String[]>() {
        });
        List<AppliedBizManegeFieldBean> bizFields = objectMapper.readValue(result.getBizFields(), new TypeReference<List<AppliedBizManegeFieldBean>>() {
        });
        //赋值
        infoBean.setBizComponents(bizComponents);
        infoBean.setBizFieldList(bizFields);

        return infoBean;
    }

    /**
     * 更新
     * 主要是实现先删后插的逻辑
     * 由于ddl 语句会隐士的自动提交事务，造成事务无法回滚所以放到最后
     *
     * @param id
     * @param savebean
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> updateAppliedBiz(Integer id, AppliedBizManegeSaveBean savebean) throws Exception {
        log.info("应用配置管理-更新");
        //验证
        checkParameters(savebean);
        AppliedBizManege result = checkDataOfExists(id);
        String oldTableName = result.getBizTableName();
        Map<String, Object> resultMap = null;
        String tableName = null;

        if (lock.tryLock(TIMEOUT, TimeUnit.MILLISECONDS)) {

            try {

                log.info("应用配置管理-更新-验证应用名称是否已存在");
                if (!result.getBizName().equals(savebean.getBizName())) {
                    int size = queryAppNameIsExist(savebean.getBizName());
                    if (size != 0) {
                        throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_APP_NAME_EXIST);
                    }
                }

                log.info("应用配置管理-更新-应用业务数据：id={}", id);
                tableName = generateTableName();

                log.info("应用配置管理-更新-创建应用产品表");
                appliedBizManegeMapper.executeSQLScript(generateBuildTableDDL(savebean, tableName));

                AppliedBizManege appbm = prepareAppliedBizDataForUpdate(savebean,tableName,id, result.getBizUri());
                int row = appliedBizManegeMapper.updateByPrimaryKey(appbm);
                log.info("应用配置管理-更新-数据,结果行:{}", row);


                log.info("应用配置管理-更新-drop旧的应用表：{}", oldTableName);
                appliedBizManegeMapper.dropTable(oldTableName);
                log.info("应用配置管理-更新-完成");

                resultMap = returnDataForAdd(id,null);

            } catch (Exception e) {
                log.error("应用配置管理-更新出现异常");
                log.info("应用配置管理-更新-drop旧的应用表：{}", tableName);
                appliedBizManegeMapper.dropTable(tableName);
                throw e;
            } finally {
                lock.unlock();
            }

            return resultMap;
        } else {
            log.info("获取不到锁，请排查日志");
            throw new BusinessException(MsgReturnEnum.LOCK_FALSE);
        }

    }

    /**
     * 更新
     *
     * @param id
     * @param updateBean
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> update(Integer id, AppliedBizManegeUpdateBean updateBean) throws Exception {
        log.info("应用配置管理-已存数据更新");
        //应用配置管理数据是否存在
        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(id);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }

        String componentsJson = objectMapper.writeValueAsString(updateBean.getBizComponents());
        AppliedBizManege bizManege = new AppliedBizManege(id, updateBean.getBizName(), null, null, componentsJson, null, updateBean.getExamineId(), updateBean.getRemark());
        log.info("应用配置管理-已存更新-删除应用业务数据：id={}", id);
        int row = appliedBizManegeMapper.updateInfo(bizManege);
        if (row > 0) {
            log.info("应用配置管理-已存更新-更新条数{}", row);
        }

        return returnDataForAdd(id, bizManege.getBizUri());
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteAppliedBizById(Integer id) {

        if (null == UserInfo.getCurrentUserInfo()) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_USER_LOGIN);
        }

        AppliedBizManege result = checkDataOfExists(id);
        String tableName = result.getBizTableName();
        log.info("应用配置管理-删除--drop应用产品表：{}", tableName);
        appliedBizManegeMapper.dropTable(tableName);

        log.info("应用配置管理-删除-删除应用业务表数据 id:{}", id);
        int row = appliedBizManegeMapper.deleteByPrimaryKey(id);
        if (row > 0) {
            log.info("应用配置管理-删除-删除应用业务表数据 row:{}", row);
            return true;
        }

        return false;
    }


    /**
     * 修改或删除的数据验证
     *
     * @param id
     * @return
     */
    private AppliedBizManege checkDataOfExists(Integer id) {

        log.info("应用配置管理-验证id:{}", id);
        if (id == null || id <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        //应用配置管理数据是否存在
        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(id);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        String tableName = result.getBizTableName();
        //应用表是否有数据
        Long sum = appliedBizManegeMapper.selectAppliedData(tableName);
        if (sum > 0) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_EXISTS_DATA);
        }

        return result;
    }

    /**
     * 应用配置管理-分页
     *
     * @param searchBean
     * @return
     */
    public PageInfo<AppliedBizManegeListBean> selectAppliedBizManegeForPage(AppliedBizManegeSearchBean searchBean) {
        log.info("应用配置管理-分页查询");
        if (searchBean.getPageNum() == 0) {
            searchBean.setPageNum(Const.PAGE_NUM_DEFAULT);
        }
        if (searchBean.getPageSize() == 0) {
            searchBean.setPageSize(Const.PAGE_SIZE_DEFAULT);
        }

        Page page = PageHelper.startPage(searchBean.getPageNum(), searchBean.getPageSize(), true);
        List<AppliedBizManege> result = appliedBizManegeMapper.searchAppliedBizManegeList(searchBean);
        List<AppliedBizManegeListBean> voList = appliedBizManegeCoverter.model2List(result);
        PageInfo<AppliedBizManegeListBean> pageInfo = new PageInfo(voList, page);
        log.info("应用配置管理-分页list pageNum:{},pageSize:{}size:{}", searchBean.getPageNum(), searchBean.getPageSize(), result.size());

        return pageInfo;
    }

    /**
     * 新增
     *
     * @param repuestSaveBean
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> saveAppliedBiz(AppliedBizManegeSaveBean repuestSaveBean) throws Exception {
        //验证
        checkParameters(repuestSaveBean);
        //保存业务表数据
        String tableName = null;
        Map<String, Object> resultMap = null;

        if (lock.tryLock(TIMEOUT, TimeUnit.MILLISECONDS)) {
            try {

                log.info("应用配置管理-添加-验证应用名称是否已存在");
                int size = queryAppNameIsExist(repuestSaveBean.getBizName());
                if (size != 0) {
                    throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_APP_NAME_EXIST);
                }

                log.info("应用配置管理-添加-保存应用配置管理数据");
                tableName = generateTableName();

                log.info("应用配置管理-添加-创建应用产品表");
                appliedBizManegeMapper.executeSQLScript(generateBuildTableDDL(repuestSaveBean, tableName));

                AppliedBizManege saveBean = prepareAppliedBizData(repuestSaveBean, tableName);
                int row = appliedBizManegeMapper.insert(saveBean);

                log.info("应用配置管理-添加-插入数据,结果行:{}", row);
                String bizUri = assembleBizUri(saveBean.getId());

                log.info("应用配置管理-添加-更新bizUri:{}", bizUri);
                appliedBizManegeMapper.updateBizUriByPrimaryKey(bizUri, saveBean.getId());

                resultMap = returnDataForAdd(saveBean.getId(), bizUri);
            } catch (Exception e) {
                log.error("应用配置管理-添加出现异常");
                appliedBizManegeMapper.dropTable(tableName);
                throw e;
            } finally {
                lock.unlock();
            }

            return resultMap;
        } else {
            log.info("获取不到锁，请排查日志");
            throw new BusinessException(MsgReturnEnum.LOCK_FALSE);
        }

    }

    private Map<String, Object> returnDataForAdd(int id, String bizUri) {
        Map map = new HashMap();
        map.put(ID_STR, id);
        map.put(BIZ_URI, bizUri);
        return map;
    }

    private String assembleBizUri(int id) {
        StringBuilder uri = new StringBuilder();
        uri.append(MENU_URI);
        uri.append(id);
        return uri.toString();
    }

    /**
     * 生成建表DDl
     *
     * @param tableName
     * @return
     */
    private String generateBuildTableDDL(AppliedBizManegeSaveBean savebean, String tableName) {

        StringBuilder ddl = new StringBuilder();
        ddl.append("CREATE TABLE `" + tableName + "` (");
        ddl.append(" `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',");
        List<AppliedBizManegeFieldBean> bizFieldList = savebean.getBizFieldList();
        bizFieldList.forEach((element) -> {
            ddl.append(" `");
            ddl.append(element.getColumnCode());
            ddl.append("`");
            ddl.append(" ");
            ddl.append(element.getColumnType());
            ddl.append("(");
            ddl.append(element.getColumnLength());
            ddl.append(")");
            ddl.append(" ");
            ddl.append("1".equals(element.getRequired()) ? "NOT NULL" : "");
            ddl.append(" ");
            ddl.append("COMMENT");
            ddl.append(" ");
            ddl.append("'");
            ddl.append(element.getColumnComment());
            ddl.append("'");
            ddl.append(", ");
        });


        ddl.append(" `examine_status` int COMMENT '审批状态',");
        ddl.append(" `create_user_id` bigint NOT NULL,");
        ddl.append(" `create_by` varchar(50) NOT NULL COMMENT '创建人',");
        ddl.append(" `update_by` varchar(50) DEFAULT NULL COMMENT '修改人',");
        ddl.append(" `create_time` datetime NOT NULL COMMENT '创建时间',");
        ddl.append(" `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',");
        ddl.append(" PRIMARY KEY (`id`)");
        ddl.append(" ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='"+savebean.getBizName()+"'");

        log.info("应用配置管理-添加-建表语句 DDl:{}", ddl.toString());
        return ddl.toString();
    }

    /**
     * 生成自定义表名
     *
     * @return
     */
    private String generateTableName() {

        Integer autoIncrementId = appliedBizManegeMapper.getAutoIncrementId();
        if (autoIncrementId == null) {
            autoIncrementId = 0;
        }
        StringBuilder tableName = new StringBuilder(APPLIED_TABLE_NAME_PREFIX);
        tableName.append("_");
        tableName.append(String.format("%02d", autoIncrementId + 1L));
        log.info("应用配置管理-计算表名 tableName {}", tableName.toString());
        return tableName.toString();
    }

    /**
     * 根据URl解析数控名称
     * @return
     */
    private String getDatabaseName() {

        String[] split = dataSourceUrl.split("\\?");
        String url = split[0];
        String databaseName = url.substring(url.lastIndexOf("/")+1,url.length());
        return databaseName;
    }

    /**
     * 数据准备
     *
     * @param repuestSavebean
     * @return
     */
    private AppliedBizManege prepareAppliedBizData(AppliedBizManegeSaveBean repuestSavebean, String tableName) throws JsonProcessingException {
        log.info("应用配置管理-添加-准备数据");
        AppliedBizManege pojoBean = new AppliedBizManege();
        pojoBean.setBizName(repuestSavebean.getBizName());
        pojoBean.setRemark(repuestSavebean.getRemark());
        pojoBean.setBizTableName(tableName);
        pojoBean.setExamineId(repuestSavebean.getExamineId());

        String componentsJson = objectMapper.writeValueAsString(repuestSavebean.getBizComponents());
        String fiedsJson = objectMapper.writeValueAsString(repuestSavebean.getBizFieldList());

        pojoBean.setBizComponents(componentsJson);
        pojoBean.setBizFields(fiedsJson);
        pojoBean.setCreateTime(LocalDateTime.now());
        pojoBean.setCreateBy(UserInfo.getCurrentUserInfo().getName());
        pojoBean.setCreateUserId(UserInfo.getCurrentUserInfo().getId());

        return pojoBean;
    }

    private AppliedBizManege prepareAppliedBizDataForUpdate(AppliedBizManegeSaveBean repuestSavebean, String tableName, Integer id, String bizUri) throws JsonProcessingException {
        log.info("应用配置管理-更新-准备数据");
        AppliedBizManege appbm = appliedBizManegeCoverter.DTO2Mode(repuestSavebean);
        appbm.setId(id);
        appbm.setBizTableName(tableName);

        if (!StringUtils.isEmpty(repuestSavebean.getExamineId())) {
            appbm.setExamineId(repuestSavebean.getExamineId());
        }

        appbm.setBizUri(bizUri);
        String componentsJson = objectMapper.writeValueAsString(repuestSavebean.getBizComponents());
        String fiedsJson = objectMapper.writeValueAsString(repuestSavebean.getBizFieldList());
        appbm.setBizComponents(componentsJson);
        appbm.setBizFields(fiedsJson);
        appbm.setUpdateTime(LocalDateTime.now());
        appbm.setUpdateBy(UserInfo.getCurrentUserInfo().getName());

        return appbm;
    }

    /**
     * 数据验证
     *
     * @param savebean
     */
    private void checkParametersOfNotNull(AppliedBizManegeSaveBean savebean) {
        log.info("应用配置管理-验证参数是否为NULL");
        if (StringUtils.isEmpty(savebean.getBizName())) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_NAME);
        }

        if (CollectionUtils.isEmpty(savebean.getBizComponents())) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COMPONENTS);
        }

        if (CollectionUtils.isEmpty(savebean.getBizFieldList())) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_FIELD);
        }

        List<AppliedBizManegeFieldBean> fieldArray = savebean.getBizFieldList();
        Stream.iterate(0, i -> i + 1).limit(fieldArray.size()).forEach(i -> {

            StringBuilder message = new StringBuilder("应用字段信息列表第");
            message.append((i + 1));
            message.append("行: ");
            boolean isHaveError = false;
            AppliedBizManegeFieldBean fieldBean = fieldArray.get(i);
            if (StringUtils.isEmpty(fieldBean.getColumnCode())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_CODE.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getColumnName())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_NAME.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getColumnType())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_TYPE.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getColumnLength())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_LENGTH.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getRequired())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_REQUIRED.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getColumnComment())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_COMMENT.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getIsListShow())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_LISTSHOW.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getIsQueryCriteria())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_QUERY_CRITERIA.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getIsImage())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_COMMENT.message());
                message.append("\n");
                isHaveError = true;
            }
            if (StringUtils.isEmpty(fieldBean.getIsVideo())) {
                message.append(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_COLUMN_ISVIDEO.message());
                message.append("\n");
                isHaveError = true;
            }

            if (isHaveError) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), message.toString());
            }
        });

    }

    /**
     * 验证请求参数
     *
     * @param saveBean
     */
    private void checkParameters(AppliedBizManegeSaveBean saveBean) throws JsonProcessingException {

        checkParametersOfNotNull(saveBean);
        checkFieldsOfSize(saveBean);
        checkParametersOfLength(saveBean);
        verifySQLKeywords(saveBean);
    }


    /**
     * 验证表单字段个数
     *
     * @param savebean
     */
    private void checkFieldsOfSize(AppliedBizManegeSaveBean savebean) {
        log.info("应用配置管理-验证动态表单数据行数");
        if (savebean.getBizFieldList().size() > MAX_FIELD_SIZE) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_SIZE);
        }
    }

    /**
     * 验证数据长度
     *
     * @param savebean
     */
    private void checkParametersOfLength(AppliedBizManegeSaveBean savebean) throws JsonProcessingException {
        log.info("应用配置管理-验证参数长度");
        if (savebean.getBizName().length() > BIZNAME_LENGTH) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_BIZ_COLUMN);
        }

        String componentsJson = objectMapper.writeValueAsString(savebean.getBizComponents());
        if (componentsJson.length() > BIZCOMPONENTS_LENGTH) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_COMPONENT);
        }

        List<AppliedBizManegeFieldBean> bizFieldList = savebean.getBizFieldList();
        bizFieldList.forEach((fileld) -> {
            if (fileld.getColumnCode().length() > FIELD_LENGTH) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_LENGTH);
            }
            if (fileld.getColumnName().length() > FIELD_LENGTH) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_LENGTH);
            }
            if (fileld.getColumnComment().length() > FIELD_LENGTH) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_LENGTH);
            }
            if (fileld.getColumnLength().length() > FIELD_LENGTH) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_LENGTH);
            }
        });
        String fiedsJson = objectMapper.writeValueAsString(bizFieldList);
        if (fiedsJson.length() > FIELD_SUM_LENGTH) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELDLIST);
        }

        if (!StringUtils.isEmpty(savebean.getRemark()) && savebean.getRemark().length() > BIZREMARK_LENGTH) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_LENGTH_REMARK);
        }

    }


    /**
     * 修改或删除的数据验证
     *
     * @param bizId
     * @return
     */
    public Integer queryProductIsUsed(Integer bizId) {
        log.info("应用配置管理-产品是否已使用-id:{}", bizId);
        if (bizId == null || bizId <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        //应用配置管理数据是否存在
        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(bizId);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        String tableName = result.getBizTableName();
        //应用表是否有数据
        Long sum = appliedBizManegeMapper.selectAppliedData(tableName);
        if (sum > 0) {
            log.info("应用业务数据已经存在，不可删除,不可修改");
            return 1;
        }
        return 0;
    }


    /**
     * 查询应用名称是否已使用
     *
     * @param appName
     * @return
     */
    public Integer queryAppNameIsExist(String appName) {
        log.info("应用配置管理-产品名称是否存在-->appName:{}", appName);
        if (StringUtils.isEmpty(appName)) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_APP_NAME_EXIST);
        }
        //应用配置管理数据是否存在
        Integer size = appliedBizManegeMapper.queryAppNameIsExist(appName);
        if (size == null) {
            return 0;
        }

        return size;
    }

    /**
     * 审批流列表表搜索
     *
     * @param bizName
     * @return
     */
    public List<Integer> getLikeName(String bizName) {
        List<Integer> list = appliedBizManegeMapper.getLikeName(bizName);
        if (CollectionUtils.isEmpty(list)) {
            return Lists.newArrayList();
        }

        return list;
    }

    /**
     * 验证sql关键字
     *
     * @param dataBean
     * @return
     */
    private boolean verifySQLKeywords(AppliedBizManegeSaveBean dataBean) {

        log.info("应用配置管理-验证sql关键字");
        List<AppliedBizManegeFieldBean> fieldArray = dataBean.getBizFieldList();
        Stream.iterate(0, i -> i + 1).limit(fieldArray.size()).forEach(i -> {

            AppliedBizManegeFieldBean fieldBean = fieldArray.get(i);
            String columnCode = fieldBean.getColumnCode();
            String columnComment = fieldBean.getColumnComment();
            for (int j = 0; j < SQL_KEY_WORD.length; j++) {

                if (columnCode.equalsIgnoreCase(SQL_KEY_WORD[j])) {
                    throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_APP_SQL_KEYWORDS);
                }
                if (columnComment.equalsIgnoreCase(SQL_KEY_WORD[j])) {
                    throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_APP_SQL_KEYWORDS);
                }

            }

        });

        return true;
    }

}

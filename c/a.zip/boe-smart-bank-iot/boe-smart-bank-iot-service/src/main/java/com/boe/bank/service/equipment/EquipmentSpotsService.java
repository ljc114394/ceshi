package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipment.EquipmentPlanDTO;
import com.boe.bank.common.bean.equipment.EquipmentSpotsQO;
import com.boe.bank.common.bean.equipment.EquipmentSpotsVO;
import com.boe.bank.common.entity.equipment.EquipmentSpots;

/**
 * 设备插播记录 Service
 *
 * @author 10183279
 * @date 2020/10/30
 */
public interface EquipmentSpotsService extends IService<EquipmentSpots> {

    /**
     * 插播
     * @param mac 设备mac地址
     * @param dto 计划id列表
     */
    void spots(String mac, EquipmentPlanDTO dto);

    /**
     * 获取插播记录
     * @param qo
     * @return
     */
    IPage<EquipmentSpotsVO> page(EquipmentSpotsQO qo);
}

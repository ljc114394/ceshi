package com.boe.bank.service.material;

import com.boe.bank.common.bean.activiti.ActivitiProcessMaterialVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessOrgVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessPlanVo;
import com.boe.bank.common.bean.material.MaterialInfoBean;
import com.boe.bank.common.bean.planmanagebean.PlanManageBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.material.MaterialManage;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.bank.mapper.material.MaterialManageMapper;
import com.boe.bank.mapper.planmanageMapper.PlanManageMapper;
import com.boe.bank.service.activitiService.manager.ActivitiSupport;
import com.boe.bank.service.planmanageService.PlanManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 素材模块-提供审核能力
 * @author caoxuhao
 */
@Component
public class MaterialActivitiSupporter implements ActivitiSupport {

    @Autowired
    private MaterialManageMapper materialManageMapper;

    @Autowired
    private MaterialManageService materialManageService;

    @Override
    public int getBusniessType() {
        return ActivitiConstants.BusniessType.material;
    }

    @Override
    public boolean updateExamineStatus(int outerId, int examineStatus, Integer outerType) {
        MaterialManage materialManage = new MaterialManage();
        materialManage.setId(outerId);
        materialManage.setStatus(examineStatus);
        return materialManageMapper.updateByPrimaryKeySelective(materialManage) > 0;
    }

    @Override
    public boolean addOuterData(int outerId, ActivitiProcessOrgVo t, Integer outerType) {

        MaterialInfoBean entity = materialManageService.getMaterialInfoWithDelete(outerId);
        if (entity == null)
            return false;

        if (t instanceof ActivitiProcessMaterialVo) {
            ActivitiProcessMaterialVo vo = (ActivitiProcessMaterialVo) t;
            vo.setMaterialTag(entity.getLableTitle());
            vo.setMateriaName(entity.getTitle());
            vo.setMaterialType(entity.getType());
            return true;
        }

        return false;
    }
}

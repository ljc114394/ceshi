package com.boe.bank.mapper.department;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.bean.department.DepartmentConBean;
import com.boe.bank.common.bean.department.DepartmentListBean;
import com.boe.bank.common.entity.department.SysDepartmentAudit;

/**
* @Description:部门管理审批
* @author: zhaohaixia
* @date: 2020年9月27日 下午2:38:17
 */
@Mapper
public interface SysDepartmentAuditMapper {

    int deleteByPrimaryKey(Integer id);

    int insertSelective(SysDepartmentAudit record);

    SysDepartmentAudit selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SysDepartmentAudit record);
    /**
    * @Description:根据部门id获取部门审批权限
    * @param intValue
    * @return
    * @author: zhaohaixia
    * @date: 2020年9月28日 下午6:35:40
     */
	SysDepartmentAudit getAudit(@Param("departmentId") Integer departmentId);
	/**
	* @Description:删除部门审批权限信息
	* @param id
	* @return
	* @author: zhaohaixia
	* @date: 2020年9月29日 下午5:10:15
	 */
	int deleteByDepartId(@Param("departmentId") Integer departmentId);
	/**
	* @Description:获取部门分页列表
	* @param bean
	* @return
	* @author: zhaohaixia
	* @date: 2020年10月10日 下午4:03:25
	 */
	List<DepartmentListBean> getList(DepartmentConBean bean);
	/**
	* @Description:部门批量删除
	* @param ids
	* @return
	* @author: zhaohaixia
	* @date: 2020年11月2日 下午3:56:43
	 */
	int deleteByIds(@Param("ids")List<Long> ids);

}
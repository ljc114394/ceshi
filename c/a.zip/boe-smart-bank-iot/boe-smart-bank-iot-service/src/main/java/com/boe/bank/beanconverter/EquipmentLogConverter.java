package com.boe.bank.beanconverter;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.boe.bank.common.entity.equipment.EquipmentLog;
import com.boe.bank.common.entity.equipment.EquipmentLogExportResultBean;
import com.boe.bank.common.entity.equipment.EquipmentLogResultBean;

/**
 * 设备日志类转换器
 *
 * @author 10085188
 * @date 2020/11/06
 */
@Mapper
public interface EquipmentLogConverter {

	EquipmentLogConverter INSTANCE = Mappers.getMapper(EquipmentLogConverter.class);

    /**
     * entity转为vo
     * @param entity
     * @return
     */
    EquipmentLogResultBean entityToVo(EquipmentLog entity);
    
    /**
     * entity转为vo
     * @param entity
     * @return
     */
    @Mappings({
    	@Mapping(target = "level", expression = "java(com.boe.bank.common.constant.logEnum.getName(entity.getLevel()))"),
    })
    EquipmentLogExportResultBean entityToExportVo(EquipmentLog entity);
}

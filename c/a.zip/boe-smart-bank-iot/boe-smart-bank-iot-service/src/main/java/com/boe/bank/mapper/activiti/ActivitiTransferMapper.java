package com.boe.bank.mapper.activiti;

import com.boe.bank.common.bean.activiti.ActivitiExamineQueryBean;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.entity.activiti.ActivitiTransfer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 审批类型
 * @author caoxuhao
 */
@Mapper
public interface ActivitiTransferMapper {

    int insertSelective(ActivitiTransfer activitiTransfer);

    List<ActivitiTransfer> getList(String PROC_INST_ID_, Long fromUserId);
    
}

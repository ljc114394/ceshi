package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentOperateLog;

/**
 * 设备操作日志 Mapper
 *
 * @author 10183279
 * @date 2020/10/28
 */
public interface EquipmentOperateLogMapper extends BaseMapper<EquipmentOperateLog> {

}

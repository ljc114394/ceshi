package com.boe.bank.service.activitiService.org;

import java.util.List;

import com.boe.bank.common.bean.activiti.UserTaskBo;

/**
 * activiti 流程相关功能
 * 部署, 开始, 停用， 恢复，查询
 * @author caoxuhao
 */
public interface ActivitiProcessOrgService {

	/**
	 * 部署项目
	 * @param category	类别（素材，设备...）
	 * @param PROCESS_NAME	项目名
	 * @param modelList
	 * @return
	 */
	public String deploy(String category, String PROCESS_NAME, List<UserTaskBo> modelList);

	/**
	 * 开始流程
	 * @param processDefinitionId
	 * @param userId      创建人
	 * @param modelList
	 * @return
	 */
	public String start(String processDefinitionId, String userId, List<UserTaskBo> modelList);

	/**
	 * 挂起已经部署的流程
	 * @return
	 */
	public boolean suspendProcess(String processDefinitionId);

	/**
	 * 恢复被挂起的流程
	 * @return
	 */
	public boolean activateProcess(String processDefinitionId);

	/**
	 * 删除整个流程
	 * @return
	 */
	public boolean deleteDeployment(String deploymentId);

	/**
	 * 是否有正在运行的流程
	 * @param processDefinitionId
	 * @return
	 */
	public boolean hasRunningTask(String processDefinitionId);

}

package com.boe.bank.service.activitiService.base;

import java.util.List;

import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.ActivitiProcessOrgDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessQueryReqExtBo;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;

/**
 * activiti和外部表关联关系
 * @author caoxuhao
 */
public interface ActivitiOuterRelationService {

	public boolean insert(ActivitiOuterRelation activitiOuterRelation);

	public boolean deleteById(Integer id);

	public List<ActivitiOuterRelation> getList(Integer busniessType, List<Integer> outerIds);

	public ActivitiOuterRelation getByBusniessTypeAndOuterId(Integer busniessType, Integer outerId, Integer outerType);

	public ActivitiOuterRelation getByProcessInstanceId(String processInstanceId);

	public ActivitiOuterRelation getByBusniessTypeAndProcessInstanceId(Integer busniessType, String processInstanceId);

	public List<ActivitiOuterRelation> getAllByBusniessTypeAndUserId(Long userId, Integer busniessType);

	/**
     * 我审批的
     * @return
     */
	public PageInfoDto<ActivitiProcessOrgDo> getExaminedProcessList(ActivitiProcessQueryReqExtBo req);

	/**
     * 我提交的
     * @return
     */
	public PageInfoDto<ActivitiProcessOrgDo> getMyProcessList(ActivitiProcessQueryReqExtBo req);

	/**
     * 待我审批
     * @return
     */
	public PageInfoDto<ActivitiProcessOrgDo> getTodoProcessList(ActivitiProcessQueryReqExtBo req);

	/**
     * 待我审批的数量
     * @param busniessType
     * @param userId
     * @return
     */
	public Integer getTodoCount(Integer busniessType, Long userId);

	/**
     * 我审批的数量
     * @param busniessType
     * @param userId
     * @return
     */
	public Integer getExaminedCount(Integer busniessType, Long userId);


	/**
	 * 废弃工作流
	 * @param busniessType		业务类型
	 * @param outerId			各业务的主建id
	 * @param outerType			只有应用要传
	 * @return
	 */
	public boolean abandon(Integer busniessType, Integer outerId, Integer outerType);
}

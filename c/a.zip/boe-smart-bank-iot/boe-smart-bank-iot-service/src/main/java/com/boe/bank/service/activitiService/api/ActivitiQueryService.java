package com.boe.bank.service.activitiService.api;

import java.util.List;
import java.util.Map;

/**
 * 给其他模块用的查询服务
 * @author caoxuhao
 */
public interface ActivitiQueryService {

	/**
	 * 获取审核结果列表
	 * @param busniessType	业务类型，用枚举ActivityConstants.BusniessType
	 * @param outerIds		需要获取审核结果的外部表id列表
	 * @return key:外部表主键outerId, value:审核结果ActivityConstants.ExamineType
	 */
	public Map<Integer, Integer> getExamineResultList(Integer busniessType, List<Integer> outerIds);

}

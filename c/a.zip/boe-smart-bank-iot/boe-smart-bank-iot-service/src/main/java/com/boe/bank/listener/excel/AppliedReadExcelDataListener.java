package com.boe.bank.listener.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSON;
import com.boe.bank.mapper.appliedbizmanege.AppliedBizManegeMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;

@Component
public class AppliedReadExcelDataListener extends AnalysisEventListener<Map<Integer, String>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppliedReadExcelDataListener.class);
    /**
     * 每隔5条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 1;
    List<Map<Integer, String>> list = new ArrayList<Map<Integer, String>>();

    //表名字
    private String tableName;
    public String getTableName() {
        return tableName;
    }
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    //表字段数组
    List<String> columnlist = new ArrayList<String>();

    //导入mapper
    private AppliedBizManegeMapper appliedBizManegeMapper;

    public AppliedReadExcelDataListener(List columnlist, AppliedBizManegeMapper appliedBizManegeMapper){
        this.columnlist = columnlist;
        this.appliedBizManegeMapper = appliedBizManegeMapper;
    }

    @Override
    public void invoke(Map<Integer, String> data, AnalysisContext context) {
        LOGGER.info("解析到一条数据:{}", JSON.toJSONString(data));
        list.add(data);
        if (list.size() >= BATCH_COUNT) {
            saveData();
            list.clear();
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        saveData();
        LOGGER.info("所有数据解析完成！");
    }

    /**
     * 加上存储数据库
     */
    private void saveData() {
        if (list != null && !list.isEmpty()) {
            //解析出来的数据然后拼接上创建人创建时间
            List datas = new ArrayList();
            Map data = list.get(0);
            for (Object value : data.values()) {
                datas.add(value);
            }
            datas.add(UserInfo.getCurrentUserInfo().getId());
            datas.add(UserInfo.getCurrentUserInfo().getName());
            datas.add(LocalDateTime.now());

            Map<String, Object> paramap = new HashMap<>();
            for (int i = 0; i < columnlist.size(); i++) {
                paramap.put(columnlist.get(i), datas.get(i));
            }
            String[] keys = new String[paramap.size()];
            Set<String> sset = paramap.keySet();
            int i = 0;
            for (String os : sset) {
                keys[i++] = os;
            }
            Map mapsum = new HashMap<>();
            mapsum.put("tablename", tableName);
            mapsum.put("keys", keys);
            mapsum.put("params", paramap);

            appliedBizManegeMapper.insertInfoByExcelData(mapsum);
            LOGGER.info("存储数据库成功！");

        }
    }
}

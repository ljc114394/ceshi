package com.boe.bank.mapper.productlibraryMapper;

import com.boe.bank.common.bean.productlibrarybean.MarketingPortraitBean;
import com.boe.bank.common.bean.productlibrarybean.ProductLibrarySearchBean;
import com.boe.bank.common.bean.productlibrarybean.ProductLibrarySearchExportBean;
import com.boe.bank.common.entity.productlibrary.ProductLibrary;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Description:产品库
 * @author: lvjiacheng
 * @date: 2020年10月21日 15:23
 */
@Mapper
public interface ProductLibraryMapper {


    int insertProductLibrary(ProductLibrary productLibrarya);

    int updateProductLibrary(ProductLibrary productLibrary);

    List<ProductLibrary> getProductLibraryList(ProductLibrarySearchBean productLibrary);

    List<ProductLibrary> getProductLibraryExportList(ProductLibrarySearchExportBean productLibrary);

    int updateProductLibraryDel(String[] id);

    ProductLibrary getProductLibraryById(Integer id);

    List<ProductLibrary> queryProductByPortraitId(Integer portraitId);

    List<ProductLibrary> getMarketingStrategyList(ProductLibrarySearchBean marketingStrategy);

    List<ProductLibrary> getMarketingStrategyExportList(ProductLibrarySearchExportBean marketingStrategy);


    List<MarketingPortraitBean> getMarketingPortraitBeanById(Integer id);

    int deleteMarketingPortrait(Integer id);


    int insertMarketingPortrait(@Param("productId") Integer productId,@Param("createBy") String createBy,@Param("createTime") LocalDateTime createTime,@Param("createUserId") Integer createUserId,@Param("portraitIds") List<Integer> portraitIds);

    int findMarketingPortraitCountByProudctId(String[] id);

    Integer marketingPortraitDelete(String[] id);

    Integer productByportraitId(Integer id);

}

package com.boe.bank.service.activitiService.api.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.alibaba.fastjson.JSON;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.activiti.ActivitiExamineSaveBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessInsertBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessUpdateBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessUpdateVo;
import com.boe.bank.common.bean.activiti.ActivitiUserTaskDto;
import com.boe.bank.common.bean.activiti.UserTaskBo;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.entity.activiti.ActivitiProcess;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.service.activitiService.api.ActivitiManageService;
import com.boe.bank.service.activitiService.base.ActivitiExamineService;
import com.boe.bank.service.activitiService.base.ActivitiProcessService;
import com.boe.bank.service.activitiService.base.ActivitiWebService;
import com.boe.bank.service.activitiService.org.ActivitiProcessOrgService;

import lombok.extern.slf4j.Slf4j;

/**
 * 审批流管理Service
 * 
 * @author caoxuhao
 */
@Service
@Slf4j
public class ActivitiManageServiceImpl implements ActivitiManageService {

	@Autowired
	private ActivitiProcessService activitiProcessService;

	@Autowired
	private ActivitiProcessOrgService activitiProcessOrgService;

	@Autowired
	private ActivitiWebService activitiWebService;
	
	@Autowired
	private ActivitiExamineService activitiExamineService;
	
	/********************************************************************************************************************
	 * 审批流
	 ********************************************************************************************************************/

	/**
	 * 创建审批流程
	 * 
	 * @param activitiProcessInsertBean
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> insertActivitiProcess(ActivitiProcessInsertBean activitiProcessInsertBean) {
		
		Integer examineId = activitiProcessInsertBean.getExamineId();
		
		ActivitiProcess old = activitiProcessService.getByExamineId(examineId);
		if(old != null)
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_ALREADY_RELATED);
		
		// 创建审批流程
		Integer activitiProcessId = activitiProcessService.insert(activitiProcessInsertBean);
		if (activitiProcessId == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_INSERT_ERROR);

		// 转化自己的节点描述为activiti节点描述
		List<UserTaskBo> modelList = activitiWebService
				.convertActivitiUserTaskDto2UserTaskBo(activitiProcessInsertBean.getList());
		
		// activiti中创建审批流程
		String processDefinitionId = activitiProcessOrgService.deploy(activitiProcessInsertBean.getBusniessType().toString(),
				activitiProcessInsertBean.getProcessName(), modelList);
		
		ActivitiProcess activitiProcess = new ActivitiProcess();
		activitiProcess.setId(activitiProcessId);
		activitiProcess.setProcdefId(processDefinitionId);
		if(activitiProcessService.updateById(activitiProcess))
			return Result.success();
		else
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_UPDATE_ERROR);
	}
	
	/**
	 * 删除审批流
	 * @param activitiProcessId activitiProcess表的id
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> deleteActivitiProcess(int activitiProcessId){
		
		ActivitiProcess activitiProcess = activitiProcessService.load(activitiProcessId);
		if(activitiProcess == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_EXIST);
		
		String procdefId = activitiProcess.getProcdefId();
		// 检查未审批完的流
		if(activitiProcessOrgService.hasRunningTask(procdefId))
			return Result.failure(MsgReturnEnum.ACTIVITI_TASK_IS_RUNNING_ERROR);
		
		//删activiti的部署
		if(!activitiProcessOrgService.deleteDeployment(procdefId))
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_DELETE_ERROR);
		
		activitiProcessService.deleteById(activitiProcessId);
		return Result.success();
	}
	
	/**
	 * 停用审批流
	 * @param activitiProcessId
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> suspendActivitiProcess(int activitiProcessId){
		
		ActivitiProcess activitiProcess = activitiProcessService.load(activitiProcessId);
		if(activitiProcess == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_EXIST);

		Integer oldStatus = activitiProcess.getStatus();
		if(oldStatus != null && oldStatus == ActivitiConstants.Status.suspend){
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND);
		}
		
		String procdefId = activitiProcess.getProcdefId();
		
		// 检查未审批完的流
		if(activitiProcessOrgService.hasRunningTask(procdefId))
			return Result.failure(MsgReturnEnum.ACTIVITI_TASK_IS_RUNNING_ERROR);
		
		//停用activiti的工作流
		if(!activitiProcessOrgService.suspendProcess(procdefId))
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_SUSPEND_ERROR);
		
		//同步更新activiti Process表
		ActivitiProcess tmp = new ActivitiProcess();
		tmp.setId(activitiProcessId);
		tmp.setStatus(ActivitiConstants.Status.suspend);
		if(!activitiProcessService.updateById(tmp))
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_UPDATE_ERROR);
		
		return Result.success();
	}

	/**
	 * 恢复审批流
	 * @param activitiProcessId
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> activeActivitiProcess(int activitiProcessId){
		
		ActivitiProcess activitiProcess = activitiProcessService.load(activitiProcessId);
		if(activitiProcess == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_EXIST);

		Integer oldStatus = activitiProcess.getStatus();
		if(oldStatus != null && oldStatus == ActivitiConstants.Status.ok){
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_ACTIVE);
		}
		
		String procdefId = activitiProcess.getProcdefId();
		
		//启用activiti的工作流
		if(!activitiProcessOrgService.activateProcess(procdefId))
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_ACTIVE_ERROR);
		
		//同步更新activiti Process表
		ActivitiProcess tmp = new ActivitiProcess();
		tmp.setId(activitiProcessId);
		tmp.setStatus(ActivitiConstants.Status.ok);
		if(!activitiProcessService.updateById(tmp))
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_UPDATE_ERROR);
		
		return Result.success();
	}
	
	/**
	 * 查看审批流
	 * @param activitiProcessId
	 * @return
	 */
	@Override
	public ActivitiProcessUpdateVo getActivitiProcess(int activitiProcessId){
		
		ActivitiProcess activitiProcess = activitiProcessService.load(activitiProcessId);
		if(activitiProcess == null)
			return null;
		
		Integer examineId = activitiProcess.getExamineId();
		ActivitiExamine examine = activitiExamineService.load(examineId);
		if(examine == null)
			return null;
		
		Integer processId = activitiProcess.getId();
		String processName = activitiProcess.getName();
		Integer busniessType = examine.getBusniessType();
		String examineType = examine.getExamineType();
		String resourceData = activitiProcess.getResourceData();
		List<ActivitiUserTaskDto> list = JSON.parseArray(resourceData, ActivitiUserTaskDto.class);
		
		ActivitiProcessUpdateVo activitiProcessUpdateBean = new ActivitiProcessUpdateVo();
		activitiProcessUpdateBean.setExamineId(examineId);
		activitiProcessUpdateBean.setBusniessType(busniessType);
		activitiProcessUpdateBean.setExamineType(examineType);
		activitiProcessUpdateBean.setProcessName(processName);
		activitiProcessUpdateBean.setProcessId(processId);
		activitiProcessUpdateBean.setList(list);
		
		return activitiProcessUpdateBean;
	}
	
	/**
	 * 更新审批流
	 * @param activitiProcessUpdateBean
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> updateActivitiProcess(ActivitiProcessUpdateBean activitiProcessUpdateBean) {
		
		Integer processId = activitiProcessUpdateBean.getProcessId();
		
		ActivitiProcess activitiProcess = activitiProcessService.load(processId);
		if(activitiProcess == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_EXIST);
		
		String procdefId = activitiProcess.getProcdefId();
		
		// 1.检查是否已经停用
		if(activitiProcess.getStatus() == ActivitiConstants.Status.ok)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_SUSPEND);

		Integer oldExamineId = activitiProcess.getExamineId();
		Integer thisExamineId = activitiProcessUpdateBean.getExamineId();
		if(thisExamineId != null && !thisExamineId.equals(oldExamineId)){
			//新改的examinId如果已经存在，则报错
			ActivitiProcess old = activitiProcessService.getByExamineId(thisExamineId);
			if(old != null)
				return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_ALREADY_RELATED);
		}

		// 2.删activiti的部署(如果还有正在执行的审批，没有结束，不能删除已经部署的任务)
//		if(!activitiProcessOrgService.deleteDeployment(procdefId))
//			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_DELETE_ERROR);
		
		// 3.新建activiti审批流
		List<ActivitiUserTaskDto> list = activitiProcessUpdateBean.getList();
		List<UserTaskBo> modelList = activitiWebService.convertActivitiUserTaskDto2UserTaskBo(list);
		
		String processDefinitionId = activitiProcessOrgService.deploy(activitiProcessUpdateBean.getBusniessType().toString(),
				activitiProcessUpdateBean.getProcessName(), modelList);

		//停用新建的流程，跟原来状态保持一致
		activitiProcessOrgService.suspendProcess(processDefinitionId);
		
		// 4.更新activitiProcess表
		ActivitiProcess update = new ActivitiProcess();
		update.setId(processId);
		update.setProcdefId(processDefinitionId);
		update.setUpdateBy(activitiProcessUpdateBean.getUpdateBy());
		update.setUpdateTime(DateUtil.current());
		update.setName(activitiProcessUpdateBean.getProcessName());
		update.setResourceData(JSON.toJSONString(list));
		update.setExamineId(activitiProcessUpdateBean.getExamineId());
		if(!activitiProcessService.updateById(update)) {
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_UPDATE_ERROR);
		}
		
		return Result.success();
	}
	
	/********************************************************************************************************************
	 * 审批类型
	 ********************************************************************************************************************/
	/**
	 * 创建审批类型
	 * 
	 * @param examineSaveBean
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> insertActivitiExamine(ActivitiExamineSaveBean examineSaveBean) {
		
		Integer busniessType = examineSaveBean.getBusniessType();
		String examineType = examineSaveBean.getExamineType();
		
		//不能重复创建
		if(checkDuplicate(busniessType, examineType, true))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_DUPLICATE_ERROR);
		
		//插入审批类型表
		ActivitiExamine activitiExamine = new ActivitiExamine();
		BeanUtils.copyProperties(examineSaveBean, activitiExamine);
		
		if(!activitiExamineService.insert(activitiExamine))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_INSERT_ERROR);
			
		return Result.success();
	}
	
	private boolean checkDuplicate(Integer busniessType, String examineType, boolean isInsert) {
		
		int count = 0;
		
		switch (busniessType) {
		case ActivitiConstants.BusniessType.device:
		case ActivitiConstants.BusniessType.plan:
			count = activitiExamineService.checkDuplicate(busniessType, null);
			break;
		case ActivitiConstants.BusniessType.material:
			count = activitiExamineService.checkDuplicate(busniessType, examineType);
			break;
		default:
			break;
		}
		
		if(isInsert) {
			return count > 0;
		}else {
			//update 排除自己本身
			return count > 1;
		}
			
	}
	
	/**
	 * 更新审批类型
	 * @param examineSaveBean
	 * @return
	 */
	@Override
	public Result<?> updateActivitiExamine(ActivitiExamineSaveBean examineSaveBean) {
		
		Integer examineId = examineSaveBean.getId();
		Integer busniessType = examineSaveBean.getBusniessType();
		String examineType = examineSaveBean.getExamineType();
		
		// 不能重复创建
		if(checkDuplicate(busniessType, examineType, false))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_DUPLICATE_ERROR);
		
		// 检查关联的审批流停用状态
		ActivitiProcess activitiProcess = activitiProcessService.getByExamineId(examineId);
		if(activitiProcess != null && activitiProcess.getStatus().intValue() == ActivitiConstants.Status.ok) {
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_IS_RUNNING_ERROR);
		}
		
		//更新审批类型表
		ActivitiExamine activitiExamine = new ActivitiExamine();
		activitiExamine.setId(examineId);
		activitiExamine.setBusniessType(busniessType);
		activitiExamine.setExamineType(examineType);
		activitiExamine.setStatus(examineSaveBean.getStatus());
		activitiExamine.setUpdateBy(examineSaveBean.getCreateBy());
		
		if(!activitiExamineService.updateById(activitiExamine))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_UPDATE_ERROR);
			
		return Result.success();
	}
	
	/**
	 * 删除审批类型
	 * @param id
	 * @return
	 */
	@Override
	public Result<?> deleteActivitiExamine(int id) {
		
		// 检查关联的审批流停用状态
		ActivitiProcess activitiProcess = activitiProcessService.getByExamineId(id);
		if(activitiProcess != null && activitiProcess.getStatus().intValue() == ActivitiConstants.Status.ok) {
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_IS_RUNNING_ERROR);
		}
		
		// 删除
		if(!activitiExamineService.deleteById(id))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_DELETE_ERROR);
			
		return Result.success();
	}
	
	/**
	 * 停用审批类型
	 * @param id
	 * @return
	 */
	@Override
	public Result<?> suspendActivitiExamine(int id) {
		
		// 检查关联的审批流停用状态
		ActivitiProcess activitiProcess = activitiProcessService.getByExamineId(id);
		if(activitiProcess != null && activitiProcess.getStatus().intValue() == ActivitiConstants.Status.ok) {
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_IS_RUNNING_ERROR);
		}
		
		//更新审批类型表
		ActivitiExamine activitiExamine = new ActivitiExamine();
		activitiExamine.setId(id);
		activitiExamine.setStatus(ActivitiConstants.Status.suspend);
				
		if(!activitiExamineService.updateById(activitiExamine))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_UPDATE_ERROR);
			
		return Result.success();
	}
	
	/**
	 * 启用审批类型
	 * @param id
	 * @return
	 */
	@Override
	public Result<?> activeActivitiExamine(int id) {
		
		//更新审批类型表
		ActivitiExamine activitiExamine = new ActivitiExamine();
		activitiExamine.setId(id);
		activitiExamine.setStatus(ActivitiConstants.Status.ok);
		
		if(!activitiExamineService.updateById(activitiExamine))
			return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_UPDATE_ERROR);
		
		return Result.success();
	}
	
}

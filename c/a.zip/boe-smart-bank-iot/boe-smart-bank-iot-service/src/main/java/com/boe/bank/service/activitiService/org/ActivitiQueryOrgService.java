package com.boe.bank.service.activitiService.org;

import java.util.List;

import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.*;

/**
 * activiti 查询的相关功能
 * @author caoxuhao
 */
public interface ActivitiQueryOrgService {

	/**
	 * 我提交的
	 */
	public PageInfoDto<ActivitiProcessOrgVo> mySubmit(ActivitiProcessQueryReqExtBo req);

	/**
	 * 我审批的已处理的
	 */
	public PageInfoDto<ActivitiProcessOrgVo> myExamined(ActivitiProcessQueryReqExtBo req);

	/**
	 * 待我审批的
	 */
	public PageInfoDto<ActivitiProcessOrgVo> myToDo(ActivitiProcessQueryReqExtBo ext);

	/**
	 * 审批流的每步审批详情
	 * @param processInstanceId
	 * @return
	 */
	public List<ActivitiDetailVo> detail(String processInstanceId);

	
}

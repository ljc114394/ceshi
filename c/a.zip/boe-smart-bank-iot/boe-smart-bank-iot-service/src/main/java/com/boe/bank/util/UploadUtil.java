package com.boe.bank.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
/**
* @Description:保存文件工具类
* @author: zhaohaixia
* @date: 2020年10月14日 下午4:26:43
 */
@Slf4j
public class UploadUtil {
	
	public static boolean saveMaterialFile(MultipartFile pic,String dirPath,String fileName) {
		log.info("=======saveMaterialFile======上传原始文件到服务器开始======");
		log.info("====文件上传的路径为：======" + dirPath + "/" +fileName);
		// 创建图片文件
		File destOrigin = new File(dirPath + "/" +fileName);
		// 检测是否存在目录
		if (!destOrigin.getParentFile().exists()) {
			destOrigin.getParentFile().mkdirs();
		}
		try {
			// 上传文件
			pic.transferTo(destOrigin);
			log.info("=======saveMaterialFile======上传原始文件到服务器结束======");
			return true;
		} catch (Exception e) {
			log.error("保存文件时发生异常：{}",ExceptionUtils.getMessage(e.fillInStackTrace()));
			return false;
		} 
		
	}
    //将MultipartFile 转换为File
    public static void SaveFileFromInputStream(InputStream stream,String path,String savefile) throws IOException
       {      
           FileOutputStream fs=new FileOutputStream( path + "/"+ savefile);
           System.out.println("------------"+path + "/"+ savefile);
           byte[] buffer =new byte[1024*1024];
           int bytesum = 0;
           int byteread = 0; 
           while ((byteread=stream.read(buffer))!=-1)
           {
              bytesum+=byteread;
              fs.write(buffer,0,byteread);
              fs.flush();
           } 
           fs.close();
           stream.close();      
       }       
    
}

package com.boe.bank.service.activitiService.api;

import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.activiti.ActivitiExamineSaveBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessInsertBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessUpdateBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessUpdateVo;

/**
 * activiti用户操作的相关功能
 * @author caoxuhao
 */
public interface ActivitiManageService {

	/**
	 * 创建审批流程
	 * @param activitiProcessInsertBean
	 * @return
	 */
	public Result<?> insertActivitiProcess(ActivitiProcessInsertBean activitiProcessInsertBean);

	/**
	 * 删除审批流
	 * @param activitiProcessId activitiProcess表的id
	 * @return
	 */
	public Result<?> deleteActivitiProcess(int activitiProcessId);

	/**
	 * 停用审批流
	 * @param activitiProcessId
	 * @return
	 */
	public Result<?> suspendActivitiProcess(int activitiProcessId);

	/**
	 * 恢复审批流
	 * @param activitiProcessId
	 * @return
	 */
	public Result<?> activeActivitiProcess(int activitiProcessId);

	/**
	 * 查看审批流
	 * @param activitiProcessId
	 * @return
	 */
	public ActivitiProcessUpdateVo getActivitiProcess(int activitiProcessId);

	/**
	 * 更新审批流
	 * @param activitiProcessUpdateBean
	 * @return
	 */
	public Result<?> updateActivitiProcess(ActivitiProcessUpdateBean activitiProcessUpdateBean);

	/**
	 * 创建审批类型
	 * 
	 * @param examineSaveBean
	 * @return
	 */
	public Result<?> insertActivitiExamine(ActivitiExamineSaveBean examineSaveBean);

	/**
	 * 更新审批类型
	 * @param examineSaveBean
	 * @return
	 */
	public Result<?> updateActivitiExamine(ActivitiExamineSaveBean examineSaveBean);

	/**
	 * 删除审批类型
	 * @param id
	 * @return
	 */
	public Result<?> deleteActivitiExamine(int id);

	/**
	 * 停用审批类型
	 * @param id
	 * @return
	 */
	public Result<?> suspendActivitiExamine(int id);

	/**
	 * 启用审批类型
	 * @param id
	 * @return
	 */
	public Result<?> activeActivitiExamine(int id);
	
	
}

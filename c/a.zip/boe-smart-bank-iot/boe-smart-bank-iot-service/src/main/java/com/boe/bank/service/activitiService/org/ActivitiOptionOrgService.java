package com.boe.bank.service.activitiService.org;

import java.util.List;

import org.activiti.engine.task.Task;

/**
 * activiti用户操作的相关功能
 * @author caoxuhao
 */
public interface ActivitiOptionOrgService {

	public boolean pass(Task task, String reviewer);

	public boolean fail(Task task, String reviewer, String comment);

	/**
	 * 如果是分给各个部门的任务。则其中一个部门拒绝，其他所有部门自动结束任务。
	 * @param task	目前处理的task
	 * @return
	 */
	public List<String> getUsersForCloseOtherDepTask(Task task);

	public boolean doCloseOtherDepTask(String processInstanceId, List<String> assigneeListIds);

	/** 
     * 获取task
     * @param processInstanceId 
     * @param reviewer 
     */
	public Task getTask(String processInstanceId, String reviewer);

	/** 
     * 转办流程 
     * @param task  当前任务
     * @param targetUserId  目标用户
     */
	public boolean transferAssignee(Task task, String targetUserId);

	/** 
     * 废弃流程
     * @param taskId 
     */
	public void abandon(String taskId);

	Task getTaskByTaskId(String taskId, String reviewer);

	/**
     * 获取taskList
     * @param processInstanceId 
     */
	public List<Task> getTaskList(String processInstanceId);

	

	

}

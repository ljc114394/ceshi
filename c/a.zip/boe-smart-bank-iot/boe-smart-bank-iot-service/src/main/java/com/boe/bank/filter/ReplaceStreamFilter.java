//package com.boe.bank.filter;
//
//
//import com.boe.bank.configurer.RequestWrapper;
//import lombok.extern.slf4j.Slf4j;
//
//import javax.servlet.*;
//import javax.servlet.http.HttpServletRequest;
//import java.io.IOException;
//
///**
// * @author lvjiacheng
// * @program
// * @description 替换HttpServletRequest
//
// * @create 2020-10-19 10:20
// * @version  1.0
// **/
//@Slf4j
//public class ReplaceStreamFilter implements Filter {
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//        log.info("StreamFilter初始化...");
//    }
//
//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//        ServletRequest requestWrapper = new RequestWrapper((HttpServletRequest) request);
//        chain.doFilter(requestWrapper, response);
//    }
//
//    @Override
//    public void destroy() {
//        log.info("StreamFilter销毁...");
//    }
//}
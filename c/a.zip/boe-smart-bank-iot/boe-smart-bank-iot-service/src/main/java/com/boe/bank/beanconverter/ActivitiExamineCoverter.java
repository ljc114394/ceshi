package com.boe.bank.beanconverter;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.boe.bank.common.bean.material.ActivitiExamineBean;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
/**
* @Description:审批类型
* @author: zhaohaixia
* @date: 2020年10月22日 下午2:47:10
 */
@Mapper(componentModel = "spring")
public interface ActivitiExamineCoverter {

    @Mappings({
            @Mapping(source = "examineType", target = "title")
    })
    ActivitiExamineBean getExamineBean(ActivitiExamine examinte);

    List<ActivitiExamineBean> getExamineListBean(List<ActivitiExamine> list);

}

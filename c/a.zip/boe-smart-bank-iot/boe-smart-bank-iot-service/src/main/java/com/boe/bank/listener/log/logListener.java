package com.boe.bank.listener.log;

import com.boe.bank.common.bean.logbean.LogSaveBean;
import com.boe.bank.service.logService.LogService;
import com.boe.cloud.megarock.security.common.UserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 日志监听事件event
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 15:13
 */
@Component
@Slf4j
public class logListener implements ApplicationListener<LogSaveBean> {


    @Autowired
    private LogService log2;
    /**
     * 日志-获取事件
     * @param event
     */
    @Override
    @Async("logTaskExecutor")
    public void onApplicationEvent(LogSaveBean event) {
        log.info("日志-监听-开始 event:{}",event);
        try {
            //Thread.sleep(2000);
            if(event.getModuleType() ==5){//审批
                log2.approvalInfo(event);
            }else{
                log2.info(event);

            }
        } catch (Exception e) {
            log.error("日志-监听-异常 event:{}error:{}",event, ExceptionUtils.getMessage(e.fillInStackTrace()));
        }
        log.info("日志-监听-结束 event:{}",event);
    }


}

package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.equipment.EquipmentSpotsVO;
import com.boe.bank.common.entity.equipment.EquipmentSpots;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 设备相关类转换器
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Mapper
public interface EquipmentSpotsConverter {

    EquipmentSpotsConverter INSTANCE = Mappers.getMapper(EquipmentSpotsConverter.class);

    /**
     * entity转为vo
     * @param entity
     * @return
     */
    @Mappings({
            @Mapping(source = "beginTime", target = "beginTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "endTime", target = "endTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "createTime", target = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    EquipmentSpotsVO entityToVo(EquipmentSpots entity);

    List<EquipmentSpotsVO> entityListToVoList(List<EquipmentSpots> entityList);
}

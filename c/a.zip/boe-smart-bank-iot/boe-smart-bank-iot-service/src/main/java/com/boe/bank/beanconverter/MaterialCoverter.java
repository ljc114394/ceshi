package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.areabean.AreaInfoBean;
import com.boe.bank.common.entity.area.Area;
import org.mapstruct.Mapper;

import com.boe.bank.common.bean.material.FolderBean;
import com.boe.bank.common.bean.material.MaterialBean;
import com.boe.bank.common.entity.material.MaterialManage;

import java.util.List;

/**
* @Description:素材管理
* @author: zhaohaixia
* @date: 2020年10月14日 上午10:49:38
 */
@Mapper(componentModel = "spring")
public interface MaterialCoverter {

	MaterialManage getMaterial(MaterialBean bean);
    
	MaterialManage getMaterialFolder(FolderBean bean);

	List<MaterialManage> getMaterialsInfoList(List<MaterialBean> materialBeans);
}

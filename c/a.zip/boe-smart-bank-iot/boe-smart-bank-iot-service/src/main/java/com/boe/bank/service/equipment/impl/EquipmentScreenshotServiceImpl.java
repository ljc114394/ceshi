package com.boe.bank.service.equipment.impl;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.boe.bank.common.entity.equipment.EquipmentScreenshot;
import com.boe.bank.mapper.equipment.EquipmentScreenshotMapper;
import com.boe.bank.service.equipment.EquipmentScreenshotService;
import com.boe.cloud.megarock.security.common.UserInfo;

/**
 * 设备截图 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/30
 */
@Service("equipmentScreenshotService")
public class EquipmentScreenshotServiceImpl extends ServiceImpl<EquipmentScreenshotMapper, EquipmentScreenshot> implements EquipmentScreenshotService {

    @Override
    public EquipmentScreenshot getOne(String mac, String updateTime) {
        return ChainWrappers.lambdaQueryChain(getBaseMapper())
                .eq(EquipmentScreenshot::getMac, mac)
                .gt(EquipmentScreenshot::getUpdateTime, updateTime)
                .one();
    }

	@Override
	public boolean save(String mac, String picUrl) {
		UserInfo userInfo = UserInfo.getCurrentUserInfo();
		EquipmentScreenshot screenshot = new EquipmentScreenshot();
		screenshot.setMac(mac);
		screenshot.setUrl(picUrl);
		if (userInfo != null) {
			screenshot.setCreateUserId(userInfo.getId());
			screenshot.setCreateBy(userInfo.getUsername());
		}
		screenshot.setCreateTime(LocalDateTime.now());
        return getBaseMapper().insert(screenshot) > 0;
	}
}

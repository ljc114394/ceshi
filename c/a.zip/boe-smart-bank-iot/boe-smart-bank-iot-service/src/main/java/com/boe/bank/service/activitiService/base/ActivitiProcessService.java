package com.boe.bank.service.activitiService.base;

import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.ActivitiProcessDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessInsertBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessQueryBean;
import com.boe.bank.common.entity.activiti.ActivitiProcess;

/**
 * 审核流程基础service
 * @author caoxuhao
 */
public interface ActivitiProcessService {

	/**
	 * 创建审批流程
	 * @param activitiProcessInsertBean
	 * @return
	 */
	public Integer insert(ActivitiProcessInsertBean activitiProcessInsertBean);

	/**
	 * 创建审批流程
	 * @param activitiProcess
	 * @return
	 */
	public boolean updateById(ActivitiProcess activitiProcess);

	public ActivitiProcess load(int id);

	public boolean deleteById(int id);

	/**
	 * 分页查询审批流
	 * @param activitiProcessQueryBean
	 * @return
	 */
	public PageInfoDto<ActivitiProcessDo> getList(ActivitiProcessQueryBean activitiProcessQueryBean);

	public ActivitiProcess getByExamineId(Integer examineId);

	public ActivitiProcess getByProcdefId(String processDefinitionId);

	/**
	 * 给设备和计划，只有唯一的流程的busniessType查询
	 * @param busniessType
	 * @return
	 */
	public ActivitiProcess getByBusniessType(Integer busniessType);
}

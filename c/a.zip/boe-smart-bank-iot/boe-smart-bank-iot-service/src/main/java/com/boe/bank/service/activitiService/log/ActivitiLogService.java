package com.boe.bank.service.activitiService.log;

import java.util.HashMap;
import java.util.Map;

import com.boe.bank.common.constant.logEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.boe.bank.common.bean.logbean.LogSaveBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;
import com.boe.bank.service.activitiService.base.ActivitiExamineService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.cloud.megarock.security.common.UserInfo;

@Component
public class ActivitiLogService {

	@Autowired
    private ApplicationEventPublisher log2;
	
	@Autowired
	private ActivitiOuterRelationService activitiOuterRelationService;
	
	@Autowired
	private ActivitiExamineService activitiExamineService;
	
	private final int BUSNIESS_TYPE = 1;
	private final int APPROVAL_TYPE = 2;
	
	/**
	 *  审批log
	 * moduleType=5代表审批
	 * busniessType=业务类型-a21素材a22计划a23设备    
	 * approvalNo审批单号      
	 * approvalType审批类型   
	 * operationContent操作内容-(如审批计划通过)  
	 * approvalResult=审批结果-a11待处理a12/同意a13/拒绝    
	 * userInfo和createUserId为用户信息
	 */
	public void info(String processInstanceId, boolean agree) {
		
		Map<Integer, String> map = getProcessInstanceInfo(processInstanceId);
		String busniessType = map.get(BUSNIESS_TYPE);
		String approvalType = map.get(APPROVAL_TYPE);
		
		if(StringUtils.isEmpty(busniessType) || StringUtils.isEmpty(approvalType))//可能刚处理完审批逻辑，就废弃了。
			return;
		
		String approvalResult = null;
		String operationContent = null;
		if(agree) {
			operationContent = "审批计划通过";
			approvalResult = "a12";
		}else {
			operationContent = "审批计划拒绝";
			approvalResult = "a13";
		}
		
		log2.publishEvent(LogSaveBean.builder ().moduleType(logEnum.APPROVAL.getCode()).busniessType(busniessType)
        		.approvalNo(processInstanceId).approvalType(approvalType)
        		.operationContent(operationContent)
        		.approvalResult(approvalResult)
        		.userInfo(UserInfo.getCurrentUserInfo()).build());
	}
	
	public void infoAutoPass(String processInstanceId) {
		
		Map<Integer, String> map = getProcessInstanceInfo(processInstanceId);
		String busniessType = map.get(BUSNIESS_TYPE);
		String approvalType = map.get(APPROVAL_TYPE);
		
		if(StringUtils.isEmpty(busniessType) || StringUtils.isEmpty(approvalType))//可能刚处理完审批逻辑，就废弃了。
			return;
		
		log2.publishEvent(LogSaveBean.builder ().moduleType(logEnum.APPROVAL.getCode()).busniessType(busniessType).approvalNo(processInstanceId)
				.approvalType(approvalType).operationContent("自动审批允许通过").approvalResult("a12").userInfo(null).build());
	}
	
	private Map<Integer, String> getProcessInstanceInfo(String processInstanceId){
		
		Map<Integer, String> map = new HashMap<>();
		
		ActivitiOuterRelation relation = activitiOuterRelationService.getByProcessInstanceId(processInstanceId);
		if(relation == null)//可能刚处理完审批逻辑，就废弃了。
			return map;
		
		Integer examineId = relation.getExamineId();
		if(examineId == null)
			return map;
		
		ActivitiExamine examine = activitiExamineService.load(examineId.intValue());
		String examineType = examine.getExamineType();
		map.put(APPROVAL_TYPE, examineType);
		
		String bType = null;
		Integer busniessType = relation.getBusniessType();
		switch (busniessType) {
		case ActivitiConstants.BusniessType.material:
			bType = "a21";
			break;
		case ActivitiConstants.BusniessType.plan:
			bType = "a22";
			break;
		case ActivitiConstants.BusniessType.device:
			bType = "a23";
			break;
		default:
			break;
		}
		
		map.put(BUSNIESS_TYPE, bType);
		return map;
	}
}

package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.boe.bank.beanconverter.EquipmentTypeConverter;
import com.boe.bank.common.bean.equipment.EquipmentTypeQO;
import com.boe.bank.common.bean.equipment.EquipmentTypeVO;
import com.boe.bank.common.entity.equipment.EquipmentType;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.equipment.EquipmentTypeMapper;
import com.boe.bank.service.equipment.EquipmentTypeService;
import org.springframework.stereotype.Service;

/**
 * 设备类型 ServiceImpl
 *
 * @author 10183279
 * @date 2020/12/1
 */
@Service("equipmentTypeService")
public class EquipmentTypeServiceImpl extends ServiceImpl<EquipmentTypeMapper, EquipmentType> implements EquipmentTypeService {

    @Override
    public IPage<EquipmentTypeVO> page(EquipmentTypeQO qo) {
        ObjectUtil.setPageNumAndPageSizeDefault(qo);
        LambdaQueryWrapper<EquipmentType> wrapper = Wrappers.lambdaQuery(EquipmentType.class)
                .like(StringUtils.isNotBlank(qo.getName()), EquipmentType::getName, qo.getName());
        wrapper.orderByDesc(EquipmentType::getCreateTime);
        Page<EquipmentType> page = baseMapper.selectPage(new Page<>(qo.getPageNum(), qo.getPageSize()), wrapper);
        return page.convert(EquipmentTypeConverter.INSTANCE::entityToVo);
    }

    @Override
    public EquipmentType getByName(String name) {
        LambdaQueryWrapper<EquipmentType> wrapper = Wrappers.lambdaQuery(EquipmentType.class).eq(EquipmentType::getName, name);
        return baseMapper.selectOne(wrapper);
    }

    @Override
    public EquipmentType getById(Integer id) {
        LambdaQueryWrapper<EquipmentType> wrapper = Wrappers.lambdaQuery(EquipmentType.class).eq(EquipmentType::getId, id);
        return baseMapper.selectOne(wrapper);
    }
}

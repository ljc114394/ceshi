package com.boe.bank.service.activitiService.job;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.TaskService;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.boe.bank.common.bean.activiti.ActivitiTaskDescriptionFlag;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.service.activitiService.log.ActivitiLogService;
import com.boe.bank.service.activitiService.org.impl.ActivitiOptionOrgServiceImpl;
import com.boe.bank.util.ActivitiTaskDescriptionFlagUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 定时任务:自动审批
 * 自动通过act_ru_task的description字段为AUTO_PASS_FLAG的task
 * 1. 需要user设置一个自动通过的人物id标识，可以是超级管理员
 * 2. 
 * @author caoxuhao
 */
@Slf4j
@Component
public class ActivitiAutoPassJobService {
	
	//存在flag的description模糊搜索条件
	private static final String DESCRIPTION_FLAG_CONDITION = ActivitiTaskDescriptionFlagUtil.start + "%";
	
	@Value("${spring.activiti.auto-pass-user-id:-1}")
	private String autoPassUserId;
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private ActivitiLogService activitiLogService;
	
	
	public void autoPass() {
		
		// 取所有自动通过标记的task
		List<Task> list = taskService.createTaskQuery().taskDescriptionLike(DESCRIPTION_FLAG_CONDITION).list();
		
		if(CollectionUtils.isEmpty(list))
			return;
		
		Map<String,Object> map = new HashMap<>();
		map.put("result", 1);
		for (Task task : list) {
			try {
				String description = task.getDescription();
				ActivitiTaskDescriptionFlag flag = ActivitiTaskDescriptionFlagUtil.parse(description);
				
				if(!flag.isAutoPass())
					continue;
				
				boolean shouldAutoPass = false;
				
				switch (flag.getPassType()) {
				case ActivitiConstants.PassType.any:
					//任何1人审核即可，但该组只有一个不可用的人，则需要自动审批
					long count = taskService.createTaskQuery().processInstanceId(task.getProcessInstanceId()).
						taskDefinitionKey(task.getTaskDefinitionKey()).count();
					if(1 == count)
						shouldAutoPass = true;
					break;
				case ActivitiConstants.PassType.all:
					//所有人都要审核，则需要自动审批
					shouldAutoPass = true;
					break;

				default:
					break;
				}
				
				if(shouldAutoPass) {
					String id = task.getId();
					log.info("定时任务taskId:"+ id + "自动置为通过");
					
					String processInstanceId = task.getProcessInstanceId();
					
					//评论
					Authentication.setAuthenticatedUserId(autoPassUserId);
					taskService.addComment(id, processInstanceId, ActivitiOptionOrgServiceImpl.EXAMINE_PASS+"节点无候选人自动审核通过");
					taskService.complete(id, map, true);
					
					//log
					activitiLogService.infoAutoPass(processInstanceId);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

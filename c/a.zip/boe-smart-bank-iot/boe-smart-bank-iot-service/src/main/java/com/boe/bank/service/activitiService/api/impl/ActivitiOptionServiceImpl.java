package com.boe.bank.service.activitiService.api.impl;

import com.alibaba.fastjson.JSON;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.activiti.ActivitiOptUser;
import com.boe.bank.common.bean.activiti.ActivitiUserTaskDto;
import com.boe.bank.common.bean.activiti.UserTaskBo;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;
import com.boe.bank.common.entity.activiti.ActivitiProcess;
import com.boe.bank.common.entity.activiti.ActivitiTransfer;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.common.utils.ParamUtil;
import com.boe.bank.mapper.activiti.ActivitiTransferMapper;
import com.boe.bank.service.activitiService.*;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.bank.service.activitiService.base.ActivitiProcessService;
import com.boe.bank.service.activitiService.base.ActivitiWebService;
import com.boe.bank.service.activitiService.org.ActivitiOptionOrgService;
import com.boe.bank.service.activitiService.org.ActivitiProcessOrgService;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.task.Task;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 审批操作
 * 提交，通过，拒绝
 * @author caoxuhao
 */
@Service
@Slf4j
public class ActivitiOptionServiceImpl implements ActivitiOptionService{
	
	@Autowired
	private ActivitiProcessOrgService activitiProcessOrgService;
	
	@Autowired
	private ActivitiProcessService activitiProcessService;
	
	@Autowired
	private ActivitiWebService activitiWebService;
	
	@Autowired
	private ActivitiOptionOrgService activitiOptionOrgService;
	
	@Autowired
	private ActivitiOuterRelationService activitiOuterRelationService;

	@Autowired
	private ActivitiTransferMapper activitiTransferMapper;

	/**
	 * 提交工作流
	 * @param userId
	 * @param busniessType
	 * @param examineId
	 * @param outerId
	 * @param outerType	二级类型（非必传）
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> submit(String userId, Integer busniessType, Integer examineId, Integer outerId, Integer outerType) {
		
		if (ParamUtil.isNullOrEmpty(userId, busniessType, outerId))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		
		ActivitiProcess activitiProcess = null;
		
		if(ActivitiConstants.BusniessType.material == busniessType || ActivitiConstants.BusniessType.application == busniessType) {
			//素材,应用
			if (ParamUtil.isNullOrEmpty(examineId))
				return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
			
			activitiProcess = activitiProcessService.getByExamineId(examineId);
			
		}else if(ActivitiConstants.BusniessType.device == busniessType) {
			//设备
			activitiProcess = activitiProcessService.getByBusniessType(ActivitiConstants.BusniessType.device);
			
		}else if(ActivitiConstants.BusniessType.plan == busniessType) {
			//计划
			activitiProcess = activitiProcessService.getByBusniessType(ActivitiConstants.BusniessType.plan);
		}
		
		//用户还没有创建对应的审批流
		if(activitiProcess == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR);

		if(activitiProcess.getStatus() == ActivitiConstants.Status.suspend)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE);
		
		examineId = activitiProcess.getExamineId();
		
		Result<String> res = submit(userId, examineId);
		if(res.isSuccess()) {
			//成功后加入ProcessDefinitionId，outerId，busniessType关联表
			ActivitiOuterRelation activitiOuterRelation = new ActivitiOuterRelation();
			activitiOuterRelation.setOuterId(outerId);
			activitiOuterRelation.setBusniessType(busniessType);
			activitiOuterRelation.setCreateTime(DateUtil.current());
			activitiOuterRelation.setCreateUserId(Long.valueOf(userId));
			
			String processInstanceId = res.getData();
			activitiOuterRelation.setProcessInstanceId(processInstanceId);
			activitiOuterRelation.setOuterType(outerType);
			activitiOuterRelation.setExamineId(examineId);
			
			activitiOuterRelationService.insert(activitiOuterRelation);
		}
		
		return res;
	}

	private Result<String> submit(String userId, Integer examineId) {
		
		ActivitiProcess activitiProcess = activitiProcessService.getByExamineId(examineId);
		if(activitiProcess == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_EXIST);
		
		String procdefId = activitiProcess.getProcdefId();
		String resourceData = activitiProcess.getResourceData();
		List<ActivitiUserTaskDto> userTaskList = JSON.parseArray(resourceData, ActivitiUserTaskDto.class);
		
		List<UserTaskBo> modelList = activitiWebService.convertActivitiUserTaskDto2UserTaskBo(userTaskList);
		
		//activiti 开始工作流
		String processInstanceId = activitiProcessOrgService.start(procdefId, userId, modelList);
		if(StringUtils.isEmpty(processInstanceId))
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_SUBMIT_ERROR); 
		
		return Result.successWithData(processInstanceId);
	}
	
	/**
	 * 拒绝工作流
	 * @param acticitiOptUser
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> fail(ActivitiOptUser acticitiOptUser) {
		
		String processInstanceId = acticitiOptUser.getProcessInstanceId();
		String reviewer = acticitiOptUser.getReviewer();
		String taskId = acticitiOptUser.getTaskId();

		//获取任务
		Task task = getTask(taskId, processInstanceId, reviewer);;
		if(task == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_HAVE_NO_TASK_ERROR);
		
		//activiti 审批拒绝
		boolean res = activitiOptionOrgService.fail(task, reviewer, acticitiOptUser.getComment());
		if(!res)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_REJECT_ERROR);
		
		//如果是分给各个部门的任务。则其中一个部门拒绝，其他所有部门自动结束任务。
		List<String> userIds = activitiOptionOrgService.getUsersForCloseOtherDepTask(task);
		if(CollectionUtils.isEmpty(userIds))
			return Result.success();
		
		//TODO !!!!!!!!!!!!!!!根据userIds每个部门获取一个人
		List<String> assigneeListIds = new ArrayList<String>();
		
		//自动拒绝其他部门的该任务
		res = activitiOptionOrgService.doCloseOtherDepTask(task.getProcessInstanceId(), assigneeListIds);
		if(!res)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_REJECT_OTHER_DEP_ERROR);
		
		return Result.success();
	}
	
	/**
	 * 通过工作流
	 * @param acticitiOptUser
	 * @return
	 */
	@Transactional
	@Override
	public Result<?> pass(ActivitiOptUser acticitiOptUser) {
		
		String processInstanceId = acticitiOptUser.getProcessInstanceId();
		String reviewer = acticitiOptUser.getReviewer();
		String taskId = acticitiOptUser.getTaskId();

		//获取任务
		Task task = getTask(taskId, processInstanceId, reviewer);
		if(task == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_HAVE_NO_TASK_ERROR);
		
		//activiti 审批通过
		boolean res = activitiOptionOrgService.pass(task, reviewer);
		if(!res)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_PASS_ERROR);
		
		return Result.success();
	}
	
	
	/** 
     * 转办流程 
     * @param processInstanceId 
     * @param reviewer  
     * @param targetUserId  目标用户
     */
	@Transactional
	@Override
	public Result<?> transferAssignee(String taskId, String processInstanceId, String reviewer, String targetUserId) {

		//获取任务
		Task task = getTask(taskId, processInstanceId, reviewer);

		if(task == null)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_HAVE_NO_TASK_ERROR);
		
		//activiti 转办
		boolean res = activitiOptionOrgService.transferAssignee(task, targetUserId);
		if(!res)
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_TRANSFER_ERROR);

		//转办记录表
		ActivitiTransfer activitiTransfer = new ActivitiTransfer();
		activitiTransfer.setFromUserId(Long.valueOf(reviewer));
		activitiTransfer.setToUserId(Long.valueOf(targetUserId));
		activitiTransfer.setPROC_INST_ID_(processInstanceId);
		activitiTransfer.setTASK_ID_(task.getId());
		activitiTransfer.setCreateTime(DateUtil.current());
		activitiTransferMapper.insertSelective(activitiTransfer);
		
		return Result.success();
	}
	
	/**
	 * 废弃
	 * @param processInstanceId
	 */
	@Override
	public void abandon(String processInstanceId) {
		List<Task> taskList = activitiOptionOrgService.getTaskList(processInstanceId);

		//没有正在执行的任务要废弃
		if(CollectionUtils.isEmpty(taskList))
			return;

		final int maxSize = taskList.size();//最多每个部门1个人
		
		//TODO 循环废弃效率，可能比按部门废弃低（参考拒绝代码）
		for (int i = 0; i < maxSize; i++) {
			//废弃第一个task
			activitiOptionOrgService.abandon(taskList.get(0).getId());			
			//如果还有没处理的，继续废弃
			taskList = activitiOptionOrgService.getTaskList(processInstanceId);
			if(CollectionUtils.isEmpty(taskList))
				break;
		}
		
	}

	private Task getTask(String taskId, String processInstanceId, String reviewer){
		Task task = null;
		if(!StringUtils.isEmpty(taskId)){
			task = activitiOptionOrgService.getTaskByTaskId(taskId, reviewer);
		}else {
			task = activitiOptionOrgService.getTask(processInstanceId, reviewer);
		}

		return task;
	}
}

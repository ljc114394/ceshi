package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.dictbean.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.boe.bank.common.entity.dict.SysDictionaries;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SysDictionariesCoverter {

	SysDictionariesBean getSysDictionariesCHange(SysDictionaries sysDictionaries);


    SysDictionaries getSysDictionaries(SysDictionariesBean sysDictionariesBean);

	@Mappings({
			@Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(sysDictionaries.getCreateTime()))"),
			@Mapping(target = "updateTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(sysDictionaries.getUpdateTime()))")
	})
	SysDictionariesInfoBean getDictInfoBean(SysDictionaries sysDictionaries);

	SysDictionariesValueBean getValueBean(SysDictionaries sysDictionaries);

	List<SysDictionariesValueBean> getValueBeanList(List<SysDictionaries>  dicts);

	List<SysDictionariesInfoBean> getDictInfoBeanList(List<SysDictionaries> dicts);

	@Mappings({
			@Mapping(target = "value", source = "childCode"),
			@Mapping(target = "label", source = "childCodeValue")
	})
	SysDictionariesLabelBean getLableBean(SysDictionariesListBean dictBean);


	List<SysDictionariesLabelBean> getListLableBean(List<SysDictionariesListBean> dictListBean);


	@Mappings({
			@Mapping(target = "parentId", expression = "java(dicts.getParentId().longValue())"),
			@Mapping(target = "id", expression = "java(dicts.getId().longValue())")
	})
	SysDictionariesTreeBean getBean(SysDictionaries dicts);


	List<SysDictionariesTreeBean> getListBean(List<SysDictionaries> dicts);

}
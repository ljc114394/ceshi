package com.boe.bank.listener.activiti;

import java.util.List;

import org.activiti.api.process.runtime.ProcessRuntime;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityImpl;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boe.bank.common.bean.activiti.ActivitiTaskDescriptionFlag;
import com.boe.bank.common.bean.userinfobean.UserInfoBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.service.activitiService.job.ActivitiAutoPassJobService;
import com.boe.bank.service.userInfoService.UserInfoService;
import com.boe.bank.util.ActivitiTaskDescriptionFlagUtil;

/**
 * 任意一人通过的监听器
 * @author caoxuhao
 */
@Component
public class UserTaskAnyListener implements 
//TaskListener
//	, ExecutionListener, 
JavaDelegate 
	{

	@Autowired
	private TaskService taskService;
	
	@Autowired
	private RepositoryService repositoryService;
	
	@Autowired
	private ProcessRuntime processRuntime;
	
	@Autowired
	private HistoryService historyService;
	
	@Autowired
	private RuntimeService runtimeService;
	
	@Autowired
	private UserInfoService userInfoService;
	
//	@Override
//	public void notify(DelegateTask delegateTask) {
//		
//		String eventName = delegateTask.getEventName();
//		System.err.println("走到监听器了6666:"+eventName);
//		
//		boolean noAssignee = false;
//		
//		String assignee = delegateTask.getAssignee();
//		if(StringUtils.isEmpty(assignee)) {
//			//节点未分配审核人
//			noAssignee = true;
//		}else {
//			UserInfoBean user = userInfoService.getUserInfoById(Integer.valueOf(assignee));
//			Integer isEnabled = user.getIsEnabled();
//			if(isEnabled != 1) {
//				//审核人不可用（离职等）
//				noAssignee = true;
//			}
//		}
//		
//		if(noAssignee) {
////			taskService.createTaskQuery().crea
//		}
//		
////		delegateTask.setDescription("-1");
//	}

	@Override
	public void execute(DelegateExecution execution) {
		List<TaskEntity> tasks = ((ExecutionEntityImpl)execution).getTasks();
		TaskEntity taskEntity = tasks.get(0);
		String assignee = taskEntity.getAssignee();
		
		boolean noAssignee = false;
		if(StringUtils.isEmpty(assignee)) {
			//节点未分配审核人
			noAssignee = true;
		}else {
			UserInfoBean user = userInfoService.getUserInfoById(Integer.valueOf(assignee));
			if(user == null || user.getIsEnabled() == null ||user.getIsEnabled() != 1) {
				//审核人不可用（离职等）
				noAssignee = true;
			}
		}
		
		if(noAssignee) {
			//设置标志位
			String oldDescription = taskEntity.getDescription();
			
			ActivitiTaskDescriptionFlag flag = new ActivitiTaskDescriptionFlag();
			flag.setAutoPass(true);
			flag.setPassType(ActivitiConstants.PassType.any);
			
			String newDescription = ActivitiTaskDescriptionFlagUtil.format(flag, oldDescription);
			taskEntity.setDescription(newDescription);
		}
	}

}

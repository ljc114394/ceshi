package com.boe.bank.netty;

import com.boe.bank.common.base.BusinessException;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;

/**
 * Description
 *
 * @author 10183279
 * @date 2020/10/21
 */
@Slf4j
@Component
public class NettyService {

    public void start(InetSocketAddress address) {
        // 配置服务端的NIO线程组
        EventLoopGroup bossGroup = new NioEventLoopGroup(1);
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap bootstrap = new ServerBootstrap()
                    // 绑定线程池
                    .group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
//                    .localAddress(address)
                    .childHandler(new NettyServerChannelInitializer())
                    // 服务端接受连接的队列长度，如果队列已满，客户端连接将被拒绝
                    .option(ChannelOption.SO_BACKLOG, 128)
                    // 保持长连接，2小时无数据激活心跳机制
                    .childOption(ChannelOption.SO_KEEPALIVE, true);
            // 绑定端口，开始接收进来的连接
            ChannelFuture future = bootstrap.bind(address).sync();
            log.info("Netty服务器开始监听端口：{}", address.getPort());
            // 关闭channel
            future.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            log.error("Netty服务器启动异常", e);
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }

    public void sendMessage(String mac, String msg) {
        log.info("向客户端[mac={}]发送指令[command={}]", mac, msg);
        Channel ch = NettyServerHandler.TERMINAL_MAP.get(mac);
        if (ch != null && ch.isActive()) {
            ByteBuf buf = Unpooled.buffer();
            try {
                buf.writeBytes(msg.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                throw new BusinessException("不支持的字符编码格式");
            }
            ChannelFuture cf = ch.writeAndFlush(new TextWebSocketFrame(buf));
            // 添加ChannelFutureListener以便在写操作完成后接收通知
            cf.addListener((ChannelFuture future) -> {
                // 写操作完成，并没有错误发生
                if (future.isSuccess()) {
                    log.info("sendCommand-success，MAC：{}，command：{}", mac, msg);
                } else {
                    // 记录错误
                    log.error("sendCommand-error，MAC：{}，command：{}", mac, msg);
                    future.cause().printStackTrace();
                }
            });
        } else {
            log.info("设备[{}]未连接", mac);
            throw new BusinessException("设备[" + mac + "]未连接");
        }
    }


    public void sendMessageNoException(String mac, String msg) {
        log.info("向客户端[mac={}]发送指令[command={}]", mac, msg);
        Channel ch = NettyServerHandler.TERMINAL_MAP.get(mac);
        if (ch != null && ch.isActive()) {
            ByteBuf buf = Unpooled.buffer();
            try {
                buf.writeBytes(msg.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                throw new BusinessException("不支持的字符编码格式");
            }
            ChannelFuture cf = ch.writeAndFlush(new TextWebSocketFrame(buf));
            // 添加ChannelFutureListener以便在写操作完成后接收通知
            cf.addListener((ChannelFuture future) -> {
                // 写操作完成，并没有错误发生
                if (future.isSuccess()) {
                    log.info("sendCommand-success，MAC：{}，command：{}", mac, msg);
                } else {
                    // 记录错误
                    log.error("sendCommand-error，MAC：{}，command：{}", mac, msg);
                    future.cause().printStackTrace();
                }
            });
        } else {
            log.info("设备[{}]未连接", mac);
            //throw new BusinessException("设备[" + mac + "]未连接");
        }
    }
}

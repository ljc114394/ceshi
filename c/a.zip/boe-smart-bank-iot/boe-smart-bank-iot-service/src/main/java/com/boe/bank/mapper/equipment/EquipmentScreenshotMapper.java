package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentScreenshot;

/**
 * 设备截图 Mapper
 *
 * @author 10183279
 * @date 2020/10/30
 */
public interface EquipmentScreenshotMapper extends BaseMapper<EquipmentScreenshot> {

}

package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.productlibrarybean.*;
import com.boe.bank.common.entity.productlibrary.ProductLibrary;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ProductLibraryCoverter {

    ProductLibraryBean getProductLibraryBean(ProductLibrary productLibrary);

    MarketingStrategyOneBean getMarketingStrategyOneBean(ProductLibrary productLibrary);

    ProductLibrary getProductLibrary(ProductLibrarySaveBean productLibraryBean);

    ProductLibraryExportBean getProductLibraryExport(ProductLibrary productLibraryBean);

    MarketingStrategyBean getMarketingStrategy(ProductLibrary productLibraryBean);

    List<ProductLibraryBean> getProductLibraryList(List<ProductLibrary> productLibraryBean);

    List<ProductLibraryExportBean> getProductLibraryExportList(List<ProductLibrary> productLibraryBean);

    List<MarketingStrategyBean> getMarketingStrategyList(List<ProductLibrary> productLibraryBean);

    MarketingStrategyExportBean getMarketingStrategyExport(ProductLibrary productLibraryBean);

    List<MarketingStrategyExportBean> getMarketingStrategyExportList(List<ProductLibrary> productLibraryBean);






}

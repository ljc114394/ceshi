package com.boe.bank.service.planmanageService;

import com.boe.bank.common.bean.activiti.ActivitiProcessOrgVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessPlanVo;
import com.boe.bank.common.bean.planmanagebean.PlanManageBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.bank.service.activitiService.manager.ActivitiSupport;
import com.boe.bank.mapper.planmanageMapper.PlanManageMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 计划模块-提供审核能力
 * @author caoxuhao
 */
@Component
public class PlanActivitiSupporter implements ActivitiSupport {

    @Autowired
    private PlanManageMapper planManageMapper;

    @Autowired
    private PlanManageService planManageService;

    @Override
    public int getBusniessType() {
        return ActivitiConstants.BusniessType.plan;
    }

    @Override
    public boolean updateExamineStatus(int outerId, int examineStatus, Integer outerType) {
        PlanManage planManagea = new PlanManage();
        planManagea.setId(outerId);
        planManagea.setState(examineStatus);
        return planManageMapper.updatePlanManage(planManagea) > 0;
    }

    @Override
    public boolean addOuterData(int outerId, ActivitiProcessOrgVo t, Integer outerType) {

        PlanManageBean entity = planManageService.getPlanById(outerId);
        if (entity == null)
            return false;

        if (t instanceof ActivitiProcessPlanVo) {
            ActivitiProcessPlanVo vo = (ActivitiProcessPlanVo) t;
            vo.setPlanName(entity.getTitle());
            vo.setOrgName(entity.getOrgName());
            vo.setPlanRemark(entity.getRemark());
            return true;
        }

        return false;
    }
}

package com.boe.bank.util;

import java.util.ArrayList;
import java.util.List;

import org.activiti.bpmn.model.ActivitiListener;
import org.activiti.bpmn.model.EndEvent;
import org.activiti.bpmn.model.ExclusiveGateway;
import org.activiti.bpmn.model.MultiInstanceLoopCharacteristics;
import org.activiti.bpmn.model.ParallelGateway;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.bpmn.model.StartEvent;
import org.activiti.bpmn.model.UserTask;
import org.apache.commons.lang3.StringUtils;

import com.boe.bank.common.constant.ActivitiConstants;

/**
 * activiti的节点的工具类
 * @author caoxuhao
 */
public class ActivitiUtil {
	
	/**单据状态*/
	public static class ActivitiStatus{
		public static final String end = "结束";
		public static final String doing = "流转";
		public static final String abandon = "作废";
	}
	
	/**处理状态*/
	public static class ProcessStatus{
		public static final String undo = "未处理";
		public static final String pass = "通过";
		public static final String reject = "拒绝";
	}
	
	/**
     * 开始任务节点
     * @return
     */
    public static StartEvent createStartEvent() {
        StartEvent startEvent = new StartEvent();
        startEvent.setId(ActivitiConstants.Node.start);
        return startEvent;
    }   

    /**
     * 成功结束任务节点
     * @return
     */
    public static EndEvent createSuccessEndEvent() {
        EndEvent endEvent = new EndEvent();
        endEvent.setId(ActivitiConstants.Node.successEnd);
        return endEvent;
    }
    
    /**
     * 拒绝结束任务节点
     * @return
     */
    public static EndEvent createRejectEndEvent() {
    	EndEvent endEvent = new EndEvent();
    	endEvent.setId(ActivitiConstants.Node.rejectEnd);
    	return endEvent;
    }
    
    /**
     * 废弃结束任务节点
     * @return
     */
    public static EndEvent createAbandonedEndEvent() {
    	EndEvent endEvent = new EndEvent();
    	endEvent.setId(ActivitiConstants.Node.abandonedEnd);
    	return endEvent;
    }
    
    /**
     * 会签节点
     * (所有人通过，或其中一人拒绝则结束)
     * @return
     */
    public static UserTask createJoinTaskAll(String id, String name, String assigneeName) {
    	UserTask userTask = new UserTask();
        userTask.setName(name);
        userTask.setId(id);
        userTask.setAssignee("${" + assigneeName + "}");
        
        MultiInstanceLoopCharacteristics loopCharacteristics = new MultiInstanceLoopCharacteristics();
        loopCharacteristics.setSequential(false);
        loopCharacteristics.setInputDataItem("${" + assigneeName + "List}");
        loopCharacteristics.setElementVariable(assigneeName);
        loopCharacteristics.setCompletionCondition("${result != '1'}");
        userTask.setLoopCharacteristics(loopCharacteristics);
        
        List<ActivitiListener> executionListeners = new ArrayList<>();
        ActivitiListener activitiListener = new ActivitiListener();
        activitiListener.setEvent("assignment");//填all可监听assignment create complete delete
//        activitiListener.setImplementation("com.boe.bank.listener.activiti.UserTaskAllListener");
//        activitiListener.setImplementationType("class");
        activitiListener.setImplementation("${userTaskAllListener.execute(execution)}");
        activitiListener.setImplementationType("expression");
        executionListeners.add(activitiListener);
        userTask.setTaskListeners(executionListeners);
        return userTask;
    }
    
    /**
     * 会签节点
     * (任一人通过或拒绝则结束)
     * @return
     */
    public static UserTask createJoinTaskAny(String id, String name, String assigneeName) {
    	UserTask userTask = new UserTask();
    	userTask.setName(name);
    	userTask.setId(id);
    	userTask.setAssignee("${" + assigneeName + "}");
    	
    	MultiInstanceLoopCharacteristics loopCharacteristics = new MultiInstanceLoopCharacteristics();
    	loopCharacteristics.setSequential(false);
    	loopCharacteristics.setInputDataItem("${" + assigneeName + "List}");
    	loopCharacteristics.setElementVariable(assigneeName);
    	loopCharacteristics.setCompletionCondition("${result >= '0'}");//没有<0的选项，所以任意一人操作都会结束
    	userTask.setLoopCharacteristics(loopCharacteristics);
    	
    	List<ActivitiListener> executionListeners = new ArrayList<>();
        ActivitiListener activitiListener = new ActivitiListener();
        activitiListener.setEvent("assignment");//填all可监听assignment create complete delete
//        activitiListener.setImplementation("com.boe.bank.listener.activiti.UserTaskAnyListener");
//        activitiListener.setImplementationType("class");
        activitiListener.setImplementation("${userTaskAnyListener.execute(execution)}");
        activitiListener.setImplementationType("expression");
        executionListeners.add(activitiListener);
        userTask.setTaskListeners(executionListeners);
    	return userTask;
    }
    
    /**
     * 普通节点
     * @param id
     * @param name
     * @param assignee
     * @param candidateGroups
     * @return
     */
    public static UserTask createUserTask(String id, String name, String assignee, List<String> candidateGroups) {
    	return createUserTask(id, name, assignee,  candidateGroups, null);
    }
    
    /**
     * 
     * @param id  对应我们画流程图中节点任务id
     * @param name 节点任务名称
     * @param assignee 任务的执行者(这一块自行决定是否添加每一环节的执行者，若是动态分配的话，可以不用传值)
     * @param candidateGroups 候选组
     * @return
     */
    public static UserTask createUserTask(String id, String name, String assignee, List<String> candidateGroups, Boolean isOwner) {
        UserTask userTask = new UserTask();
        userTask.setName(name);
        userTask.setId(id);
        userTask.setAssignee(assignee);
        userTask.setCandidateGroups(candidateGroups);
        if(isOwner != null && isOwner)
        	userTask.setOwner(assignee);
        
        userTask.setSkipExpression("${skip == '1'}");
        
        return userTask;
    }
    
    /**
     * 并行网关
     * @param id  网关id
     * @return
     */
    public static ParallelGateway createParallelGateway(String id) {
    	ParallelGateway pg = new ParallelGateway();
    	pg.setId(id);
    	return pg;
    }
    
    /**
     * 排他网关
     * @param id  网关id
     * @return
     */
    public static ExclusiveGateway createExclusiveGateway(String id) {
        ExclusiveGateway exclusiveGateway = new ExclusiveGateway();
        exclusiveGateway.setId(id);
        return exclusiveGateway;
    }

	/**
     * @param from         连线来源节点
     * @param to        连线目标节点
     * @param name          连线名称(可不填)
     * @param conditionExpression  网关每一种线路走向的条件表达式
     * @return
     */
    public static SequenceFlow createSequenceFlow(String from, String to, String name, String conditionExpression) {
        SequenceFlow flow = new SequenceFlow();
        flow.setSourceRef(from);
        flow.setTargetRef(to);
        flow.setName(name);
        if (StringUtils.isNotEmpty(conditionExpression)) {
            flow.setConditionExpression(conditionExpression);
        }
        
        List<ActivitiListener> executionListeners = new ArrayList<>();
        ActivitiListener activitiListener = new ActivitiListener();
        activitiListener.setEvent("take");
        activitiListener.setImplementation("${sequenceFlowListener.execute(execution)}");
        activitiListener.setImplementationType("expression");
        executionListeners.add(activitiListener);
        flow.setExecutionListeners(executionListeners);
        
        return flow;
    }
    
    
}

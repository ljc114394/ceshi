package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.bean.equipment.EquipmentBatchPlanDTO;
import com.boe.bank.common.entity.equipment.EquipmentPlan;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 设备计划 Mapper
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentPlanMapper extends BaseMapper<EquipmentPlan> {

    int batchInsert(@Param("mac") List<String> mac,@Param ("dto") EquipmentBatchPlanDTO dto);

    int batchDelete(@Param("mac") List<String> mac);

    int updelEquipment(@Param("mac") List<String> mac);
}

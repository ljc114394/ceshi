package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.equipment.EquipmentTypeDTO;
import com.boe.bank.common.bean.equipment.EquipmentTypeVO;
import com.boe.bank.common.entity.equipment.EquipmentType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 设备类型类转换器
 *
 * @author 10183279
 * @date 2020/12/1
 */
@Mapper
public interface EquipmentTypeConverter {

    EquipmentTypeConverter INSTANCE = Mappers.getMapper(EquipmentTypeConverter.class);

    /**
     * dto转为entity
     * @param dto
     * @return
     */
    EquipmentType dtoToEntity(EquipmentTypeDTO dto);

    /**
     * entity转为vo
     * @param entity
     * @return
     */
    @Mappings({
            @Mapping(source = "createTime", target = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "updateTime", target = "updateTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    EquipmentTypeVO entityToVo(EquipmentType entity);

    List<EquipmentTypeVO> entityListToVoList(List<EquipmentType> entityList);
}

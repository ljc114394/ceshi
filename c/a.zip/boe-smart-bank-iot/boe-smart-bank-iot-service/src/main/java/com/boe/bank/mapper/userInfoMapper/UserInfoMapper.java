package com.boe.bank.mapper.userInfoMapper;

import com.boe.bank.common.bean.userinfobean.UserInfoBean;
import com.boe.bank.common.bean.userinfobean.UserInfoByRoleSearchBean;
import com.boe.bank.common.bean.userinfobean.UserInfoSearchBean;
import com.boe.bank.common.entity.userinfo.UserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;
@Mapper
public interface UserInfoMapper {


    Integer insertUserInfo(UserInfo userInfo);

    Integer updateUserInfo(UserInfo userInfo);

    int updateUserInfoDel(List<Integer> id);

    UserInfo getUserInfoById(Integer id);

    List<UserInfo> getUserInfoList(@Param("userInfo") UserInfoSearchBean userInfo,@Param("userInfoList") List<Long> userInfoList);

    List<UserInfo> getUserInfoList(@Param("userInfo") UserInfoByRoleSearchBean userInfo, @Param("userInfoList") List<Long> userInfoList);

    List<UserInfo> getListByAddPeople(@Param("userInfo") UserInfoByRoleSearchBean userInfo, @Param("userInfoList") List<Long> userInfoList);

    int selectByName(UserInfo userInfo);

    List<UserInfo> getUserByRoleId(Integer id);

    UserInfoBean getDepartMentByUserId(Long id);

    List<UserInfo> getUserInfoByJurisdiction(@Param("userInfo") UserInfoSearchBean userInfo,@Param("userInfoList") List<Long> orgIds);

    Integer getDepartmentIdByUserId(Integer id);

    Integer selectCountBydepartmentId(@Param("ids") List<Long> ids);
}

package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipment.EquipmentConfigDTO;
import com.boe.bank.common.bean.equipment.EquipmentInitConfigVO;
import com.boe.bank.common.entity.equipment.EquipmentConfig;

import java.util.List;

/**
 * 设备配置 Service
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentConfigService extends IService<EquipmentConfig> {

    /**
     * 根据mac获取设备配置信息
     * @param mac
     * @return
     */
    EquipmentConfig getByMac(String mac);

    /**
     * 获取设备初始化信息接口
     * @param mac
     */
    EquipmentInitConfigVO getInitInfo(String mac);

    /**
     * 新增、更新设备配置接口
     *
     * @param mac
     * @param dto
     * @return
     */
    int saveOrUpdate(String mac, EquipmentConfigDTO dto);

    /**
     * 初始化设备配置，设置屏幕区域布局
     * @param mac
     */
    void init(String mac);

    /**
     * 根据批量mac获取设备配置信息
     * @param mac
     * @return
     */
    List<EquipmentConfig> getByBatchMac(List<String> mac);
}

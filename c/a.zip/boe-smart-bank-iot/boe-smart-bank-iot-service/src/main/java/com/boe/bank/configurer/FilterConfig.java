//package com.boe.bank.configurer;
//
//import com.boe.bank.filter.ReplaceStreamFilter;
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.servlet.Filter;
//
///**
// * @author lvjiahceng
// * @program
// * @description 过滤器配置类
// * @create 2020-10-19 11:07
// * @version  1.0
// **/
//@Configuration
//public class FilterConfig {
//    /**
//     * 注册过滤器
//     *
//     * @return FilterRegistrationBean
//     */
//    @Bean
//    public FilterRegistrationBean someFilterRegistration() {
//        FilterRegistrationBean registration = new FilterRegistrationBean();
//        registration.setFilter(replaceStreamFilter());
//        registration.addUrlPatterns("/material/page");
//        registration.setName("streamFilter");
//        return registration;
//    }
//
//    /**
//     * 实例化StreamFilter
//     *
//     * @return Filter
//     */
//    @Bean(name = "replaceStreamFilter")
//    public Filter replaceStreamFilter() {
//        return new ReplaceStreamFilter();
//    }
//}
package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipment.EquipmentBatchPlanDTO;
import com.boe.bank.common.bean.equipment.EquipmentPlanDTO;
import com.boe.bank.common.bean.equipment.ProgramConfigVO;
import com.boe.bank.common.entity.equipment.EquipmentPlan;

import java.util.List;

/**
 * 设备计划 Service
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentPlanService extends IService<EquipmentPlan> {

    /**
     * 根据mac获取设备计划信息
     * @param mac
     * @param type 类型 1：正常计划，2：插播计划
     * @return
     */
    List<EquipmentPlan> getByMacAndType(String mac, Integer type);

    /**
     * 更新设备的计划
     * @param mac
     * @param dto
     */
    int update(String mac, EquipmentPlanDTO dto);

    /**
     * 删除设备的计划
     * @param mac
     * @param dto
     */
    void delete(String mac, EquipmentPlanDTO dto);

    /**
     * 获取设备播放节目信息
     * @param mac
     * @param fileUrlPrefix 资源访问路径前缀
     * @return
     */
    List<ProgramConfigVO> getProgram(String mac, String fileUrlPrefix);

    /**
     * 校验新设置的计划和之前的计划是否冲突
     * @param mac
     * @param dto
     * @return
     */
    String validatePlan(String mac, EquipmentPlanDTO dto);

    /**
     * 批量更新设备的计划
     * @param dto
     */
    int batchUpdate(EquipmentBatchPlanDTO dto);
}

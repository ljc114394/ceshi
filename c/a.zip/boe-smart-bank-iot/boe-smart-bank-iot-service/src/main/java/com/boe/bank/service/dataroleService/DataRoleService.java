package com.boe.bank.service.dataroleService;

import com.boe.bank.beanconverter.DataRoleCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.bean.activiti.ActivitiProcessOrgDo;
import com.boe.bank.common.bean.datarolebean.*;
import com.boe.bank.common.bean.userinfobean.UserInfoByLoginBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.datarolebean.DataRole;
import com.boe.bank.mapper.dataroleMapper.DataRoleMapper;
import com.boe.bank.service.userInfoService.UserInfoService;
import com.boe.cloud.megarock.security.common.Organization;
import com.boe.cloud.megarock.security.common.Role;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.javabean.vo.OrganizationVO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/15
 */
@Service
@Slf4j
public class DataRoleService {

    @Resource
    private DataRoleMapper dataRoleMapper;

    @Resource
    private DataRoleCoverter dataRoleCoverter;

    @Resource
    private OrganizationService organizationService;

    @Resource
    private UserInfoService userInfoService;

    /**
     * 数据权限-修改/添加
     *
     * @param dataRoleSaveBean
     * @return int
     */
    @Transactional
    public Integer updateDataRole(DataRoleSaveBean dataRoleSaveBean) {
        if (dataRoleSaveBean.getRoleId() == null || dataRoleSaveBean.getRoleId() <= 0 ) {
            throw new BusinessException (MsgReturnEnum.DATA_ROLE_ROLE_ID);
        }
        int resa = 0;
        List<DataRole> dataRole = new ArrayList<DataRole>();
        if(CollectionUtils.isNotEmpty(dataRoleSaveBean.getOrgIds())) {
            dataRoleSaveBean.getOrgIds().stream().forEach(item -> {
                DataRole ro = new DataRole();
                ro.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());
                ro.setCreateTime(LocalDateTime.now());
                ro.setCreateUserId(UserInfo.getCurrentUserId());
                ro.setOrgId(item);
                dataRole.add(ro);
            });
        }
        //查询角色id是否存在权限表中
        List<DataRoleBean> list = getDataRoleByRoleId(dataRoleSaveBean.getRoleId());
        if(CollectionUtils.isNotEmpty(list)){//如果表中有就先删除后添加,否则，直接添加
            resa = dataRoleMapper.deleteDataRoleByRoleId(dataRoleSaveBean.getRoleId());
            log.info ("数据权限-删除-返回结果 resa:{}", resa);
            if(resa>0 && CollectionUtils.isNotEmpty(dataRole)){
                resa = dataRoleMapper.insertDataRole (dataRoleSaveBean.getRoleId(),dataRole);
            }
        }else{
            if(CollectionUtils.isNotEmpty(dataRole)) {
                resa = dataRoleMapper.insertDataRole(dataRoleSaveBean.getRoleId(), dataRole);
            }
        }
        log.info ("数据权限-编辑/新增-返回结果 res:{}", resa);
        return  resa;
    }

    /**
     * 数据授权-根据角色id获取List
     *
     * @param id
     * @param id
     * @return
     */
    public List<DataRoleBean> getDataRoleByRoleId(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        List<DataRole> dataRole = dataRoleMapper.getDataRoleByRoleId(id);
        List<DataRoleBean> dataRoleBean = dataRoleCoverter.getDataRoleBeanList (dataRole);
        log.info ("数据授权-根据id获取详细信息 dataRoleBean:{}", dataRoleBean);
        return dataRoleBean;
    }

    /**
     * 获取当前用户对应的角色的机构信息-给素材管理、设备管理用、计划管理
     *
     * @param
     * @return
     */
    public List<DataRoleOrgBean> getDataRoleByRoleList() {
        //Organization organization = UserInfo.getCurrentUserInfo ().getOrganization();//获取机构
        List<Role> list= UserInfo.getCurrentUserInfo ().getRoleDTOList();//获取角色列表
        log.info ("获取当前登录用户角色列表 size:{}", list.size());
        List<DataRoleOrgBean> dataRole = dataRoleMapper.getDataRoleByRoleList(list);//根据角色获取机构信息
        log.info ("获取授权机构信息 dataRole:{}", dataRole.size());
        //List<DataRoleOrgBean> orgList = dataRoleMapper.getOrgNameListByOrgId(dataRole);//根据机构id获取机构名称
//        List<DataRoleOrgBean> orgLists = new ArrayList<DataRoleOrgBean>();
//        DataRoleOrgBean dataRoleOrgBean = DataRoleOrgBean.builder().id(userInfoByLoginBean.getDepartmentId()).name(userInfoByLoginBean.getDepartmentName()).build();
//        if(CollectionUtils.isNotEmpty(dataRole)){
//            orgLists = dataRole.stream().filter(org -> !org.getId().equals(userInfoByLoginBean.getDepartmentId())).collect(Collectors.toList ());
//        }
        //if(organization != null) {
          //  orgLists.add(0, dataRoleOrgBean);
        //}
        log.info ("获取当前登录用户的角色授权的机构 orgLists:{}", dataRole.size());
        return dataRole;
    }

    /**
     * 获取数据权限机构列表
     *
     * @param
     * @return
     */
    /**
     * 获取数据权限机构列表
     *
     * @param
     * @return
     */
    public List<DataRoleOrgListBean> getDataRoleOrg() {
        UserInfoByLoginBean userInfoByLoginBean = userInfoService.getUserByLogin();
        if(userInfoByLoginBean ==null || userInfoByLoginBean.getDepartmentId() ==null ||StringUtils.isEmpty(userInfoByLoginBean.getDepartmentName())){
            throw new BusinessException (MsgReturnEnum.DEPART_AUDIT_NULL);
        }
        List<Role> list= UserInfo.getCurrentUserInfo ().getRoleDTOList();//获取角色列表
        if(CollectionUtils.isEmpty(list)){
            throw new BusinessException (MsgReturnEnum.DATA_ROLE_NULL);
        }
        log.info ("获取当前登录用户角色列表尺寸 size:{}", list.size());
        List<Integer> orgsIds = dataRoleMapper.getDataRoleList(list);//根据角色获取机构信息
        if(CollectionUtils.isEmpty(orgsIds)){
            throw new BusinessException (MsgReturnEnum.DATA_ROLE_ORG_NULL);
        }
        log.info ("获取数据授权信息尺寸 size:{}", orgsIds.size());
        List<Integer> orgsIdss = orgsIds.stream().filter(org -> !org.equals(userInfoByLoginBean.getDepartmentId())).collect(Collectors.toList ());
        orgsIdss.add(userInfoByLoginBean.getDepartmentId());
        //批量获取父id
        List<Integer> parents = dataRoleMapper.getDataRoleParentIdByOrgIds(orgsIdss);
        //将机构id和层级的全路径去重
        List<Integer> olist = new ArrayList<Integer>();
        olist.addAll(orgsIdss);
        olist.addAll(parents);
        List<Integer> orgList = olist.stream().distinct().collect(Collectors.toList());//机构和全路径综合id
        List<DataRoleOrgListBean> listData = new ArrayList<DataRoleOrgListBean>();
        orgList.stream().forEach(a ->{
            DataRoleOrgListBean dataRoleOrgListBean = DataRoleOrgListBean.builder().orgId(a).id(a).build();
            listData.add(dataRoleOrgListBean);
        });
        listData.stream().forEach(item->item.setPermission(0));//默认都没有权限
        //赋值是否可用
        listData.stream().flatMap(x -> orgsIdss.stream().filter(
                y -> x.getOrgId() == y).map(a-> {
            x.setPermission(1);
            return x;
        })).collect(Collectors.toList());
        //赋值父id  赋值机构名称
        List<Long> orgs = listData.stream().map(o -> o.getOrgId().longValue()).distinct().collect(Collectors.toList());//机构id的集合
        if(CollectionUtils.isNotEmpty(orgList)){
            List<OrganizationDO>  orgLists = organizationService.selectBatch(orgs);//获取机构信息（要机构名称）
            if(CollectionUtils.isNotEmpty(orgLists)){
                listData.stream().flatMap(x -> orgLists.stream().filter(
                        y -> x.getOrgId() == y.getId().intValue()).map(a-> {
                    x.setName(a.getName());
                    x.setParentId(a.getParent().intValue());
                    x.setType(a.getType());
                    return x;
                })).collect(Collectors.toList());
            }
        }
        log.info ("获取数据权限机构列表 orgList:{}", listData.size());
        return listData;
    }

    /**
     * 获取当前机构下有数据权限的用户信息列表
     *
     * @param
     * @return
     */
    public List<UserAndData> getUserByOrgId() {
        Long orgId = UserInfo.getCurrentUserInfo ().getOrgId();//获取当前机构id
        if(orgId ==null && orgId<=0){
            throw new BusinessException (MsgReturnEnum.USER_ORG);
        }
        log.info ("获取当前登录用户的机构id orgId:{}", orgId);
//        OrganizationVO organization = organizationService.getTree(orgId,2);
//        if(CollectionUtils.isEmpty(organization.getChildren())){
//            throw new BusinessException (MsgReturnEnum.USER_ORGCHILDREN_DEPARTMENT);
//        }
//        List<OrganizationVO> organizationList = organization.getChildren().stream().filter(o -> o.getType().equals(2)).collect(Collectors.toList ());
        List<UserAndData> userAndData = dataRoleMapper.getUserByOrgId(orgId);
        log.info ("获取当前机构下有数据权限的用户信息列表 orgLists:{}", userAndData.size());
        return userAndData;
    }
}

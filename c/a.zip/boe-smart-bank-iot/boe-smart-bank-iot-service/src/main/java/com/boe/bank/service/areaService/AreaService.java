package com.boe.bank.service.areaService;

import com.boe.bank.beanconverter.AreaCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.areabean.AreaBean;
import com.boe.bank.common.bean.areabean.AreaInfoBean;
import com.boe.bank.common.bean.areabean.AreaNameBean;
import com.boe.bank.common.bean.areabean.AreaSearchBean;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.area.Area;
import com.boe.bank.mapper.areaMapper.AreaMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author lu
 * @version 1.0
 * @data 2020/9/29
 */
@Service
@Slf4j
public class AreaService {

    @Autowired
    private AreaMapper areaMapper;

    @Autowired
    private AreaCoverter areaCoverter;

    @Autowired
    private OrganizationService organizationService;


    /**
     * 根据分区id获取分区信息
     *
     * @param id
     * @return selectByPrimaryKey
     */
    public AreaBean getAreaById(Integer id) {

        log.info ("getAreaById id:{}", id);
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        Area area = areaMapper.selectByPrimaryKey (id);
        if (area == null) {
            throw new BusinessException (MsgReturnEnum.VALUE_NOTGET);
        }
        AreaBean bean = areaCoverter.getAreaBean (area);
        log.info ("getAreaBean :{}", bean);
        return bean;
    }

    /**
     * 分区分页条件查询
     *
     * @param areaSearchBean
     * @return getAreaList
     */
    public PageInfo<AreaInfoBean> getAreaList(AreaSearchBean areaSearchBean) {
        log.info ("getAreaList:{}", areaSearchBean);
        if (areaSearchBean.getPageNum () == 0) {
            areaSearchBean.setPageNum (Const.PAGE_NUM_DEFAULT);
        }
        if (areaSearchBean.getPageSize () == 0) {
            areaSearchBean.setPageSize (Const.PAGE_SIZE_DEFAULT);
        }
        //如果部门机构和组织机构都为空   那么直接返回null值  不返回全部数据
        if(areaSearchBean.getOrgId() != null && areaSearchBean.getOrgId() == 99999999){
            Page page = PageHelper.startPage (areaSearchBean.getPageNum (), areaSearchBean.getPageSize (), true);
            PageInfo<AreaInfoBean> pageInfo = new PageInfo<AreaInfoBean> (null, page);
            return pageInfo;
        }
        List<Long> orgIds = Lists.newArrayList ();
        //调用机构服务获取机构list获取机构id
        if (areaSearchBean.getOrgId () != null && areaSearchBean.getOrgId ().intValue () > 0) {
            List<OrganizationDO> organizationDTOList = organizationService.listSelfAndChildren (areaSearchBean.getOrgId ());
            orgIds = organizationDTOList.stream ().filter (org -> org.getType () == 1).map (OrganizationDO::getId).collect (Collectors.toList ());
        }
        log.info ("orgIds:{}", orgIds);
        Page page = PageHelper.startPage (areaSearchBean.getPageNum (), areaSearchBean.getPageSize (), true);
        List<Area> areaList = areaMapper.getAreaList (areaSearchBean, orgIds);

        List<AreaInfoBean> areaBean = areaCoverter.getAreaInfoList (areaList);
        log.info ("areaBean:{}", areaBean);
        PageInfo<AreaInfoBean> pageInfo = new PageInfo<AreaInfoBean> (areaBean, page);
//        int total = (int) page.getTotal();
//        pageInfo.setTotal(total);
        return pageInfo;
    }

    /**
     * 根据机构id获取区域列表
     * @param id
     * @return
     */
    public List<AreaNameBean>  getAreaNameList(Integer id) {
        if (id == null || id.intValue () <=0) {
            return Lists.newArrayList ();
        }

        List<OrganizationDO> organizationDTOList = organizationService.listSelfAndChildren (id.longValue ());
        if (CollectionUtils.isEmpty (organizationDTOList)) {
            organizationDTOList = Lists.newArrayList ();
        }

        List<Long> orgIds = organizationDTOList.stream ().filter (organizationDO -> organizationDO.getType () == 1).map (OrganizationDO::getId).collect (Collectors.toList ());
        if (CollectionUtils.isEmpty (orgIds)) {
            return Lists.newArrayList ();
        }
        List<Area> areaList = areaMapper.getAreaNameList (orgIds);
        return areaCoverter.getAreaNameListBean (areaList);

    };




    /**
     * 添加分区
     *
     * @param areaBean
     * @return int
     */
    @Transactional
    public int add(AreaBean areaBean) {
        log.info ("add area:{}", areaBean);
        if (StringUtils.isAllBlank (areaBean.getTitle ())) {
            throw new BusinessException (MsgReturnEnum.AREA_TITLE.code (), MsgReturnEnum.AREA_TITLE.message ());
        }
        if (areaBean.getOrgId () == null || areaBean.getOrgId ().intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.AREA_ORGNAME.code (), MsgReturnEnum.AREA_ORGNAME.message ());
        }
        if (areaBean.getDepartmentId () == null || areaBean.getDepartmentId ().intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.AREA_DEPTMENTNAME.code (), MsgReturnEnum.AREA_DEPTMENTNAME.message ());
        }
        Integer count = selectByDepId (areaBean);
        if (count == 0) {

            Area area = areaCoverter.getArea (areaBean);
            //area.setCreateBy("小明");
            area.setCreateBy (UserInfo.getCurrentUserInfo().getUsername());
            area.setCreateTime (LocalDateTime.now ());
            //area.setCreateUserId(11);
            area.setCreateUserId (UserInfo.getCurrentUserId ());
            log.info ("add area:{}", area);
            return areaMapper.insertArea (area);
        }
        throw new BusinessException (MsgReturnEnum.AREA_DEPTMENTNAMEREPEAT.code (), MsgReturnEnum.AREA_DEPTMENTNAMEREPEAT.message ());

    }


    /**
     * 根据分区id删除
     *
     * @param id
     * @return int
     */
    @Transactional
    public int deleteAreaById(String id) {
        log.info ("deleteAreaById id:{}", id);
        if (id == null || id.equals("")) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND.code (), MsgReturnEnum.ID_NOFAND.message ());
        }
        String[] ids = id.split(",");
        return areaMapper.deleteAreaById (ids);
    }


    /**
     * 分区更新
     *
     * @param id
     * @param areaBean
     * @return
     */
    @Transactional
    public int updateArea(Integer id, AreaBean areaBean) {
        log.info ("update id:{} area:{}", id, areaBean);

        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.PARAMETER_NOT_NULL.code (), MsgReturnEnum.PARAMETER_NOT_NULL.message ());
        }
        if (StringUtils.isAllBlank (areaBean.getTitle ())) {
            throw new BusinessException (MsgReturnEnum.AREA_TITLE.code (), MsgReturnEnum.AREA_TITLE.message ());
        }
        if (areaBean.getDepartmentId () == null || areaBean.getDepartmentId ().intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.AREA_DEPTMENTNAME.code (), MsgReturnEnum.AREA_DEPTMENTNAME.message ());
        }

//        int count = selectByDepId (areaBean);
//        if (count == 0) {
            Area area = areaCoverter.getArea (areaBean);
            area.setId (id);
            //area.setCreateBy("小明");
            area.setUpdateBy (UserInfo.getCurrentUserInfo().getUsername());
            area.setUpdateTime (LocalDateTime.now ());
            log.info ("update area:{}", area);
            return areaMapper.updateArea (area);
//        }
//        throw new BusinessException (MsgReturnEnum.AREA_DEPTMENTNAMEREPEAT.code (), MsgReturnEnum.AREA_DEPTMENTNAMEREPEAT.message ());
    }


    /**
     * 查询部门有没有相同的分区名称
     *
     * @param areaBean
     * @return selectByDepId
     */
    private int selectByDepId(AreaBean areaBean) {

        int count = areaMapper.selectByDepId (areaBean.getDepartmentId (),areaBean.getTitle ());

        return count;
    }

    public List<Area> listByIds(List<Integer> idList) {
        return areaMapper.listByIds(idList);
    }
}

package com.boe.bank.service.department;

import ch.qos.logback.core.rolling.helper.IntegerTokenConverter;
import com.boe.bank.beanconverter.DepartmentCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.department.DepartmentBean;
import com.boe.bank.common.bean.department.DepartmentConBean;
import com.boe.bank.common.bean.department.DepartmentDeleteBean;
import com.boe.bank.common.bean.department.DepartmentListBean;
import com.boe.bank.common.constant.AuditTypeEnum;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.department.SysDepartmentAudit;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.mapper.department.SysDepartmentAuditMapper;
import com.boe.bank.mapper.userInfoMapper.UserInfoMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.cloud.megarock.user.javabean.bo.OrganizationBO;
import com.boe.cloud.megarock.user.javabean.dto.OrganizationDTO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class SysDepartmentAuditService {

    @Resource
    private SysDepartmentAuditMapper sysDepartmentAuditMapper;

    @Resource
    private RedissionUtils redissionUtils;

    @Autowired
    private OrganizationService organizationService;

    @Autowired
    private UserInfoMapper userInfoMapper;

    @Resource
    private DepartmentCoverter departmentCoverter;
    
	public PageInfo<DepartmentListBean> getList(DepartmentConBean bean) {
		if (bean.getPageNum() == null || bean.getPageNum() < 1) {
			bean.setPageNum(Const.PAGE_NUM_DEFAULT);
		}
		if (bean.getPageSize() == null || bean.getPageSize() < 0) {
			bean.setPageSize(Const.PAGE_SIZE_DEFAULT);
		}
		try {
			Page page = PageHelper.startPage(bean.getPageNum(), bean.getPageSize(), true);
			List<DepartmentListBean> lst = sysDepartmentAuditMapper.getList(bean);
			if (CollectionUtils.isEmpty(lst)) {
				lst = Lists.newArrayList();
			}
			PageInfo<DepartmentListBean> pageInfo = new PageInfo<DepartmentListBean>(lst,page);
			log.info("获取部门分页列表 getList pageNum:{},pageSize:{}size:{}", bean.getPageNum(), bean.getPageSize(), lst.size());
			return pageInfo;
		} finally {
			PageHelper.clearPage();
		}
	}

	public Integer add(OrganizationBO organizationBO, Integer isAudit) {
		Integer res = 1;
		OrganizationDTO organizationDTO;
		try{
			organizationDTO = organizationService.add(organizationBO);
		}catch (Exception e){
			throw new BusinessException(e.getMessage());
		}
		if(organizationDTO == null) {
			res = 0;
			throw new BusinessException(MsgReturnEnum.DEPART_ADD);
		}
		//保存部门审批权限
		SysDepartmentAudit audit = new SysDepartmentAudit(); 
		audit.setDepartmentId(organizationDTO.getId());
		if(AuditTypeEnum.IS_AUDIT.getCode() == isAudit.intValue()) {//有审批权限
			audit.setIsAudit(true);
		}else if(AuditTypeEnum.NO_AUDIT.getCode() == isAudit.intValue()){
			audit.setIsAudit(false);
		}
		setAuditGeneral(audit);
		int ares = sysDepartmentAuditMapper.insertSelective(audit);
		log.info("添加部门审批权限信息结果  ares：{}",ares);

		return res;
	}

	public DepartmentBean getDepartInfo(Integer id) {
		OrganizationDTO res = organizationService.get(id.longValue());
		DepartmentBean bean = departmentCoverter.getDepartmentBean(res);
		//是否具有审批权限
		SysDepartmentAudit audit = sysDepartmentAuditMapper.getAudit(res.getId().intValue());
		if(audit != null && audit.getIsAudit()) {
			bean.setIsAudit(AuditTypeEnum.IS_AUDIT.getCode());
		}else {
			bean.setIsAudit(AuditTypeEnum.NO_AUDIT.getCode());
		}
		return bean;
	}

	public Integer updateDepart(DepartmentBean bean) {
		OrganizationBO orgBO = departmentCoverter.getOrganizationBO(bean);
//		//更新部门基本信息
		boolean ures;
		try{
			ures = organizationService.edit(bean.getId().longValue(), orgBO);
		}catch (Exception e){
			throw new BusinessException(e.getMessage());
		}
		log.info("更新部门基本信息结果  ures：{}",ures);
		if(!ures) {
			throw new BusinessException(MsgReturnEnum.DEPART_UPDATE);
		}
		//更新审批权限
		SysDepartmentAudit audit = sysDepartmentAuditMapper.getAudit(bean.getId());
		if(AuditTypeEnum.IS_AUDIT.getCode() == bean.getIsAudit()) {
			audit.setIsAudit(true);
		}else if(AuditTypeEnum.NO_AUDIT.getCode() == bean.getIsAudit()){
			audit.setIsAudit(false);
		}
		setAuditGeneral(audit);
		int res = sysDepartmentAuditMapper.updateByPrimaryKeySelective(audit);
		log.info("更新部门审批权限结果  res：{}",res);
		if(res < 1) {
			throw new BusinessException(MsgReturnEnum.DEPART_AUDIT_UPDATE);
		}
		return res;
	}
	
	public void setAuditGeneral(SysDepartmentAudit audit) {
		audit.setDateCreated(new Date());
		audit.setDateUpdated(new Date());
		audit.setCreatedBy(UserInfo.getCurrentUserInfo().getUsername());
		audit.setUpdatedBy(UserInfo.getCurrentUserInfo().getUsername());
	}

	public Integer deleteDepart(Integer id) {
		//确保没有下级部门、人员才可以删除？？？
		try {
            List<Long> ids =Lists.newArrayList();
			ids.add(id.longValue());
			Integer count  = userInfoMapper.selectCountBydepartmentId(ids);
			if(count>0){
				throw new BusinessException(MsgReturnEnum.DEPART_USER);
			}
			organizationService.delete(id.longValue());
		}catch (Exception e){
			throw new BusinessException(e.getMessage());
		}
		//删除成功后，删除部门审批权限
		int res = sysDepartmentAuditMapper.deleteByDepartId(id);
		if(res < 1) {
			throw new BusinessException(MsgReturnEnum.DEPART_AUDIT_DELETE);
	}
		return res;
	}
	/**
	* @Description:批量删除部门
	* @param id
	* @return
	* @author: zhaohaixia
	* @date: 2020年11月2日 下午3:30:18
	 */
	@Transactional
	public Integer deleteDeparts(DepartmentDeleteBean bean) {

		//确保没有下级部门、人员才可以删除
		Integer count  = userInfoMapper.selectCountBydepartmentId(bean.getIds());
		if(count>0){
			throw new BusinessException(MsgReturnEnum.DEPART_USER);
		}
		organizationService.delete(bean.getIds());
		//删除成功后，删除部门审批权限
		int res = sysDepartmentAuditMapper.deleteByIds(bean.getIds());
		if(res < 1) {
			throw new BusinessException(MsgReturnEnum.DEPART_AUDIT_DELETE);
		}
		return res;
	}

}

package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.boe.bank.beanconverter.EquipmentSpotsConverter;
import com.boe.bank.common.bean.equipment.EquipmentPlanDTO;
import com.boe.bank.common.bean.equipment.EquipmentSpotsQO;
import com.boe.bank.common.bean.equipment.EquipmentSpotsVO;
import com.boe.bank.common.entity.equipment.EquipmentSpots;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.equipment.EquipmentSpotsMapper;
import com.boe.bank.service.equipment.EquipmentSpotsService;
import com.boe.bank.service.planmanageService.PlanManageService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 设备插播记录 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/30
 */
@Service("equipmentSpotsService")
public class EquipmentSpotsServiceImpl extends ServiceImpl<EquipmentSpotsMapper, EquipmentSpots> implements EquipmentSpotsService {

    @Autowired
    private PlanManageService planManageService;
    @Autowired
    private OrganizationService organizationService;

    @Override
    public void spots(String mac, EquipmentPlanDTO dto) {
        UserInfo userInfo = UserInfo.getCurrentUserInfo();
        List<PlanManage> planList = planManageService.listByIds(dto.getPlanIds(), false);
        for (PlanManage plan : planList) {
            EquipmentSpots entity = new EquipmentSpots();
            entity.setMac(mac);
            entity.setPlanName(plan.getTitle());
            entity.setBeginTime(plan.getBeginTime());
            entity.setEndTime(plan.getEndTime());
            entity.setPlanTime(plan.getPlanTime());
            entity.setOrgId(userInfo.getOrgId());
            entity.setCreateBy(userInfo.getUsername());
            entity.setCreateTime(LocalDateTime.now());
            getBaseMapper().insert(entity);
        }
    }

    @Override
    public IPage<EquipmentSpotsVO> page(EquipmentSpotsQO qo) {
        ObjectUtil.setPageNumAndPageSizeDefault(qo);
        LambdaQueryWrapper<EquipmentSpots> wrapper = Wrappers.lambdaQuery(EquipmentSpots.class)
                .eq(StringUtils.isNotBlank(qo.getMac()), EquipmentSpots::getMac, qo.getMac())
                .eq(qo.getOrgId() != null, EquipmentSpots::getOrgId, qo.getOrgId())
                .like(StringUtils.isNotBlank(qo.getPlanName()), EquipmentSpots::getPlanName, qo.getPlanName())
                .like(StringUtils.isNotBlank(qo.getCreateBy()), EquipmentSpots::getCreateBy, qo.getCreateBy())
                .orderByDesc(EquipmentSpots::getCreateTime);
        Page<EquipmentSpots> page = getBaseMapper().selectPage(new Page<>(qo.getPageNum(), qo.getPageSize()), wrapper);
        List<EquipmentSpots> records = page.getRecords();
        List<OrganizationDO> orgList = null;
        if (CollectionUtils.isNotEmpty(records)) {
            List<Long> orgIdList = records.stream().map(EquipmentSpots::getOrgId).distinct().collect(Collectors.toList());
            orgList = organizationService.selectBatch(orgIdList);
        }
        List<OrganizationDO> finalOrgList = orgList;
        return page.convert(spots -> convet(spots, finalOrgList));
    }

    private EquipmentSpotsVO convet(EquipmentSpots spots, List<OrganizationDO> orgList) {
        if (spots == null) {
            return null;
        }
        EquipmentSpotsVO spotsVO = EquipmentSpotsConverter.INSTANCE.entityToVo(spots);
        if (CollectionUtils.isNotEmpty(orgList)) {
            OrganizationDO org = orgList.stream().filter(o -> spotsVO.getOrgId().equals(o.getId())).findFirst().orElse(null);
            spotsVO.setOrgName(org == null ? "" : org.getName());
        }
        return spotsVO;
    }
}

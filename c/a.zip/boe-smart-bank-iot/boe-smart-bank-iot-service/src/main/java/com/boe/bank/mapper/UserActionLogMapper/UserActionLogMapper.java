package com.boe.bank.mapper.UserActionLogMapper;

import org.apache.ibatis.annotations.Insert;

import com.boe.bank.common.entity.UserActionLog.UserActionLog;

public interface UserActionLogMapper {

	@Insert({ "insert into user_action_log(face_id, create_time, condition_action_type,product_id) "
			+ "values(#{faceId}, #{createTime, jdbcType=TIMESTAMP}, #{conditonActionType},#{actionProductId})" })
    public int insert(UserActionLog userActionLog);
}

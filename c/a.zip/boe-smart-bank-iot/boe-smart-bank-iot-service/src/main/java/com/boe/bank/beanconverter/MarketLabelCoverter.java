package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.marketLabel.MarketLabelBean;
import com.boe.bank.common.bean.marketLabel.MarketLabelInfoBean;
import com.boe.bank.common.bean.marketLabel.MarketLabelsTreeBean;
import com.boe.bank.common.entity.marketLabel.MarketLabel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * @Description:转义
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Mapper(componentModel = "spring")
public interface MarketLabelCoverter {

    MarketLabel getMarketLabel(MarketLabelInfoBean marketLabelInfoBean);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(marketLabel.getCreateTime()))")
    })
    MarketLabelBean getMarketLabelBean(MarketLabel marketLabel);

    List<MarketLabelBean> getMarketLabelBeans(List<MarketLabel> marketLabel);

    @Mappings({
            @Mapping(target = "parentId", expression = "java(marketLabel.getParentId().longValue())"),
            @Mapping(target = "id", expression = "java(marketLabel.getId().longValue())")
    })
    MarketLabelsTreeBean getMarketLabelsTreeBean(MarketLabel marketLabel);

    List<MarketLabelsTreeBean> getMarketLabelsTreeBeans(List<MarketLabel> marketLabels);
}

package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentSpots;

/**
 * 设备插播记录 Mapper
 *
 * @author 10183279
 * @date 2020/10/30
 */
public interface EquipmentSpotsMapper extends BaseMapper<EquipmentSpots> {

}

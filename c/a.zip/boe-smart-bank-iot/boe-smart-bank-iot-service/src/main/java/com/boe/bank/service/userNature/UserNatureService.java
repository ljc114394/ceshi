package com.boe.bank.service.userNature;

import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.userNature.*;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.userNatureInfoMapper.UserNatureInfoMapper;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description:
 * @Author: lijianglong
 * @Data:2020/12/17
 */

@Service
@Slf4j
public class UserNatureService {

    @Autowired
    private UserNatureInfoMapper userNatureInfoMapper;

    /**
     * 人脸库
     * @param userNatureSearchDTO
     * @return
     */
    public PageInfo<UserNatureDTO> userNaturePage(UserNatureSearchDTO userNatureSearchDTO) {
        log.info("query UserNature:{}", userNatureSearchDTO);
        ObjectUtil.setPageNumAndPageSizeDefault(userNatureSearchDTO);
        Page page = PageHelper.startPage(userNatureSearchDTO.getPageNum(), userNatureSearchDTO.getPageSize(), true);
        List<UserNatureDTO> userNatureDTOS = userNatureInfoMapper.userNaturePage(userNatureSearchDTO);
        log.info("query UserNature.size():", userNatureDTOS.size());
        return new PageInfo<UserNatureDTO>(userNatureDTOS, page);
    }

    /**
     *
     * 埋点统计
     * @param userActionSearchDTO
     * @return
     */
    public PageInfo<UserActionDTO> userActionPage(UserActionSearchDTO userActionSearchDTO) {
        log.info("query UserNature:{}", userActionSearchDTO);
        ObjectUtil.setPageNumAndPageSizeDefault(userActionSearchDTO);
        Page page = PageHelper.startPage(userActionSearchDTO.getPageNum(), userActionSearchDTO.getPageSize(), true);
        userActionSearchDTO.setConditionType(3);//现在只有点击次数可以统计  其他类型统计不了
        List<UserActionDTO> userActionDTOS = userNatureInfoMapper.userActionPage(userActionSearchDTO);
        log.info("query UserNature.size():", userActionDTOS.size());
        return new PageInfo<UserActionDTO>(userActionDTOS, page);
    }


    /**
     * 首页-数据分析-埋点数据
     * @param userActionSearchDTO
     * @return
     */
    public List<UserActionHeadDTO> buriedPointData() {
        log.info("query 首页-数据分析-埋点数据:{}");
        Integer conditionType = 3;//现在只有点击次数可以统计  其他类型统计不了
        return userNatureInfoMapper.buriedPointData(conditionType);
    }

}

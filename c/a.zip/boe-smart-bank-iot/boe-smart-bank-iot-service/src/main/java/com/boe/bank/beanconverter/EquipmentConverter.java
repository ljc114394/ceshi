package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.equipment.EquipmentDTO;
import com.boe.bank.common.bean.equipment.EquipmentVO;
import com.boe.bank.common.entity.equipment.Equipment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * 设备相关类转换器
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Mapper
public interface EquipmentConverter {

    EquipmentConverter INSTANCE = Mappers.getMapper(EquipmentConverter.class);

    /**
     * dto转为entity
     * @param dto
     * @return
     */
    Equipment dtoToEntity(EquipmentDTO dto);

    /**
     * entity转为vo
     * @param entity
     * @return
     */
    @Mappings({
            @Mapping(source = "createTime", target = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "updateTime", target = "updateTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    EquipmentVO entityToVo(Equipment entity);
}

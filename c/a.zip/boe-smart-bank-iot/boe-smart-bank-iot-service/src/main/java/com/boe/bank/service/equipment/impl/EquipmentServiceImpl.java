package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.boe.bank.beanconverter.EquipmentConverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.datarolebean.DataRoleOrgBean;
import com.boe.bank.common.bean.equipment.*;
import com.boe.bank.common.constant.*;
import com.boe.bank.common.entity.area.Area;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.common.entity.equipment.EquipmentType;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.common.utils.StringUtil;
import com.boe.bank.mapper.equipment.EquipmentMapper;
import com.boe.bank.netty.NettyService;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.bank.service.areaService.AreaService;
import com.boe.bank.service.dataroleService.DataRoleService;
import com.boe.bank.service.equipment.EquipmentConfigService;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.bank.service.equipment.EquipmentStatusService;
import com.boe.bank.service.equipment.EquipmentTypeService;
import com.boe.bank.service.uploadService.UploadService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.google.common.collect.Lists;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 设备 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Slf4j
@Service("equipmentService")
public class EquipmentServiceImpl extends ServiceImpl<EquipmentMapper, Equipment> implements EquipmentService {

    @Value("${url.server:}")
    private String serverUrl;

    @Autowired
    private EquipmentConfigService equipmentConfigService;
    @Autowired
    private EquipmentStatusService equipmentStatusService;
    @Autowired
    private EquipmentTypeService equipmentTypeService;
    @Autowired
    private ActivitiOptionService activitiOptionService;
    @Autowired
    private AreaService areaService;
    @Autowired
    private UploadService uploadService;
    @Autowired
    private RedissionUtils redissionUtils;
    @Autowired
    private NettyService nettyService;
    @Autowired
    private DataRoleService dataRoleService;

    @Autowired
    private ActivitiOuterRelationService activitiOuterRelationService;

    @SneakyThrows
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(Equipment entity) {
        entity.setMac(entity.getMac().toUpperCase());
        Equipment equ = getByMac(entity.getMac());
        if (equ != null) {
            throw new BusinessException(MsgReturnEnum.EQUMENT_MAC);
        }
        entity.setAuditStatus(ActivitiConstants.ExamineStatus.undo);
        int ret = getBaseMapper().insert(entity);
        if (ret == 0) {
            return false;
        }
        // 初始化设备配置，设置屏幕区域布局
        equipmentConfigService.init(entity.getMac());

        redissionUtils.getRBucket(StringUtil.appendToStr(RedisPrefix.EQU_MAC, entity.getMac())).set(entity.getId(), 30, TimeUnit.DAYS);

        Long userId = UserInfo.getCurrentUserId();
        Result result = activitiOptionService.submit(userId.toString(), ActivitiConstants.BusniessType.device, null, entity.getId(), null);
        if (!result.isSuccess()) {
          if ((result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR.code())||
                  (result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE.code()))  {
            // 没有审批流，则将设备的状态直接改为审批通过
            entity.setAuditStatus(ActivitiConstants.ExamineStatus.pass);
            ret = getBaseMapper().updateById(entity);
          }else {
              throw new Exception("审批异常,请重新添加");
          }
        }
        return ret == 1;
    }

    @SneakyThrows
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean update(EquipmentDTO dto, Integer id) {
        dto.setMac(dto.getMac().toUpperCase());
        Equipment equ = getByMac(dto.getMac());
        if (equ != null && !equ.getId().equals(id)) {
            throw new BusinessException(MsgReturnEnum.EQUMENT_MAC);
        }
        Equipment oldEqu = getById(id);
        String key = StringUtil.appendToStr(RedisPrefix.EQU_MAC, oldEqu.getMac());
        if (redissionUtils.getRBucket(key).isExists()) {
            redissionUtils.getRBucket(key).delete();
        }
        Equipment entity = EquipmentConverter.INSTANCE.dtoToEntity(dto);
        entity.setId(id);
        boolean ret = updateById(entity);
        log.info("更新设备，ret={}", ret);
        int res =0;
        if(ret){
            Long userId = UserInfo.getCurrentUserId();
            if(!oldEqu.getOrgId().equals(dto.getOrgId()) || oldEqu.getAreaId() != dto.getAreaId() || oldEqu.getTypeId() != dto.getTypeId()){
                activitiOuterRelationService.abandon(ActivitiConstants.BusniessType.plan, entity.getId(), null);
                // 重置审批状态
                entity.setAuditStatus(ActivitiConstants.ExamineStatus.undo);
                res = getBaseMapper().updateById(entity);
            }
            Result result = activitiOptionService.submit(userId.toString(), ActivitiConstants.BusniessType.device, null, entity.getId(), null);
            if (!result.isSuccess()) {
                if ((result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR.code())||
                        (result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE.code()))  {
                    // 没有审批流，则将设备的状态直接改为审批通过
                    entity.setAuditStatus(ActivitiConstants.ExamineStatus.pass);
                    res = getBaseMapper().updateById(entity);
                    if(res<1){
                        throw new Exception("更新审批异常,请重新添加");
                    }
                }else {
                    throw new Exception("审批异常,请重新添加");
                }
            }
        }
        return res ==1;
    }

    @Override
    public IPage<EquipmentVO> page(EquipmentQO qo) {
        // 本机构和数据授权中勾选的机构列表
        List<DataRoleOrgBean> orgList = dataRoleService.getDataRoleByRoleList();
        ObjectUtil.setPageNumAndPageSizeDefault(qo);
        if (qo.getOrgId() == null) {
            // 当前机构下的用户只能查看并编辑当前机构与数据授权中勾选的机构中的设备数据
            qo.setOrgIds(orgList.stream().map(o -> o.getId().longValue()).collect(Collectors.toList()));
        }
        IPage<EquipmentVO> page = getBaseMapper().selectPageVO(new Page<>(qo.getPageNum(), qo.getPageSize()), qo);
        List<EquipmentVO> records = page.getRecords();
        if (CollectionUtils.isEmpty(records)) {
            return page;
        }
        List<Integer> areaIdList = records.stream().map(EquipmentVO::getAreaId).distinct().collect(Collectors.toList());
        List<Area> areaList = null;
        if (CollectionUtils.isNotEmpty(areaIdList)) {
            areaList = areaService.listByIds(areaIdList);
        }
        // 设备类型
        List<EquipmentType> typeList = equipmentTypeService.list();
        List<Area> finalAreaList = areaList;
        return page.convert(equipment -> convert(equipment, orgList, finalAreaList, typeList));
    }

    @Override
    public Equipment getByMac(String mac) {
        return ChainWrappers.lambdaQueryChain(getBaseMapper()).eq(Equipment::getMac, mac).one();
    }

    @Override
    public List<Equipment> getLikeName(String name) {
        return ChainWrappers.lambdaQueryChain(getBaseMapper()).like(Equipment::getName, name).list();
    }

    @Override
    public void sendCommand(EquipmentCommandDTO commandDTO) {
        List<Equipment> list = ChainWrappers.lambdaQueryChain(getBaseMapper()).in(Equipment::getId, commandDTO.getIdList()).list();
        if (CollectionUtils.isNotEmpty(list)) {
            for (Equipment equ : list) {
                nettyService.sendMessage(equ.getMac(), commandDTO.getCommand());
            }
        }
    }

    @Override
    public void upgradeVersion(EquipmentUpgradeDTO dto) {
        String url;
        String md5;
        MultipartFile file = dto.getFile();
        try {
            url = uploadService.upload(UploadTypeEnum.PROGRAM.getCode(), file);
            md5 = DigestUtils.md5Hex(new FileInputStream(url));
        } catch (Exception e) {
            log.error("升级失败！设备[mac={}]升级包[file={}]上传失败", dto.getMac(), file.getOriginalFilename());
            throw new BusinessException("升级包上传失败");
        }
        // 升级包指令
        String command = EquipmentCommandEnum.UPGRADE.getCode() + ";" + (serverUrl + url).replaceAll("//", "/") + ";" + md5 + ";" + file.getSize();
        nettyService.sendMessage(dto.getMac(), command);
    }

    @Override
    public void printScreen(String mac) {
        nettyService.sendMessage(mac, EquipmentCommandEnum.SCREENSHOT.getCode());
    }

    @Override
    public Integer getEquId(String mac) {
        if (StringUtils.isBlank(mac)) {
            log.info("getEquId mac:{}为空", mac);
            return 0;
        }
        String key = StringUtil.appendToStr(RedisPrefix.EQU_MAC, mac);
        try {
            if (redissionUtils.getRBucket(key).isExists()) {
                return (Integer) redissionUtils.getRBucket(key).get();
            } else {
                Equipment equ = getByMac(mac);
                if (equ != null) {
                    redissionUtils.getRBucket(key).set(equ.getId(), 30, TimeUnit.DAYS);
                    return equ.getId();
                } else {
                    log.info("getEquId mac:{} db获取为空", mac);
                    return 0;
                }
            }
        } catch (Exception e) {
            return getByMac(mac).getId();
        }
    }


    private EquipmentVO convert(EquipmentVO equipmentVO, List<DataRoleOrgBean> orgList, List<Area> areaList, List<EquipmentType> typeList) {
        if (equipmentVO == null) {
            return null;
        }
        DataRoleOrgBean org = orgList.stream().filter(o -> equipmentVO.getOrgId().equals(o.getId().longValue())).findFirst().orElse(null);
        equipmentVO.setOrgName(org == null ? "" : org.getName());
        if (CollectionUtils.isNotEmpty(areaList)) {
            Area area = areaList.stream().filter(o -> o.getId().equals(equipmentVO.getAreaId())).findFirst().orElse(null);
            equipmentVO.setAreaName(area == null ? "" : area.getTitle());
        }
        EquipmentType equipmentType = typeList.stream().filter(o -> o.getId().equals(equipmentVO.getTypeId())).findFirst().orElse(null);
        equipmentVO.setTypeName(equipmentType == null ? "" : equipmentType.getName());
        if (equipmentVO.getIsOnline() == null) {
            equipmentVO.setIsOnline(EquipmentStatusEnum.OFFLINE.getCode());
        }
        return equipmentVO;
    }

    /**
     * 获取在线和离线的设备数量
     *
     * @return countByIsOnline
     */
    @Override
    public List<EquipmentCount> countByIsOnline() {
        EquipmentQO qo = new EquipmentQO();

        //数据授权中勾选的机构列表
        List<DataRoleOrgBean> orgList = dataRoleService.getDataRoleByRoleList();
        if (CollectionUtils.isNotEmpty(orgList)) {
            // 当前机构下的用户只能查看并编辑当前机构与数据授权中勾选的机构中的设备数据
            qo.setOrgIds(orgList.stream().map(o -> o.getId().longValue()).collect(Collectors.toList()));
        }
        qo.setIsOnline(1);//在线
        List<EquipmentCount> list = Lists.newArrayList();
        EquipmentCount equipmentCount = new EquipmentCount();
        List<EquipmentVO> zlist = getBaseMapper().selectPageVO(qo);
        equipmentCount.setName("在线设备");
        equipmentCount.setValue(zlist.size());
        list.add(equipmentCount);
        qo.setIsOnline(2);//在线
        List<EquipmentVO> llist = getBaseMapper().selectPageVO(qo);
        EquipmentCount equipmentCounta = new EquipmentCount();
        equipmentCounta.setName("离线设备");
        equipmentCounta.setValue(llist.size());
        list.add(equipmentCounta);
        return  list;
    }
}

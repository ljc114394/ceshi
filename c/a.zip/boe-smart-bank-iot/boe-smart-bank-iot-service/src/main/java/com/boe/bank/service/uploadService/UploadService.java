package com.boe.bank.service.uploadService;

import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.UploadDir;
import com.boe.bank.common.constant.UploadTypeEnum;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.util.UploadUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/26
 */
@Service
@Slf4j
public class UploadService {

    //上传文件地址
    @Value("${upload.upath:}")
    private String upath;
    //素材上传地址
    @Value("${material.path:}")
    private String path;

    /**
     * 处理上传的文件
     */
    public String upload(Integer type, MultipartFile mfile) {
        if (mfile == null || mfile.isEmpty() || type == null || type <= 0) {
            //文件不能为空
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
        //处理上传的文件
        String originFileName = mfile.getOriginalFilename();
        // 获取文件后缀
        String subfix = originFileName.substring(originFileName.indexOf('.') + 1);
        String uuid = UUID.randomUUID().toString() + "." + subfix;
        String fileName = uuid.toString().replaceAll("\\-", "");
//        String fileName = DateUtil.formatlong2(new Date()) + "." + subfix;
        String endPath = "";
        if (UploadTypeEnum.PIC.getCode() == type) {
            endPath = UploadDir.PIC;
        } else if (UploadTypeEnum.VIDEO.getCode() == type) {
            endPath = UploadDir.VIDEO;
        } else if (UploadTypeEnum.DOCUMENT.getCode() == type) {
            endPath = UploadDir.DOCUMENT;
        } else if (UploadTypeEnum.PROGRAM.getCode() == type) {
            endPath = UploadDir.PROGRAM;
        } else if (UploadTypeEnum.XML.getCode() == type) {
            endPath = UploadDir.XML;
        }

        String filePath = upath + endPath;
        if (UploadUtil.saveMaterialFile(mfile, filePath, fileName)) {
            if(upath.contains(":")){
                String up = upath.substring(upath.indexOf(":")+1);
                return up + endPath + "/" + fileName;
            }
            return upath + endPath + "/" + fileName;
        } else {
            throw new BusinessException(MsgReturnEnum.FILE_EXCEP);
        }
    }
    /**
     * 处理上传的文件-包含自定义路径
     */
    public String productUpload( MultipartFile mfile,String customPath,Integer type) {
        if (mfile == null || mfile.isEmpty() ) {
            //文件不能为空
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
        //处理上传的文件
        String originFileName = mfile.getOriginalFilename();
        // 获取文件后缀
        String subfix = originFileName.substring(originFileName.indexOf('.') + 1);
        String uuid = UUID.randomUUID().toString() + "." + subfix;
        String fileName = uuid.toString().replaceAll("\\-", "");
//        String fileName = DateUtil.formatlong2(new Date()) + "." + subfix;
        String endPath = "";
        if (UploadTypeEnum.PIC.getCode() == type) {
            endPath = UploadDir.PIC;
        } else if (UploadTypeEnum.VIDEO.getCode() == type) {
            endPath = UploadDir.VIDEO;
        } else if (UploadTypeEnum.DOCUMENT.getCode() == type) {
            endPath = UploadDir.DOCUMENT;
        } else if (UploadTypeEnum.PROGRAM.getCode() == type) {
            endPath = UploadDir.PROGRAM;
        } else if (UploadTypeEnum.XML.getCode() == type) {
            endPath = UploadDir.XML;
        }
        String filePath = upath +customPath+"/" + endPath;
        if (UploadUtil.saveMaterialFile(mfile, filePath, fileName)) {
            if(upath.contains(":")){
                String up = upath.substring(upath.indexOf(":")+1);
                return up+customPath+"/" + endPath+ "/" + fileName;
            }
            return filePath + "/" + fileName;
        } else {
            throw new BusinessException(MsgReturnEnum.FILE_EXCEP);
        }
    }


    /**
     * 处理上传的多文件
     */
    public List<Map> uploadList(Integer type, MultipartFile[] mfiles) {
        if (mfiles.length == 0 || type == null || type <= 0) {
            //文件不能为空
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
        // 获取文件后缀
        String mpath = "";
        if (UploadTypeEnum.PIC.getCode() == type) {
            mpath = UploadDir.PIC;
        } else if (UploadTypeEnum.VIDEO.getCode() == type) {
            mpath = UploadDir.VIDEO;
        } else if (UploadTypeEnum.DOCUMENT.getCode() == type) {
            mpath = UploadDir.DOCUMENT;
        } else if (UploadTypeEnum.PROGRAM.getCode() == type) {
            mpath = UploadDir.PROGRAM;
        } else if (UploadTypeEnum.XML.getCode() == type) {
            mpath = UploadDir.XML;
        }
        //处理上传的文件
        List<Map> filePathList = new ArrayList<>();
        for (MultipartFile mfile :mfiles) {
            String originFileName =  mfile.getOriginalFilename();
            String title = originFileName.substring(0,originFileName.indexOf('.'));
            String subfix = originFileName.substring(originFileName.indexOf('.') + 1);
//            String fileName = DateUtil.formatlong3(new Date()) + "." + subfix;
            String uuid = UUID.randomUUID().toString() + "." + subfix;
            String fileName = uuid.toString().replaceAll("\\-", "");
            String dirPath = path + mpath;
            int size = (int) mfile.getSize();
            //文件md5值
            String md5 = "";
            try {
                md5 =(DigestUtils.md5Hex(mfile.getInputStream()));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            if (UploadUtil.saveMaterialFile(mfile, dirPath, fileName)) {
                Map matMap = new HashMap();
                matMap.put("title",title);
                matMap.put("url",dirPath + "/" + fileName);
                matMap.put("md5",md5);
                matMap.put("size",size);
                filePathList.add(matMap);
            } else {
                throw new BusinessException(MsgReturnEnum.FILE_EXCEP);
            }
        }
        return filePathList;
    }
}

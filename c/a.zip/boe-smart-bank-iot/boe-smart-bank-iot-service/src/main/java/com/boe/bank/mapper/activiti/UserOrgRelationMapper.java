package com.boe.bank.mapper.activiti;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.bean.user.OrgAncestorDo;
import com.boe.bank.common.bean.user.UserOrgDo;

/**
 * 用户，部门，机构关系
 * @author caoxuhao
 */
@Mapper
public interface UserOrgRelationMapper {
	
	/**
	 * 查询一个部门下的所有人 sys_user
	 * @param depIds
	 * @return
	 */
	public List<Long> selectUserIdByDep(Long depId);

	/**
	 * 查询多个部门下的所有人	sys_user
	 * @param depIds
	 * @return
	 */
	public List<UserOrgDo> selectDepByUserIds(@Param("userIds")List<Long> userIds);

    /**
     * 查询一个机构下所有的部门	sys_organization
     * @param orgId
     * @return
     */
	public List<Long> selectDepIdByOrg(String orgId);
	
	/**
	 * 获取有某个组织权限的，角色列表
	 * @param orgId
	 * @param roleIds
	 * @return
	 */
	public List<Integer> selectRoleByRolesAndOrg(@Param("orgId")Integer orgId, @Param("roleIds")List<Integer> roleIds);
	
	/**
	 * 根据角色获取用户
	 * @param roleIds
	 * @return
	 */
	public List<Long> selectUserIdByRoles(@Param("roleIds")List<Integer> roleIds);
	
	/**
	 * 根据组织架构和用户列表，获取用户id
	 * @param orgIds
	 * @param userIds
	 * @return
	 */
	public List<Long> selectUserIdByOrgAndUserIds(@Param("orgIds")List<Long> orgIds, @Param("userIds")List<Long> userIds);
	
	/**
     * 查询父级机构id	sys_organization
     * @param orgId
     * @return
     */
	public Long selectFatherByOrg(Long orgId);
	
	/**
	 * 获取同级机构的部门  sys_organization
	 * @param orgId
	 * @return
	 */
	public List<Long> selectDepBySameOrg(Long orgId);
	
	/**
	 * 查询所有祖先机构  sys_organization
	 * @param orgId
	 * @return
	 */
	public OrgAncestorDo selectAncestorByOrg(Long orgId);
	
	/**
     * 查询一个机构下直属的部门	sys_organization
     * @param orgId
     * @return
     */
	public List<Long> selectChildDepIdByOrg(@Param("orgIds")List<Long> orgIds);
}

package com.boe.bank.beanconverter;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.boe.bank.common.bean.department.DepartmentBean;
import com.boe.bank.common.entity.department.SysDepartmentAudit;
import com.boe.cloud.megarock.user.javabean.bo.OrganizationBO;
import com.boe.cloud.megarock.user.javabean.dto.OrganizationDTO;
/**
* @Description:部门管理
* @author: zhaohaixia
* @date: 2020年9月29日 上午9:12:13
 */
@Mapper(componentModel = "spring")
public interface DepartmentCoverter {

    @Mappings({
            @Mapping(source = "comment", target = "remark")
    })
    DepartmentBean getDepartmentBean(OrganizationDTO organizationDTO);

    @Mappings({
            @Mapping(source = "remark", target = "comment")
    })
	OrganizationBO getOrganizationBO(DepartmentBean bean);
    
}

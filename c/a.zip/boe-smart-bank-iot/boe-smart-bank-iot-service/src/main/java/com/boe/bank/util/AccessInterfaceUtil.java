package com.boe.bank.util;

import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;

import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.common.utils.RedissionUtils;

/**
* @Description:接口访问间隔限制
* @author: zhaohaixia
* @date: 2020年11月2日 下午5:45:56
 */
public class AccessInterfaceUtil {
	
	@Resource
    private RedissionUtils redissionUtils;
	
	/**
	* @Description:判断是否可以访问接口
	* @param interval 时间间隔，以秒为单位
	* @return true 可以访问；false 不可以访问
	* @author: zhaohaixia
	* @date: 2020年11月3日 上午9:20:30
	 */
	public boolean access(BigDecimal interval) {
		if(interval == null) {
			interval = new BigDecimal(Const.ACCESS_TIME);
		}
		//获取上一次访问接口的时间，若不存在，将此次访问时间存入缓存
		if (redissionUtils.isExist (RedisPrefix.ACCESS_INTERFACE_DATE)) {
            Date accessDate = (Date) redissionUtils.getRBucketValue(RedisPrefix.ACCESS_INTERFACE_DATE);
            //获取时间差
            long offsetSec = DateUtil.getDiffSeconds(new Date(), accessDate);
            //毫秒
            BigDecimal intervalM = interval.multiply(new BigDecimal(1000));
            return offsetSec > intervalM.longValue();
        }else {
        	//将此次访问时间存入缓存
        	redissionUtils.setRBucket(RedisPrefix.ACCESS_INTERFACE_DATE, new Date());
        	return true;
        }
		
	}
	
	
}

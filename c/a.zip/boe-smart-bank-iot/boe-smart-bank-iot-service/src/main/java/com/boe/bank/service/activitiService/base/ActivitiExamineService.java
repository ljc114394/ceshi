package com.boe.bank.service.activitiService.base;

import java.util.List;

import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.ActivitiExamineQueryBean;
import com.boe.bank.common.entity.activiti.ActivitiExamine;

/**
 * 审核流程基础service
 * @author caoxuhao
 */
public interface ActivitiExamineService {
	
	/**
	 * 通过业务类型获取 审批类型列表(只看已启用的)
	 * @param busniessType
	 * @return
	 */
	public List<ActivitiExamine> getActivitiExamineListByBusniessType(Integer busniessType);
	
	public ActivitiExamine load(int id);

	public boolean insert(ActivitiExamine activitiExamine);

	/**
	 * 查询是否有重复的审批类型
	 * @param busniessType
	 * @param examineType
	 * @return
	 */
	public int checkDuplicate(Integer busniessType, String examineType);

	/**
	 * 更新审批类型
	 * @param activitiExamine
	 * @return
	 */
	public boolean updateById(ActivitiExamine activitiExamine);

	/**
	 * 删除审批类型
	 * @param activitiExamine
	 * @return
	 */
	public boolean deleteById(int id);

	/**
	 * 瀑布分页获取 审批类型列表(所有)
	 * @param busniessType
	 * @return
	 */
	public PageInfoDto<ActivitiExamine> getList(ActivitiExamineQueryBean query);


}

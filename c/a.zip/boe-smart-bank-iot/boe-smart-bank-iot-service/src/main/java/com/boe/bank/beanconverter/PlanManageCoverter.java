package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.planmanagebean.PlanManageBean;
import com.boe.bank.common.bean.planmanagebean.PlanManageSaveBean;
import com.boe.bank.common.entity.planmanage.PlanManage;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PlanManageCoverter {

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(planManage.getCreateTime()))"),
            @Mapping(target = "updateTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(planManage.getUpdateTime()))"),
            @Mapping(target = "beginTime", expression = "java(com.boe.bank.common.utils.DateUtil.dateParse(planManage.getBeginTime()))"),
            @Mapping(target = "endTime", expression = "java(com.boe.bank.common.utils.DateUtil.dateParse(planManage.getEndTime()))")
    })
    PlanManageBean getPlanManageBean(PlanManage planManage);

    @Mappings({
            @Mapping(target = "beginTime", expression = "java(com.boe.bank.common.utils.DateUtil.parseLocalDate1(planManageSaveBean.getBeginTime()))"),
            @Mapping(target = "endTime", expression = "java(com.boe.bank.common.utils.DateUtil.parseLocalDate1(planManageSaveBean.getEndTime()))")
    })
    PlanManage getPlanManage(PlanManageSaveBean planManageSaveBean);

    List<PlanManage> getPlanManageList(List<PlanManageSaveBean> planManageSaveBean);


    List<PlanManageBean> getPlanManageBeanList(List<PlanManage> dicts);


}

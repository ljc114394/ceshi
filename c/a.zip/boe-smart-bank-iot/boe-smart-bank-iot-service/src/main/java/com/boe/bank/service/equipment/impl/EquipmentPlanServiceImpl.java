package com.boe.bank.service.equipment.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.boe.bank.beanconverter.ScreenLayoutConverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.bean.equipment.*;
import com.boe.bank.common.bean.planmanagebean.PlanMaterialManageBean;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.equipment.EquipmentConfig;
import com.boe.bank.common.entity.equipment.EquipmentPlan;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.bank.mapper.equipment.EquipmentPlanMapper;
import com.boe.bank.mapper.planmanageMapper.PlanManageMapper;
import com.boe.bank.service.equipment.EquipmentConfigService;
import com.boe.bank.service.equipment.EquipmentPlanService;
import com.boe.bank.service.planmanageService.PlanManageService;
import com.boe.cloud.megarock.security.common.UserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

/**
 * 设备计划 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/19
 */
@Slf4j
@Service("equipmentPlanService")
public class EquipmentPlanServiceImpl extends ServiceImpl<EquipmentPlanMapper, EquipmentPlan> implements EquipmentPlanService {

    @Autowired
    private EquipmentConfigService equipmentConfigService;
    @Autowired
    private PlanManageService planManageService;
    @Autowired
    private EquipmentPlanMapper equipmentPlanMapper;
    @Autowired
    private PlanManageMapper planManageMapper;


    @Override
    public List<EquipmentPlan> getByMacAndType(String mac, Integer type) {
        return ChainWrappers.lambdaQueryChain(getBaseMapper())
                .eq(EquipmentPlan::getMac, mac)
                .eq(type != null, EquipmentPlan::getType, type)
                .list();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(String mac, EquipmentPlanDTO dto) {
        int ret = 0;
        for (Integer planId : dto.getPlanIds()) {
            EquipmentPlan plan = ChainWrappers.lambdaQueryChain(getBaseMapper()).eq(EquipmentPlan::getMac, mac)
                    .eq(EquipmentPlan::getType, dto.getType()).eq(EquipmentPlan::getPlanId, planId).one();
            if (plan == null) {
                EquipmentPlan entity = new EquipmentPlan();
                entity.setMac(mac);
                entity.setPlanId(planId);
                entity.setType(dto.getType());
                getBaseMapper().insert(entity);
                ret++;
            }
        }
        if (CollectionUtils.isNotEmpty(dto.getDelPlanIds())) {
            List<EquipmentPlan> planList = ChainWrappers.lambdaQueryChain(getBaseMapper()).eq(EquipmentPlan::getMac, mac)
                    .eq(EquipmentPlan::getType, dto.getType())
                    .in(EquipmentPlan::getPlanId, dto.getDelPlanIds()).list();
            if (CollectionUtils.isNotEmpty(planList)) {
                getBaseMapper().deleteBatchIds(planList.stream().map(EquipmentPlan::getId).collect(Collectors.toList()));
                ret++;
            }
        }
        return ret;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(String mac, EquipmentPlanDTO dto) {
        for (Integer planId : dto.getPlanIds()) {
            LambdaQueryWrapper<EquipmentPlan> wrapper = Wrappers.lambdaQuery(EquipmentPlan.class)
                    .eq(EquipmentPlan::getMac, mac)
                    .eq(EquipmentPlan::getPlanId, planId)
                    .eq(EquipmentPlan::getType, dto.getType());
            getBaseMapper().delete(wrapper);
        }
    }

    @Override
    public List<ProgramConfigVO> getProgram(String mac, String fileUrlPrefix) {
        List<EquipmentPlan> epList = getByMacAndType(mac, null);
        if (CollectionUtils.isEmpty(epList)) {
            return null;
        }
        EquipmentConfig config = equipmentConfigService.getByMac(mac);
        List<ScreenLayout> layoutList = JSON.parseArray(config.getScreenLayout(), ScreenLayout.class);
        List<Integer> planIds = epList.stream().map(EquipmentPlan::getPlanId).distinct().collect(Collectors.toList());
        List<PlanManage> planList = planManageService.listByIds(planIds, true);
        List<ProgramConfigVO> dataList = new ArrayList<>();
        for (EquipmentPlan ep : epList) {
            PlanManage plan = planList.stream().filter(o -> o.getId().equals(ep.getPlanId())).findFirst().orElse(null);
            if (plan == null) {
                continue;
            }
            // 素材列表
            List<PlanMaterialManageBean> materialList = plan.getList();
            if (CollectionUtils.isEmpty(materialList)) {
                continue;
            }
            ProgramConfigVO pc = new ProgramConfigVO();
            pc.setId(plan.getId());
            pc.setStartTime(plan.getBeginTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            pc.setEndTime(plan.getEndTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            pc.setDayOfWeek(convertStrToNum(plan.getPlanTime()));
            pc.setType(ep.getType());
            pc.setUpdateTime(plan.getUpdateTime());
            int i = 1;
            List<ScreenLayoutVO> layoutVOList = ScreenLayoutConverter.INSTANCE.entityListToVoList(layoutList);
            List<ScreenLayoutVO> screenLayoutVOList = new ArrayList<>();
            for (ScreenLayoutVO layout : layoutVOList) {
                // 指定屏幕区域内的素材列表
                int j = i++;
                List<PlanMaterialManageBean> beanList = materialList.stream()
                        .filter(o -> o.getScreenArea() != null && o.getScreenArea() == j)
                        .collect(Collectors.toList());
                if (CollectionUtils.isEmpty(beanList)) {
                    continue;
                }
                layout.setResArr(beanList.stream().map(o -> ScreenLayoutConverter.INSTANCE.beanToVo(o, fileUrlPrefix))
                        .collect(Collectors.toList()));
                screenLayoutVOList.add(layout);
            }
            if (CollectionUtils.isEmpty(screenLayoutVOList)) {
                continue;
            }
            pc.setAreas(screenLayoutVOList);
            dataList.add(pc);
        }
        // 计划有交集时，先播计划的更新时间最近的，即按更新时间倒序排列
        dataList.sort(Comparator.comparing(ProgramConfigVO::getType).thenComparing(ProgramConfigVO::getUpdateTime).reversed());
        return dataList;
    }

    @Override
    public String validatePlan(String mac, EquipmentPlanDTO dto) {
        List<EquipmentPlan> epList = getByMacAndType(mac, dto.getType());
        if (CollectionUtils.isEmpty(epList)) {
            return null;
        }
        List<Integer> planIdList = epList.stream().map(EquipmentPlan::getPlanId).collect(Collectors.toList());
        // 旧的计划
        List<PlanManage> oldPlanList = planManageService.listByIds(planIdList, false);
        // 新的计划
        List<PlanManage> newPlanList = planManageService.listByIds(dto.getPlanIds(), false);
        for (PlanManage oldPlan : oldPlanList) {
            for (PlanManage newPlan : newPlanList) {
                if (validateContains(oldPlan.getPlanTime(), newPlan.getPlanTime())) {
                    // 计划播放时间相同
                }
            }
        }
        return null;
    }

    /**
     * 判断是否有相同的数据
     * @param planTime
     * @param planTime1
     * @return
     */
    private boolean validateContains(String planTime, String planTime1) {
        if (StringUtils.isBlank(planTime) || StringUtils.isBlank(planTime1)) {
            return false;
        }
        String[] times = planTime.split("、");
        String[] times1 = planTime1.split("、");
        for (String time : times) {
            for (String time1 : times1) {
                if (time.equals(time1)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 将周一转为1，周二转为2...
     *
     * @param planTime
     * @return
     */
    private String convertStrToNum(String planTime) {
        if (StringUtils.isBlank(planTime)) {
            return null;
        }
        String[] times = planTime.split("、");
        String[] weeks = new String[]{"周一", "周二", "周三", "周四", "周五", "周六", "周日"};
        int[] num = new int[]{1, 2, 3, 4, 5, 6, 7};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times.length; i++) {
            for (int j = 0; j < weeks.length; j++) {
                if (times[i].equals(weeks[j])) {
                    sb.append(sb.length() > 0 ? "," : "").append(num[j]);
                    break;
                }
            }
        }
        return sb.toString();
    }

    /**
     * 批量更新设备关联计划
     *
     * @param dto
     * @return
     */
    @Override
    @Transactional
    public int batchUpdate( EquipmentBatchPlanDTO dto) {
        if(dto !=null && CollectionUtils.isEmpty(dto.getMac())){
            throw new BusinessException(MsgReturnEnum.EQUIPMENT_ID_NULL);
        }
        //设备的屏幕数量一致
        //判断批量的设备的屏幕区域数是否一致，如果不一致，提示“所选设备屏幕区域数不一致，无法批量设置”
        List<EquipmentConfig> ecList = equipmentConfigService.getByBatchMac(dto.getMac());
        if (CollectionUtils.isEmpty(ecList)) {
            throw new BusinessException(MsgReturnEnum.EQUIPMENT_NULL);
        }
//        for(int i=1;i<ecList.size();i++ ){
//            if (StringUtils.isNotBlank(ecList.get(i).getScreenLayout())&& StringUtils.isNotBlank(ecList.get(i-1).getScreenLayout())) {
//                if(JSONArray.parseArray(ecList.get(i).getScreenLayout()).size() != JSONArray.parseArray(ecList.get(i-1).getScreenLayout()).size()){
//                    throw new BusinessException(MsgReturnEnum.EQUIPMENT_NOT_BATCH);
//                }
//            }
//        }
        //List<PlanMaterialManageBean> list = planManageMapper.getPlanMaterialByPlanId(planManage.getId());
        if(dto !=null && CollectionUtils.isNotEmpty(dto.getPlanIds())){
            //批量删除设备的计划
            if(CollectionUtils.isNotEmpty(dto.getMac()) && equipmentPlanMapper.batchDelete(dto.getMac())<1){
                throw new BusinessException(MsgReturnEnum.EQUIPMENT_PLAN_DELETE_FAILS);
            }
            Integer count =0;
            if (ecList.get(0) !=null &&StringUtils.isNotBlank(ecList.get(0).getScreenLayout())) {//所有的屏幕区域一致才能关联，所以找第一个就行
                count = JSONArray.parseArray(ecList.get(0).getScreenLayout()).size();
            }

            //计划的屏幕数量大于等于设备屏幕区域
            //根据计划id查询屏幕区域
            List<PlanMaterialManageBean> list = planManageMapper.getBatchPlanMaterialByPlanId(dto.getPlanIds());
            if(CollectionUtils.isNotEmpty(list)){
                //List<Integer> countList = Lists.newArrayList();
                StringJoiner countList = new StringJoiner(",");

                Integer finalCount = count;
                list.stream().forEach(item ->{
                 if(item.getScreenArea()< finalCount){
                     //countList.add(item.getId());
                     countList.add(item.getTitle());
                 }
                });
                if(StringUtils.isNotBlank(countList.toString())){
                    throw new BusinessException (1234, "批量设置失败,名称为"+countList+"的计划小于设备的屏幕区域数");
                }
            }else{
                throw new BusinessException(MsgReturnEnum.PLAN_SCREE_AREA_NULL);
            }
            //批量添加设备
            dto.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());
            dto.setCreateTime(LocalDateTime.now());
            dto.setCreateUserId(UserInfo.getCurrentUserId());
            return equipmentPlanMapper.batchInsert(dto.getMac(),dto);
        }

        return 1;
    }
}

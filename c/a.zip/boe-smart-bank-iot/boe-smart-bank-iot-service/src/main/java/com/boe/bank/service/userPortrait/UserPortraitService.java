package com.boe.bank.service.userPortrait;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.util.StringUtils;
import com.boe.bank.beanconverter.MarketLabelCoverter;
import com.boe.bank.beanconverter.ProductLibraryCoverter;
import com.boe.bank.beanconverter.UserPortraitCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.marketLabel.MarketLabelNatureAiDTO;
import com.boe.bank.common.bean.marketLabel.MarketLabelNatureDTO;
import com.boe.bank.common.bean.marketLabel.MarketLabelsTreeBean;
import com.boe.bank.common.bean.productlibrarybean.*;
import com.boe.bank.common.bean.userPortrait.*;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.entity.marketLabel.MarketLabel;
import com.boe.bank.common.entity.userPortrait.UserPortrait;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.common.utils.TreeUtil;
import com.boe.bank.mapper.dictMapper.SysDictionariesMapper;
import com.boe.bank.mapper.marketLabel.MarketLabelMapper;
import com.boe.bank.mapper.productlibraryMapper.ProductLibraryMapper;
import com.boe.bank.mapper.userPortrait.UserPortraitMapper;
import com.boe.bank.service.marketLabel.MarketLabelService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @Description:serviceImpl
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Service
@Slf4j
public class UserPortraitService {

    private final String parentCode = "behaviorTAB";

    @Autowired
    private UserPortraitMapper userPortraitMapper;

    @Autowired
    private UserPortraitCoverter userPortraitCoverter;

    @Autowired
    private MarketLabelCoverter marketLabelCoverter;

    @Autowired
    private ProductLibraryMapper productLibraryMapper;

    @Autowired
    private ProductLibraryCoverter productLibraryCoverter;

    @Autowired
    private MarketLabelMapper marketLabelMapper;

    @Autowired
    private MarketLabelService marketLabelService;

    @Autowired
    private RedissionUtils redissionUtils;

    @Autowired
    private SysDictionariesMapper sysDictionariesMapper;


    public PageInfo<UserPortraitBean> queryUserPortraitList(UserPortraitSearchBean userPortraitSearchBean) {
        log.info("query UserPortrait:{}", userPortraitSearchBean);
        ObjectUtil.setPageNumAndPageSizeDefault(userPortraitSearchBean);
        Page page = PageHelper.startPage(userPortraitSearchBean.getPageNum(), userPortraitSearchBean.getPageSize(), true);
        if(userPortraitSearchBean.getWeightSort() == null){
            userPortraitSearchBean.setWeightSort(2);//默认时间排序
        }
        List<UserPortraitBean> userPortraitBeanList = userPortraitCoverter.getUserPortraitBeanList(userPortraitMapper.weightSort(userPortraitSearchBean));
        log.info("query UserPortrait.size():", userPortraitSearchBean);
        return new PageInfo<UserPortraitBean>(userPortraitBeanList, page);
    }

    /**
     * 权重排序
     * @param userPortraitSearchBean
     * @return
     */
    public PageInfo<UserPortraitBean> weightSort(UserPortraitSearchBean userPortraitSearchBean) {
        log.info("weightSort:{}", userPortraitSearchBean);
        if(userPortraitSearchBean.getWeightSort() == null){
            throw new BusinessException(MsgReturnEnum.WEIGHT_SORT_MESSAGE);
        }
        ObjectUtil.setPageNumAndPageSizeDefault(userPortraitSearchBean);
        Page page = PageHelper.startPage(userPortraitSearchBean.getPageNum(), userPortraitSearchBean.getPageSize(), true);
        List<UserPortraitBean> userPortraitBeanList = userPortraitCoverter.getUserPortraitBeanList(userPortraitMapper.weightSort(userPortraitSearchBean));
        log.info("weightSort UserPortrait.size():", userPortraitSearchBean);
        return new PageInfo<UserPortraitBean>(userPortraitBeanList, page);
    }

    @Transactional
    public Integer addUserPortrait(UserPortraitInfoBean userPortraitInfoBean) {
        log.info("add UserPortrait:{}", userPortraitInfoBean);
        if (StringUtils.isEmpty(userPortraitInfoBean)) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_NAME);
        }
        if (userPortraitInfoBean.getEnable() == null) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_ENABLE);
        }
        if (userPortraitMapper.isHasUserPortrait(userPortraitInfoBean.getPortraitName()) > 0) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_NAME_HAS);
        }
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        Long createById = UserInfo.getCurrentUserInfo().getId();
        LocalDateTime now = LocalDateTime.now();
        UserPortrait userPortrait = userPortraitCoverter.getUserPortrait(userPortraitInfoBean);
        userPortrait.setCreateBy(createBy);
        userPortrait.setCreateTime(now);
        userPortrait.setCreateUserId(createById);
        if(userPortrait.getEnable() == 1){
            userPortrait.setEnableTime(now);
        }
        userPortraitMapper.addUserPortrait(userPortrait);
        Integer nums = 0;
        if (!CollectionUtils.isEmpty(userPortraitInfoBean.getUserPortraitLabelInfoBeans())) {
            nums = userPortraitMapper.addUserPortraitLabel(userPortrait.getId(), createBy, createById, now, userPortraitInfoBean.getUserPortraitLabelInfoBeans());
        }
        log.info("add UserPortrait:{}", nums);
        return nums;
    }

    public UserPortraitInfoBean selectUserPortrait(Integer id) {
        log.info("根据id查询用户画像数据", id);
        if (id == null) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        UserPortraitInfoBean userPortraitInfoBean = userPortraitMapper.selectUserPortrait(id);
        if(userPortraitInfoBean.getLabelTrees() == null){
            userPortraitInfoBean.setLabelTrees("");
        }
        if(userPortraitInfoBean.getLabelTreesFrom() == null){
            userPortraitInfoBean.setLabelTreesFrom("");
        }
        log.info("根据id查询用户画像数据", userPortraitInfoBean);
        return userPortraitInfoBean;
    }

    @Transactional
    public Integer editUserPortrait(UserPortraitLabelDTO userPortraitLabelDTO) {
        log.info("edit UserPortrait:{}", userPortraitLabelDTO);
        if (StringUtils.isEmpty(userPortraitLabelDTO)) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_NOT);
        }
        if(StringUtils.isEmpty(userPortraitLabelDTO.getPortraitName())){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_NAME);
        }
        if(userPortraitLabelDTO.getConditionType() == null){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_CONDITION_TYPE_NULL);
        }
        UserPortrait userPortrait = userPortraitCoverter.getUserPortrait(userPortraitLabelDTO);
        if(userPortrait.getWeight() == null){
            userPortrait.setWeight(0);//如果删除权重，恢复默认0
        }
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        LocalDateTime now = LocalDateTime.now();
        userPortrait.setUpdateBy(createBy);
        userPortrait.setUpdateTime(now);
        Integer nums = userPortraitMapper.updateUserPortraitById(userPortrait);
        if(userPortraitLabelDTO.getUserPortraitLabelBeanList().size() == 1){
            UserPortraitLabelBean up = userPortraitLabelDTO.getUserPortraitLabelBeanList().get(0);
            if(up.getLabelId() == null && up.getLabelParentId() == null &&(up.getLabelName() == null || up.getLabelName().equals(""))) {
                userPortraitLabelDTO.setUserPortraitLabelBeanList(null);
            }else if(up.getLabelId() == null){
                throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_LABEL_ID_NULL);
            }else if(up.getLabelParentId() == null){
                throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_LABEL_PARENT_ID_NULL);
            }
        }
        if (nums > 0) {
//            if (userPortraitLabelDTO.getPortraitLabelIds() != null) {
//                String[] ids = userPortraitLabelDTO.getPortraitLabelIds().split(",");
                userPortraitMapper.deleteUserPortraitByIds(userPortraitLabelDTO.getId());//根据画像id删除画像标签中间表
   //         }
                if( !CollectionUtils.isEmpty(userPortraitLabelDTO.getUserPortraitLabelBeanList())) {
                    userPortraitMapper.addUserPortraitLabels(userPortraitLabelDTO.getId(),
                            createBy,
                            UserInfo.getCurrentUserInfo().getId(),
                            now,
                            userPortraitLabelDTO.getUserPortraitLabelBeanList());
                }

        }
        log.info("edit UserPortrait:{}", nums);
        return nums;
    }

    /**
     * 删除用户画像
     * @param id
     * @return
     */
    @Transactional
    public Integer deleteUserPortrait(Integer id) {
        log.info("delete UserPortrait:{}", id);
        if (id == null) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        if(productLibraryMapper.productByportraitId(id)>0){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_PRODUCT_IS);
        }
        Integer nums = userPortraitMapper.deleteUserPortraitById(id);
        Integer numsLabel = 0;
        if (nums > 0) {
            numsLabel = userPortraitMapper.deleteUserPortraitLabelById(id);
        }
        log.info("delete UserPortrait:{}", id);
        return numsLabel;
    }

    /**
     * 存储用户画像相关属性值-并返回对应的产品id
     *
     * @param marketLogsBean
     * @return 对应的产品id
     * @throws JsonProcessingException
     * @throws InterruptedException
     */
    @Transactional
    public List<Integer> addMarketLogs(MarketLogsBean marketLogsBean) throws InterruptedException {
        log.info("add MarketLogs:{}", marketLogsBean);
        if (CollectionUtils.isEmpty(marketLogsBean.getPropertyJsons())) {
            throw new BusinessException(MsgReturnEnum.MARKET_LOGS_PARAMS);
        }
        //更新画像人数分布
        if (!StringUtils.isEmpty(marketLogsBean.getPortraitId())) {
            String[] ids = marketLogsBean.getPortraitId().split(",");
            for (String id : ids) {
                userPortraitMapper.updateUserPortraitPersonNums(Integer.parseInt(id));
            }
        }
        //更新标签人数分布
        if (!StringUtils.isEmpty(marketLogsBean.getMarketLabelId())) {
            String[] ids = marketLogsBean.getMarketLabelId().split(",");
            for (String id : ids) {
                marketLabelMapper.updateMarketLabelPersonNums(Integer.parseInt(id));
            }
        }

        if(marketLogsBean.getProductId() != null){//如果产品id不为空，直接return
            return null;
        }

        //根据属性值匹配相对应的产品id
        //如果此用户没有行为属性，直接查缓存（8小时）数据并返回
        List<UserActionInfoBean> userActionInfoBeans =
                userPortraitMapper.queryUserActionInfoCondition(marketLogsBean.getFaceId());
        if (CollectionUtils.isEmpty (userActionInfoBeans)) {
            //判断Redis缓存是否有faceid相应的数据（有效期8小时）
            if (redissionUtils.isExist(RedisPrefix.PRODUCT_FACE + marketLogsBean.getFaceId())) {
                List<Integer> productIds = (List<Integer>) redissionUtils.getRMap(RedisPrefix.PRODUCT_FACE + marketLogsBean.getFaceId())
                        .get(RedisPrefix.PRODUCT_FACE_KEY + marketLogsBean.getFaceId());
                return productIds;
            }
        }

        //获取具体属性值
        List<MarketLabelNatureAiDTO> marketLabelNatureAiDTO = marketLogsBean.getPropertyJsons();

        //测试  用于获取最新的数据   生产环境删除   2020.11.05
        marketLabelService.deleteProductPortraitMarketRedis();
        //获取缓存产品、画像、属性数据
        List<ProductPortraitDTO> productPortraitDTOS = this.getProductPortraitDTOS();
        //获取字典表标签属性值
        List<ProductDictDO> parentCodeByLabel = sysDictionariesMapper.getParentCodeByLabel(this.parentCode);

        List<Integer> productIds = Lists.newArrayList();//返回的产品id集合
        ProductNatureDO pnd = new ProductNatureDO();//临时存储符合条件的用户画像、产品，判断权重，去重

        for (ProductPortraitDTO ppd : productPortraitDTOS) {//产品

            for (PortraitDTO por:ppd.getPortraitDTOList()){//用户画像

                if(pnd.getFaceId()!=null){
                    if(pnd.getWeight() > por.getWeight()){
                        continue ;
                    }else if(pnd.getWeight() == por.getWeight()){
                        if(pnd.getCreateTime().getTime() >= por.getCreateTime().getTime()){
                            continue ;
                        }
                    }
                }

                boolean sizeFlag = false;//如果用户画像标签数为一，直接进行属性匹配即可，有就添加并返回走下一个
                if (por.getMarketLabelNatureDTOS().size() == 1) {
                    sizeFlag = true;
                }

                Integer conditionType = por.getConditionType();
                if(conditionType == 1){//条件判断：0或  1且
                    if (!sizeFlag) {
                        if(verifyPorLabelSize(por,userActionInfoBeans,marketLabelNatureAiDTO)){
                            continue ;
                        }
                    }
                }

                Integer verifyNums = 0;//记录匹配画像数，且判断
                n:
                for (MarketLabelNatureDTO mlnd : por.getMarketLabelNatureDTOS()) {//标签属性
                    if (mlnd.getLabelType() == 0) {//标签属性区分：0属性标签、1行为标签
                        try {
                            for (MarketLabelNatureAiDTO mlna : marketLabelNatureAiDTO) {//终端参数
                                if(verifyNature(mlnd, mlna)){
                                    ++verifyNums;
                                    if (sizeFlag) {
                                        break n;
                                    }
                                    if(conditionType == 0){
                                        break n;
                                    }
                                }
                            }
                        } catch (Exception e) {
                            continue;//转换错误  跳出此循环
                        }
                    } else {//标签属性区分：0属性标签、1行为标签
                        try {
                            for (UserActionInfoBean u : userActionInfoBeans) {
                                if (verifyAction(mlnd, u, parentCodeByLabel)) {
                                    ++verifyNums;
                                    if (sizeFlag) {
                                        break n;
                                    }
                                    if(conditionType == 0){
                                        break n;
                                    }
                                }
                            }
                        } catch (Exception e) {
                            continue;//转换错误  跳出此循环
                        }
                    }

                }
                if (sizeFlag) {
                    pnd = addAbility(marketLogsBean, ppd, por);
                    continue;
                }
                if(conditionType == 1){
                    if(userActionInfoBeans.size()>0){
                        if((userActionInfoBeans.size()+marketLabelNatureAiDTO.size()) == verifyNums){
                            pnd = addAbility(marketLogsBean, ppd, por);
                        }else{
                            continue ;
                        }
                    }else{
                        if(marketLabelNatureAiDTO.size() == verifyNums){
                            pnd = addAbility(marketLogsBean, ppd, por);
                        }else{
                            continue ;
                        }
                    }
                }else{
                    if(verifyNums > 0){//符合一个条件即可添加
                        pnd = addAbility(marketLogsBean, ppd, por);
                    }
                }
            }
        }

        if(pnd.getProductId() != null){
            productIds.add(pnd.getProductId());
        }

        //将匹配的产品id  放在缓存中   有效期为8小时
        if (!CollectionUtils.isEmpty(productIds)) {
            redissionUtils.getRMap(RedisPrefix.PRODUCT_FACE + marketLogsBean.getFaceId())
                    .put(RedisPrefix.PRODUCT_FACE_KEY + marketLogsBean.getFaceId(), productIds);
            redissionUtils.getRMap(RedisPrefix.PRODUCT_FACE + marketLogsBean.getFaceId())
                    .expire(8, TimeUnit.HOURS);
            /*
            List<Integer> ids = (List<Integer>) redissionUtils
                    .getRMap(RedisPrefix.PRODUCT_FACE + marketLogsBean.getFaceId())
                    .get(RedisPrefix.PRODUCT_FACE_KEY + marketLogsBean.getFaceId());
            ids.forEach(id -> {
                System.out.println("id: " + id);
            });

            System.out.println("+++++++++++++++++++++");
            System.out.println("+++++++++++++++++++++");
            System.out.println("+++++++++++++++++++++");

            //测试代码  生产环境需要删除
            Thread.sleep(1000 * 11);
            List<Integer> ids = (List<Integer>) redissionUtils
                    .getRMap(RedisPrefix.PRODUCT_FACE + marketLogsBean.getFaceId())
                    .get(RedisPrefix.PRODUCT_FACE_KEY + marketLogsBean.getFaceId());
            ids.forEach(id -> {
                System.out.println("id: " + id);
            });*/
        }

        log.info("返回产品id集合长度 :{}", productIds.size());
        return productIds;
    }

    @Transactional
    public Integer updateUserPortraitPersonNums(Integer id) {
        log.info("updateUserPortraitPersonNums:{}", id);
        if (StringUtils.isEmpty(id)) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        Integer nums = userPortraitMapper.updateUserPortraitPersonNums(id);
        log.info("updateUserPortraitPersonNums:{}", nums);
        return nums;
    }

    public void userPortraitExport(HttpServletResponse response, UserPortraitExportBean userPortraitExportBean) throws IOException {
        /*ObjectUtil.setPageNumAndPageSizeDefault(userPortraitExportBean);
        PageHelper.startPage(userPortraitExportBean.getPageNum(), userPortraitExportBean.getPageSize(), true);*/
        List<UserPortraitExportDTO> userPortraitBeanList = userPortraitMapper.userPortraitExport(userPortraitExportBean);
        String name = "userPortrait_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), UserPortraitExportDTO.class).sheet("excel").doWrite(userPortraitBeanList);
    }

    public List<ProductLibraryBean> queryProductByPortraitId(Integer portraitId) {
        log.info("queryProductByPortraitId id:", portraitId);
        if (portraitId == null) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        return productLibraryCoverter.getProductLibraryList(
                productLibraryMapper.queryProductByPortraitId(portraitId));
    }

    /**
     * 获取产品信息、用户画像、标签属性数据
     *
     * @return
     */
    public List<ProductPortraitDTO> getProductPortraitDTOS() {
        try {
            if (redissionUtils.isExist(RedisPrefix.PRODUCT_PORTRAIT_MARKET)) {
                return (List<ProductPortraitDTO>) redissionUtils.getRMap(RedisPrefix.PRODUCT_PORTRAIT_MARKET)
                        .get(RedisPrefix.PRODUCT_PORTRAIT_MARKET_KEY);
            } else {
                List<ProductPortraitDTO>  productPortraitDTOS = marketLabelService.productPortraitMarketByDb();
                if(!CollectionUtils.isEmpty(productPortraitDTOS)){
                    redissionUtils.getRMap (RedisPrefix.PRODUCT_PORTRAIT_MARKET)
                            .put (RedisPrefix.PRODUCT_PORTRAIT_MARKET_KEY, productPortraitDTOS);
                }
                return productPortraitDTOS;
            }
        } catch (Exception e) {
            return marketLabelService.productPortraitMarketByDb();
        }
    }

    /**
     * 可选画像
     *
     * @param id
     * @return
     */
    public List<UserPortraitBean> queryProductCPortraitList(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        List<UserPortraitBean> userPortraitBeanList = userPortraitCoverter.getUserPortraitBeanList(userPortraitMapper.queryProductCPortraitList(id));
        return userPortraitBeanList;
    }

    /**
     * 获取标签属性结构
     * labelType：标签属性区分：0属性标签、1行为标签
     */
    public MarketLabelsTreeBean getMarketLabelsTreeBean(UserPortrailtLabelDTO userPortrailtLabelDTO){
        log.info("getMarketLabelsTreeBean :",userPortrailtLabelDTO.getLabelType());
        if(userPortrailtLabelDTO.getLabelType() == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_TYPE);
        }
        List<MarketLabel> marketLabels = marketLabelMapper.queryMarketLabelsTreeHaveUserPor(userPortrailtLabelDTO);
        if (CollectionUtils.isEmpty (marketLabels)) {
            return MarketLabelsTreeBean.builder ().build ();
        }
        List<MarketLabelsTreeBean> marketLabelsTreeBeans = marketLabelCoverter.getMarketLabelsTreeBeans(marketLabels);
        MarketLabelsTreeBean marketLabelsTreeBean = TreeUtil.toTree(marketLabelsTreeBeans,new MarketLabelsTreeBean().getClass(),0l);
        log.info("getMarketLabelsTreeBean :",marketLabelsTreeBean);
        return  marketLabelsTreeBean;
    }

    /**
     * 用户画像-权重修改-替换
     * @param productWeigthDTO
     * @return
     */
    @Transactional
    public Integer productWeigthEdit(ProductWeigthDTO productWeigthDTO){
        log.info("用户画像-权重修改  bean：{}",productWeigthDTO);
        if (productWeigthDTO.getId() == null) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        if(productWeigthDTO.getWeight() == null){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_WEIGTH_NULL);
        }
        if(productWeigthDTO.getWeigthReplace() == null){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_WEIGTH_NULL);
        }
        Integer weight = 0;
        weight = productWeigthDTO.getWeight();
        productWeigthDTO.setWeight(productWeigthDTO.getWeigthReplace());
        userPortraitMapper.productWeigthEdit(productWeigthDTO);
        productWeigthDTO.setWeight(weight);
        productWeigthDTO.setId(productWeigthDTO.getReplaceId());
        Integer nums = userPortraitMapper.productWeigthEdit(productWeigthDTO);
        log.info("用户画像-权重修改 size：{}",nums);
        return  nums;
    }

    /**
     *用户画像-验证权重是否重复  不重复修改，重复返回
     * @param productWeigthDTO
     */
    @Transactional
    public ProductWeigthVO productWeigthEditCheck(ProductWeigthDTO productWeigthDTO){
        log.info("验证用户画像  bean",productWeigthDTO);
        if(productWeigthDTO.getId() == null){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        if(productWeigthDTO.getWeight() == null){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_WEIGTH_NULL);
        }

        ProductWeigthVO pw = userPortraitMapper.productWeigthEditCheck(productWeigthDTO);
        if(pw != null && pw.getReplaceId() != null){
            pw.setReplace(true);
        }else{
            userPortraitMapper.productWeigthEdit(productWeigthDTO);
            ProductWeigthVO pwV = new ProductWeigthVO();
            pwV.setReplace(false);
            pw = pwV;
        }
        return pw;
    }

    /**
     * 验证属性值
     */
    public boolean verifyNature(MarketLabelNatureDTO mlnd,
                             MarketLabelNatureAiDTO mlna) {
        boolean flag = false;
        if (mlnd.getConditionName().equals(mlna.getConditionName())) {
            if (mlnd.getConditionValue() != null &&
                    mlnd.getConditionValue().equals(mlna.getConditionValue())) {
                flag = true;
            } else if (mlnd.getConditionMinRange() != null && mlnd.getConditionMaxRange() != null) {
                String min = mlnd.getConditionMinRange();
                String max = mlnd.getConditionMaxRange();
                Integer val = Integer.parseInt(mlna.getConditionValue());
                if(verifyMinAndMax(min,max,val)){
                    flag = true;
                }
            } else if (mlnd.getConditionMinRange() != null) {
                String min = mlnd.getConditionMinRange();
                Integer val = Integer.parseInt(mlna.getConditionValue());
                if(verifyMin(min,val)){
                    flag = true;
                }
            } else if (mlnd.getConditionMaxRange() != null) {
                String max = mlnd.getConditionMaxRange();
                Integer val = Integer.parseInt(mlna.getConditionValue());
                if(verifyMax(max,val)){
                    flag = true;
                }
            }
        }
        return flag;
    }

    /**
     * 验证行为
     */

    public boolean verifyAction(MarketLabelNatureDTO mlnd,
                                UserActionInfoBean u,
                                List<ProductDictDO> parentCodeByLabel) {
        boolean flag = false;
        if (mlnd.getBehaviorCondition() == 0 || mlnd.getBehaviorCondition() == 1) {//时间段
            /*if (getConName(mlnd.getConditionName(),parentCodeByLabel) == u.getConditionActionType()
                    && u.getConditionActionType() == 2) {//查看应用累计时间
                if(actionJudgeTime(mlnd, u)){
                    flag = true;
                }
            } else*/
            if (getConName(mlnd.getConditionName(),parentCodeByLabel)
                == u.getConditionActionType()) {//访问网点数、点击应用二维码次数、查看应用累计时间
                if(actionJudge(mlnd,u)){
                    flag = true;
                }
            }
        } else if (mlnd.getBehaviorCondition() == 2) {//近一个月
            if (getConName(mlnd.getConditionName(),parentCodeByLabel)
                    == u.getConditionActionType()) {//访问网点数、点击应用二维码次数、查看应用累计时间
                if(actionJudge(mlnd,u)){
                    flag = true;
                }
            }
        } else if (mlnd.getBehaviorCondition() == 3) {//近一周
            if (getConName(mlnd.getConditionName(),parentCodeByLabel)
                    == u.getConditionActionType()) {//访问网点数、点击应用二维码次数、查看应用累计时间
                if(actionJudge(mlnd,u)){
                    flag = true;
                }
            }
        } else if (mlnd.getBehaviorCondition() == 4) {//近三天
            if (getConName(mlnd.getConditionName(),parentCodeByLabel)
                    == u.getConditionActionType()) {//访问网点数、点击应用二维码次数、查看应用累计时间
                if(actionJudge(mlnd,u)){
                    flag = true;
                }
            }
        }
        return flag;
    }

    /**
     * 验证行为属性判断
     */
    public boolean actionJudge(MarketLabelNatureDTO mlnd, UserActionInfoBean u) {
        boolean flag = false;
        if (mlnd.getConditionValue() != null
                && mlnd.getConditionValue().equals(u.getConditionActionValue())) {
            flag = true;
        } else if (mlnd.getConditionMinRange() != null && mlnd.getConditionMaxRange() != null) {
            String min = mlnd.getConditionMinRange();
            String max = mlnd.getConditionMaxRange();
            Integer val = Integer.parseInt(u.getConditionActionValue());
            if(verifyMinAndMax(min,max,val)){
                flag = true;
            }
        } else if (mlnd.getConditionMinRange() != null) {
            String min = mlnd.getConditionMinRange();
            Integer val = Integer.parseInt(u.getConditionActionValue());
            if(verifyMin(min,val)){
                flag = true;
            }
        } else if (mlnd.getConditionMaxRange() != null) {
            String max = mlnd.getConditionMaxRange();
            Integer val = Integer.parseInt(u.getConditionActionValue());
            if(verifyMax(max,val)){
                flag = true;
            }
        }
        return flag;
    }

    /**
     * 行为属性：应用累计时间判断
     * @param mlnd
     * @param u
     */
    /*public boolean actionJudgeTime(MarketLabelNatureDTO mlnd,
                                   UserActionInfoBean u) {
        boolean flag = false;
        if (mlnd.getConditionValue() != null) {//等值判断
            if(DateUtil.parse(mlnd.getConditionValue()).getTime()
                    == DateUtil.parse(u.getConditionActionValue()).getTime()){
                flag = true;
            }
        } else if (mlnd.getConditionMinRange() != null && mlnd.getConditionMaxRange() != null) {
            String min = mlnd.getConditionMinRange();
            String max = mlnd.getConditionMaxRange();
            long date = DateUtil.parse(u.getConditionActionValue()).getTime();
            boolean minFlag = false;
            boolean maxFlag = false;
            if(min.substring(0, 1).equals("0")){
                long minDate = DateUtil.parse(min.substring(1, min.length())).getTime();
                if(date >= minDate){
                    minFlag = true;
                }
            }else{
                long minDate = DateUtil.parse(min).getTime();
                if(date > minDate){
                    minFlag = true;
                }
            }
            if(minFlag){
                if(max.substring(0, 1).equals("0")){
                    long maxDate = DateUtil.parse(max.substring(1,max.length())).getTime();
                    if(date <= maxDate){
                        maxFlag = true;
                    }
                }else{
                    long maxDate = DateUtil.parse(max).getTime();
                    if(date < maxDate){
                        maxFlag = true;
                    }
                }
                if(minFlag && maxFlag){
                    flag = true;
                }
            }
        } else if (mlnd.getConditionMinRange() != null) {
            String min = mlnd.getConditionMinRange();
            long date = DateUtil.parse(u.getConditionActionValue()).getTime();
            if (min.substring(0, 1).equals("0")) {
                long minDate = DateUtil.parse(min.substring(1, min.length())).getTime();
                if(date >= minDate){
                    flag = true;
                }
            }else{
                long minDate = DateUtil.parse(min).getTime();
                if(date > minDate){
                    flag = true;
                }
            }
        } else if (mlnd.getConditionMaxRange() != null) {
            String max = mlnd.getConditionMaxRange();
            long date = DateUtil.parse(u.getConditionActionValue()).getTime();
            if (max.substring(0, 1).equals("0")) {// <=
                long maxDate = DateUtil.parse(max.substring(1,max.length())).getTime();
                if(date <= maxDate){
                    flag = true;
                }
            } else{ // <
                long maxDate = DateUtil.parse(max).getTime();
                if(date < maxDate){
                    flag = true;
                }
            }
        }
        return flag;
    }*/

    /**
     * 临时添加用户属性公共方法
     *
     * @param mlnd
     * @param mlna
     * @param pnd
     * @param type
     * @return
     */
    public ProductNatureDO tsAbility(MarketLogsBean marketLogsBean,
                                     ProductPortraitDTO ppd,
                                     PortraitDTO por,
                                     MarketLabelNatureDTO mlnd,
                                     MarketLabelNatureAiDTO mlna,
                                     ProductNatureDO pnd,
                                     Integer type) {

        pnd.setFaceId(marketLogsBean.getFaceId());
        pnd.setLabelId(mlnd.getLabelId());
        pnd.setProductId(ppd.getProductId());
        pnd.setWeight(por.getWeight());
        pnd.setPortraitId(por.getPortraitId());
        pnd.setConditionName(mlna.getConditionName());
        pnd.setConditionType(por.getConditionType());
        pnd.setCreateTime(por.getCreateTime());
        if (type == 1) {
            pnd.setConditionValue(mlna.getConditionValue());
        } else if (type == 2) {
            pnd.setConditionMinRange(mlnd.getConditionMinRange());
            pnd.setConditionMaxRange(mlnd.getConditionMaxRange());
        } else if (type == 3) {
            pnd.setConditionMinRange(mlnd.getConditionMinRange());
        } else if (type == 4) {
            pnd.setConditionMaxRange(mlnd.getConditionMaxRange());
        } else if (type == 5) {
            pnd.setBehaviorCondition(mlnd.getBehaviorCondition());
            pnd.setConditionValue(mlna.getConditionValue());
        } else if (type == 6) {
            pnd.setBehaviorCondition(mlnd.getBehaviorCondition());
            pnd.setConditionMinRange(mlnd.getConditionMinRange());
            pnd.setConditionMaxRange(mlnd.getConditionMaxRange());
        } else if (type == 7) {
            pnd.setBehaviorCondition(mlnd.getBehaviorCondition());
            pnd.setConditionMinRange(mlnd.getConditionMinRange());
        } else if (type == 8) {
            pnd.setBehaviorCondition(mlnd.getBehaviorCondition());
            pnd.setConditionMaxRange(mlnd.getConditionMaxRange());
        } else {
            return null;
        }
        return pnd;
    }

    /**
     * 临时添加用户属性公共方法
     *
     * @return
     */
    public ProductNatureDO addAbility(MarketLogsBean marketLogsBean,
                                     ProductPortraitDTO ppd,
                                     PortraitDTO por) {
        ProductNatureDO pnd = new ProductNatureDO();
        pnd.setFaceId(marketLogsBean.getFaceId());
        pnd.setProductId(ppd.getProductId());
        pnd.setWeight(por.getWeight());
        pnd.setPortraitId(por.getPortraitId());
        pnd.setConditionType(por.getConditionType());
        pnd.setCreateTime(por.getCreateTime());

        return pnd;
    }

    public Integer getConName(String cName,List<ProductDictDO> parentCodeByLabel){
        try {
            if (parentCodeByLabel.size() > 0) {
                Integer name = 9999;
                for (ProductDictDO p : parentCodeByLabel) {
                    if (cName.equals(p.getCode())) {
                        name = Integer.parseInt(p.getCodeVlaue());
                        break;
                    }
                }
                return name;
            }
            return 9999;
        }catch (Exception e){
            return 9999;
        }
    }

    public boolean verifyMinAndMax(String min,String max,Integer val){
        boolean minFlag = false;
        boolean maxFlag = false;

        if(min.substring(0, 1).equals("0")){
            if(val >= Integer.parseInt(min.substring(1, min.length()))){
                minFlag = true;
            }
        }else{
            if(val > Integer.parseInt(min)){
                minFlag = true;
            }
        }
        if(minFlag){
            if(max.substring(0, 1).equals("0")){
                if(val <= Integer.parseInt(max.substring(1, max.length()))){
                    maxFlag = true;
                }
            }else{
                if(val < Integer.parseInt(max)){
                    maxFlag = true;
                }
            }
            if(maxFlag && minFlag){
                return true;
            }
        }
        return minFlag;
    }

    public boolean verifyMin(String min,Integer val){
        boolean minFlag = false;
        if(min.substring(0, 1).equals("0")){
            if(val >= Integer.parseInt(min.substring(1, min.length()))){
                minFlag = true;
            }
        }else{
            if(val > Integer.parseInt(min)){
                minFlag = true;
            }
        }
        return minFlag;
    }

    public boolean verifyMax(String max,Integer val){
        boolean maxFlag = false;
        if(max.substring(0, 1).equals("0")){
            if(val <= Integer.parseInt(max.substring(1, max.length()))){
                maxFlag = true;
            }
        }else{
            if(val < Integer.parseInt(max)){
                maxFlag = true;
            }
        }
        return maxFlag;
    }

    public boolean verifyPorLabelSize(PortraitDTO por,
                                 List<UserActionInfoBean> userActionInfoBeans,
                                 List<MarketLabelNatureAiDTO> marketLabelNatureAiDTO){
        boolean porMarNatuSizeFlag = false;
        if(por.getMarketLabelNatureDTOS().size()<marketLabelNatureAiDTO.size()){
            porMarNatuSizeFlag = true;
        }
        if(!porMarNatuSizeFlag && userActionInfoBeans.size()>0){

            if(por.getMarketLabelNatureDTOS().size() < (userActionInfoBeans.size()+marketLabelNatureAiDTO.size())){
                porMarNatuSizeFlag = true;
            }

        }

        return porMarNatuSizeFlag;
    }

}

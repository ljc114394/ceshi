package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentStatus;

/**
 * 设备状态 Mapper
 *
 * @author 10183279
 * @date 2020/10/19
 */
public interface EquipmentStatusMapper extends BaseMapper<EquipmentStatus> {

}

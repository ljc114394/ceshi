package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.equipment.EquipmentPlayLogQO;
import com.boe.bank.common.bean.equipment.PlayLogVO;
import com.boe.bank.common.bean.equipment.SpotsLogVO;
import com.boe.bank.common.bean.playlogbean.PlayLogSaveBean;
import com.boe.bank.common.constant.PlayModeEnum;
import com.boe.bank.common.entity.equipment.EquipmentPlayLog;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.equipment.EquipmentPlayLogMapper;
import com.boe.bank.service.equipment.EquipmentPlayLogService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 设备播放日志 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/28
 */
@Service("equipmentPlayLogService")
public class EquipmentPlayLogServiceImpl extends ServiceImpl<EquipmentPlayLogMapper, EquipmentPlayLog> implements EquipmentPlayLogService {

    @Override
    public void save(PlayLogSaveBean saveBean) {
        EquipmentPlayLog playLog = new EquipmentPlayLog();
        playLog.setMac(saveBean.getMac());
        playLog.setEquipmentId(saveBean.getEquipmentId());
        if (!StringUtils.isEmpty(saveBean.getProgramId())) {
            playLog.setProgramId(Integer.parseInt(saveBean.getProgramId()));
        }
        playLog.setPlayTime(saveBean.getPlayTime());
        playLog.setLogUrl(saveBean.getLogUrl());
        getBaseMapper().insert(playLog);
    }

    @Override
    public PageInfo<PlayLogVO> pagePlayLog(EquipmentPlayLogQO qo) {
        qo.setType(PlayModeEnum.NORMAL.getCode());
        // 分页
        ObjectUtil.setPageNumAndPageSizeDefault(qo);
        Page page = PageHelper.startPage(qo.getPageNum(), qo.getPageSize());
        List<PlayLogVO> playLogList = getBaseMapper().listPlayLog(qo);
        return new PageInfo<>(playLogList, page);
    }

    @Override
    public PageInfo<SpotsLogVO> pageSpotsLog(EquipmentPlayLogQO qo) {
        qo.setType(PlayModeEnum.SPOTS.getCode());
        ObjectUtil.setPageNumAndPageSizeDefault(qo);
        Page page = PageHelper.startPage(qo.getPageNum(), qo.getPageSize(), true);
        List<SpotsLogVO> spotsLogList = getBaseMapper().listSpotsLog(qo);
        return new PageInfo<>(spotsLogList, page);
    }

    @Override
    public List<PlayLogVO> listPlayLog(EquipmentPlayLogQO qo) {
        qo.setType(PlayModeEnum.NORMAL.getCode());
        return getBaseMapper().listPlayLog(qo);
    }
}

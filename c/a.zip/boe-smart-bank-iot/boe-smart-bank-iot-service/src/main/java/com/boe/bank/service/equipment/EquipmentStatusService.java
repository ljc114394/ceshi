package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.entity.equipment.EquipmentStatus;

import java.util.List;

/**
 * 设备状态 Service
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentStatusService extends IService<EquipmentStatus> {

    /**
     * 根据mac获取设备状态信息
     * @param macList
     * @return
     */
    List<EquipmentStatus> listByMacs(List<String> macList);

    /**
     * 更新设备在线状态
     * @param mac
     * @param isOnline
     */
    void update(String mac, Integer isOnline);
}

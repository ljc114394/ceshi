package com.boe.bank.mapper.planmanageMapper;

import com.boe.bank.common.bean.planmanagebean.PlanEquipmentBean;
import com.boe.bank.common.bean.planmanagebean.PlanManageSearchBean;
import com.boe.bank.common.bean.planmanagebean.PlanMaterialManageBean;
import com.boe.bank.common.bean.planmanagebean.PlanMaterialManageSaveBean;
import com.boe.bank.common.entity.equipment.EquipmentAndEnameConfig;
import com.boe.bank.common.entity.equipment.EquipmentConfig;
import com.boe.bank.common.entity.equipment.EquipmentPlan;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.cloud.megarock.security.common.Role;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface PlanManageMapper {


    int insertPlanManage(PlanManage planManagea);

    int updatePlanManage(PlanManage planManagea);

    List<PlanManage> getPlanManageList(PlanManageSearchBean planManage);

    int updatePlanManageDel(String[] id);

    int deletePlanMaterial(String[] id);

    PlanManage getPlanManageById(Integer id);

    int insertPlanMaterialId(@Param ("planId") Integer planId,@Param ("createBy") String createBy,@Param ("createTime") LocalDateTime createTime,@Param ("createUserId") Integer createUserId,@Param ("list") List<PlanMaterialManageSaveBean> list);

    List<PlanMaterialManageBean> getPlanMaterialByPlanId(Integer id);

    int deletePlanMaterialByPlanId(Integer id);

    int getPlanAndMaterialCount(@Param ("id") Integer id);

    int getManyPlanAndMaterialCount(@Param ("ids") List<Integer> ids);

    int updatePlanManageState(@Param ("id")Integer id ,@Param ("updateBy")String updateBy ,@Param ("updateTime")LocalDateTime updateTime ,@Param ("state")Integer state);

    List<PlanManage> listByIds(@Param("idList") List<Integer> idList);

    PlanMaterialManageBean findMaterial(Integer plan_id);

    List<Integer> getLikeName(@Param ("name")String name);

    List<PlanMaterialManageBean> getMaterialIdByPlanId(Integer id);

    int batchInsertPlanManage(@Param ("planManageList") List<PlanManage> planManageList);

    int batchInsertPlanMaterialId(@Param ("createBy") String createBy,@Param ("createTime") LocalDateTime createTime,@Param ("createUserId") Long createUserId, @Param ("pList")  List<PlanMaterialManageBean> pList);

    List<EquipmentAndEnameConfig> batGetByMac(@Param("equipMacList") List<String> equipMacList);

    int delEquipment(@Param("id") Integer id,@Param("delEquipMac") List<String> delEquipMac);

    int editEquipment(@Param ("equipMac") List<String> equipMac, @Param ("id") Integer id, @Param ("createBy") String createBy, @Param ("createTime") LocalDateTime createTime, @Param ("createUserId") Long createUserId, @Param ("type") Integer type);

    List<EquipmentPlan> getByPlanIdAndType(Integer id);

    PlanMaterialManageBean getScreenCountByPlanId(Integer id);

    List<PlanMaterialManageBean> getBatchPlanMaterialByPlanId(@Param ("planIds") List<Integer> planIds);
}

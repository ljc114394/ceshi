package com.boe.bank.mapper.terminalversion;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.terminalversion.TerminalVersion;

/**
 * 客户端版本 Mapper
 *
 * @author 10183279
 * @date 2020/10/29
 */
public interface TerminalVersionMapper extends BaseMapper<TerminalVersion> {

}

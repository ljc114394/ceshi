package com.boe.bank.service.marketLogService;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.boe.bank.beanconverter.MarketLogsCoverter;
import com.boe.bank.common.bean.marketLabel.MarketLabelNatureAiDTO;
import com.boe.bank.common.bean.userPortrait.MarketLogsBean;
import com.boe.bank.common.entity.UserActionLog.UserActionLog;
import com.boe.bank.common.entity.userNatureInfo.UserNatureInfo;
import com.boe.bank.common.entity.userPortrait.MarketLogs;
import com.boe.bank.common.entity.userStayLog.UserStayLog;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.mapper.UserActionLogMapper.UserActionLogMapper;
import com.boe.bank.mapper.userNatureInfoMapper.UserNatureInfoMapper;
import com.boe.bank.mapper.userPortrait.UserPortraitMapper;
import com.boe.bank.mapper.userStayLogMapper.UserStayLogMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MarketLogService {
	
	@Autowired
	private UserPortraitMapper userPortraitMapper;
	
	@Autowired
	private UserStayLogMapper userStayLogMapper;
	
	@Autowired
	private UserNatureInfoMapper userNatureInfoMapper;
	
	@Autowired
	private UserActionLogMapper userActionLogMapper;
	
	@Autowired
    private MarketLogsCoverter marketLogsCoverter;
	
	@Autowired
    private ObjectMapper objectMapper;
	
	/**
	 * 保存属性的值
	 * @param marketLogsBean
	 * @throws JsonProcessingException
	 */
	@Transactional
	public void saveAttributeValue(MarketLogsBean marketLogsBean) throws JsonProcessingException {
		
		MarketLogs marketLogs = marketLogsCoverter.getMarketLogs(marketLogsBean);
		List<MarketLabelNatureAiDTO> list = marketLogsBean.getPropertyJsons();
		
		//save market_logs
		saveMarketLogs(marketLogs, list);
		
		//save user_stay_log
		saveUserStayLog(marketLogs);
		
		//save user_nature_info
		String faceFeature = marketLogsBean.getFaceFeature();
		saveUserNatureInfo(marketLogs, list, faceFeature);
		
	}
	
	/**
	 * 保存行为的值
	 * @param marketLogsBean
	 * @throws JsonProcessingException
	 */
	@Transactional
	public void saveBehaviorValue(MarketLogsBean marketLogsBean) throws JsonProcessingException {
		
		MarketLogs marketLogs = marketLogsCoverter.getMarketLogs(marketLogsBean);
		List<MarketLabelNatureAiDTO> list = marketLogsBean.getPropertyJsons();
		
		//save market_logs
		saveMarketLogs(marketLogs, list);
		
		//save user_stay_log
		saveUserStayLog(marketLogs);
		
		//save user_action_log
		saveUserActionLog(marketLogs, list);
	}
	
	private void saveMarketLogs(MarketLogs marketLogs, List<MarketLabelNatureAiDTO> list) throws JsonProcessingException {
		marketLogs.setCreateTime(LocalDateTime.now());
		marketLogs.setPropertyJson(objectMapper.writeValueAsString(list));
		Integer res = userPortraitMapper.addMarketLogs(marketLogs);
		if(res == null || res == 0)
			throw new RuntimeException("save market_logs failed:"+JSON.toJSONString(marketLogs));
	}
	
	private void saveUserStayLog(MarketLogs marketLogs) {
		UserStayLog userStayLog = new UserStayLog();
		BeanUtils.copyProperties(marketLogs, userStayLog);
		userStayLog.setCreateAt(DateUtil.asSecond(marketLogs.getCreateTime()));
		int res = userStayLogMapper.insert(userStayLog);
		if(res == 0)
			throw new RuntimeException("save user_stay_log failed:"+JSON.toJSONString(marketLogs));
	}
	
	private void saveUserNatureInfo(MarketLogs marketLogs, List<MarketLabelNatureAiDTO> list, String faceFeature) {
		
		if(CollectionUtils.isEmpty(list)) 
			return;
			
		UserNatureInfo userNatureInfo = new UserNatureInfo();
		BeanUtils.copyProperties(marketLogs, userNatureInfo);
		
		if(!StringUtils.isEmpty(faceFeature))
			userNatureInfo.setFaceFeature(faceFeature);
		
		for (MarketLabelNatureAiDTO dto : list) {
			String name = dto.getConditionName();
			if(StringUtils.isEmpty(name))
				continue;
			
			String value = dto.getConditionValue();
			switch (name) {
			case "sex":
				userNatureInfo.setRecoSex(Integer.valueOf(value));
				break;
			case "age":
				userNatureInfo.setRecoAge(Integer.valueOf(value));
				break;
			case "firstVisit":
				userNatureInfo.setFirstVisit("1".equals(value));
				break;
				
			default:
				break;
			}
		}
		LocalDateTime now = LocalDateTime.now();
		if(userNatureInfoMapper.select(userNatureInfo.getFaceId())>0){
			userNatureInfo.setUpdateTime(now);
			int res = userNatureInfoMapper.update(userNatureInfo);
			if(res == 0)
				throw new RuntimeException("update user_nature_info failed:"+JSON.toJSONString(marketLogs));

		}else{
			userNatureInfo.setCreateTime(now);
			int res = userNatureInfoMapper.insert(userNatureInfo);
			if(res == 0)
				throw new RuntimeException("save user_nature_info failed:"+JSON.toJSONString(marketLogs));
		}
	}
	
	private void saveUserActionLog(MarketLogs marketLogs, List<MarketLabelNatureAiDTO> list) {
		
		UserActionLog userActionLog = new UserActionLog();
		BeanUtils.copyProperties(marketLogs, userActionLog);
		
		//属性行为 1:访问网点数 2:查看应用累计时间 3:点击应用二维码次数
		for (MarketLabelNatureAiDTO dto : list) {
			boolean shouldSave = true;
			String name = dto.getConditionName();
			if(StringUtils.isEmpty(name))
				continue;
			
			switch (name) {
			case "visitNum":
				userActionLog.setConditonActionType(1);
				if(dto.getActionProductId() != null){
					userActionLog.setActionProductId(dto.getActionProductId());
				}
				break;
				
			case "checkProductTime":
				userActionLog.setConditonActionType(2);
				if(dto.getActionProductId() != null){
					userActionLog.setActionProductId(dto.getActionProductId());
				}
				break;
				
			case "clickProductQrCodeNum":
				userActionLog.setConditonActionType(3);
				if(dto.getActionProductId() != null){
					userActionLog.setActionProductId(dto.getActionProductId());
				}
				break;
				
			default:
				shouldSave = false;
				break;
			}
			
			if(shouldSave) {
				userActionLog.setCreateTime(LocalDateTime.now());
				int res = userActionLogMapper.insert(userActionLog);
				if(res == 0)
					throw new RuntimeException("save user_action_log failed:"+JSON.toJSONString(marketLogs));
			}
		}
		
	}
	
}

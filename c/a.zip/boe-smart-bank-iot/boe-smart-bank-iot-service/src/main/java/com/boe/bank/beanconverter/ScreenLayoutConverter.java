package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.equipment.ProgramVO;
import com.boe.bank.common.bean.equipment.ScreenLayout;
import com.boe.bank.common.bean.equipment.ScreenLayoutVO;
import com.boe.bank.common.bean.planmanagebean.PlanMaterialManageBean;
import com.boe.bank.common.constant.MaterialTypeEnum;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 屏幕区域布局转换器
 *
 * @author 10183279
 * @date 2020/11/6
 */
@Mapper
public interface ScreenLayoutConverter {

    ScreenLayoutConverter INSTANCE = Mappers.getMapper(ScreenLayoutConverter.class);

    @Mappings({
            @Mapping(source = "w", target = "width"),
            @Mapping(source = "h", target = "height")
    })
    ScreenLayoutVO entityToVo(ScreenLayout entity);

    List<ScreenLayoutVO> entityListToVoList(List<ScreenLayout> entityList);

    @Mappings({
            @Mapping(target = "url", expression = "java(customConverter(fileUrlPrefix, bean.getContent(), bean.getType()))"),
            @Mapping(source = "bean.type", target = "type"),
            @Mapping(source = "bean.fileSize", target = "fileSize"),
            @Mapping(source = "bean.md5", target = "md5"),
            @Mapping(source = "bean.playOperation", target = "times"),
            @Mapping(target = "text", expression = "java(bean.getType() != null && bean.getType() == com.boe.bank.common.constant.MaterialTypeEnum.TEXT.getCode() ? bean.getContent() : \"\")"),
            @Mapping(source = "bean.programEntry", target = "param")
    })
    ProgramVO beanToVo(PlanMaterialManageBean bean, String fileUrlPrefix);

    default String customConverter(String fileUrlPrefix, String content, Integer type) {
        if (type == null) {
            return "";
        }
        if (type == MaterialTypeEnum.WEB.getCode()) {
            return content;
        }
        if (type == MaterialTypeEnum.PIC.getCode() || type == MaterialTypeEnum.VIDEO.getCode()
                || type == MaterialTypeEnum.DOCUMENT.getCode() || type == MaterialTypeEnum.PROGRAM.getCode()) {
            return fileUrlPrefix + content;
        }
        return "";
    }
}

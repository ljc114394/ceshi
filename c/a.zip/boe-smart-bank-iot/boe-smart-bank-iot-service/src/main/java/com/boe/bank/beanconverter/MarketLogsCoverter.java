package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.userPortrait.MarketLogsBean;
import com.boe.bank.common.entity.userPortrait.MarketLogs;
import org.mapstruct.Mapper;

/**
 * @Description:转义
 * @Author: lijianglong
 * @Data:2020/10/27
 */
@Mapper(componentModel = "spring")
public interface MarketLogsCoverter {

    MarketLogs getMarketLogs(MarketLogsBean marketLogsBean);

}

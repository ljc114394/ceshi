package com.boe.bank.listener.activiti;

import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.common.entity.material.MaterialManage;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.bank.mapper.equipment.EquipmentMapper;
import com.boe.bank.mapper.material.MaterialManageMapper;
import com.boe.bank.mapper.planmanageMapper.PlanManageMapper;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;

import com.boe.bank.service.activitiService.manager.ActivitiSupport;
import com.boe.bank.service.activitiService.manager.ActivitiSupportManager;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.model.EndEvent;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 连线的监听器
 * @author caoxuhao
 */
@Slf4j
@Component
public class SequenceFlowListener implements JavaDelegate{
	
	@Autowired
	private ActivitiOuterRelationService activitiOuterRelationService;

	@Autowired
	private ActivitiSupportManager activitiSupportManager;

	@Override
	public void execute(DelegateExecution execution) {
		
		FlowElement currentFlowElement = execution.getCurrentFlowElement();
		if(!(currentFlowElement instanceof SequenceFlow))
			return;
		
		//本节点是SequenceFlow
		SequenceFlow sf = (SequenceFlow)currentFlowElement;
		
		//目标节点
		FlowElement fe = sf.getTargetFlowElement();
		//目标节点是结束节点
		if(fe instanceof EndEvent) {
			EndEvent ee = (EndEvent)fe;
			String endActivityId = ee.getId();
			if(StringUtils.isEmpty(endActivityId))
				return;
			
			switch (endActivityId) {
			case ActivitiConstants.Node.successEnd:
				doInTheEndEvent(execution.getProcessInstanceId(), ActivitiConstants.ExamineStatus.pass);
				break;
				
			case ActivitiConstants.Node.rejectEnd:
				doInTheEndEvent(execution.getProcessInstanceId(), ActivitiConstants.ExamineStatus.reject);
				break;
			default:
				break;
			}
		}
	}
	
	/**处理结束节点逻辑, 结束后更新外部表中的审核状态*/
	private void doInTheEndEvent(String processInstanceId, int examineStatus) {
		ActivitiOuterRelation relation = activitiOuterRelationService.getByProcessInstanceId(processInstanceId);
		
		//没有外部表
		if(relation == null)
			return;
		
		Integer busniessType = relation.getBusniessType();
		Integer outerId = relation.getOuterId();
		Integer outerType = relation.getOuterType();

		ActivitiSupport activitiSupport = activitiSupportManager.getActivitiSupport(busniessType);
		if(activitiSupport == null){
			log.error("更新审核状态失败,没有获取到support："+ relation);
			return;
		}

		if(!activitiSupport.updateExamineStatus(outerId, examineStatus, outerType)){
			log.error("更新审核状态失败："+ relation);
			return;
		}
	}

}

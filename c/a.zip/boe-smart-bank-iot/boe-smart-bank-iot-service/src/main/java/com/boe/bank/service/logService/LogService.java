package com.boe.bank.service.logService;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.boe.bank.beanconverter.LogCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.logbean.*;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.logEnum;
import com.boe.bank.common.entity.dict.SysDictionaries;
import com.boe.bank.common.entity.log.ApprovalLog;
import com.boe.bank.common.entity.log.OperationLog;
import com.boe.bank.common.entity.log.PublicLog;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.logMapper.LogMapper;
import com.boe.bank.service.dictService.SysDictionariesService;
import com.boe.cloud.megarock.security.common.Organization;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 日志管理
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/29
 */
@Service
@Slf4j
public class LogService {

    @Resource
    private LogMapper logMapper;

    @Resource
    private LogCoverter logCoverter;

//    @Resource
//    private SysDictionariesService sysDictionariesService;


    @Resource
    private OrganizationService organizationService;

    /**
     * 操作-日志-添加
     *
     * @param logBean
     * @return int
     */
    @Transactional
    public Integer info(LogSaveBean logBean) {
        if(logBean.getModuleType()== logEnum.MATERIAL.getCode()){//素材
            if (StringUtils.isEmpty( logBean.getMaterialType())){
                throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
            }
        }
        if (logBean.getOperationType() == null || logBean.getOperationType() <= 0
                 || StringUtils.isEmpty(logBean.getOperationContent())
                 || logBean.getModuleType() == null || logBean.getModuleType() <= 0

        ) {
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
         OperationLog logm = logCoverter.getOperationLog(logBean);
         Organization organization = logBean.getUserInfo().getOrganization();
         if(organization!=null){
             logm.setOrgId(organization.getId().intValue());
         }
        logm.setCreateBy(logBean.getUserInfo().getUsername());
        logm.setCreateTime(LocalDateTime.now());
        logm.setCreateUserId(logBean.getUserInfo().getId());
        logm.setCreateAt(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
        int res = logMapper.insertLog(logm);
        log.info("日志-添加-返回结果 res:{}", res);
        return res;
    }

    /**
     * 审批-日志-添加
     *
     * @param logBean
     * @return int
     */
    @Transactional
    public Integer approvalInfo(LogSaveBean logBean) {
            if(StringUtils.isEmpty(logBean.getApprovalNo())//审批单号
                    || StringUtils.isEmpty(logBean.getApprovalType())//审批类型
                    || StringUtils.isEmpty(logBean.getApprovalResult())
                    || StringUtils.isEmpty(logBean.getOperationContent())){
                throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
            }
        ApprovalLog logm = logCoverter.getApprovalLog(logBean);
        logm.setCreateTime(LocalDateTime.now());
        logm.setCreateAt(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
        if(logBean.getUserInfo() == null ){//自动审批
            logm.setCreateBy("job");
            logm.setCreateUserId(-1l);
            logm.setOrgId(-1);
        }else{
            Organization organization = logBean.getUserInfo().getOrganization();
            if(organization!=null){
                logm.setOrgId(organization.getId().intValue());
            }
            logm.setCreateBy( logBean.getUserInfo().getUsername());
            logm.setCreateUserId(logBean.getUserInfo().getId());
        }
        int res = logMapper.insertApprovalLog(logm);
        log.info("日志-添加-返回结果 res:{}", res);
        return res;
    }
    /**
     * 根据机构id获取自己以及本机构id
     */
    private List<String> getOrgAllByOrgId(Integer orgId ){
        List<String> list = new ArrayList<String>();
        if(orgId !=null && orgId >0){
            List<OrganizationDO>  orgList = organizationService.listSelfAndChildren(orgId.longValue());
            if(!CollectionUtils.isEmpty(orgList)){
                list =orgList.stream().map(o -> o.getId().toString()).distinct().collect(Collectors.toList());//机构id的集合
            }
        }
        return  list;
    }

    /**
     * 操作-日志-分页
     *
     * @param logBean
     * @return int
     */
    public PageInfo<LogBean> getOrganizationLogPage(OperationLogSearchBean logBean) {
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
        ObjectUtil.setPageNumAndPageSizeDefault(logBean);
       // List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toEpochSecond(ZoneOffset.of("+8")));
//        }
        Page page = PageHelper.startPage(logBean.getPageNum(), logBean.getPageSize(), true);
        List<OperationLog> logList = logMapper.getOperationLogList(logBean);
        List<LogBean> logBeanList = logCoverter.getOperationLogBeanList(logList);
        PageInfo<LogBean> pageInfo = new PageInfo<LogBean>(logBeanList, page);
        log.info("日志-分页list pageNum:{},pageSize:{}size:{}", logBean.getPageNum(), logBean.getPageSize(), logBeanList.size());
        return pageInfo;
    }

    /**
     * 审批-日志-分页
     *
     * @param logBean
     * @return int
     */
    public PageInfo<LogBean> getApprovalLogLogPage(ApprovalLogSearchBean logBean) {
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
        ObjectUtil.setPageNumAndPageSizeDefault(logBean);
      //  List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toEpochSecond(ZoneOffset.of("+8")));
//        }
        Page page = PageHelper.startPage(logBean.getPageNum(), logBean.getPageSize(), true);
        List<ApprovalLog> logList = logMapper.getApprovalLogList(logBean);
        List<LogBean> logBeanList = logCoverter.getApprovalLogBeanList(logList);
        //批量获取机构名称并赋值
        PageInfo<LogBean> pageInfo = new PageInfo<LogBean>(logBeanList, page);
        log.info("日志-分页list pageNum:{},pageSize:{}size:{}", logBean.getPageNum(), logBean.getPageSize(), logBeanList.size());
        return pageInfo;
    }

    /**
     * 登录-日志-分页
     *
     * @param logBean
     * @return int
     */
    public PageInfo<LoginlogBean>  getLoginPage(LoginlogSearchBean logBean) {
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
        ObjectUtil.setPageNumAndPageSizeDefault(logBean);
      //  List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toInstant(ZoneOffset.of("+8")).toEpochMilli());
//        }
        Page page = PageHelper.startPage(logBean.getPageNum(), logBean.getPageSize(), true);
        List<PublicLog> logList = logMapper.getLoginLogPage(logBean);
        logList.stream().map(item->{
            if(item.getStatus() !=null){
                item.setJsonResult(item.getStatus()==0?"成功":"失败");
            }
            return item;
        }).collect(Collectors.toList());
        List<LoginlogBean> logBeanList = logCoverter.getLoginlogBeanList(logList);
        PageInfo<LoginlogBean> pageInfo = new PageInfo<LoginlogBean>(logBeanList, page);
        log.info("登录日志-分页list pageNum:{},pageSize:{}size:{}", logBean.getPageNum(), logBean.getPageSize(), logBeanList.size());
        return pageInfo;
    }

    /**
     * 接口-日志-分页
     *
     * @param logBean
     * @return int
     */
    public PageInfo<InterfacelogBean> getInterfacePage(InterfacelogSearchBean logBean) {
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
        ObjectUtil.setPageNumAndPageSizeDefault(logBean);
      //  List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toInstant(ZoneOffset.of("+8")).toEpochMilli());
//        }
        Page page = PageHelper.startPage(logBean.getPageNum(), logBean.getPageSize(), true);
        List<PublicLog> logList = logMapper.getInterfacePage(logBean);
        List<InterfacelogBean> logBeanList = logCoverter.getInterfaceBeanList(logList);
        PageInfo<InterfacelogBean> pageInfo = new PageInfo<InterfacelogBean>(logBeanList, page);
        log.info("日志-分页list pageNum:{},pageSize:{}size:{}", logBean.getPageNum(), logBean.getPageSize(), logBeanList.size());
        return pageInfo;
    }


    /**
     * 操作和审批日志-导出
     * @param response
     * @param logBean
     * @return
     */
    public void getLogExport(HttpServletResponse response, LogSearchExportBean logBean) throws IOException {
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
//        if(logBean.getModuleType() ==null || logBean.getModuleType()<=0){
//            throw new BusinessException(MsgReturnEnum.LOGS_MANAGE_MODULE);
//        }
        //导出
        String prefix ="";
            if(logBean.getModuleType()!=null){
            if (logBean.getModuleType() == logEnum.MATERIAL_ENGLISH.getCode()) {//素材
                prefix = logEnum.MATERIAL_ENGLISH.getName();
                //prefix = "素材日志";
            } else if (logBean.getModuleType() == logEnum.PLAN_ENGLISH.getCode()) {//计划
                prefix = logEnum.PLAN_ENGLISH.getName();
                //prefix = "计划日志";
            } else if (logBean.getModuleType() == logEnum.EQUIPMENT_ENGLISH.getCode()) {//设备
                prefix = logEnum.EQUIPMENT_ENGLISH.getName();
                //prefix = "设备日志";
            } else if (logBean.getModuleType() == logEnum.POWER_ENGLISH.getCode()) {//权限
                prefix = logEnum.POWER_ENGLISH.getName();
                //prefix = "权限日志";
            } else if (logBean.getModuleType() == logEnum.APPROVAL_ENGLISH.getCode()) {//审批
                prefix = logEnum.APPROVAL_ENGLISH.getName();
                //prefix = "审批日志";
            }
            }else{
                prefix = "operation";
            }
        String name = prefix+"_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
     //   List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toEpochSecond(ZoneOffset.of("+8")));
//        }
          //导出数据,最多为5万条,超过5万条,导出5万条,没两万条分execl导出
          PageHelper.startPage(1, 50000, false);
        ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream()).build();
        try {
        if(logBean.getModuleType()==null){
            List<OperationLog> logList = logMapper.getOperationLogListExport(logBean);
            List<List<OperationLog>> partition = Lists.partition(logList, 20000);//指定长度切割list
            for (int i = 0; i < partition.size(); i++) {
                    //整个操作日志
                    List<LogExportAllBean> powerBeanList = logCoverter.geAllExportBeanList(partition.get(i));
                    WriteSheet mainSheet = EasyExcel.writerSheet(i, "操作" + i).head(LogExportAllBean.class).build();
                    excelWriter.write(powerBeanList, mainSheet);
            }

        } else if (logBean.getModuleType() != logEnum.APPROVAL.getCode()) {//不是审批
             List<OperationLog> logList = logMapper.getOperationLogListExport(logBean);
             List<List<OperationLog>> partition = Lists.partition(logList, 20000);//指定长度切割list
             //判断类别
             for (int i = 0; i < partition.size(); i++) {
                 if (logBean.getModuleType() != null) {
                     if (logBean.getModuleType() == logEnum.MATERIAL.getCode()) {//素材
                         List<LogExportMaterialBean> materialBeanList = logCoverter.getMaterialExportBeanList(partition.get(i));
                         WriteSheet mainSheet = EasyExcel.writerSheet(i, "素材" + i).head(LogExportMaterialBean.class).build();
                         excelWriter.write(materialBeanList, mainSheet);
                     } else if (logBean.getModuleType() == logEnum.PLAN.getCode()) {//计划
                         List<LogExportPlanBean> planBeanList = logCoverter.getPlanExportBeanList(partition.get(i));
                         WriteSheet mainSheet = EasyExcel.writerSheet(i, "计划" + i).head(LogExportPlanBean.class).build();
                         excelWriter.write(planBeanList, mainSheet);
                     } else if (logBean.getModuleType() == logEnum.EQUIPMENT.getCode()) {//设备
                         List<LogExportEquipmentBean> equipmentBeanList = logCoverter.getEquipmentExportBeanList(partition.get(i));
                         WriteSheet mainSheet = EasyExcel.writerSheet(i, "设备" + i).head(LogExportEquipmentBean.class).build();
                         excelWriter.write(equipmentBeanList, mainSheet);
                     } else if (logBean.getModuleType() == logEnum.POWER.getCode()) {//权限
                         List<LogExportPowerBean> powerBeanList = logCoverter.getPowerExportBeanList(partition.get(i));
                         WriteSheet mainSheet = EasyExcel.writerSheet(i, "权限" + i).head(LogExportPowerBean.class).build();
                         excelWriter.write(powerBeanList, mainSheet);
                     }
                 }
             }
        } else {//审批
            List<ApprovalLog> logLists = logMapper.getApprovalLogListExport(logBean);
            List<List<ApprovalLog>> partitiona = Lists.partition(logLists, 20000);//指定长度切割list
             for (int i = 0; i < partitiona.size(); i++) {
                 List<LogExportApprovalBean> approvalBeanList = logCoverter.getApprovalExportBeanList(partitiona.get(i));
                 WriteSheet mainSheet = EasyExcel.writerSheet(i, "审批"+i).head(LogExportApprovalBean.class).build();
                 excelWriter.write(approvalBeanList,mainSheet);
             }
        }
        }finally {
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }
    }


    /**
     * 登录日志-导出
     * @param response
     * @param logBean
     * @return
     */
    public void getLoginAndInterLogExport(HttpServletResponse response, LoginLogSearchExportBean logBean) throws IOException{
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
        String name = "login_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
    //    List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toEpochSecond(ZoneOffset.of("+8")));
//        }
        //导出数据,最多为5万条,超过5万条,导出5万条,没两万条分execl导出
        PageHelper.startPage(1, 50000, false);
        List<PublicLog> logList = logMapper.getLoginLogListExport(logBean);

        logList.stream().map(item->{
            if(item.getStatus() !=null){
                item.setJsonResult(item.getStatus()==0?"成功":"失败");
            }
            return item;
        }).collect(Collectors.toList());
        List<List<PublicLog>> partition = Lists.partition(logList, 20000);//指定长度切割list
        ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream()).build();
        try {
        for (int i = 0; i < partition.size(); i++) {
            List<LogExportLoginBean> planBeanList = logCoverter.getLoginExportBeanList(partition.get(i));
            WriteSheet mainSheet = EasyExcel.writerSheet(i, "登录"+i).head(LogExportLoginBean.class).build();
            excelWriter.write(planBeanList,mainSheet);
        }
        }finally {
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }
    }

    /**
     * 接口日志-导出
     * @param response
     * @param logBean
     * @return
     */
    public void getInterLogExport(HttpServletResponse response, InterfaceLogSearchExportBean logBean) throws IOException{
        Integer orgId = logBean.getOrgId();
        logBean.setOrgIdList(getOrgAllByOrgId(orgId));
        String name = "interface_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
     //   List<SysDictionaries> dictionariesList = sysDictionariesService.getDictionariesRedis("t01");//时间
//        if(!CollectionUtils.isEmpty(dictionariesList)){
//            logBean.setExportTime(LocalDateTime.now().minusDays(Integer.parseInt(dictionariesList.get(1).getCodeValue())).toEpochSecond(ZoneOffset.of("+8")));
//        }
        //导出数据,最多为5万条,超过5万条,导出5万条,没两万条分execl导出
        PageHelper.startPage(1, 50000, false);
        List<PublicLog> logList = logMapper.getInterfaceLogListExport(logBean);
        List<List<PublicLog>> partition = Lists.partition(logList, 20000);//指定长度切割list
        ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream()).build();

        try {
        for (int i = 0; i < partition.size(); i++) {
            List<LogExportInterfaceBean> planBeanList = logCoverter.getInterfaceExportBeanList(partition.get(i));
            WriteSheet mainSheet = EasyExcel.writerSheet(i, "接口"+i).head(LogExportInterfaceBean.class).build();
            excelWriter.write(planBeanList,mainSheet);
        }
        }finally {
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }
    }

    /**
     * 首页-系统日志
     * @return
     */
    public List<SysLogBean> getSysList() {
        long exportTime = LocalDateTime.of(LocalDate.now(), LocalTime.MIN).toInstant(ZoneOffset.of("+8")).toEpochMilli();//获取当前零点
        List<SysLogBean> logList = logMapper.getSysList(exportTime);
        log.info("首页-系统日志 size:{}", logList.size());
        return logList;
    }

    /**
     * 保留一周内点数据
     *
     * @return int
     */
    @Transactional
    public void delectCronLog() {
    try {
        //获取距离现在7天的时间戳
        Long deleteTime = LocalDateTime.now().minusDays(7).toInstant(ZoneOffset.of("+8")).toEpochMilli();
        logMapper.timedDeleteLog(deleteTime);
    }catch (Exception e){
        e.printStackTrace();
    }
    }

    /**
     * 操作日志-机构和子机构的所有日志
     *
     * @param logBean
     * @return int
     */

//    public PageInfo<LogBean> logByOrgAll(OperationLogSearchBean logBean) {
//        Integer orgId = logBean.getOrgId();
//        if(orgId !=null && orgId >0){
//            List<OrganizationDO>  orgList = organizationService.listSelfAndChildren(orgId.longValue());
//            if(!CollectionUtils.isEmpty(orgList)){
//                logBean.setOrgIdList( orgList.stream().map(o -> o.getId()).distinct().collect(Collectors.toList()));//机构id的集合
//            }
//        }
//        ObjectUtil.setPageNumAndPageSizeDefault(logBean);
//        Page page = PageHelper.startPage(logBean.getPageNum(), logBean.getPageSize(), true);
//        List<OperationLog> logList = logMapper.logByOrgAll(logBean);
//        List<LogBean> logBeanList = logCoverter.getOperationLogBeanList(logList);
//        PageInfo<LogBean> pageInfo = new PageInfo<LogBean>(logBeanList, page);
//        log.info("日志-分页list pageNum:{},pageSize:{}size:{}", logBean.getPageNum(), logBean.getPageSize(), logBeanList.size());
//        return pageInfo;
//    }

}

package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.boe.bank.beanconverter.EquipmentLogConverter;
import com.boe.bank.common.bean.equipmentlogbean.EquipmentLogSaveBean;
import com.boe.bank.common.entity.equipment.EquipmentLog;
import com.boe.bank.common.entity.equipment.EquipmentLogExportResultBean;
import com.boe.bank.common.entity.equipment.EquipmentLogResultBean;
import com.boe.bank.common.entity.equipment.EquipmentLogSearchBean;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.equipment.EquipmentLogMapper;
import com.boe.bank.service.equipment.EquipmentLogService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 设备日志 ServiceImpl
 *
 * @author 10085188
 * @date 2020/11/5
 */
@Service("equipmentLogService")
public class EquipmentLogServiceImpl extends ServiceImpl<EquipmentLogMapper, EquipmentLog> implements EquipmentLogService {

	@Override
    public void save(EquipmentLogSaveBean saveBean) {
        EquipmentLog equipmentLog = new EquipmentLog();
        equipmentLog.setLevel(saveBean.getLevel());
        equipmentLog.setMessage(saveBean.getMessage());
        equipmentLog.setTime(saveBean.getTime());
        equipmentLog.setLogUrl(saveBean.getLogUrl());
        equipmentLog.setEquipmentId(saveBean.getEquipmentId());
        equipmentLog.setMac(saveBean.getMac());
        getBaseMapper().insert(equipmentLog);
    }

	@Override
	public IPage<EquipmentLogResultBean> page(EquipmentLogSearchBean searchBean) {
		ObjectUtil.setPageNumAndPageSizeDefault(searchBean);
		LambdaQueryWrapper<EquipmentLog> wrapper = Wrappers.lambdaQuery(EquipmentLog.class)
				.eq(StringUtils.isNotBlank(searchBean.getMac()), EquipmentLog::getMac, searchBean.getMac())
				.eq(StringUtils.isNotBlank(searchBean.getLevel()), EquipmentLog::getLevel, StringUtils.isNotBlank(searchBean.getLevel()) ? Integer.parseInt(searchBean.getLevel()) : searchBean.getLevel())
				.like(StringUtils.isNotBlank(searchBean.getMessage()), EquipmentLog::getMessage, searchBean.getMessage())
				.ge(StringUtils.isNotBlank(searchBean.getStartTime()), EquipmentLog::getTime, searchBean.getStartTime())
				.le(StringUtils.isNotBlank(searchBean.getEndTime()), EquipmentLog::getTime, searchBean.getEndTime())
				.orderByDesc(EquipmentLog::getCreateTime);
		Page<EquipmentLog> page = getBaseMapper().selectPage(new Page<>(searchBean.getPageNum(), searchBean.getPageSize()), wrapper);
		List<EquipmentLog> records = page.getRecords();
		List<EquipmentLogResultBean> resultBeanList = new ArrayList<EquipmentLogResultBean>();
		if (CollectionUtils.isNotEmpty(records)) {
			for (EquipmentLog record : records) {
				EquipmentLogResultBean rs = EquipmentLogConverter.INSTANCE.entityToVo(record);
				resultBeanList.add(rs);
			}
		}
		Page<EquipmentLogResultBean> pg = new Page<EquipmentLogResultBean>();
		pg.setTotal(page.getTotal());
		pg.setSize(page.getSize());
		pg.setRecords(resultBeanList);
		return pg;
	}

	@Override
	public List<EquipmentLogResultBean> listEquipmentLog(EquipmentLogSearchBean searchBean) {
		ObjectUtil.setPageNumAndPageSizeDefault(searchBean);
		LambdaQueryWrapper<EquipmentLog> wrapper = Wrappers.lambdaQuery(EquipmentLog.class)
				.eq(StringUtils.isNotBlank(searchBean.getMac()), EquipmentLog::getMac, searchBean.getMac())
				.eq(StringUtils.isNotBlank(searchBean.getLevel()), EquipmentLog::getLevel, StringUtils.isNotBlank(searchBean.getLevel()) ? Integer.parseInt(searchBean.getLevel()) : searchBean.getLevel())
				.like(StringUtils.isNotBlank(searchBean.getMessage()), EquipmentLog::getMessage, searchBean.getMessage())
				.ge(StringUtils.isNotBlank(searchBean.getStartTime()), EquipmentLog::getTime, searchBean.getStartTime())
				.le(StringUtils.isNotBlank(searchBean.getEndTime()), EquipmentLog::getTime, searchBean.getEndTime());
		List<EquipmentLog> equLogList = getBaseMapper().selectList(wrapper);
		List<EquipmentLogResultBean> resultBeanList = new ArrayList<EquipmentLogResultBean>();
		if (CollectionUtils.isNotEmpty(equLogList)) {
			for (EquipmentLog record : equLogList) {
				EquipmentLogResultBean rs = EquipmentLogConverter.INSTANCE.entityToVo(record);
				resultBeanList.add(rs);
			}
		}
		return resultBeanList;
	}

	@Override
	public List<EquipmentLogExportResultBean> listEquipmentLogExport(EquipmentLogSearchBean searchBean) {
		ObjectUtil.setPageNumAndPageSizeDefault(searchBean);
		LambdaQueryWrapper<EquipmentLog> wrapper = Wrappers.lambdaQuery(EquipmentLog.class)
				.eq(StringUtils.isNotBlank(searchBean.getMac()), EquipmentLog::getMac, searchBean.getMac())
				.eq(StringUtils.isNotBlank(searchBean.getLevel()), EquipmentLog::getLevel, StringUtils.isNotBlank(searchBean.getLevel()) ? Integer.parseInt(searchBean.getLevel()) : searchBean.getLevel())
				.like(StringUtils.isNotBlank(searchBean.getMessage()), EquipmentLog::getMessage, searchBean.getMessage())
				.ge(StringUtils.isNotBlank(searchBean.getStartTime()), EquipmentLog::getTime, searchBean.getStartTime())
				.le(StringUtils.isNotBlank(searchBean.getEndTime()), EquipmentLog::getTime, searchBean.getEndTime());
		List<EquipmentLog> equLogList = getBaseMapper().selectList(wrapper);
		List<EquipmentLogExportResultBean> resultBeanList = new ArrayList<EquipmentLogExportResultBean>();
		if (CollectionUtils.isNotEmpty(equLogList)) {
			for (EquipmentLog record : equLogList) {
				EquipmentLogExportResultBean rs = EquipmentLogConverter.INSTANCE.entityToExportVo(record);
				resultBeanList.add(rs);
			}
		}
		return resultBeanList;
	}
}

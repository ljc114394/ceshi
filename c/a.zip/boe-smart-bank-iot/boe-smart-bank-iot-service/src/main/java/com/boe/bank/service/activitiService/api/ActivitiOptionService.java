package com.boe.bank.service.activitiService.api;

import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.activiti.ActivitiOptUser;

public interface ActivitiOptionService {
	/**
	 * 提交工作流
	 * @param userId		提交人（必传）
	 * @param busniessType	业务类型（必传）
	 * @param examineId		素材模块必传，设备/计划模块不需要
	 * @param outerId		外部表主键id（必传）
	 * @param outerType	二级类型（非必传）
	 * @return	
	 * 		成功：Result.success()
	 * 		用户还没有创建对应的审批流 Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR)
	 * 		其他失败:Result.failure
	 */
	public Result<?> submit(String userId, Integer busniessType, Integer examineId, Integer outerId, Integer outerType);

	/**
	 * 拒绝工作流
	 * @param acticitiOptUser
	 * @return
	 */
	public Result<?> fail(ActivitiOptUser acticitiOptUser);

	/**
	 * 通过工作流
	 * @param acticitiOptUser
	 * @return
	 */
	public Result<?> pass(ActivitiOptUser acticitiOptUser);

	/** 
     * 转办流程 
     * @param processInstanceId 
     * @param reviewer  
     * @param targetUserId  目标用户
     */
	public Result<?> transferAssignee(String taskId, String processInstanceId, String reviewer, String targetUserId);

	/**
	 * 废弃
	 * @param processInstanceId
	 */
	public void abandon(String processInstanceId);
}

package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentConfig;

/**
 * 设备配置 Mapper
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentConfigMapper extends BaseMapper<EquipmentConfig> {

}

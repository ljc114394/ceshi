package com.boe.bank.mapper.areaMapper;

import com.boe.bank.common.bean.areabean.AreaSearchBean;
import com.boe.bank.common.entity.area.Area;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * TODO
 *
 * @author lu
 * @version 1.0
 * @data 2020/9/29
 */

@Mapper
public interface AreaMapper {

    Area selectByPrimaryKey(@Param("id") Integer id);

    int insertArea(Area area);

    int updateArea(Area area);

    int deleteAreaById(String[] ids);

    List<Area> getAreaList(@Param("areaSearchBean") AreaSearchBean areaSearchBean,@Param("areaList") List<Long> areaList);

    List<Area> getAreaNameList(@Param("areaList") List<Long> areaList);

    int selectByDepId(@Param ("departmentId") Integer departmentId,@Param ("title") String title);

    List<Area> listByIds(@Param("idList") List<Integer> idList);
}

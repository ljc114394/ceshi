package com.boe.bank.service.activitiService.base;

import java.util.List;
import java.util.Map;

import com.boe.bank.common.bean.activiti.ActivitiUserTaskDto;
import com.boe.bank.common.bean.activiti.UserTaskBo;

/**
 * activiti 
 * 	1. 前端流程图存储
 * 	2. 前端<-->后端 类型相互转化
 * @author caoxuhao
 */
public interface ActivitiWebService {

	/**
	 * 将前端传入的ActivitiUserTaskDto节点对象转化为UserTaskBo实际activiti需要创建的节点描述对象
	 * @param userTaskList
	 * @param creator		选角色时候必传
	 * @return
	 */
	public List<UserTaskBo> convertActivitiUserTaskDto2UserTaskBo(List<ActivitiUserTaskDto> userTaskList);

	/**
	 * 设置各节点审批人 到 审批流参数map
	 * @param map			审批流参数map
	 * @param modelList		节点描述列表
	 * @param creator		审批单提交者
	 * @throws Exception 
	 */
	public void putAssignee(Map<String, Object> map, List<UserTaskBo> modelList, Long creator);

}

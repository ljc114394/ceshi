package com.boe.bank.mapper.material;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.boe.bank.common.bean.material.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.entity.material.MaterialManage;
/**
* @Description:素材管理mapper
* @author: zhaohaixia
* @date: 2020年10月13日 下午2:00:22
 */
@Mapper
public interface MaterialManageMapper {

    int deleteByPrimaryKey(Integer id);

    int insertSelective(MaterialManage record);

	int insertMaterialList(@Param("materialManages") List<MaterialManage> materialManages);

    MaterialManage selectByPrimaryKey(Integer id);

    Integer selectByLabelId(String id);//验证素材管理表中是否存在标签数据

    int updateByPrimaryKeySelective(MaterialManage record);

	int updateMaterialActiveState(@Param ("id")Integer id , @Param ("updateBy")String updateBy , @Param ("updateTime") LocalDateTime updateTime , @Param ("state")Integer state);//审批流更新状态
    /**
    * @Description:根据查询条件分页获取素材列表
    * @param bean
    * @return
    * @author: zhaohaixia
    * @date: 2020年10月13日 下午3:37:03
     */
	List<MaterialListBean> getList(@Param("bean") MaterialConBean bean,@Param("myOrgList") List<Integer> myOrgList );
	/**
	* @Description:根据文档，应用名称查询是否重复
	* @param content
	* @param type
	* @return
	* @author: zhaohaixia
	* @date: 2020年10月14日 下午4:44:27
	 */
	MaterialManage selectByContent(@Param("content")String content,@Param("type") Integer type);
	/**
	* @Description:根据主键id查看素材基本信息
	* @param id
	* @return
	* @author: zhaohaixia
	* @date: 2020年10月15日 上午9:41:56
	 */
	MaterialInfoBean getMaterialInfo(Integer id);
	/**
	* @Description:根据主键id查看素材基本信息
	* @param id
	* @return
	* @author: caoxuhao
	 */
	MaterialInfoBean getMaterialInfoWithDelete(Integer id);
	/**
	* @Description:逻辑删除素材
	* @param id
	* @return
	* @author: zhaohaixia
	* @date: 2020年10月15日 上午11:15:29
	 */
	Integer updateDel(Integer id);
	/**
	* @Description:批量删除素材文件夹
	* @param ids 文件夹素材list id
	* @return
	* @author: zw
	* @date: 2020年12月17日 下午2:46:01
	 */
	Integer updateBatchDel(@Param("ids")List<Integer> ids);
	/**
	 * @Description:逻辑删除文件夹
	 * @param folderId 文件夹id
	 * @return
	 * @author: zhaohaixia
	 * @date: 2020年10月23日 下午2:46:01
	 */
	Integer updateById(@Param("folderId")Integer folderId);
	/**
	* @Description:素材管理列表分页获取 包含文件夹
	* @param bean
	* @return
	* @author: zhaohaixia
	* @date: 2020年10月23日 下午3:40:06
	 */
	List<MaterialFolderListBean> mfpage(@Param("bean") MaterialFolderConBean bean,@Param("myOrgList") List<Integer> myOrgList );
	/**
	* @Description:获取二级文件夹的主键id
	* @param folderId
	* @return
	* @author: zhaohaixia
	* @date: 2020年10月28日 下午5:46:34
	 */
	List<Integer> getFolderIds(@Param("folderId")Integer folderId);
	/**
	 * @Description:获取文件夹下所有文件夹和素材的id
	 * @param folderId
	 * @return
	 * @author: 005
	 * @date: 2020年12月16日 下午5:46:34
	 */
	List<Integer> getFolderAndMaterIds(@Param("folderIds") List<Integer> folderIds);


	/**
	 * @Description:根据parentid查询他的子类 包括未删除的文件夹和素材
	 * @param parentId
	 * @return
	 * @author: user005
	 * @date: 2020年11月25日 下午3:37:03
	 */
	List<MaterialManage> getSubListByParentId(Integer parentId);

	/**
	 * @Description:根据parentid查询他的子类 包括未删除的素材
	 * @param parentId
	 * @return
	 * @author: user005
	 * @date: 2020年11月25日 下午3:37:03
	 */
	List<Integer> getSubMatListByParentId(Integer parentId);

	Integer updateByFolder(@Param("ids")List<Integer> ids);
	List<Map<Integer,Integer>> getMaterialStats(@Param("userId") Long userId);

	List<Integer> getLikeName(@Param("name")String name);
	/**
	 * @Description:素材管理列表分页获取-计划管理-添加素材
	 * @param bean
	 * @return
	 * @author: lvjiacheng
	 * @date: 2020年11月30日
	 */
	List<MaterialFolderListBean> pfpage(@Param("bean") MaterialPlanBean bean,@Param("orgIdList") List<Long> orgIdList);
}
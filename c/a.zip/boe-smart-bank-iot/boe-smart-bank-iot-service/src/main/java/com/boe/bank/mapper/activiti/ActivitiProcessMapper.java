package com.boe.bank.mapper.activiti;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.bean.activiti.ActivitiProcessDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessQueryBean;
import com.boe.bank.common.entity.activiti.ActivitiProcess;

/**
 * 审批流程
 * @author caoxuhao
 */
@Mapper
public interface ActivitiProcessMapper {

	ActivitiProcess selectByPrimaryKey(@Param("id") Integer id);

    int insertSelective(ActivitiProcess activitiProcess);

    int updateByPrimaryKeySelective(ActivitiProcess activitiProcess);

    int deleteByPrimaryKey(@Param("id") Integer id);

    List<ActivitiProcessDo> getList(ActivitiProcessQueryBean activitiProcessQueryBean);
    
    Integer getByExamineId(@Param("examineId") Integer examineId);
    
    Integer getByProcdefId(@Param("processdefinitionId") String processdefinitionId);
    
    Integer getByBusniessType(@Param("busniessType") Integer busniessType);
}

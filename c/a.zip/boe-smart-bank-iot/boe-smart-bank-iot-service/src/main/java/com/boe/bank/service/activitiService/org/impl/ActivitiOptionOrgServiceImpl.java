package com.boe.bank.service.activitiService.org.impl;

import com.alibaba.fastjson.JSON;
import com.boe.bank.common.bean.activiti.ActivitiUserTaskDto;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.activiti.ActivitiProcess;
import com.boe.bank.service.activitiService.base.ActivitiProcessService;
import com.boe.bank.service.activitiService.org.ActivitiOptionOrgService;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * activiti 用户操作
 * @author caoxuhao
 */
@Service
@Slf4j
public class ActivitiOptionOrgServiceImpl implements ActivitiOptionOrgService{
	
	public static final String EXAMINE_PASS = "通过:";
	public static final String EXAMINE_FAIL = "拒绝:";
	
	@Autowired
	private TaskService taskService;

	@Autowired
	private ActivitiProcessService activitiProcessService;
	
	@Override
	public boolean pass(Task task, String reviewer) {
		
		//个人任务
		if(task == null)
			return false;
		
		//候选人组的处理
//		List<String> candidateGroups = acticitiOptUser.getCandidateGroups();
//		boolean isPersonal = true;
//		if(task == null) {
//			if(CollectionUtils.isEmpty(candidateGroups)) {
//				System.err.println("当前没有待审批的任务");
//				return false;
//			}
//			
//			//组任务
//			task = taskService.createTaskQuery()
//				.taskId(taskId)
//				.taskCandidateGroupIn(candidateGroups)
//				.singleResult();
//			
//			if(task == null) {
//				System.err.println("当前没有能审批通过的任务，可能已经被组内其他人审批了，请刷新页面");
//				return false;
//			}
//			
//			isPersonal = false;
//		}
//		
//		if(!isPersonal) {
//			//组任务需要先认领任务
//			taskService.claim(taskId, reviewer);
//		}
		
		String taskId = task.getId();
		
		//评论
		Authentication.setAuthenticatedUserId(reviewer);
		taskService.addComment(taskId, task.getProcessInstanceId(), EXAMINE_PASS);
		
		//处理
		Map<String,Object> map = new HashMap<>();
		map.put("result", 1);
		taskService.complete(taskId, map, true);//localScope必须设置为true，否则之前有同意后，拒绝无法覆盖
		return true;
	}
	
	/**
	 * 拒绝
	 */
	@Override
	public boolean fail(Task task, String reviewer, String comment) {
		
		//个人任务
		if(task == null)
			return false;
		
		String taskId = task.getId();
		String processInstanceId = task.getProcessInstanceId();
		
		//评论
		Authentication.setAuthenticatedUserId(reviewer);
		taskService.addComment(taskId, processInstanceId, EXAMINE_FAIL + comment);
		
		//处理
		Map<String,Object> map = new HashMap<>();
		map.put("result", 0);
		taskService.complete(taskId, map, true);//localScope必须设置为true，否则之前有同意后，拒绝无法覆盖
		return true;
	}
	
	/**
	 * 如果是分给各个部门的任务。则其中一个部门拒绝，其他所有部门自动结束任务。
	 * @param task	目前处理的task
	 * @return
	 */
	@Override
	public List<String> getUsersForCloseOtherDepTask(Task task) {
		String processDefinitionId = task.getProcessDefinitionId();
		ActivitiProcess activitiProcess = activitiProcessService.getByProcdefId(processDefinitionId);
		String resourceData = activitiProcess.getResourceData();
		List<ActivitiUserTaskDto> list = JSON.parseArray(resourceData, ActivitiUserTaskDto.class);
		
		boolean isPassTypeDepartment = false;
		String name = task.getName();
		for (ActivitiUserTaskDto activitiUserTaskDto : list) {
			if(activitiUserTaskDto.getName().equals(name)) {
				int passType = activitiUserTaskDto.getPassType();
				isPassTypeDepartment = (passType == ActivitiConstants.PassType.department);
				break;
			}
		}
		
		if(!isPassTypeDepartment) {
			return null;
		}
		
		String processInstanceId = task.getProcessInstanceId();
		
		//获取剩下所有其他部门的任务
		List<Task> otherDeps = taskService.createTaskQuery().processInstanceId(processInstanceId).list();
		if(CollectionUtils.isEmpty(otherDeps))
			return null;
		
		List<String> userIds = otherDeps.stream().map(Task::getAssignee).collect(Collectors.toList());
		return userIds;
	}
	
	@Override
	public boolean doCloseOtherDepTask(String processInstanceId, List<String> assigneeListIds) {
		
		//获取剩下所有其他部门的任务
		List<Task> otherDeps = taskService.createTaskQuery().processInstanceId(processInstanceId)
				.taskAssigneeIds(assigneeListIds).list();
		if(CollectionUtils.isEmpty(otherDeps))
			return true;
		
		Map<String,Object> map = new HashMap<>();
		map.put("result", 0);
		
		for (Task otherDep : otherDeps) {
			if(assigneeListIds.contains(otherDep.getAssignee())) {
				String otherDepTaskId = otherDep.getId();
				//评论
				Authentication.setAuthenticatedUserId("-1");
				taskService.addComment(otherDepTaskId, processInstanceId, EXAMINE_FAIL + "由于其他组的审核人员已经拒绝，此任务自动结束");
				
				//处理
				taskService.complete(otherDepTaskId, map, true);//localScope必须设置为true，否则之前有同意后，拒绝无法覆盖
			}
		}
		
		return true;
	}
	
	/** 
     * 转办流程 
     * @param task  当前任务
     * @param targetUserId  目标用户
     */
	@Override
    public boolean transferAssignee(Task task, String targetUserId) {  
        taskService.setAssignee(task.getId(), targetUserId);
        return true;
    }
	
	/** 
     * 废弃流程
     * @param taskId 
     */  
	@Override
    public void abandon(String taskId) { 
    	
    	Map<String,Object> map = new HashMap<>();
		map.put("result", 2);
		taskService.complete(taskId, map);
    }  
    
    /** 
     * 获取task
     * @param processInstanceId 
     * @param reviewer 
     */
    @Override
    public Task getTask(String processInstanceId, String reviewer) { 
    	
    	return taskService.createTaskQuery()// 创建任务查询对象
				.processInstanceId(processInstanceId)
				.taskAssignee(reviewer)// 指定个人任务查询
				.singleResult();
    }  

    /**
     * 获取task
     * @param taskId
     * @param reviewer
     */
    @Override
    public Task getTaskByTaskId(String taskId, String reviewer) {

    	return taskService.createTaskQuery()// 创建任务查询对象
				.taskId(taskId)
				.taskAssignee(reviewer)// 指定个人任务查询
				.singleResult();
    }

    /** 
     * 获取taskList
     * @param processInstanceId 
     */
    @Override
    public List<Task> getTaskList(String processInstanceId) { 
    	
    	return taskService.createTaskQuery()// 创建任务查询对象
    			.processInstanceId(processInstanceId)
    			.list();
    }  
}

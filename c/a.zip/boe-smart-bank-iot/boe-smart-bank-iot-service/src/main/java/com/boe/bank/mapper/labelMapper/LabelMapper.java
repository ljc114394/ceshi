package com.boe.bank.mapper.labelMapper;

import com.boe.bank.common.bean.labelBean.LabelInfoBean;
import com.boe.bank.common.bean.labelBean.LabelSearchBean;
import com.boe.bank.common.entity.label.Label;

import java.util.List;

/**
 * TODO
 * 标签管理mapper
 * @author lijianglong
 * @data 2020/10/13
 */

public interface LabelMapper {

    List<Label> getLabelList(LabelSearchBean labelSearchBean);

    List<Label> getLabelAllList();

    int queryLabel(LabelInfoBean labelInfoBean);

    int addLabel(Label label);

    int updateLabel(Label label);

    int deleteLabelById(String[] id);
}

package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.userinfobean.*;
import com.boe.bank.common.entity.userinfo.UserInfo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UserInfoCoverter {


    UserInfoBean getUserInfoBean(UserInfo userInfo);


    UserInfo getUserInfo(UserInfoSaveBean userInfoBean);


    List<UserInfoBean> getUserInfoBeanList(List<UserInfo> dicts);

    @Mappings({
            @Mapping(source = "id", target = "uid")
    })
    UserInfoPeopleBean getUserInfoPeopleBean(UserInfo userInfo);

    List<UserInfoPeopleBean> getUserInfoPeopleBeanList(List<UserInfo> dicts);

    UserInfoByLoginBean getUserInfoLogin(com.boe.cloud.megarock.security.common.UserInfo userInfo);


}

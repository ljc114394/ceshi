package com.boe.bank.service.activitiService.base.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.boe.bank.common.bean.activiti.ActivitiProcessQueryReqExtBo;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.utils.DateUtil;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.boe.bank.common.base.PageBean;
import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.ActivitiProcessDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessOrgDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessQueryReqExt;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;
import com.boe.bank.mapper.activiti.ActivitiOuterRelationMapper;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;

@Service
public class ActivitiOuterRelationServiceImpl implements ActivitiOuterRelationService{

	@Autowired
	private ActivitiOuterRelationMapper activitiOuterRelationMapper;
	
	@Autowired
	private ActivitiOptionService activitiOptionService;

	@Transactional
	@Override
	public boolean insert(ActivitiOuterRelation activitiOuterRelation) {

		Integer busniessType = activitiOuterRelation.getBusniessType();
		Integer outerId = activitiOuterRelation.getOuterId();
		Integer outerType = activitiOuterRelation.getOuterType();

		ActivitiOuterRelation old = getByBusniessTypeAndOuterId(busniessType, outerId, outerType);
		if (old != null) {
			if (!deleteById(old.getId()))
				return false;
			
			//作废原有的工作流
			String processInstanceId = old.getProcessInstanceId();
			activitiOptionService.abandon(processInstanceId);
		}

		activitiOuterRelation.setShowId(createShowId());

		return activitiOuterRelationMapper.insertSelective(activitiOuterRelation) > 0;
	}

	private static String createShowId(){
		int i = new Random().nextInt(99999);
		String showId = DateUtil.format(new Date(), "yyyyMMddHHmmss") + String.format("%05d", i);
		return showId;
	}

	@Override
	public boolean deleteById(Integer id) {
		return activitiOuterRelationMapper.deleteByPrimaryKey(id) > 0;
	};

	@Override
	public List<ActivitiOuterRelation> getList(Integer busniessType, List<Integer> outerIds) {
		return activitiOuterRelationMapper.getList(busniessType, outerIds);
	}

	@Override
	public ActivitiOuterRelation getByBusniessTypeAndOuterId(Integer busniessType, Integer outerId, Integer outerType) {
		return activitiOuterRelationMapper.getByBusniessTypeAndOuterId(busniessType, outerId, outerType);
	}
	
	@Override
	public ActivitiOuterRelation getByProcessInstanceId(String processInstanceId) {
		return activitiOuterRelationMapper.getByProcessInstanceId(processInstanceId);
	}

	@Override
	public ActivitiOuterRelation getByBusniessTypeAndProcessInstanceId(Integer busniessType, String processInstanceId) {
		return activitiOuterRelationMapper.getByBusniessTypeAndProcessInstanceId(busniessType, processInstanceId);
	}

	@Override
	public List<ActivitiOuterRelation> getAllByBusniessTypeAndUserId(Long userId, Integer busniessType) {
		return activitiOuterRelationMapper.getAllByBusniessTypeAndUserId(userId, busniessType);
	}
	
	@Override
	public PageInfoDto<ActivitiProcessOrgDo> getExaminedProcessList (ActivitiProcessQueryReqExtBo req){
		
		return queryByPage(req, p -> {
			return activitiOuterRelationMapper.getExaminedProcessList(
					p.getBusniessType(), p.getUserId(), p.getOuterIds(), p.getEndActIds(), p.getProcessStatus(), p.getOuterTypes());
		});
	}
	
	@Override
	public PageInfoDto<ActivitiProcessOrgDo> getMyProcessList (ActivitiProcessQueryReqExtBo req){
		
		return queryByPage(req, p -> {
			List<ActivitiProcessOrgDo> list = activitiOuterRelationMapper.getMyProcessList(p.getBusniessType(), p.getUserId(),
					p.getOuterIds(), p.getEndActIds(), p.getOuterTypes());
			List<String> processInstanceIds = list.stream().filter(t -> ActivitiConstants.Node.rejectEnd.equals(t.getEai())).map(ActivitiProcessOrgDo::getProcessInstanceId).collect(Collectors.toList());
			if(!CollectionUtils.isEmpty(processInstanceIds)){
				List<ActivitiProcessOrgDo> processStatuss = activitiOuterRelationMapper.getProcessStatus(processInstanceIds);
				Map<String, String> map = processStatuss.stream().collect(Collectors.toMap(ActivitiProcessOrgDo::getProcessInstanceId, ActivitiProcessOrgDo::getProcessStatus));
				list.stream().filter(t -> ActivitiConstants.Node.rejectEnd.equals(t.getEai())).forEach(t->t.setProcessStatus(map.get(t.getProcessInstanceId())));
			}
			return list;
		});
	}
	
	@Override
	public PageInfoDto<ActivitiProcessOrgDo> getTodoProcessList (ActivitiProcessQueryReqExtBo req){
		
		return queryByPage(req, p -> {
			return activitiOuterRelationMapper.getTodoProcessList(p.getBusniessType(), p.getUserId(),
					p.getOuterIds(), p.getEndActIds(), p.getOuterTypes());
		});
	}
	
	@Override
	public Integer getTodoCount(Integer busniessType, Long userId) {

		Integer i = activitiOuterRelationMapper.getTodoCount(busniessType, userId);

		if(i == null)
			i = 0;

		return i;
	}
	
	@Override
	public Integer getExaminedCount(Integer busniessType, Long userId) {
		return activitiOuterRelationMapper.getExaminedCount(busniessType, userId);
	}

	@Override
	public boolean abandon(Integer busniessType, Integer outerId, Integer outerType){

		ActivitiOuterRelation old = getByBusniessTypeAndOuterId(busniessType, outerId, outerType);
		if (old != null) {
//			if (!deleteById(old.getId()))
//				return true;

			//作废未完成工作流
			String processInstanceId = old.getProcessInstanceId();
			activitiOptionService.abandon(processInstanceId);

			//作废已完成工作流
			activitiOuterRelationMapper.abandon(processInstanceId);
		}

		return true;
	}
	
	private <T> PageInfoDto<T> queryByPage(ActivitiProcessQueryReqExtBo req, Function<ActivitiProcessQueryReqExtBo, List<T>> f){
		Page<T> page = PageHelper.startPage(req.getPageNum(), req.getPageSize(), true);
		List<T> list = f.apply(req);
		
		if(CollectionUtils.isEmpty(list)) {
			list = Lists.newArrayList();
		}
		
		PageInfoDto<T> pageInfo = new PageInfoDto<>(list, page);
		return pageInfo;
	}
}

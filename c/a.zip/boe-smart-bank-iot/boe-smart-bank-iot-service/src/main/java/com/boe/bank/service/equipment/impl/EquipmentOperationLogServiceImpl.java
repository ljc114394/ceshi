package com.boe.bank.service.equipment.impl;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.equipment.EquipmentOperationLogQO;
import com.boe.bank.common.bean.equipment.EquipmentOperationLogVO;
import com.boe.bank.common.entity.equipment.EquipmentOperationLog;
import com.boe.bank.mapper.equipment.EquipmentOperationLogMapper;
import com.boe.bank.service.equipment.EquipmentOperationLogService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;

import cn.hutool.core.collection.CollectionUtil;
import jodd.util.StringUtil;

/**
 * 设备运维日志 ServiceImpl
 * @author 10085188
 *
 */
@Service("equipmentOperationLogService")
public class EquipmentOperationLogServiceImpl implements EquipmentOperationLogService {

	@Autowired
	private EquipmentOperationLogMapper mapper;
	
	@Override
	public PageInfo<EquipmentOperationLogVO> page(EquipmentOperationLogQO qo) {
		Page<EquipmentOperationLogVO> page = PageHelper.startPage(qo.getPageNum(), qo.getPageSize(), true);
		List<EquipmentOperationLogVO> list = mapper.getList(qo);
		if (!CollectionUtil.isEmpty(list)) {
			DecimalFormat df = new DecimalFormat("0.00%");
			for (EquipmentOperationLogVO vo : list) {
				String disk = vo.getDisk();
				String memory = vo.getMemory();
				String cpu = vo.getCpu();
				if (!StringUtil.isEmpty(cpu)) {
					vo.setCpu(df.format(Double.parseDouble(cpu)));
				}
				if (!StringUtil.isEmpty(disk)) {
					vo.setDisk(readableFileSize(Long.parseLong(disk)));
				}
				if (!StringUtil.isEmpty(memory)) {
					vo.setMemory(readableFileSize(Long.parseLong(memory)));
				}
			}
		}
		return new PageInfo<EquipmentOperationLogVO>(list, page);
	}

	@Override
	public List<EquipmentOperationLogVO> getByOrgId(Integer orgId) {
		return mapper.getByOrgId(orgId);
	}

	@Override
	public List<EquipmentOperationLogVO> getByTypeId(Integer typeId) {
		return mapper.getByTypeId(typeId);
	}

	@Override
	public List<EquipmentOperationLogVO> list(EquipmentOperationLogQO qo) {
		List<EquipmentOperationLogVO> list =  mapper.getList(qo);
		if (!CollectionUtil.isEmpty(list)) {
			DecimalFormat df = new DecimalFormat("0.00%");
			for (EquipmentOperationLogVO vo : list) {
				String disk = vo.getDisk();
				String memory = vo.getMemory();
				String cpu = vo.getCpu();
				if (!StringUtil.isEmpty(cpu)) {
					vo.setCpu(df.format(Double.parseDouble(cpu)));
				}
				if (!StringUtil.isEmpty(disk)) {
					vo.setDisk(readableFileSize(Long.parseLong(disk)));
				}
				if (!StringUtil.isEmpty(memory)) {
					vo.setMemory(readableFileSize(Long.parseLong(memory)));
				}
			}
		}
		return list;
	}

	@Override
	public List<EquipmentOperationLogVO> getEquipmentLogList() {
		List<EquipmentOperationLogVO> list =  mapper.getEquipmentLogList();
		if (!CollectionUtil.isEmpty(list)) {
			DecimalFormat df = new DecimalFormat("0.00%");
			for (EquipmentOperationLogVO vo : list) {
				String disk = vo.getDisk();
				String memory = vo.getMemory();
				String cpu = vo.getCpu();
				if (!StringUtil.isEmpty(cpu)) {
					vo.setCpu(df.format(Double.parseDouble(cpu)));
				}
				if (!StringUtil.isEmpty(disk)) {
					vo.setDisk(readableFileSize(Long.parseLong(disk)));
				}
				if (!StringUtil.isEmpty(memory)) {
					vo.setMemory(readableFileSize(Long.parseLong(memory)));
				}
			}
		}
		return list;
	}

	@Override
	public void saveBatch(List<EquipmentOperationLog> list) {
		mapper.saveBatch(list);
	}



	// 转为 KB GB TB
	private static String readableFileSize(long size) {
		// 如果原字节数除于1000之后，少于1000，则可以直接以KB作为单位
		// 因为还没有到达要使用另一个单位的时候
		// 接下去以此类推
		if (size < 1000) {
			return String.valueOf(size) + "KB";
		} else {
			size = size / 1000;
		}

		if (size < 1000) {
			// 因为如果以MB为单位的话，要保留最后1位小数，
			// 因此，把此数乘以100之后再取余
			size = size * 100;
			if (size % 100 == 0) {
				return String.valueOf((size / 100)) + "MB";
			} else {
				return String.valueOf((size / 100)) + "." + String.valueOf((size % 100)) + "MB";
			}

		}
		if (size < 1000000) {
			// 否则如果要以GB为单位的，先除于1024再作同样的处理
			size = size * 100 / 1000;
			if (size % 100 == 0) {
				return String.valueOf((size / 100)) + "GB";
			} else {
				return String.valueOf((size / 100)) + "." + String.valueOf((size % 100)) + "GB";
			}

		} else {
			size = size * 100 / 1000000;
			if (size % 100 == 0) {
				return String.valueOf((size / 100)) + "TB";
			} else {
				return String.valueOf((size / 100)) + "." + String.valueOf((size % 100)) + "TB";
			}

		}

	}
		
	public static void main(String[] args) {
		System.out.print(readableFileSize(8438048));
	}
}

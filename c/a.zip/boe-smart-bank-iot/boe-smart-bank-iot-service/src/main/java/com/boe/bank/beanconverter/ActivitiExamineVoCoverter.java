package com.boe.bank.beanconverter;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.boe.bank.common.bean.activiti.ActivitiExamineVo;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
/**
 * 审批类型列表界面展示转化类
 * @author caoxuhao
 */
@Mapper(componentModel = "spring")
public interface ActivitiExamineVoCoverter {

    @Mappings({
    	@Mapping(target = "busniessType", expression = "java(com.boe.bank.common.constant.ActivitiConstants.BusniessType.get(examinte.getBusniessType()))"),
    	@Mapping(target = "status", expression = "java(com.boe.bank.common.constant.ActivitiConstants.Status.get(examinte.getStatus()))")
    })
    ActivitiExamineVo getExamineVo(ActivitiExamine examinte);

    List<ActivitiExamineVo> getExamineVoList(List<ActivitiExamine> list);

}

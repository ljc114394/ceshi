package com.boe.bank.mapper.dictMapper;

import java.util.List;

import com.boe.bank.common.bean.dictbean.SysDictionariesBean;
import com.boe.bank.common.bean.dictbean.SysDictionariesListBean;
import com.boe.bank.common.bean.dictbean.SysDictionariesParentBean;
import com.boe.bank.common.bean.productlibrarybean.ProductDictDO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.entity.dict.SysDictionaries;


@Mapper
public interface SysDictionariesMapper {

	List<SysDictionaries> getDictionariestList(@Param ("id") Integer id,@Param ("type")Integer type,@Param ("title")String title);

   /**
    * 新增下一级
    * @param sysDictionaries
    * @return
    */
    int saveDictionaries(SysDictionaries sysDictionaries);
    
    /**
     * 根据id删除字典管理
     * @param id
     * @return
     */
    int deleteSysDictionariesId(@Param("id")Integer id,@Param("isDeleted")Long isDeleted);
    
    /**
     * 编辑当前页面
     * @param sysDictionaries
     * @return
     */
	int updateDictionariesId(SysDictionaries sysDictionaries);
	

	
	/**
	 * 查取下拉树
	 * @param
	 * @return
	 */
	List<SysDictionaries> getDictionariesTree();
	
	
	SysDictionaries getDictionariesId(Integer id);

	SysDictionaries getDictionariesByCode(@Param ("code") String code,@Param ("id") Integer id);

	List<SysDictionaries>  getDictionariesByParentId(@Param ("parentId") Integer parentId);

	List<SysDictionariesParentBean> getParentCode(@Param ("code") String code);

	/**
	 * 通过parentcode  获取 字标签值
	 * @param code
	 * @return
	 */
	List<ProductDictDO> getParentCodeByLabel(String code);


	List<SysDictionariesListBean> getDictAll();

	List<SysDictionaries>  getDictCondition();

	int isEnableSysDictionariesId(@Param("id")Integer id,@Param("isEnable")Integer isEnable);
}

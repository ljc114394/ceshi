package com.boe.bank.service.activitiService.manager;

import com.google.common.collect.Maps;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 管理所有实现activitiSupport接口的类
 */
@Component
public class ActivitiSupportManager implements InitializingBean {

    @Autowired
    private ApplicationContext applicationContext;

    /**每个busniessType由一个对应的support处理*/
    private Map<Integer, ActivitiSupport> activitiSupports = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        Map<String, ActivitiSupport> beans = applicationContext.getBeansOfType(ActivitiSupport.class);
        if(beans != null && beans.size() > 0)
            beans.values().forEach(bean ->  activitiSupports.put(bean.getBusniessType(), bean));
    }

    /**
     * 根据busniessType和outerType 获取实际需要操作的support
     * @param busniessType
     * @return
     */
    public ActivitiSupport getActivitiSupport(int busniessType){
        return activitiSupports.get(busniessType);
    }
}

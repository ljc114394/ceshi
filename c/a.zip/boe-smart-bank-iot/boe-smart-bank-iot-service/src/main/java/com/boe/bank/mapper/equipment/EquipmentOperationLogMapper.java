package com.boe.bank.mapper.equipment;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.bean.equipment.EquipmentOperationLogQO;
import com.boe.bank.common.bean.equipment.EquipmentOperationLogVO;
import com.boe.bank.common.entity.equipment.EquipmentOperationLog;

/**
 * 设备运维日志 Mapper
 * @author 10085188
 *
 */
@Mapper
public interface EquipmentOperationLogMapper extends BaseMapper<EquipmentOperationLog> {
	EquipmentOperationLog selectByPrimaryKey(@Param("id") Integer id);

    int insertSelective(EquipmentOperationLog operationLog);

    List<EquipmentOperationLogVO> getList(EquipmentOperationLogQO queryBean);
    
    List<EquipmentOperationLogVO> getByOrgId(@Param("orgId") Integer orgId);
    
    List<EquipmentOperationLogVO> getByTypeId(@Param("typeId") Integer typeId);
    
    void saveBatch(@Param("list") List<EquipmentOperationLog> list);

    List<EquipmentOperationLogVO> getEquipmentLogList();
}

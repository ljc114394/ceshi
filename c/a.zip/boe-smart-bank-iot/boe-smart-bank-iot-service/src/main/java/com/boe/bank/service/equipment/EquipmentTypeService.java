package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipment.EquipmentTypeQO;
import com.boe.bank.common.bean.equipment.EquipmentTypeVO;
import com.boe.bank.common.entity.equipment.EquipmentType;

/**
 * 设备类型 Service
 *
 * @author 10183279
 * @date 2020/12/1
 */
public interface EquipmentTypeService extends IService<EquipmentType> {

    /**
     * 分页获取设备类型信息
     *
     * @param qo
     * @author: 10183279
     * @date: 2020/12/1
     * @return:
     */
    IPage<EquipmentTypeVO> page(EquipmentTypeQO qo);

    /**
     * 根据名称获取设备类型信息
     *
     * @param name
     * @author: 10183279
     * @date: 2020/12/1
     * @return:
     */
    EquipmentType getByName(String name);

    EquipmentType getById(Integer id);
}

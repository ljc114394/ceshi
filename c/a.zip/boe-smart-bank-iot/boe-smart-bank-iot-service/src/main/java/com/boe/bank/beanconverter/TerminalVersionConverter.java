package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.equipment.EquipmentVersionVO;
import com.boe.bank.common.bean.terminalversion.TerminalVersionDTO;
import com.boe.bank.common.entity.terminalversion.TerminalVersion;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 设备相关类转换器
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Mapper
public interface TerminalVersionConverter {

    TerminalVersionConverter INSTANCE = Mappers.getMapper(TerminalVersionConverter.class);

    /**
     * dto转为entity
     * @param dto
     * @return
     */
    TerminalVersion dtoToEntity(TerminalVersionDTO dto);

    EquipmentVersionVO entityToVo(TerminalVersion entity);

    List<EquipmentVersionVO> entityListToVoList(List<TerminalVersion> entityList);
}

package com.boe.bank.service.activitiService.base.impl;

import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.ActivitiExamineQueryBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.mapper.activiti.ActivitiExamineMapper;
import com.boe.bank.service.activitiService.base.ActivitiExamineService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@Slf4j
public class ActivitiExamineServiceImpl implements ActivitiExamineService {
	
	@Autowired
	private ActivitiExamineMapper activitiExamineMapper;
	
	/**
	 * 通过业务类型获取 审批类型列表(只看已启用的)
	 * @param busniessType
	 * @return
	 */
	@Override
	public List<ActivitiExamine> getActivitiExamineListByBusniessType(Integer busniessType){
		ActivitiExamineQueryBean query = new ActivitiExamineQueryBean();
		query.setBusniessType(busniessType);
		query.setStatus(ActivitiConstants.Status.ok);
		List<ActivitiExamine> list = activitiExamineMapper.getAvailableList(query);
		return list;
	}
	
	/**
	 * 瀑布分页获取 审批类型列表(所有)
	 * @param query
	 * @return
	 */
	@Override
	public PageInfoDto<ActivitiExamine> getList(ActivitiExamineQueryBean query){
		
		Page<ActivitiExamine> page = PageHelper.startPage(query.getPageNum(),
				query.getPageSize(), true);
		
		List<ActivitiExamine> list = activitiExamineMapper.getList(query);
		
		PageInfoDto<ActivitiExamine> pageInfo = new PageInfoDto<>(list, page);
		return pageInfo;
	}
	
	
	
	@Override
	public ActivitiExamine load(int id) {
		return activitiExamineMapper.selectByPrimaryKey(id);
	}
	
	@Override
	public boolean insert(ActivitiExamine activitiExamine) {
		
		if(activitiExamine.getId() != null)
			activitiExamine.setId(null);
		
		if(activitiExamine.getStatus() == null)
			activitiExamine.setStatus(ActivitiConstants.Status.ok);
		
		activitiExamine.setCreateTime(DateUtil.current());
		
		return activitiExamineMapper.insertSelective(activitiExamine) > 0;
	}
	
	@Override
	public int checkDuplicate(Integer busniessType, String examineType) {
		return activitiExamineMapper.checkDuplicate(busniessType, examineType);
	}
	
	/**
	 * 更新审批类型
	 * @param activitiExamine
	 * @return
	 */
	@Override
	public boolean updateById(ActivitiExamine activitiExamine) {
		
		Integer id = activitiExamine.getId();
		if (id == null)
			return false;

		if(StringUtils.isEmpty(activitiExamine.getUpdateBy()))
			activitiExamine.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());

		activitiExamine.setUpdateTime(DateUtil.current());
		
		return activitiExamineMapper.updateByPrimaryKeySelective(activitiExamine) > 0;

	}
	
	/**
	 * 删除审批类型
	 * @param id
	 * @return
	 */
	@Override
	public boolean deleteById(int id) {
		return activitiExamineMapper.deleteByPrimaryKey(id) > 0;
	}
}

package com.boe.bank.mapper.logMapper;

import com.boe.bank.common.base.PageBean;
import com.boe.bank.common.bean.logbean.*;
import com.boe.bank.common.entity.log.ApprovalLog;
import com.boe.bank.common.entity.log.OperationLog;
import com.boe.bank.common.entity.log.PublicLog;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Description:日志管理
 * @author: lvjiacheng
 * @date: 2020年10月29日 16:57
 */
@Mapper
public interface LogMapper {


    int insertLog(OperationLog log);

    int insertApprovalLog(ApprovalLog logm);

    List<OperationLog> getOperationLogList(OperationLogSearchBean logBean);

    List<ApprovalLog> getApprovalLogList(ApprovalLogSearchBean logBean);

    List<OperationLog> getOperationLogListExport(LogSearchExportBean logBean);

    List<ApprovalLog> getApprovalLogListExport(LogSearchExportBean logBean);

    List<PublicLog> getLoginLogPage(LoginlogSearchBean logBean);

    List<PublicLog> getInterfacePage(InterfacelogSearchBean logBean);

    List<PublicLog> getLoginLogListExport(LoginLogSearchExportBean logBean);

    List<PublicLog> getInterfaceLogListExport(InterfaceLogSearchExportBean logBean);

    List<SysLogBean> getSysList(Long exportTime);

    List<OperationLog> logByOrgAll(OperationLogSearchBean logBean);

    int timedDeleteLog(Long deleteTime);
}

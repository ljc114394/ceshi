package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.boe.bank.common.entity.equipment.EquipmentStatus;
import com.boe.bank.mapper.equipment.EquipmentStatusMapper;
import com.boe.bank.service.equipment.EquipmentStatusService;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 设备状态 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/19
 */
@Service("equipmentStatusService")
public class EquipmentStatusServiceImpl extends ServiceImpl<EquipmentStatusMapper, EquipmentStatus> implements EquipmentStatusService {

    @Override
    public List<EquipmentStatus> listByMacs(List<String> macList) {
        if (CollectionUtils.isEmpty(macList)) {
            return new ArrayList<>();
        }
        return ChainWrappers.lambdaQueryChain(getBaseMapper()).in(EquipmentStatus::getMac, macList).list();
    }

    @Override
    public void update(String mac, Integer isOnline) {
        EquipmentStatus entity = ChainWrappers.lambdaQueryChain(getBaseMapper()).eq(EquipmentStatus::getMac, mac).one();
        if (entity == null) {
            entity = new EquipmentStatus();
            entity.setMac(mac);
            entity.setIsOnline(isOnline);
            entity.setLastOnlineTime(LocalDateTime.now());
            getBaseMapper().insert(entity);
        } else {
            entity.setIsOnline(isOnline);
            entity.setLastOnlineTime(LocalDateTime.now());
            getBaseMapper().updateById(entity);
        }
    }
}

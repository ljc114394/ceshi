package com.boe.bank.service.dictService;

import com.boe.bank.beanconverter.SysDictionariesCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.dictbean.*;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.DictConst;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.entity.dict.SysDictionaries;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.common.utils.TreeUtil;
import com.boe.bank.mapper.dictMapper.SysDictionariesMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SysDictionariesService {
    @Autowired
    private SysDictionariesMapper sysDictionariesMapper;
    @Autowired
    private SysDictionariesCoverter sysDictionariesCoverter;
    @Autowired
    private RedissionUtils redissionUtils;

    /**
     * 字典分页
     *
     * @param sysDictionariesSearchBean
     * @return
     */
    public PageInfo<SysDictionariesInfoBean> dictPage(SysDictionariesSearchBean sysDictionariesSearchBean) {

        if (sysDictionariesSearchBean.getPageNum () == null) {
            sysDictionariesSearchBean.setPageNum (Const.PAGE_NUM_DEFAULT);
        }
        if (sysDictionariesSearchBean.getPageSize () == null) {
            sysDictionariesSearchBean.setPageSize (Const.PAGE_SIZE_DEFAULT);
        }
        if (sysDictionariesSearchBean.getId () == null || sysDictionariesSearchBean.getId () < 0) {
            sysDictionariesSearchBean.setId (0);
        }
        if (sysDictionariesSearchBean.getType () == null || sysDictionariesSearchBean.getType () < 0) {
            sysDictionariesSearchBean.setType (0);
        }

        Page page = PageHelper.startPage (sysDictionariesSearchBean.getPageNum (), sysDictionariesSearchBean.getPageSize (), true);
        List<SysDictionaries> sysDictionaries = sysDictionariesMapper.getDictionariestList (sysDictionariesSearchBean.getId (), sysDictionariesSearchBean.getType (),sysDictionariesSearchBean.getTitle());
        List<SysDictionariesInfoBean> dictBean = sysDictionariesCoverter.getDictInfoBeanList (sysDictionaries);

        return new PageInfo<SysDictionariesInfoBean> (dictBean, page);
    }

    /**
     * 新增下一级
     *
     * @param sysDictionariesBean
     * @return
     */
    @Transactional
    public int saveDictionaries(SysDictionariesBean sysDictionariesBean) {

        log.info ("新增下一级 sysDictionariesBean:{}", sysDictionariesBean);
        if (StringUtils.isEmpty (sysDictionariesBean.getTitle ())) {
            throw new BusinessException (MsgReturnEnum.DICT_TITLE);
        }
        if (StringUtils.isEmpty (sysDictionariesBean.getCode ())) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE);
        }
        if (StringUtils.isEmpty (sysDictionariesBean.getCodeValue ())) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE_VALUE);
        }

        if (getCodeVaild (sysDictionariesBean.getCode (),0)) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE_REPEAT);
        }

        SysDictionaries sysDictionaries = sysDictionariesCoverter.getSysDictionaries (sysDictionariesBean);
        sysDictionaries.setCreateBy (UserInfo.getCurrentUserInfo().getUsername());
        sysDictionaries.setCreateTime (LocalDateTime.now ());
        sysDictionaries.setCreateUserId (UserInfo.getCurrentUserId ());
        int ret = sysDictionariesMapper.saveDictionaries (sysDictionaries);
        if (ret > 0) {
            if (redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).isExists ()) {
                redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).delete ();
            }


            if (CollectionUtils.isEmpty (sysDictionariesMapper.getDictionariesByParentId (sysDictionaries.getId ()))) {
                redissionUtils.getRMap (RedisPrefix.DICT_MAP).put (sysDictionaries.getCode (), Lists.newArrayList (sysDictionaries));
            }
            //更新parentId 对应的 缓存
            if (sysDictionaries.getParentId () > 0) {
                List<SysDictionaries> dicts = sysDictionariesMapper.getDictionariesByParentId (sysDictionaries.getParentId ());
                SysDictionaries parentDict = sysDictionariesMapper.getDictionariesId (sysDictionaries.getParentId ());
                if (parentDict.getId () != null) {
                    redissionUtils.getRMap (RedisPrefix.DICT_MAP).put (parentDict.getCode (), dicts);
                }

            }
        }
        return ret;
    }

    /**
     * 编辑当前回显
     *
     * @param id
     * @return
     */
    public SysDictionariesBean getDictionariesId(Integer id) {
        log.info ("getDictionariesId id:{}", id);
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.DICT_ID);
        }
        SysDictionaries sysDictionaries = sysDictionariesMapper.getDictionariesId (id);
        if (sysDictionaries == null) {
            return new SysDictionariesBean ();
        }
        SysDictionariesBean bean = sysDictionariesCoverter.getSysDictionariesCHange (sysDictionaries);
        log.info ("getMemberById id:{} bean:{}", id, bean);
        return bean;
    }

    /**
     * 根据ID删除字典管理
     *
     * @param id
     * @return
     */
    public int deleteSysDictionariesId(Integer id) {
        log.info ("deleteAreaById id:{}", id);
        if (id == null || id.intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.DICT_ID);
        }
        List<SysDictionaries> dicts = sysDictionariesMapper.getDictionariesByParentId (id);

        if (!CollectionUtils.isEmpty (dicts)) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE_PARENT);
        }
        SysDictionaries dict = sysDictionariesMapper.getDictionariesId (id);//获取当前信息
        Long isDeleted = LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"));//获取当前时间的秒的时间戳
        int ret = sysDictionariesMapper.deleteSysDictionariesId (id,isDeleted);//删除数据库
        if (ret > 0) {
            if (redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).isExists ()) {//删除所有缓存
                redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).delete ();
            }
            if (redissionUtils.isExist (RedisPrefix.DICT_MAP)) {
                redissionUtils.getRMap (RedisPrefix.DICT_MAP).remove (dict.getCode ());//删除对应的缓存
                //更新parentId 对应的 缓存
                if (dict.getParentId () > 0) {
                    SysDictionaries parentDict = sysDictionariesMapper.getDictionariesId (dict.getParentId ());//获取上一级的信息
                    if (parentDict.getId () != null) {//上一级信息有,在缓存中删除
                        redissionUtils.getRMap (RedisPrefix.DICT_MAP).remove (parentDict.getCode ());
                    }

                }
            }
        }
        return ret;
    }

    /**
     * 编辑当前页面
     *
     * @param sysDictionariesBean
     * @return
     */
    public int updateDictionariesId(SysDictionariesBean sysDictionariesBean, Integer id) {

        log.info ("updateDictionariesId sysDictionariesBean:{}", sysDictionariesBean);

        if (id == null || id.intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.DICT_ID);
        }

        if (StringUtils.isEmpty (sysDictionariesBean.getTitle ())) {
            throw new BusinessException (MsgReturnEnum.DICT_TITLE);
        }
        if (StringUtils.isEmpty (sysDictionariesBean.getCode ())) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE);
        }
        if (StringUtils.isEmpty (sysDictionariesBean.getCodeValue ())) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE_VALUE);
        }

        if (getCodeVaild (sysDictionariesBean.getCode (),id)) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE_REPEAT);
        }

        SysDictionaries sysDictionaries = sysDictionariesCoverter.getSysDictionaries (sysDictionariesBean);
        sysDictionaries.setUpdateBy (UserInfo.getCurrentUserInfo().getUsername());
        sysDictionaries.setUpdateTime (LocalDateTime.now ());
        SysDictionaries oldSysDictionaries = sysDictionariesMapper.getDictionariesId (id);
        sysDictionaries.setId (id);
        int ret = sysDictionariesMapper.updateDictionariesId (sysDictionaries);
        if (ret > 0) {
            if (redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).isExists ()) {
                redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).delete ();
            }
            if (redissionUtils.isExist (RedisPrefix.DICT_MAP)) {
                redissionUtils.getRMap (RedisPrefix.DICT_MAP).remove (oldSysDictionaries.getCode ());
                //更新parentId 对应的 缓存
                if (sysDictionaries.getParentId () > 0) {
                    SysDictionaries parentDict = sysDictionariesMapper.getDictionariesId (sysDictionaries.getParentId ());
                    if (parentDict.getId () != null) {
                        redissionUtils.getRMap (RedisPrefix.DICT_MAP).remove (parentDict.getCode ());
                    }

                }
            }
            if (CollectionUtils.isEmpty (sysDictionariesMapper.getDictionariesByParentId (sysDictionaries.getId ()))) {
                redissionUtils.getRMap (RedisPrefix.DICT_MAP).put (sysDictionaries.getCode (), Lists.newArrayList (sysDictionaries));
            }
            //更新parentId 对应的 缓存
            if (sysDictionaries.getParentId () > 0) {
                List<SysDictionaries> dicts = sysDictionariesMapper.getDictionariesByParentId (sysDictionaries.getParentId ());
                SysDictionaries parentDict = sysDictionariesMapper.getDictionariesId (sysDictionaries.getParentId ());
                if (parentDict.getId () != null) {
                    redissionUtils.getRMap (RedisPrefix.DICT_MAP).put (parentDict.getCode (), dicts);
                }

            }

        }
        return ret;
    }

    /**
     * 根据code获取对应的字典值
     *
     * @param code
     * @return
     */
    public List<SysDictionaries> getDictionariesRedis(String code) {
        try {
            if (StringUtils.isEmpty (code)) {
                throw new BusinessException (MsgReturnEnum.DICT_CODE);
            }
            List<SysDictionaries> dicts = Lists.newArrayList ();
            if (redissionUtils.isExist (RedisPrefix.DICT_MAP)) {
                dicts = (List<SysDictionaries>) redissionUtils.getRMap (RedisPrefix.DICT_MAP).get (code);
                if (!CollectionUtils.isEmpty (dicts)) {
                    return dicts;
                }

            }
            if (CollectionUtils.isEmpty (dicts)) {
                List<SysDictionaries> dictDb = getDictDb(code);
                //redissionUtils.getRMap (RedisPrefix.DICT_MAP).put (code,dictDb);
                return dictDb;
            } else {
                return dicts;
            }

        } catch (Exception e) {
            log.info ("getDictionariesRedis code:{} error:{}", code, ExceptionUtils.getMessage (e.fillInStackTrace ()));
            return getDictDb(code);
        }
    }

    /**
     * 获取字典表条件属性名称
     *
     * @return
     */
    public List<SysDictionaries> getDictCondition() {
       return sysDictionariesMapper.getDictCondition();
    }


    /**
     * 获取字典树
     * @return
     * @throws Exception
     */
    public SysDictionariesTreeBean getDictionariesTree() throws Exception {
        List<SysDictionaries> sysDictionariesList = sysDictionariesMapper.getDictionariesTree ();
        if (CollectionUtils.isEmpty (sysDictionariesList)) {
            return SysDictionariesTreeBean.builder ().build ();
        }
        List<SysDictionariesTreeBean> sBean = sysDictionariesCoverter.getListBean (sysDictionariesList);
        SysDictionariesTreeBean sbean = TreeUtil.toTree (sBean, new SysDictionariesTreeBean ().getClass (), 0l);
        log.info ("getDictionariesTree  sbean:{}", sbean);
        return sbean;
    }

    public Map<String,List<SysDictionariesLabelBean>> getLabelBean() {

        if(redissionUtils.isExist (RedisPrefix.DICT_ALL_MAP)) {
            return redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP);
        }else {
            List<SysDictionariesListBean> bean = sysDictionariesMapper.getDictAll ();
            if (CollectionUtils.isEmpty (bean)) {
                return Maps.newHashMap ();
            }else {
                Map<String,List<SysDictionariesListBean>> map = bean.stream().collect ( Collectors.groupingBy(SysDictionariesListBean::getCode));
                Map<String,List<SysDictionariesLabelBean>> LableMap = Maps.newHashMap ();
                map.forEach((k,v)->{
                    LableMap.put (k,sysDictionariesCoverter.getListLableBean (v));
                });
                redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).putAll (LableMap);
                return LableMap;

            }

        }
    }

    /**
     * 根据code验证是否重复
     *
     * @param code
     * @return
     */
    private Boolean getCodeVaild(String code,Integer id) {

        SysDictionaries dict = sysDictionariesMapper.getDictionariesByCode (code,id);
        if (dict == null || dict.getId () == null) {
            return false;
        }
        return true;

    }

    private List<SysDictionaries> getDictDb(String code) {
        List<SysDictionariesParentBean> parentBeans = sysDictionariesMapper.getParentCode (code);
        if (CollectionUtils.isEmpty (parentBeans)) {
            log.info ("getDictionariesRedis code:{} 数据库无对应值", code);
            return Lists.newArrayList ();
        } else {
            if (parentBeans.size () == 1) {
                if (StringUtils.isEmpty (parentBeans.get (0).getChildValue ())) {
                    return Lists.newArrayList (sysDictionariesMapper.getDictionariesId (parentBeans.get (0).getId ()));
                } else {
                    return Lists.newArrayList (sysDictionariesMapper.getDictionariesId (parentBeans.get (0).getChildId ()));
                }
            } else {
                List<SysDictionaries> dicts = sysDictionariesMapper.getDictionariesByParentId (parentBeans.get (0).getId ());
                return dicts;

            }
        }
    }

    /**
     * 根据id禁用或启用字典管理
     *
     * @param id
     * @return
     */
    public int isEnableSysDictionariesId(Integer id, Integer isEnable) {
        log.info ("isEnableSysDictionariesId id:{}", id);
        if (id == null || id.intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.DICT_ID);
        }
        List<SysDictionaries> dicts = sysDictionariesMapper.getDictionariesByParentId (id);

        if (!CollectionUtils.isEmpty (dicts)) {
            throw new BusinessException (MsgReturnEnum.DICT_CODE_DISABLE);
        }
        SysDictionaries dict = sysDictionariesMapper.getDictionariesId (id);//获取当前信息
        Long isDeleted = LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"));//获取当前时间的秒的时间戳
        int ret = sysDictionariesMapper.isEnableSysDictionariesId (id,isEnable);//禁用启用
        if (ret > 0) {
            if (redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).isExists ()) {//删除所有缓存
                redissionUtils.getRMap (RedisPrefix.DICT_ALL_MAP).delete ();
            }
            if (isEnable == DictConst.IS_DISABLE && redissionUtils.isExist (RedisPrefix.DICT_MAP)) {//禁用删除缓存
                redissionUtils.getRMap (RedisPrefix.DICT_MAP).remove (dict.getCode ());//删除对应的缓存
                //更新parentId 对应的 缓存
                if (dict.getParentId () > 0) {
                    SysDictionaries parentDict = sysDictionariesMapper.getDictionariesId (dict.getParentId ());//获取上一级的信息
                    if (parentDict.getId () != null) {//上一级信息有,在缓存中删除
                        redissionUtils.getRMap (RedisPrefix.DICT_MAP).remove (parentDict.getCode ());
                    }

                }
            }else if(isEnable == DictConst.IS_ENABLE){//启用添加缓存
                SysDictionaries sysDictionaries = sysDictionariesMapper.getDictionariesId (id);
                if(sysDictionaries !=null){
                if (CollectionUtils.isEmpty (sysDictionariesMapper.getDictionariesByParentId (sysDictionaries.getId ()))) {
                    redissionUtils.getRMap (RedisPrefix.DICT_MAP).put (sysDictionaries.getCode (), Lists.newArrayList (sysDictionaries));
                }
                //更新parentId 对应的 缓存
                if (sysDictionaries.getParentId () > 0) {
                    List<SysDictionaries> dictss = sysDictionariesMapper.getDictionariesByParentId(sysDictionaries.getParentId());
                    SysDictionaries parentDict = sysDictionariesMapper.getDictionariesId(sysDictionaries.getParentId());
                    if (parentDict.getId() != null) {
                        redissionUtils.getRMap(RedisPrefix.DICT_MAP).put(parentDict.getCode(), dictss);
                    }
                }
                }
            }

        }
        return ret;
    }
}

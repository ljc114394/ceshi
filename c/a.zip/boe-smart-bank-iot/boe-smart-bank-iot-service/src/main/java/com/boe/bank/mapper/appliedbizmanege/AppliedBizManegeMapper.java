package com.boe.bank.mapper.appliedbizmanege;

import com.baomidou.mybatisplus.annotation.SqlParser;
import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeSearchBean;
import com.boe.bank.common.entity.appliedbizmanege.AppliedBizManege;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Mapper
public interface AppliedBizManegeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(AppliedBizManege record);

    int insertSelective(AppliedBizManege record);

    AppliedBizManege selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(AppliedBizManege record);

    List<AppliedBizManege> searchAppliedBizManegeList(AppliedBizManegeSearchBean record);
    @SqlParser(filter = true)
    Integer getAutoIncrementId() ;

    int executeSQLScript(String sql);

    int dropTable(String tableName);

    Long selectAppliedData(String tableName);

    List<Map<String,Object>> selectModuleOfData(String sql);

    Map<String,Object> selectModuleDataById(@Param("tableName")String tableName,@Param("id")Integer id);

    int deleteModuleData(@Param("tableName")String tableName,@Param("id")Integer id);

    //批量插入excel 数据 mapper
    int insertInfoByExcelData(Map map);

    int batchDeletes(Map map);

    int updateBizUriByPrimaryKey(@Param("bizUri")String bizUri,@Param("id")Integer id);

    int updateInfo(AppliedBizManege record);

    int updateExamineStatus(Map map);

    Integer queryAppNameIsExist(String bizName);

    /**
     * 审批列表搜索辅助接口
     * @param bizName
     * @return
     */
    List<Integer> getLikeName(String bizName);

    List<Map<String,Object>> selectExportData(String sql);

}

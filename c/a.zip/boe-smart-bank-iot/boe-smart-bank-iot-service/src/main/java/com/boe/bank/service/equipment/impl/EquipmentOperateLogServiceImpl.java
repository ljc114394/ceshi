package com.boe.bank.service.equipment.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.boe.bank.common.bean.equipment.EquipmentOperateLogQO;
import com.boe.bank.common.entity.equipment.EquipmentOperateLog;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.equipment.EquipmentOperateLogMapper;
import com.boe.bank.service.equipment.EquipmentOperateLogService;
import com.boe.cloud.megarock.security.common.UserInfo;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 设备操作日志 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/28
 */
@Service("equipmentOperateLogService")
public class EquipmentOperateLogServiceImpl extends ServiceImpl<EquipmentOperateLogMapper, EquipmentOperateLog> implements EquipmentOperateLogService {

    @Override
    public IPage<EquipmentOperateLog> page(EquipmentOperateLogQO qo) {
        ObjectUtil.setPageNumAndPageSizeDefault(qo);
        LambdaQueryWrapper<EquipmentOperateLog> wrapper = Wrappers.lambdaQuery(EquipmentOperateLog.class)
                .eq(StringUtils.isNotBlank(qo.getMac()), EquipmentOperateLog::getMac, qo.getMac())
                .eq(StringUtils.isNotBlank(qo.getType()), EquipmentOperateLog::getType, qo.getType())
                .like(StringUtils.isNotBlank(qo.getOperateUser()), EquipmentOperateLog::getOperateUser, qo.getOperateUser())
                .orderByDesc(EquipmentOperateLog::getOperateTime);
        return getBaseMapper().selectPage(new Page<>(qo.getPageNum(), qo.getPageSize()), wrapper);
    }

    @Override
    public void save(String mac, String command, String content) {
        UserInfo userInfo = UserInfo.getCurrentUserInfo();
        EquipmentOperateLog operateLog = new EquipmentOperateLog();
        operateLog.setMac(mac);
        operateLog.setOperateUser(userInfo.getUsername());
        operateLog.setOrgName(userInfo.getOrganization().getName());
        operateLog.setOperateTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        operateLog.setType(command);
        operateLog.setContent(command + content);
        getBaseMapper().insert(operateLog);
    }
}

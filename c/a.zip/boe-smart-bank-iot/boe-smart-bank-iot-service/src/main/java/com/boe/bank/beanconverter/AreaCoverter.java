package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.areabean.AreaBean;
import com.boe.bank.common.bean.areabean.AreaInfoBean;
import com.boe.bank.common.bean.areabean.AreaNameBean;
import com.boe.bank.common.entity.area.Area;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;


@Mapper(componentModel = "spring")
public interface AreaCoverter {

    AreaBean getAreaBean(Area area);

    Area getArea(AreaBean areaBean);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(area.getCreateTime()))")
    })
    AreaInfoBean getAreaInfoBean(Area area);

    @Mappings({
            @Mapping(source = "title", target = "name")
    })
    AreaNameBean getAreaNameBean(Area area);

    List<AreaInfoBean> getAreaInfoList(List<Area> area);

    List<AreaNameBean> getAreaNameListBean(List<Area> area);

}

package com.boe.bank.service.activitiService.base.impl;

import com.alibaba.excel.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.bean.activiti.ActivitiProcessDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessInsertBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessQueryBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.entity.activiti.ActivitiProcess;
import com.boe.bank.common.utils.BaseFunctionUtil;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.common.utils.StringUtil;
import com.boe.bank.mapper.activiti.ActivitiProcessMapper;
import com.boe.bank.service.activitiService.base.ActivitiProcessService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class ActivitiProcessServiceImpl implements ActivitiProcessService {

	@Autowired
	private ActivitiProcessMapper activitiProcessMapper;

	@Autowired
	private RedissionUtils redissionUtils;

	/**
	 * 创建审批流程
	 * 
	 * @param activitiProcessInsertBean
	 * @return
	 */
	@Override
	public Integer insert(ActivitiProcessInsertBean activitiProcessInsertBean) {

		ActivitiProcess activitiProcess = new ActivitiProcess();
		activitiProcess.setCreateBy(activitiProcessInsertBean.getCreateBy());
		activitiProcess.setCreateUserId(activitiProcessInsertBean.getCreateUserId());
		activitiProcess.setName(activitiProcessInsertBean.getProcessName());
		activitiProcess.setExamineId(activitiProcessInsertBean.getExamineId());
		activitiProcess.setStatus(ActivitiConstants.Status.ok);
		activitiProcess.setResourceData(JSON.toJSONString(activitiProcessInsertBean.getList()));
		activitiProcess.setCreateTime(DateUtil.current());

		activitiProcessMapper.insertSelective(activitiProcess);
		return activitiProcess.getId();
	}

	/**
	 * 更新审批流
	 * 
	 * @param activitiProcess
	 * @return
	 */
	@Override
	public boolean updateById(ActivitiProcess activitiProcess) {
		
		Integer id = activitiProcess.getId();
		if (id == null)
			return false;

		if(StringUtils.isEmpty(activitiProcess.getUpdateBy()))
			activitiProcess.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());

		activitiProcess.setUpdateTime(DateUtil.current());

		return BaseFunctionUtil.deleteRedisAndOptDb(RedisPrefix.ACTIVITI_PROCESS_ID, id + "", redissionUtils,
				() -> (activitiProcessMapper.updateByPrimaryKeySelective(activitiProcess) > 0));

	}

	@Override
	public ActivitiProcess load(int id) {
		return BaseFunctionUtil.loadFromRedis(log, RedisPrefix.ACTIVITI_PROCESS_ID, id + "", redissionUtils,
				() -> activitiProcessMapper.selectByPrimaryKey(id));
	}

	@Override
	public boolean deleteById(int id) {
		return BaseFunctionUtil.deleteRedisAndOptDb(RedisPrefix.ACTIVITI_PROCESS_ID, id + "", redissionUtils,
				() -> (activitiProcessMapper.deleteByPrimaryKey(id) > 0));
	}

	/**
	 * 分页查询审批流
	 * 
	 * @param activitiProcessQueryBean
	 * @return
	 */
	@Override
	public PageInfoDto<ActivitiProcessDo> getList(ActivitiProcessQueryBean activitiProcessQueryBean) {
		Page<ActivitiProcessDo> page = PageHelper.startPage(activitiProcessQueryBean.getPageNum(),
				activitiProcessQueryBean.getPageSize(), true);
		List<ActivitiProcessDo> list = activitiProcessMapper.getList(activitiProcessQueryBean);

		PageInfoDto<ActivitiProcessDo> pageInfo = new PageInfoDto<>(list, page);
		return pageInfo;
	}

	@Override
	public ActivitiProcess getByExamineId(Integer examineId) {
		Integer id = activitiProcessMapper.getByExamineId(examineId);
		if(id == null)
			return null;
		
		return load(id);
	}

	@Override
	public ActivitiProcess getByProcdefId(String processdefinitionId) {
		Integer id = activitiProcessMapper.getByProcdefId(processdefinitionId);
		if(id == null)
			return null;
		
		return load(id);
	}
	
	/**
	 * 给设备和计划，只有唯一的流程的busniessType查询
	 * @param busniessType
	 * @return
	 */
	@Override
	public ActivitiProcess getByBusniessType(Integer busniessType) {
		Integer id = activitiProcessMapper.getByBusniessType(busniessType);
		if(id == null)
			return null;
		
		return load(id);
	}
}

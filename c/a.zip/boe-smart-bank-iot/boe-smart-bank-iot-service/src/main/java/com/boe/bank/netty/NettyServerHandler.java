package com.boe.bank.netty;

import com.boe.bank.common.constant.EquipmentStatusEnum;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.bank.service.equipment.EquipmentStatusService;
import com.boe.cloud.megarock.boot.SpringUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Netty服务端处理类
 *
 * @author 10183279
 * @date 2020/10/21
 */
@Slf4j
public class NettyServerHandler extends ChannelInboundHandlerAdapter {

    /**
     * 管理一个全局map，保存连接进服务端的终端设备信息
     */
    public static ConcurrentHashMap<String, Channel> TERMINAL_MAP = new ConcurrentHashMap<>();

    private static final EquipmentService equipmentService = SpringUtil.getBean(EquipmentService.class);

    private static final EquipmentStatusService equipmentStatusService = SpringUtil.getBean(EquipmentStatusService.class);

    /**
     * 客户端连接服务器触发此方法
     *
     * @param ctx
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        log.info("客户端[{}；channelId={}]连接netty服务器，连接设备数量：{}", ctx.channel().remoteAddress(), ctx.channel().id()
                , TERMINAL_MAP.size());
        super.channelActive(ctx);
    }

    /**
     * 客户端终止连接服务器会触发此方法
     *
     * @param ctx
     */
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        log.info("客户端[{}；channelId={}]连接断开，连接设备数量：{}", ctx.channel().remoteAddress(), ctx.channel().id()
                , TERMINAL_MAP.size());
        String mac = getMacByChannel(ctx.channel());
        if (StringUtils.isNotBlank(mac)) {
            Equipment equ = equipmentService.getByMac(mac);
            if (equ != null) {
                // 更新设备离线状态
                equipmentStatusService.update(mac, EquipmentStatusEnum.OFFLINE.getCode());
                TERMINAL_MAP.remove(mac);
                log.info("客户端[mac={}]连接断开，连接设备数量：{}", mac, TERMINAL_MAP.size());
            }
        }
        super.channelInactive(ctx);
    }

    /**
     * 客户端发消息会触发此方法
     *
     * @param ctx
     * @param msg
     * @throws Exception
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Channel ch = ctx.channel();
        if (msg instanceof TextWebSocketFrame) {
            // TEXT消息类型
            TextWebSocketFrame frame = (TextWebSocketFrame) msg;
            String text = frame.text();
            log.info("加载客户端[{}；channelId={}]报文[{}]", ctx.channel().remoteAddress(), ctx.channel().id(), text);
            if (text.startsWith("MAC_")) {
                String mac = text.substring(4).toUpperCase();
                Equipment equ = equipmentService.getByMac(mac);
                if (equ == null) {
                    log.info("添加客户端[mac={}]，设备未找到", mac);
//                    ch.writeAndFlush(new TextWebSocketFrame("Unauthorized@"));
                } else {
                    // 更新设备在线状态
                    equipmentStatusService.update(mac, EquipmentStatusEnum.ONLINE.getCode());
                    TERMINAL_MAP.put(mac, ch);
                    log.info("添加客户端[mac={}]，连接设备数量：{}", mac, TERMINAL_MAP.size());
//                    ch.writeAndFlush(new TextWebSocketFrame("authorized@"));
                }
            } else {
                // 心跳
//                ch.writeAndFlush(new TextWebSocketFrame("Unauthorized@"));
            }
        }
        super.channelRead(ctx, msg);
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            Channel ch = ctx.channel();
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state() == IdleState.READER_IDLE) {
                log.info("客户端[{}；channelId={}] READER_IDLE 读超时", ctx.channel().remoteAddress(), ctx.channel().id());
                ctx.disconnect();
            } else if (event.state() == IdleState.WRITER_IDLE) {
                log.info("客户端[{}；channelId={}] WRITER_IDLE 写超时", ctx.channel().remoteAddress(), ctx.channel().id());
            } else if (event.state() == IdleState.ALL_IDLE) {
                log.info("客户端[{}；channelId={}] ALL_IDLE 总超时", ctx.channel().remoteAddress(), ctx.channel().id());
                // 发送心跳消息
//                ch.writeAndFlush(new TextWebSocketFrame("Unauthorized@"));
            }
        }
    }

    /**
     * 发生异常会触发此方法
     *
     * @param ctx
     * @param cause
     * @throws Exception
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        Channel ch = ctx.channel();
        String mac = getMacByChannel(ch);
        if (mac != null) {
            log.info("客户端[mac={}]连接异常，连接设备数量：{}", mac, TERMINAL_MAP.size());
            Equipment equ = equipmentService.getByMac(mac);
            if (equ != null) {
                log.info("客户端[mac={}]连接异常，连接断开", mac);
                // 更新设备离线状态
                equipmentStatusService.update(mac, EquipmentStatusEnum.OFFLINE.getCode());
                TERMINAL_MAP.remove(mac);
            }
        } else {
            log.info("客户端[{}；channelId={}]连接异常", ctx.channel().remoteAddress(), ctx.channel().id());
        }
        ctx.close();
    }

    private String getMacByChannel(Channel ch) {
        String mac = null;
        for (Map.Entry<String, Channel> terminal : TERMINAL_MAP.entrySet()) {
            if (terminal.getValue().equals(ch)) {
                mac = terminal.getKey();
                break;
            }
        }
        return mac;
    }
}

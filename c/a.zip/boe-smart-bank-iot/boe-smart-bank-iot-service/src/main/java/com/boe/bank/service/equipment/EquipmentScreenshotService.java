package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.entity.equipment.EquipmentScreenshot;

/**
 * 设备截图 Service
 *
 * @author 10183279
 * @date 2020/10/30
 */
public interface EquipmentScreenshotService extends IService<EquipmentScreenshot> {

    /**
     * 获取截图
     * @param mac        设备mac
     * @param updateTime 更新时间
     * @return
     */
    EquipmentScreenshot getOne(String mac, String updateTime);
    
    /**
     * 保存截图
     * @param mac    mac
     * @param picUrl 图片路径
     */
    boolean save(String mac, String picUrl);
}

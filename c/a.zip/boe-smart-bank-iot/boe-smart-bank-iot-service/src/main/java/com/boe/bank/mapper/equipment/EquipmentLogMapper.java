package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentLog;

/**
 * 设备日志 Mapper
 *
 * @author 10085188
 * @date 2020/11/05
 */
public interface EquipmentLogMapper extends BaseMapper<EquipmentLog> {

}

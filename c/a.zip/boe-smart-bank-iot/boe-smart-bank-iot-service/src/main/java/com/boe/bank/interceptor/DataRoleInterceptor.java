//package com.boe.bank.interceptor;
//
//import com.alibaba.fastjson.JSONObject;
//import com.boe.bank.common.base.Result;
//import com.boe.bank.common.constant.MsgReturnEnum;
//import com.boe.bank.configurer.RequestWrapper;
//import com.boe.bank.mapper.dataroleMapper.DataRoleMapper;
//import com.boe.cloud.megarock.security.common.Role;
//import com.boe.cloud.megarock.security.common.UserInfo;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.http.MediaType;
//import org.springframework.stereotype.Component;
//import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.ModelAndView;
//
//import javax.annotation.Resource;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.List;
//
///**
// * 数据授权拦截器
// *
// * @author lvjiacheng
// * @version 1.0
// * @data 2020/10/16 10:21
// */
//@Component
//@Slf4j
//public class DataRoleInterceptor implements HandlerInterceptor {
//
//    @Resource
//    private DataRoleMapper dataRoleMapper;
//
//     //访问接口之前执行
//    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
//        if(UserInfo.getCurrentUserInfo ()!=null&&isJson(request)){
//            // 获取json字符串
//            String jsonParam = new RequestWrapper(request).getBodyString();
//            JSONObject jsonObject =JSONObject.parseObject(jsonParam);
//            String orgId = jsonObject.get("orgId").toString();
//            List<Role> list= UserInfo.getCurrentUserInfo ().getRoleDTOList();//获取角色列表
//            //Integer orgId= UserInfo.getCurrentUserInfo ().getOrgId().intValue();//获取机构
//            if(StringUtils.isNotEmpty(orgId)) {
//               // int count = dataRoleMapper.getDataRoleCountByOrgIdAndRoleId(list, Integer.parseInt(orgId));
//                int count =1;
//                if (count <= 0) {
//                    PrintWriter writer = null;
//                    request.setCharacterEncoding("UTF-8");
//                    response.setContentType("text/html; charset=utf-8");
//                    try {
//                        writer = response.getWriter();
//                        writer.print(Result.failure(MsgReturnEnum.DATA_ROLE_POWER));
//                        return false;
//                    } catch (IOException e) {
//                        log.info("该用户未授权 error:{}", e.getMessage());
//                    } finally {
//                        if (writer != null)
//                            writer.close();
//                    }
//                }
//            }
//            return true;
//        }
//       return false;
//    }
//    //preHandle返回true后执行
//    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
//
//    }
//
//    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
//
//    }
//
//    /**
//     * 判断本次请求的数据类型是否为json
//     *
//     * @param request request
//     * @return boolean
//     */
//    private boolean isJson(HttpServletRequest request) {
//        if (request.getContentType() != null) {
//            return request.getContentType().equals(MediaType.APPLICATION_JSON_VALUE) ||
//                    request.getContentType().equals(MediaType.APPLICATION_JSON_UTF8_VALUE);
//        }
//
//        return false;
//    }
//}

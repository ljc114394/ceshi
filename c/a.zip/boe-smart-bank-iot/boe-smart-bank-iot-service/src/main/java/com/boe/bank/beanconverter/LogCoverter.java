package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.logbean.*;
import com.boe.bank.common.entity.log.ApprovalLog;
import com.boe.bank.common.entity.log.OperationLog;
import com.boe.bank.common.entity.log.PublicLog;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring")
public interface LogCoverter {


    OperationLog getOperationLog(LogSaveBean logSaveBean);

    ApprovalLog getApprovalLog(LogSaveBean logSaveBean);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogBean getOperationLogBean(OperationLog log);

    List<LogBean> getOperationLogBeanList(List<OperationLog> log);

    List<LogBean> getApprovalLogBeanList(List<ApprovalLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportMaterialBean getMaterialExportBean(OperationLog log);

    List<LogExportMaterialBean> getMaterialExportBeanList (List<OperationLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportPlanBean getPlanExportBean(OperationLog log);

    List<LogExportPlanBean> getPlanExportBeanList (List<OperationLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportEquipmentBean getEquipmentExportBean(OperationLog log);

    List<LogExportEquipmentBean> getEquipmentExportBeanList (List<OperationLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportPowerBean getPowerExportBean(OperationLog log);

    List<LogExportPowerBean> getPowerExportBeanList (List<OperationLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportApprovalBean getApprovalExportBean(ApprovalLog log);

    List<LogExportApprovalBean> getApprovalExportBeanList (List<ApprovalLog> log);


    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(publicLog.getCreateTime()))")
    })
    LoginlogBean  getLoginlogBean(PublicLog publicLog);

    List<LoginlogBean>  getLoginlogBeanList(List<PublicLog> publicLog);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(publicLog.getCreateTime()))")
    })
    InterfacelogBean  getInterfaceBean(PublicLog publicLog);

    List<InterfacelogBean> getInterfaceBeanList(List<PublicLog> logBean);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportInterfaceBean getInterfaceExportBean(PublicLog log);

    List<LogExportInterfaceBean> getInterfaceExportBeanList (List<PublicLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportLoginBean getLoginExportBean(PublicLog log);

    List<LogExportLoginBean> getLoginExportBeanList (List<PublicLog> log);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(log.getCreateTime()))")
    })
    LogExportAllBean geAllExportBean(OperationLog log);

    List<LogExportAllBean> geAllExportBeanList (List<OperationLog> log);
}

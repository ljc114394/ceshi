package com.boe.bank.util;

import org.apache.commons.lang3.StringUtils;

import com.boe.bank.common.bean.activiti.ActivitiTaskDescriptionFlag;
import com.boe.bank.common.constant.ActivitiConstants;

/**
 *activiti task 工具类
 * 已经执行的task中description字段前会加上描述标志，做辅助功能
 * @author caoxuhao
 */
public class ActivitiTaskDescriptionFlagUtil {
	
	public static final String start = "taskFlagStart:";
	private static final int startLen = start.length();
	
	private static final String end = ":taskFlagEnd";
	private static final int endLen = end.length();
	
	private static class First{
		private static final String notAutoPass = "0";
		private static final String autoPass = "1";
	}
	
	/**此处定义数字与ActivitiConstant.PassType相同，所以不用任何转化*/
//	private static class Second{
//		/**任意一人通过*/
//		private final static int any = 1;
//		/**所有人都通过*/
//		private final static int all = 2;
//		/**每个部门任意1人通过*/
//		private final static int department = 3;
//	}
	
	/**
	 * 格式化描述字段中的标志位
	 * @param flag
	 * @param oldDescription 原描述字段中的值
	 * @return
	 */
	public static String format(ActivitiTaskDescriptionFlag flag, String oldDescription) {
		if(flag == null)
			return oldDescription;
		
		StringBuilder sb = new StringBuilder(start);
		
		//第一位
		sb.append(flag.isAutoPass() ? First.autoPass : First.notAutoPass);
		
		//第二位
		sb.append(flag.getPassType());
		
		//结束
		sb.append(end);
		
		//所有标志位后添加原描述
		if(oldDescription == null)
			oldDescription = "";
		
		sb.append(oldDescription);
		
		return sb.toString();
	}
	
	/**
	 * 解析description字段中的flag
	 * @param description
	 * @return
	 */
	public static ActivitiTaskDescriptionFlag parse(String description) {
		
		//不需要解析
		if(StringUtils.isEmpty(description) || !description.startsWith(start))
			return null;
		
		//取出数据部分
		int s = description.indexOf(start);
		int e = description.indexOf(end);
		
		String data = description.substring(s + startLen, e);
		int length = data.length();
		ActivitiTaskDescriptionFlag flag = new ActivitiTaskDescriptionFlag();
		
		//第一位
		if(length > 0) {
			String first = data.substring(0,1);
			flag.setAutoPass(First.autoPass.equals(first));
		}
		
		//第二位
		if(length > 1) {
			String second = data.substring(1,2);
			flag.setPassType(Integer.valueOf(second));
		}
		
		return flag;
	}
}

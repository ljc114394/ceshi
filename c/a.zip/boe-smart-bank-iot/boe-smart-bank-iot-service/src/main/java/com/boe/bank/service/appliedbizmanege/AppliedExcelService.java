package com.boe.bank.service.appliedbizmanege;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.EasyExcelFactory;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeFieldBean;
import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeListBean;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.appliedbizmanege.AppliedBizManege;
import com.boe.bank.common.entity.dict.SysDictionaries;
import com.boe.bank.listener.excel.AppliedReadExcelDataListener;
import com.boe.bank.listener.excel.ExcelWriteHandler;
import com.boe.bank.mapper.appliedbizmanege.AppliedBizManegeMapper;
import com.boe.bank.service.dictService.SysDictionariesService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;


@Service
@Slf4j
public class AppliedExcelService {
    @Resource
    ExcelWriteHandler excelWriteHandler;

    @Resource
    AppliedBizManegeMapper appliedBizManegeMapper;

    @Resource
    private SysDictionariesService sysDictionariesService;

    @Resource
    ObjectMapper objectMapper;

    /**
     * 通过id下载模板
     *
     * @param id
     * @return
     */
    public void downLoadAppliedExcelTemplateById(HttpServletResponse response,Integer id) throws IOException {

        if (id == null || id.intValue () <= 0) {
            throw new BusinessException (MsgReturnEnum.DICT_ID);
        }
        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(id);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        //表字段生成list集合
        List<AppliedBizManegeFieldBean> bizFields = objectMapper.readValue(result.getBizFields(), new TypeReference<List<AppliedBizManegeFieldBean>>() {});
        //生成表格头
        List<List<String>> headlist = new ArrayList<List<String>>();
        Map<Integer, String[]> mapDropDown = new HashMap<>();
        for (int i = 0; i < bizFields.size(); i++) {
            AppliedBizManegeFieldBean bean = bizFields.get(i);
           // 如果不是0的话生成下拉列表
            if (!bean.getDictId().equals("0")){
                List<SysDictionaries> dicts = sysDictionariesService.getDictionariesRedis(bean.getDictId());
                String[] campusTypeslist = new String[dicts.size()];
                for (int j = 0; j < dicts.size(); j++) {
                    SysDictionaries sysDictionarie = dicts.get(j);
                    campusTypeslist[j] = sysDictionarie.getCodeValue();
                }
                mapDropDown.put(i,campusTypeslist);
            }
            List<String> head0 = new ArrayList<String>();
            head0.add(bean.getColumnName());
            headlist.add(head0);
        }
//        不生成下拉列表代码
//        for (AppliedBizManegeFieldBean bean: bizFields ) {
//            List<String> head0 = new ArrayList<String>();
//            head0.add(bean.getColumnName());
//            headlist.add(head0);
//        }
        //生成表格模板
        String name = result.getBizTableName() +"_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
//        EasyExcel.write(response.getOutputStream()).head(headlist).sheet("excel").doWrite(new ArrayList());
        excelWriteHandler.setMapDropDown(mapDropDown);
        EasyExcelFactory.write(response.getOutputStream()).head(headlist).registerWriteHandler(excelWriteHandler).sheet().doWrite(new ArrayList());
    }

    /**
     * 导入模板数据
     *
     * @param id
     * @return
     */
    public void importExcelTemplateData(MultipartFile file,Integer id) throws IOException {

        if (id == null || id.intValue () <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(id);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        List<AppliedBizManegeFieldBean> bizFields = objectMapper.readValue(result.getBizFields(), new TypeReference<List<AppliedBizManegeFieldBean>>() {});
        //比如我从数据库查到的所有表字段
        List<String> columnlist = new ArrayList();
        for (AppliedBizManegeFieldBean bizField:bizFields) {
            columnlist.add(bizField.getColumnCode());
        }
        //默认字段
        String[] publicColumn = {"create_user_id", "create_by", "create_time"};
        for (String column : publicColumn) {
            columnlist.add(column);
        }
        AppliedReadExcelDataListener appliedReadExcelDataListener = new AppliedReadExcelDataListener(columnlist,appliedBizManegeMapper);
        appliedReadExcelDataListener.setTableName( result.getBizTableName());
        EasyExcel.read(file.getInputStream(),appliedReadExcelDataListener).sheet().doRead();
    }
}

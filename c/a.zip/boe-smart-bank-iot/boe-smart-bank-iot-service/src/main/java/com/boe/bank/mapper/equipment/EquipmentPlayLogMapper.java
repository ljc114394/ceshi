package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.bean.equipment.EquipmentPlayLogQO;
import com.boe.bank.common.bean.equipment.PlayLogVO;
import com.boe.bank.common.bean.equipment.SpotsLogVO;
import com.boe.bank.common.entity.equipment.EquipmentPlayLog;

import java.util.List;

/**
 * 设备播放日志 Mapper
 *
 * @author 10183279
 * @date 2020/10/28
 */
public interface EquipmentPlayLogMapper extends BaseMapper<EquipmentPlayLog> {

    /**
     * 分页获取播放记录
     * @param qo
     * @return
     */
    List<PlayLogVO> listPlayLog(EquipmentPlayLogQO qo);

    /**
     * 分页获取插播记录
     * @param qo
     * @return
     */
    List<SpotsLogVO> listSpotsLog(EquipmentPlayLogQO qo);
}

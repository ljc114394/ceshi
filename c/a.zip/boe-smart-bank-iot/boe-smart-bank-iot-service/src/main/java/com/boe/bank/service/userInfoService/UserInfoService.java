package com.boe.bank.service.userInfoService;

import com.boe.bank.beanconverter.UserInfoCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.userinfobean.*;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.userinfo.UserInfo;
import com.boe.bank.common.utils.Md5Utils;
import com.boe.bank.mapper.userInfoMapper.UserInfoMapper;
import com.boe.cloud.megarock.user.javabean.bo.UserBO;
import com.boe.cloud.megarock.user.javabean.dto.OrganizationDTO;
import com.boe.cloud.megarock.user.javabean.dto.UserDTO;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.javabean.qo.OrganizationQO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import com.boe.cloud.megarock.user.service.UserService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author 吕佳程
 * @version 1.0
 * @data 2020/9/29
 */
@Service
@Slf4j
public class UserInfoService {

    @Resource
    private UserInfoMapper userInfoMapper;

    @Resource
    private UserInfoCoverter userInfoCoverter;

    @Resource
    private OrganizationService organizationService;

    @Resource
    private UserService userService;


    /**
     * 用户信息添加
     *
     * @param userInfo
     * @return int
     */
    @Transactional
    public Integer add(UserInfoSaveBean userInfo) {
        log.info ("添加的用户信息 userInfo:{}", userInfo);
        Integer count = selectByName (userInfo);
        if(count>0){
            throw new BusinessException (MsgReturnEnum.USER_USERNAME);
         }
//            if (StringUtils.isAllBlank (userInfo.getName ())) {
//                throw new BusinessException (MsgReturnEnum.USER_NAME);
//            }
            if (StringUtils.isAllBlank (userInfo.getPassword ())) {
                throw new BusinessException (MsgReturnEnum.USER_PASSWORD);
            }
            if (userInfo.getOrgId () == null || userInfo.getOrgId ().intValue () <= 0) {
                throw new BusinessException (MsgReturnEnum.USER_ORG);
            }
            if (userInfo.getDepartmentId () == null || userInfo.getDepartmentId ().intValue () <= 0) {
                throw new BusinessException (MsgReturnEnum.USER_DEPARTMENT);
            }
            UserInfo userInfoa = userInfoCoverter.getUserInfo (userInfo);
            userInfoa.setCreateBy (com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserInfo().getUsername());
            userInfoa.setCreateTime (LocalDateTime.now ());
            userInfoa.setCreateUserId (com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserId ());
            log.info ("转换后要添加的用户信息 userInfo:{}", userInfoa);
            List<Long> roleIds = new ArrayList<Long> ();
            UserBO userBO = new UserBO ();
            userBO.setUsername (userInfoa.getUsername ());
            userBO.setName (userInfoa.getName ());
            userBO.setPassword (userInfoa.getPassword ());
            userBO.setOrgId (userInfoa.getOrgId ().longValue ());
            userBO.setPhoneNum (userInfoa.getPhoneNum ());
            UserDTO userDTO = userService.save (userBO, roleIds);
            if (userDTO.getId () > 0) {
                userInfoa.setId (userDTO.getId ().intValue ());//获取用户id
                return userInfoMapper.insertUserInfo (userInfoa);
            }
            return 0;
    }

    /**
     * 用户信息更新
     *
     * @param id
     * @param userInfo
     * @return
     */
    @Transactional
    public Integer updateUserInfo(Integer id, UserInfoSaveBean userInfo) {
        log.info ("更新前用户信息 userInfo:{}", userInfo);
            if (id == null || id <= 0) {
                throw new BusinessException (MsgReturnEnum.PARAMETER_NOT_NULL);
            }
            if (StringUtils.isAllBlank (userInfo.getName ())) {
                throw new BusinessException (MsgReturnEnum.USER_NAME);
            }
//            if (StringUtils.isAllBlank (userInfo.getPassword ())) {
//                throw new BusinessException (MsgReturnEnum.USER_PASSWORD);
//            }
            if (userInfo.getOrgId () == null || userInfo.getOrgId ().intValue () <= 0) {
                throw new BusinessException (MsgReturnEnum.USER_ORG);
            }
            if (userInfo.getDepartmentId () == null || userInfo.getDepartmentId ().intValue () <= 0) {
                throw new BusinessException (MsgReturnEnum.USER_DEPARTMENT);
            }
            UserInfo userInfoa = userInfoCoverter.getUserInfo (userInfo);
            userInfoa.setId (id);
            userInfoa.setUpdateBy (com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserInfo().getUsername());
            userInfoa.setUpdateTime (LocalDateTime.now ());
            //userInfoa.setPassword (Md5Utils.getMd5Code (userInfo.getPassword ()));
            log.info ("转换后要更新的用户信息:{}", userInfoa);
            List<Long> roleIds = new ArrayList<Long> ();
            UserBO userBO = new UserBO ();
            userBO.setUsername (userInfoa.getUsername ());
            userBO.setName (userInfoa.getName ());
            //userBO.setPassword (userInfoa.getPassword ());
            userBO.setOrgId (userInfoa.getOrgId ().longValue ());
            userBO.setPhoneNum (userInfoa.getPhoneNum ());
            userBO.setUpdateTime (LocalDateTime.now ());
            boolean state = userService.update (id.longValue (), userBO, roleIds);
            int ret =0;
            if (state) {
                ret =  userInfoMapper.updateUserInfo (userInfoa);
            }
            return ret;
    }

    /**
     * 用户列表多条件查询
     *
     * @param userInfo
     * @return
     */
    public PageInfo<UserInfoBean> getUserInfoList(UserInfoSearchBean userInfo) {
        log.info ("用户列表多条件查询开始 userInfo:{}", userInfo);
        if (userInfo.getPageNum () == 0) {
            userInfo.setPageNum (Const.PAGE_NUM_DEFAULT);
        }
        if (userInfo.getPageSize () == 0) {
            userInfo.setPageSize (Const.PAGE_SIZE_DEFAULT);
        }
        Page page = PageHelper.startPage (userInfo.getPageNum (), userInfo.getPageSize (), true);
        if(userInfo.getDepartmentId() !=null && userInfo.getDepartmentId() == 99999999){
            return  new PageInfo(Lists.newArrayList(),page);
        }
//        if(userInfo.getOrgId()==null && com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserInfo().getOrgId() !=null){
//            userInfo.setOrgId(com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserInfo().getOrgId().intValue());
//        }
        //调用机构服务获取机构list获取机构id
        List<Long> orgIds = Lists.newArrayList ();
        if (userInfo.getOrgId () != null && userInfo.getOrgId ().intValue () > 0) {
            //OrganizationQO organizationQO = new OrganizationQO();
            //organizationQO.setParent(userInfo.getOrgId ().longValue ());
            List<OrganizationDO> organizationDTOList = organizationService.listSelfAndChildren (userInfo.getOrgId ().longValue ());
            if(!CollectionUtils.isEmpty(organizationDTOList)){
                orgIds = organizationDTOList.stream ().filter (org -> org.getType () == 1).map (OrganizationDO::getId).distinct().collect (Collectors.toList ());
            }
//            if(!orgIds.contains(userInfo.getOrgId ())){//子部门id加上上级部门id
//                orgIds.add(userInfo.getOrgId ().longValue());
//            }
        }
        List<UserInfo> userInfoList  = userInfoMapper.getUserInfoList (userInfo, orgIds);
        List<UserInfoBean> userInfoBeanList = userInfoCoverter.getUserInfoBeanList (userInfoList);
        log.info ("用户列表多条件查询返回值 userInfoBeanList:{}", userInfoBeanList.size ());
        PageInfo<UserInfoBean> pageInfo = new PageInfo<UserInfoBean> (userInfoBeanList, page);
        return pageInfo;
    }

    /**
     * 用户信息删除
     *
     * @param id
     * @param id
     * @return
     */
    @Transactional
    public int deleteUserInfoById(List<Integer> id) {
        log.info ("用户删除开始 id:{}", id);
        if (StringUtils.isNotBlank (String.valueOf (id))) {
            int ret = userInfoMapper.updateUserInfoDel(id);
            if (ret > 0) {
                id.stream().forEach(item->{
                     userService.delete(item).getId().intValue();
                });
            }
        return ret;
        }
        return 0;
    }

    /**
     * 通过id获取用户信息
     *
     * @param id
     * @param id
     * @return
     */
    public UserInfoBean getUserInfoById(Integer id) {
        log.info ("根据id获取用户信息 id:{}", id);
        if (id == null || id <= 0) {
            return UserInfoBean.builder ().build ();
        }
        UserInfo userInfo = userInfoMapper.getUserInfoById(id);
        if (userInfo == null) {
            return UserInfoBean.builder ().build ();
        }
        UserInfoBean userInfoBean = userInfoCoverter.getUserInfoBean (userInfo);
        log.info ("根据id获取用户信息 userInfoBean:{}", userInfoBean);
        return userInfoBean;
    }

    /**
     * 查询账号密码是否存在
     *
     * @param userInfo
     * @return selectByNameAndPwd
     */
    private int selectByName(UserInfoSaveBean userInfo) {
        if (StringUtils.isAllBlank (userInfo.getUsername())) {
            throw new BusinessException (MsgReturnEnum.USER_NAME);
        }
        UserInfo userInfoa = userInfoCoverter.getUserInfo (userInfo);
        return  userInfoMapper.selectByName(userInfoa);

    }

    /**
     * 用户信息-添加人员-获取列表
     *
     * @param userInfo
     * @return
     */
    public List<UserInfoPeopleBean> getUserByOrgList(UserInfoByRoleSearchBean userInfo) {
        if ( userInfo.getRoleId() ==null ||userInfo.getRoleId() <= 0) {
            throw new BusinessException (MsgReturnEnum.PARAMETER_EMPTY);
        }
        log.info ("用户信息-根据机构获取用户信息 userInfo:{}", userInfo);

        //调用机构服务获取机构list获取机构id
        List<Long> orgIds = null;
        if (userInfo.getOrgId () != null && userInfo.getOrgId ().intValue () > 0) {
            List<OrganizationDO> organizationDTOList = organizationService.listSelfAndChildren (userInfo.getOrgId ().longValue ());
            if(!CollectionUtils.isEmpty(organizationDTOList)){
                orgIds = organizationDTOList.stream ().filter (org -> org.getType () == 1).map (OrganizationDO::getId).distinct().collect (Collectors.toList ());
            }
        }
        List<UserInfo> userInfoList = userInfoMapper.getListByAddPeople (userInfo, orgIds);
        List<UserInfoPeopleBean> userInfoBeanList = userInfoCoverter.getUserInfoPeopleBeanList (userInfoList);
        List<UserInfoBean> list = getUserByRoleId(userInfo.getRoleId());//获取角色的用户信息
        if(!CollectionUtils.isEmpty(userInfoBeanList) && !CollectionUtils.isEmpty(list)){
            //userInfoBeanList.stream().forEach(item->item.setWhether(0));//默认都没有权限
            List<Integer> userIdList = list.stream ().map (UserInfoBean::getId).collect (Collectors.toList ());
            userInfoBeanList.stream().map(item->{
                if(userIdList.contains(item.getUid())){
                    item.setWhether(1);
                }else{
                    item.setWhether(0);
                }
              return item;
            }).collect(Collectors.toList());
        }
        log.info ("用户信息-根据机构获取用户信息 userInfoBeanList:{}", userInfoBeanList.size ());
        return userInfoBeanList;
    }


    /**
     * 用户信息-根据角色获取用户信息
     *
     * @param id
     * @return
     */
    public  List<UserInfoBean> getUserByRoleId(Integer id) {
        log.info ("用户信息-根据角色获取用户信息 id:{}", id);
        List<UserInfo> userInfoList = userInfoMapper.getUserByRoleId(id);
        List<UserInfoBean> userInfoBeanList = userInfoCoverter.getUserInfoBeanList (userInfoList);
        log.info ("用户信息-根据角色获取用户信息 userInfoBeanList尺寸:{}", userInfoBeanList.size());
        return userInfoBeanList;
    }

    /**
     * 用户信息-获取登录后的用户信息
     *
     * @return
     */
    public UserInfoByLoginBean getUserByLogin() {
       com.boe.cloud.megarock.security.common.UserInfo  userInfo = com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserInfo();
        UserInfoByLoginBean userInfoBean = userInfoCoverter.getUserInfoLogin (userInfo);
        if(userInfoBean !=null && com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserId () !=null){
           Long id = com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserId ();
           UserInfoBean userinfo = userInfoMapper.getDepartMentByUserId(id);
           if(userinfo !=null){
               userInfoBean.setDepartmentId(userinfo.getDepartmentId());
               userInfoBean.setDepartmentName(userinfo.getDepartmentName());
           }
       }
        return userInfoBean;
    }


    /**
     * 用户信息-获取已授权的用户信息
     *
     * @return
     */
    public List<UserInfoBean> getUserInfoByJurisdiction(UserInfoSearchBean userInfo) {
        log.info ("用户信息-获取已授权的用户信息 userInfo:{}", userInfo);
        //调用机构服务获取机构list获取机构id
        List<Long> orgIds = Lists.newArrayList ();
        if (userInfo.getOrgId () != null && userInfo.getOrgId ().intValue () > 0) {
            List<OrganizationDO> organizationDTOList = organizationService.listSelfAndChildren (userInfo.getOrgId ().longValue ());
            if(!CollectionUtils.isEmpty(organizationDTOList)){
                orgIds = organizationDTOList.stream ().filter (org -> org.getType () == 2).map (OrganizationDO::getId).distinct().collect (Collectors.toList ());
            }
        }
        //Page page = PageHelper.startPage (userInfo.getPageNum (), userInfo.getPageSize (), true);
        List<UserInfo> userInfoList  = userInfoMapper.getUserInfoByJurisdiction (userInfo, orgIds);
        List<UserInfoBean> userInfoBeanList = userInfoCoverter.getUserInfoBeanList (userInfoList);
        log.info ("用户信息-获取已授权的用户信息 userInfoBeanList:{}", userInfoBeanList.size ());
        //PageInfo<UserInfoBean> pageInfo = new PageInfo<UserInfoBean> (userInfoBeanList, page);
        return userInfoBeanList;
    }

    /**
     * 通过当前用户id获取部门id
     *
     * @return
     */
    public Integer getDepartmentIdByUserId() {

        Integer departmentId = userInfoMapper.getDepartmentIdByUserId(com.boe.cloud.megarock.security.common.UserInfo.getCurrentUserId().intValue());
        log.info ("通过用户id获取部门id departmentId:{}", departmentId);
        return departmentId;
    }

}

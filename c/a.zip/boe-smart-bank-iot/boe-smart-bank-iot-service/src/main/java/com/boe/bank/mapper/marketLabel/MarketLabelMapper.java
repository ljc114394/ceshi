package com.boe.bank.mapper.marketLabel;

import com.boe.bank.common.bean.marketLabel.*;
import com.boe.bank.common.bean.productlibrarybean.ProductPortraitDTO;
import com.boe.bank.common.bean.userPortrait.UserPortrailtLabelDTO;
import com.boe.bank.common.entity.marketLabel.MarketLabel;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Description:精准营销-标签表mapper
 * @Author: lijianglong
 * @Data:2020/10/19
 */
public interface MarketLabelMapper {

    List<MarketLabel> queryMarketLabel(MarketLabelSearchBean marketLabelSearchBean);

    List<MarketLabelHeadrDTO> queryMarketLabelHeadr();

    List<MarketLabel> queryMarketLabelT(MarketLabelSearchBean marketLabelSearchBean);

    List<MarketLabelExportDTO> marketLabelExport(MarketLabelExportBean marketLabelExportBean);

    List<MarketLabelExportTDTO> marketLabelTExport(MarketLabelExportBean marketLabelExportBean);

    List<MarketLabelActionExportDTO> marketLabelActionExport(MarketLabelExportBean marketLabelExportBean);

    List<MarketLabelActionTExportDTO> marketLabelActionTExport(MarketLabelExportBean marketLabelExportBean);

    Integer isHasMarketLabel(MarketLabelInfoBean marketLabelInfoBean);

    Integer isHasPropertyMarketLabel(Integer type);//验证属性、行为标签是否有值

    Integer isHasMarketLabelSon(Integer id);

    Integer addMarketLabel(MarketLabel marketLabel);

    Integer addMarketLabelNature(@Param("id") Integer id,
                                 @Param("createBy") String createBy,
                                 @Param("now") LocalDateTime now,
                                 @Param("createUserId") Long userId,
                                 @Param("natureBean") MarketLabelNatureInfoBean marketLabelNatureInfoBean);

    MarketLabelInfoBean selectMarketLabel(Integer id);

    Integer editMarketLabel(MarketLabel marketLabel);

    Integer editMarketLabelNatures(@Param("updateBy") String updateBy,
                                   @Param("now") LocalDateTime now,
                                   @Param("marketLabelNatureInfoBean") MarketLabelNatureInfoBean marketLabelNatureInfoBean);

    Integer deleteMarketLabel(Integer id);

    Integer deleteMarketLabelNatureByLabelId(Integer labelId);

    Integer deleteMarketLabelNature(Integer id);

    List<MarketLabel> queryMarketLabelsTreeBean(Integer labelType);

    List<MarketLabel> queryMarketLabelsTreeHaveUserPor(UserPortrailtLabelDTO userPortrailtLabelDTO);

    Integer updateMarketLabelPersonNums(Integer id);

    List<ProductPortraitDTO> queryMarketLabelsProductPortraits();// 获取产品、用户画像、标签属性信息

}

package com.boe.bank.mapper.activiti;

import java.util.List;

import com.baomidou.mybatisplus.annotation.SqlParser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.bean.activiti.ActivitiProcessOrgDo;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;

/**
 * 审批流程
 * @author caoxuhao
 */
@Mapper
public interface ActivitiOuterRelationMapper {

    int insertSelective(ActivitiOuterRelation activitiOuterRelation);

//    int updateByPrimaryKeySelective(ActivitiProcess activitiProcess);

    int deleteByPrimaryKey(@Param("id") Integer id);

    List<ActivitiOuterRelation> getList(@Param("busniessType")Integer busniessType, @Param("outerIds")List<Integer> outerIds);
    
    ActivitiOuterRelation getByBusniessTypeAndOuterId(@Param("busniessType")Integer busniessType,
                                                      @Param("outerId")Integer outerId, @Param("outerType")Integer outerType);
    
    ActivitiOuterRelation getByBusniessTypeAndProcessInstanceId(@Param("busniessType")Integer busniessType, @Param("processInstanceId")String processInstanceId);
    
    ActivitiOuterRelation getByProcessInstanceId(@Param("processInstanceId")String processInstanceId);
    
    int deleteByBusniessTypeAndOuterId(@Param("busniessType")Integer busniessType, @Param("outerId")Integer outerId);
    
    List<ActivitiOuterRelation> getAllByBusniessTypeAndUserId(@Param("userId")Long userId, @Param("busniessType")Integer busniessType);

    /**
     * 获取评论
     * @param processInstanceIds
     * @return
     */
    List<ActivitiProcessOrgDo> getProcessStatus(@Param("processInstanceIds")List<String> processInstanceIds);

    /**
     * 待我审批
     * @param busniessType
     * @param userId
     * @return
     */
    List<ActivitiProcessOrgDo> getTodoProcessList(@Param("busniessType")Integer busniessType, @Param("userId")Long userId,
        @Param("outerIds")List<Integer> outerIds, @Param("endActIds")List<String> endActIds,
                                                  @Param("outerTypes")List<Integer> outerTypes);
    
    /**
     * 我提交的
     * @param busniessType
     * @param userId
     * @return
     */
    List<ActivitiProcessOrgDo> getMyProcessList(@Param("busniessType")Integer busniessType, @Param("userId")Long userId,
        @Param("outerIds")List<Integer> outerIds, @Param("endActIds")List<String> endActIds,
                                                @Param("outerTypes")List<Integer> outerTypes);

    /**
     * 我审批的
     */
    List<ActivitiProcessOrgDo> getExaminedProcessList(@Param("busniessType")Integer busniessType,
        @Param("userId")Long userId, @Param("outerIds")List<Integer> outerIds,
        @Param("endActIds")List<String> endActIds, @Param("processStatus")Integer processStatus,
                                                      @Param("outerTypes")List<Integer> outerTypes);

    /**
     * 我转办的
     */
    List<ActivitiProcessOrgDo> getTransferProcessList(@Param("busniessType")Integer busniessType,
        @Param("userId")Long userId, @Param("outerIds")List<Integer> outerIds,
        @Param("endActIds")List<String> endActIds, @Param("outerTypes")List<Integer> outerTypes);

    /**
     * 待我审批的数量
     * @param busniessType
     * @param userId
     * @return
     */
    Integer getTodoCount(@Param("busniessType")Integer busniessType, @Param("userId")Long userId);
    
    /**
     * 我审批的数量
     * @param busniessType
     * @param userId
     * @return
     */
    Integer getExaminedCount(@Param("busniessType")Integer busniessType, @Param("userId")Long userId);

    /**
     * 置处理结果为废弃
     * @param procInstId
     * @return
     */
    int abandon(@Param("procInstId")String procInstId);
}

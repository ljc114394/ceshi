package com.boe.bank.service.marketLabel;

import com.alibaba.excel.EasyExcel;
import com.boe.bank.beanconverter.MarketLabelCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.marketLabel.*;
import com.boe.bank.common.bean.productlibrarybean.ProductLibraryExportBean;
import com.boe.bank.common.bean.productlibrarybean.ProductPortraitDTO;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.entity.marketLabel.MarketLabel;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.common.utils.TreeUtil;
import com.boe.bank.mapper.marketLabel.MarketLabelMapper;
import com.boe.bank.mapper.userPortrait.UserPortraitMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Description:serviceimpl
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Service
@Slf4j
public class MarketLabelService {

    @Autowired
    private MarketLabelMapper marketLabelMapper;

    @Autowired
    private MarketLabelCoverter marketLabelCoverter;

    @Autowired
    private UserPortraitMapper userPortraitMapper;

    @Autowired
    private RedissionUtils redissionUtils;

    public PageInfo<MarketLabelBean> queryMarketLabel(MarketLabelSearchBean marketLabelSearchBean){
        log.info("标签库查询条件:{}", marketLabelSearchBean);
        if (marketLabelSearchBean.getId() == null) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        if (marketLabelSearchBean.getLabelType() == null) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_TYPE);
        }
        if(marketLabelSearchBean.getLevel() == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_LEVEL);
        }
        ObjectUtil.setPageNumAndPageSizeDefault(marketLabelSearchBean);
        Page page = PageHelper.startPage(marketLabelSearchBean.getPageNum(), marketLabelSearchBean.getPageSize(), true);
        List<MarketLabelBean> marketLabelBeanList = new ArrayList<>();
        if(marketLabelSearchBean.getLevel() < 3){
            marketLabelBeanList = marketLabelCoverter.getMarketLabelBeans(marketLabelMapper.queryMarketLabelT(marketLabelSearchBean));
        }else{
            marketLabelBeanList = marketLabelCoverter.getMarketLabelBeans(marketLabelMapper.queryMarketLabel(marketLabelSearchBean));
        }

        log.info("标签库返回值数量:{}", marketLabelBeanList.size());
        return new PageInfo<MarketLabelBean>(marketLabelBeanList,page);
    }

    @Transactional
    public Integer addMarketLabel(MarketLabelInfoBean marketLabelInfoBean){
        log.info("add marketLabelInfoBean:{}", marketLabelInfoBean);
        //标签库  有默认的根标签   行为标签   属性标签
        if (marketLabelInfoBean.getId() == null) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        if (marketLabelInfoBean.getLabelType() == null) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_TYPE);
        }
        if (StringUtils.isAllBlank(marketLabelInfoBean.getLabelName())) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE);
        }
        if(marketLabelInfoBean.getLevel() == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_LEVEL);
        }
        /*if (marketLabelInfoBean.getMarketLabelNatureInfoBean() == null) {
            throw new BusinessException(MsgReturnEnum.MARKET_LABEL_NATURE);
        }*/

       /* //如果是第一次添加，新建的标签就是跟标签 行为/属性 各有一个跟标签
        if(marketLabelMapper.isHasPropertyMarketLabel(marketLabelInfoBean.getLabelType()) == 0){
            marketLabelInfoBean.setId(0);
        }*/

        if(marketLabelMapper.isHasMarketLabel(marketLabelInfoBean) > 0){
            throw new BusinessException(MsgReturnEnum.MARKET_LABEL_NATURE_HAS);
        }
        MarketLabel marketLabel = marketLabelCoverter.getMarketLabel(marketLabelInfoBean);
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        Long userId = UserInfo.getCurrentUserInfo().getId();
        LocalDateTime now = LocalDateTime.now();
        marketLabel.setCreateBy(createBy);
        marketLabel.setCreateTime(now);
        marketLabel.setCreateUserId(userId);
        marketLabel.setEnableTime(marketLabelInfoBean.getEnable() == 1 ? new Date() : null);
        Integer count = 0;
        if(marketLabelMapper.addMarketLabel(marketLabel) > 0){
            Integer id = marketLabel.getId();
            count = marketLabelMapper.addMarketLabelNature(id,createBy,now,userId,marketLabelInfoBean.getMarketLabelNatureInfoBean());
            log.info("add marketLabel :id ", id);
        }
        return count;
    }

    public MarketLabelInfoBean selectMarketLabel(Integer id){
        log.info("selectMarketLabel :id ", id);
        if(id == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        log.info("selectMarketLabel :id ", id);
        return marketLabelMapper.selectMarketLabel(id);
    }

    @Transactional
    public Integer editMarketLabel(MarketLabelInfoBean marketLabelInfoBean){
        log.info("editMarketLabel :marketLabelInfoBean{}  ", marketLabelInfoBean);
        if(marketLabelInfoBean.getId() == null){
            throw new BusinessException(MsgReturnEnum.MARKET_LABEL_NATURE);
        }
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        LocalDateTime now = LocalDateTime.now();
        MarketLabel marketLabel = marketLabelCoverter.getMarketLabel(marketLabelInfoBean);
        marketLabel.setUpdateTime(now);
        marketLabel.setUpdateBy(createBy);
        marketLabel.setEnableTime(marketLabelInfoBean.getEnable() == 1 ? new Date() : null);
        Integer nums = marketLabelMapper.editMarketLabel(marketLabel);
        if(nums>0 && marketLabelInfoBean.getMarketLabelNatureInfoBean() != null){
            marketLabelMapper.editMarketLabelNatures(createBy,now,marketLabelInfoBean.getMarketLabelNatureInfoBean());
        }
        log.info("editMarketLabel :marketLabelInfoBean.size(){}  ", nums);
        return nums;
    }

    /**
     * 删除标签
     * @param id
     * @return
     */
    @Transactional
    public Integer deleteMarketLabel(Integer id){
        log.info("delete MarketLabel id :",id);
        if(id == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        //判断此标签是否有子标签
        if(marketLabelMapper.isHasMarketLabelSon(id) > 0){
            throw new BusinessException(MsgReturnEnum.IS_LABEL_SON);
        }
        //判断用户画像是否有用
        if(userPortraitMapper.isHasUserPortraitLabel(id) > 0){
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_LABEL);
        }
        Integer nums = marketLabelMapper.deleteMarketLabel(id);
        if(nums > 0){
            marketLabelMapper.deleteMarketLabelNatureByLabelId(id);
        }
        log.info("delete MarketLabel id nums:",nums);
        return nums;
    }

    @Transactional
    public Integer deleteMarketLabelNature(Integer id){
        log.info("delete MarketLabelNature id :",id);
        if(id == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        return marketLabelMapper.deleteMarketLabelNature(id);
    }

    public MarketLabelsTreeBean getMarketLabelsTreeBean(Integer labelType){
        log.info("getMarketLabelsTreeBean :",labelType);
        if(labelType == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_TYPE);
        }
        List<MarketLabel> marketLabels = marketLabelMapper.queryMarketLabelsTreeBean(labelType);
        if (CollectionUtils.isEmpty (marketLabels)) {
            return MarketLabelsTreeBean.builder ().build ();
        }
        List<MarketLabelsTreeBean> marketLabelsTreeBeans = marketLabelCoverter.getMarketLabelsTreeBeans(marketLabels);
        MarketLabelsTreeBean marketLabelsTreeBean = TreeUtil.toTree(marketLabelsTreeBeans,new MarketLabelsTreeBean().getClass(),0l);
        log.info("getMarketLabelsTreeBean :",marketLabelsTreeBean);
        return  marketLabelsTreeBean;
    }

    public Integer updateMarketLabelPersonNums(Integer id){
        log.info("updateMarketLabelPersonNums:{}", id);
        if (id == null) {
            throw new BusinessException(MsgReturnEnum.USER_PORTRAIT_IS_ID);
        }
        Integer nums = marketLabelMapper.updateMarketLabelPersonNums(id);
        log.info("updateMarketLabelPersonNums:{}", nums);
        return nums;
    }

    public void marketLabelExport(HttpServletResponse response, MarketLabelExportBean marketLabelExportBean) throws IOException {

        /*ObjectUtil.setPageNumAndPageSizeDefault(marketLabelExportBean);
        PageHelper.startPage(marketLabelExportBean.getPageNum(), marketLabelExportBean.getPageSize(), true);*/
        if (marketLabelExportBean.getId() == null) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        if (marketLabelExportBean.getLabelType() == null) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_TYPE);
        }
        if(marketLabelExportBean.getLabelType() == null){
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_LEVEL);
        }
        List<MarketLabelExportDTO> marketLabelBeans = new ArrayList<MarketLabelExportDTO>();
        List<MarketLabelExportTDTO> marketLabelBeansT = new ArrayList<MarketLabelExportTDTO>();
        List<MarketLabelActionExportDTO> marketLabelActionBeans = new ArrayList<MarketLabelActionExportDTO>();
        List<MarketLabelActionTExportDTO> marketLabelActionBeansT = new ArrayList<MarketLabelActionTExportDTO>();
        if(marketLabelExportBean.getLabelType() == 0){
            if(marketLabelExportBean.getLevel()<3){
                marketLabelBeansT = marketLabelMapper.marketLabelTExport(marketLabelExportBean);
            }else{
                marketLabelBeans = marketLabelMapper.marketLabelExport(marketLabelExportBean);
            }
        }else{
            if(marketLabelExportBean.getLevel()<3){
                marketLabelActionBeansT = marketLabelMapper.marketLabelActionTExport(marketLabelExportBean);
            }else{
                marketLabelActionBeans = marketLabelMapper.marketLabelActionExport(marketLabelExportBean);
            }
        }
        String name = "marketLabel_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        if(marketLabelExportBean.getLabelType() == 0){
            if(marketLabelExportBean.getLevel()<3){
                EasyExcel.write(response.getOutputStream(), MarketLabelExportTDTO.class).sheet("excel").doWrite(marketLabelBeansT);
            }else{
                EasyExcel.write(response.getOutputStream(), MarketLabelExportDTO.class).sheet("excel").doWrite(marketLabelBeans);
            }
        }else{
            if(marketLabelExportBean.getLevel()<3){
                EasyExcel.write(response.getOutputStream(), MarketLabelActionTExportDTO.class).sheet("excel").doWrite(marketLabelActionBeansT);
            }else{
                EasyExcel.write(response.getOutputStream(), MarketLabelActionExportDTO.class).sheet("excel").doWrite(marketLabelActionBeans);
            }
        }
    }

    /**
     * 获取精准营销-产品id、用户画像、标签属性数据
     * @return
     */
    public List<ProductPortraitDTO> productPortraitMarketByDb(){
        List<ProductPortraitDTO> productPortraitDTOS = marketLabelMapper.queryMarketLabelsProductPortraits();
        return productPortraitDTOS;
    }

    /**
     * 首页-数据统计-标签库
     * @return
     */
    public List<MarketLabelHeadrDTO> headPage(){
        log.info("首页-数据统计-标签库:{} 开始查询");
        return marketLabelMapper.queryMarketLabelHeadr();
    }

    public void deleteProductPortraitMarketRedis(){
        if (redissionUtils.isExist (RedisPrefix.PRODUCT_PORTRAIT_MARKET)) {
            redissionUtils.getRMap (RedisPrefix.PRODUCT_PORTRAIT_MARKET)
                    .remove (RedisPrefix.PRODUCT_PORTRAIT_MARKET_KEY);
        }
    }
}

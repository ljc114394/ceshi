package com.boe.bank.mapper.activiti;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.boe.bank.common.bean.activiti.ActivitiExamineQueryBean;
import com.boe.bank.common.entity.activiti.ActivitiExamine;

/**
 * 审批类型
 * @author caoxuhao
 */
@Mapper
public interface ActivitiExamineMapper {

	ActivitiExamine selectByPrimaryKey(@Param("id") Integer id);

    int insertSelective(ActivitiExamine activitiExamine);

    int updateByPrimaryKeySelective(ActivitiExamine activitiExamine);

    int deleteByPrimaryKey(@Param("id") Integer id);

    List<ActivitiExamine> getList(ActivitiExamineQueryBean activitiExamineQueryBean);

    List<ActivitiExamine> getAvailableList(ActivitiExamineQueryBean activitiExamineQueryBean);

    Integer checkDuplicate(@Param("busniessType") Integer busniessType, @Param("examineType") String examineType);
}

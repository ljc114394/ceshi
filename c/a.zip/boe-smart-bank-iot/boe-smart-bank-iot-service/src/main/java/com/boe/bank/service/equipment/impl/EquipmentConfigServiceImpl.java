package com.boe.bank.service.equipment.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.boe.bank.beanconverter.EquipmentConfigConverter;
import com.boe.bank.common.bean.equipment.*;
import com.boe.bank.common.entity.equipment.EquipmentConfig;
import com.boe.bank.mapper.equipment.EquipmentConfigMapper;
import com.boe.bank.service.equipment.EquipmentConfigService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 设备配置 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/19
 */
@Service("equipmentConfigService")
public class EquipmentConfigServiceImpl extends ServiceImpl<EquipmentConfigMapper, EquipmentConfig> implements EquipmentConfigService {

    @Override
    public EquipmentConfig getByMac(String mac) {
        return ChainWrappers.lambdaQueryChain(getBaseMapper()).eq(EquipmentConfig::getMac, mac).one();
    }

    @Override
    public EquipmentInitConfigVO getInitInfo(String mac) {
        EquipmentInitConfigVO configVO = new EquipmentInitConfigVO();
        EquipmentConfig equConfig = this.getByMac(mac);
        if (equConfig != null) {
            configVO.setStartupTime(equConfig.getOnTime());
            configVO.setShutdownTime(equConfig.getOffTime());
            configVO.setVolume(equConfig.getVolume());
            configVO.setDownloadSpeed(equConfig.getDownloadSpeed());
            if (StringUtils.isNotBlank(equConfig.getDownloadTime()) && equConfig.getDownloadTime().contains("-")) {
                String[] downloadTimes = equConfig.getDownloadTime().split("-");
                DownloadTimeVO downloadTime = new DownloadTimeVO();
                downloadTime.setBegin(downloadTimes[0]);
                downloadTime.setEnd(downloadTimes[1]);
                configVO.setDownloadTime(downloadTime);
            }
            if (StringUtils.isNotBlank(equConfig.getLogReturnTime()) && equConfig.getLogReturnTime().contains("-")) {
                String[] uploadTimes = equConfig.getLogReturnTime().split("-");
                UploadTimeVO uploadTime = new UploadTimeVO();
                uploadTime.setBegin(uploadTimes[0]);
                uploadTime.setEnd(uploadTimes[1]);
                configVO.setUploadTime(uploadTime);
            }
        }
        return configVO;
    }

    @Override
    public int saveOrUpdate(String mac, EquipmentConfigDTO dto) {
        EquipmentConfig equConfig = getByMac(mac);
        int ret;
        EquipmentConfig entity = EquipmentConfigConverter.INSTANCE.dtoToEntity(dto);
        if (CollectionUtils.isNotEmpty(dto.getLayoutList())) {
            entity.setScreenLayout(JSON.toJSONString(dto.getLayoutList()));
        }
        if (equConfig != null) {
            entity.setId(equConfig.getId());
            ret = getBaseMapper().updateById(entity);
        } else {
            entity.setMac(mac);
            ret = getBaseMapper().insert(entity);
        }
        return ret;
    }

    @Override
    public void init(String mac) {
        List<ScreenLayout> layoutList = new ArrayList<>(1);
        ScreenLayout layout = new ScreenLayout();
        layout.setX(0);
        layout.setY(0);
        layout.setW(1920);
        layout.setH(1080);
        layoutList.add(layout);
        EquipmentConfigDTO dto = new EquipmentConfigDTO();
        dto.setLayoutList(layoutList);
        dto.setOnTime("08:00:00");
        dto.setOffTime("18:30:00");
        dto.setVolume(50);
        dto.setDownloadTime("08:00:00-18:30:00");
        dto.setLogReturnTime("13:00:00-18:30:00");
        dto.setLogRetentionTime(7);
        dto.setDownloadSpeed(2048);
        saveOrUpdate(mac, dto);
    }

    @Override
    public List<EquipmentConfig> getByBatchMac(List<String> macList) {
        QueryWrapper<EquipmentConfig> queryWrapper = new QueryWrapper<EquipmentConfig>();
        queryWrapper.in("mac",macList);
        return getBaseMapper().selectList(queryWrapper);
    }
}

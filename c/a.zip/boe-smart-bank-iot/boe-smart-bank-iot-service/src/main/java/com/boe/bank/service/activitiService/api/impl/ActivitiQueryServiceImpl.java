package com.boe.bank.service.activitiService.api.impl;

import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;
import com.boe.bank.common.utils.ParamUtil;
import com.boe.bank.service.activitiService.api.ActivitiQueryService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;

import lombok.extern.slf4j.Slf4j;
import org.activiti.engine.HistoryService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 给其他模块用的查询服务
 * 
 * @author caoxuhao
 */
@Service
@Slf4j
public class ActivitiQueryServiceImpl implements ActivitiQueryService {

	@Autowired
	private HistoryService historyService;

	@Autowired
	private ActivitiOuterRelationService activitiOuterRelationService;

	/**
	 * 获取审核结果列表
	 */
	@Override
	public Map<Integer, Integer> getExamineResultList(Integer busniessType, List<Integer> outerIds) {

		Map<Integer, Integer> map = new HashMap<>();

		if (ParamUtil.isNullOrEmpty(busniessType, outerIds))
			return map;

		List<ActivitiOuterRelation> relations = activitiOuterRelationService.getList(busniessType, outerIds);
		if (CollectionUtils.isEmpty(relations))
			return map;
		
		Map<String, Integer> outerMap = relations.stream().collect(Collectors.toMap(
				ActivitiOuterRelation::getProcessInstanceId, ActivitiOuterRelation::getOuterId));

		Set<String> processInstanceIds = outerMap.keySet();

		List<HistoricProcessInstance> list = historyService.createHistoricProcessInstanceQuery()
				.processInstanceIds(processInstanceIds).list();

		if (CollectionUtils.isEmpty(list))
			return map;

		// 转化成页面要的结果
		Map<String, Integer> processInstanceMap = list.stream().collect(Collectors.toMap(HistoricProcessInstance::getId,
				t -> changeEndActivityId2Int(t.getEndActivityId())
				));
		
		for (String processInstanceId : processInstanceIds) {
			
			Integer outerId = outerMap.get(processInstanceId);
			if(outerId == null)
				continue;
			
			Integer result = processInstanceMap.get(processInstanceId);
			if(result == null)
				result = ActivitiConstants.ExamineStatus.undo;
			
			map.put(outerId, result);
		}

		return map;
	}

	private static Integer changeEndActivityId2Int(String endActivityId) {
		if (StringUtils.isEmpty(endActivityId)) {
			return ActivitiConstants.ExamineStatus.undo;
		} else if (ActivitiConstants.Node.successEnd.equals(endActivityId)) {
			return ActivitiConstants.ExamineStatus.pass;
		} else if (ActivitiConstants.Node.rejectEnd.equals(endActivityId)) {
			return ActivitiConstants.ExamineStatus.reject;
		} else {
			return ActivitiConstants.ExamineStatus.undo;
		}
	}


}

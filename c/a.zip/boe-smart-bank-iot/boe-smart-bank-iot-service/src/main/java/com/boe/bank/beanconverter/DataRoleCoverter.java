package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.datarolebean.DataRoleBean;
import com.boe.bank.common.bean.datarolebean.DataRoleSaveBean;
import com.boe.bank.common.entity.datarolebean.DataRole;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DataRoleCoverter {

    DataRoleBean getDataRoleBean(DataRole dataRole);


    DataRole getDataRole(DataRoleSaveBean dataRoleBean);

    List<DataRole> getDataRoleList(List<DataRoleSaveBean> dataRoleBean);


    List<DataRoleBean> getDataRoleBeanList(List<DataRole> dicts);



}

package com.boe.bank.service.activitiService.org.impl;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.activiti.api.process.runtime.ProcessRuntime;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.Process;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.DeploymentQuery;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.repository.ProcessDefinitionQuery;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.boe.bank.common.bean.activiti.ActivitiProcessBo;
import com.boe.bank.common.bean.activiti.UserTaskBo;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.utils.StringUtil;
import com.boe.bank.service.activitiService.base.ActivitiWebService;
import com.boe.bank.service.activitiService.org.ActivitiProcessOrgService;
import com.boe.bank.util.ActivitiUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * activiti 流程部署，删除等操作
 * @author caoxuhao
 */
@Service
@Slf4j
public class ActivitiProcessOrgServiceImpl implements ActivitiProcessOrgService {

	public static final String ASSIGNEE_NAME_PREFIX = "assigneeName";

	@Autowired
	private TaskService taskService;

	@Autowired
	private RepositoryService repositoryService;

	@Autowired
	private ProcessRuntime processRuntime;

	@Autowired
	private HistoryService historyService;

	@Autowired
	private RuntimeService runtimeService;
	
	@Autowired
	private ActivitiWebService activitiWebService;

	@Override
	public String deploy(String category, String processName, List<UserTaskBo> modelList) {

		BpmnModel model = new BpmnModel();

		Process process = new Process();
		model.addProcess(process);
		
		//NCName(即processKey) 要以字母或下划线 () 字符开头，后接 XML 规范中允许的任意字母、数字、重音字符、变音符号、句点 (.)、连字符 (-) 和下划线 () 的组合
		String processKey = "_" + StringUtil.getUUID();
		process.setId(processKey);
		process.setName(processName);

		// 全局监听器(暂时不用留作参考代码)
//		List<EventListener> eventListeners = new ArrayList<>();
//		EventListener eventListener = new EventListener();
//		eventListeners.add(eventListener);
//		eventListener.setEvents("TASK_CREATED");
//		eventListener.setImplementation("${globalEventListener}");
//		eventListener.setImplementationType("delegateExpression");
//		process.setEventListeners(eventListeners);

		// 多节点任务
		// 构造开始节点任务
		process.addFlowElement(ActivitiUtil.createStartEvent());

		int gateWayIndex = 1;
		int taskIndex = 1;
		for (UserTaskBo userTaskModel : modelList) {

			process.addFlowElement(ActivitiUtil.createParallelGateway("createParallelGateway" + gateWayIndex));

			String taskName = userTaskModel.getName();
			int passType = userTaskModel.getPassType();
			int number = userTaskModel.getNumber();
			//按部门审核number = 部门数，其他情况=1
			for (int j = 0; j < number; j++) {
				switch (passType) {
				case ActivitiConstants.PassType.any:
					process.addFlowElement(ActivitiUtil.createJoinTaskAny("task" + taskIndex, taskName,
							ASSIGNEE_NAME_PREFIX + taskIndex));
					break;
				case ActivitiConstants.PassType.all:
					process.addFlowElement(ActivitiUtil.createJoinTaskAll("task" + taskIndex, taskName,
							ASSIGNEE_NAME_PREFIX + taskIndex));
					break;

				default:
					break;
				}
				taskIndex++;
			}

			gateWayIndex++;
		}

		// 最后一个网关
		process.addFlowElement(ActivitiUtil.createParallelGateway("createParallelGateway" + gateWayIndex));

		// 构造结束节点任务
		process.addFlowElement(ActivitiUtil.createSuccessEndEvent());
		process.addFlowElement(ActivitiUtil.createRejectEndEvent());
		process.addFlowElement(ActivitiUtil.createAbandonedEndEvent());

		// 构造连线(加网关)
		// 起始节点-->第一个网关
		process.addFlowElement(
				ActivitiUtil.createSequenceFlow(ActivitiConstants.Node.start, "createParallelGateway1", "", ""));
		// 最后一个网关-->终止节点
		process.addFlowElement(ActivitiUtil.createSequenceFlow("createParallelGateway" + gateWayIndex,
				ActivitiConstants.Node.successEnd, "", ""));

		//构造连线
		gateWayIndex = 1;
		taskIndex = 1;
		for (UserTaskBo userTaskModel : modelList) {

			int number = userTaskModel.getNumber();

			for (int j = 0; j < number; j++) {
				// 网关流出连线
				process.addFlowElement(ActivitiUtil.createSequenceFlow("createParallelGateway" + gateWayIndex,
						"task" + taskIndex, "", ""));

				// 网关流入连线
				// 通过
				process.addFlowElement(ActivitiUtil.createSequenceFlow("task" + taskIndex,
						"createParallelGateway" + (gateWayIndex + 1), "通过", "${result == '1'}"));

				// 拒绝
				process.addFlowElement(ActivitiUtil.createSequenceFlow("task" + taskIndex, ActivitiConstants.Node.rejectEnd,
						"废弃", "${result == '0'}"));

				// 废弃
				process.addFlowElement(ActivitiUtil.createSequenceFlow("task" + taskIndex,
						ActivitiConstants.Node.abandonedEnd, "不通过", "${result == '2'}"));

				taskIndex++;
			}

			gateWayIndex++;
		}

		// 3.部署流程
		Deployment deployment = repositoryService.createDeployment().addBpmnModel(processKey + ".bpmn", model)
				.name(processKey + "部署").category(category).deploy();

		String deploymentId = deployment.getId();
		ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().deploymentId(deploymentId).singleResult();
		
		log.info(processDefinition.getId());
		return processDefinition.getId();
	}

	/**
	 * 开始流程
	 * @param processDefinitionId
	 * @param userId
	 * @param modelList
	 * @return
	 */
	@Override
	public String start(String processDefinitionId, String userId, List<UserTaskBo> modelList) {

		// 设置流程发起人
		Authentication.setAuthenticatedUserId(userId);

		Map<String, Object> map = new HashMap<>();
		
		activitiWebService.putAssignee(map, modelList, Long.valueOf(userId));

//		int taskIndex = 1;
//		for (UserTaskBo userTaskModel : modelList) {
//
//			Map<Long, Set<Long>> depMap = userTaskModel.getMap();
//
//			for (Long key : depMap.keySet()) {
//				Set<Long> userIds = depMap.get(key);
//				// map的key要与MultiInstanceLoopCharacteristics的InputDataItem相同
//				map.put(ASSIGNEE_NAME_PREFIX + taskIndex + "List", new ArrayList<>(userIds));
//				taskIndex++;
//			}
//		}
		
		ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinitionId, map);

		String res = "流程实例ID--->" + processInstance.getId();
		log.info(res);
		return processInstance.getId();
	}

	/**
	 * 挂起已经部署的流程
	 * @return
	 */
	@Override
	public boolean suspendProcess(String processDefinitionId) {
		try {
			repositoryService.suspendProcessDefinitionById(processDefinitionId);
		} catch (Exception e) {
			return false;
		}

		return true;
	}

	/**
	 * 恢复被挂起的流程
	 * @return
	 */
	@Override
	public boolean activateProcess(String processDefinitionId) {
		try {
			repositoryService.activateProcessDefinitionById(processDefinitionId);
		} catch (Exception e) {
			return false;
		}

		return true;
	}
	
	/**
	 * 删除整个流程
	 * @return
	 */
	@Override
	public boolean deleteDeployment(String procdefId) {
		try {
			ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(procdefId).singleResult();
			if(processDefinition == null)
				return true;//没有查到，表示不需要删除
			
			String deploymentId = processDefinition.getDeploymentId();
			repositoryService.deleteDeployment(deploymentId);
		} catch (Exception e) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * 获取所有已经部署的流程(瀑布分页)
	 * @return
	 */
	public List<ActivitiProcessBo> getAllProcess(String category, Integer pageNum, Integer pageSize) {
		
		if(pageNum == null)
			pageNum = 0;
		
		if(pageSize == null)
			pageSize = 10;
		
		List<ActivitiProcessBo> res = new ArrayList<>();

		DeploymentQuery query = repositoryService.createDeploymentQuery();

		if (!StringUtils.isEmpty(category))
			query.deploymentCategory(category);

		List<Deployment> deploymentList = query.list();
		if (CollectionUtils.isEmpty(deploymentList)) {
			return res;
		}

		Set<String> deploymentIds = deploymentList.stream().map(Deployment::getId).collect(Collectors.toSet());

		Map<String, String> deploymentMap = deploymentList.stream().collect(Collectors.toMap(Deployment::getId, d -> {
			if(StringUtils.isEmpty(d.getCategory()))
				return "";
			return d.getCategory();
		}));
		
		ProcessDefinitionQuery query2 = repositoryService.createProcessDefinitionQuery().deploymentIds(deploymentIds);
		List<ProcessDefinition> processDefs = query2.listPage(pageNum, pageSize);
		for (ProcessDefinition processDefinition : processDefs) {
			String deploymentId = processDefinition.getDeploymentId();
			String thisCategory = deploymentMap.get(deploymentId);

			ActivitiProcessBo bo = new ActivitiProcessBo();
			bo.setCategory(thisCategory);
			bo.setDeploymentId(deploymentId);
			bo.setProcessKey(processDefinition.getKey());
			bo.setProcessName(processDefinition.getName());
			bo.setResourceName(processDefinition.getResourceName());
			res.add(bo);
		}
		
		return res;
	}

	/**
	 * 获取已经部署的流程的xml
	 * 
	 * @param deploymentId
	 * @param resourceName
	 * @return
	 */
	public String getDeploy(String deploymentId, String resourceName) {
		InputStream inputStream = repositoryService.getResourceAsStream(deploymentId, resourceName);
		String result = new BufferedReader(new InputStreamReader(inputStream)).lines()
				.collect(Collectors.joining(System.lineSeparator()));

		log.info(result);
		return result;
	}
	

	/**
	 * 是否有正在运行的流程
	 * @param processDefinitionId
	 * @return
	 */
	@Override
	public boolean hasRunningTask(String processDefinitionId) {
		List<Task> list = taskService.createTaskQuery().processDefinitionId(processDefinitionId).listPage(0, 1);
		if(CollectionUtils.isEmpty(list))
			return false;
		
		return true;
	}
	

}

package com.boe.bank.service.appliedbizmanege;

import com.boe.bank.common.bean.activiti.ActivitiProcessApplicationVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessOrgVo;

import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.appliedbizmanege.AppliedBizManege;

import com.boe.bank.service.activitiService.manager.ActivitiSupport;

import org.springframework.stereotype.Component;

import javax.annotation.Resource;


/**
 * 应用模块-提供审核能力
 *
 * @author caoxuhao
 */
@Component
public class AppliedActivitiSupporter implements ActivitiSupport {

    @Resource
    AppliedModuleService appliedModuleService;

    @Override
    public int getBusniessType() {
        return ActivitiConstants.BusniessType.application;
    }

    @Override
    public boolean updateExamineStatus(int outerId, int examineStatus, Integer outerType) {
        return appliedModuleService.updateExamineStatus(outerType, outerId, examineStatus);
    }

    @Override
    public boolean addOuterData(int outerId, ActivitiProcessOrgVo t, Integer outerType) {
        AppliedBizManege appbm = appliedModuleService.getAppliedBizManegeById(outerType);
        if (appbm == null) {
            return false;
        }
        if (t instanceof ActivitiProcessApplicationVo) {
            ActivitiProcessApplicationVo vo = (ActivitiProcessApplicationVo) t;
            vo.setApplicationName(appbm.getBizName());
            return true;
        }

        return false;
    }
}

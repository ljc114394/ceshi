package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipment.EquipmentOperateLogQO;
import com.boe.bank.common.entity.equipment.EquipmentOperateLog;

/**
 * 设备操作日志 Service
 *
 * @author 10183279
 * @date 2020/10/28
 */
public interface EquipmentOperateLogService extends IService<EquipmentOperateLog> {

    /**
     * 分页获取设备操作日志
     * @param qo
     * @return
     */
    IPage<EquipmentOperateLog> page(EquipmentOperateLogQO qo);

    /**
     * 保存设备操作日志
     * @param mac mac地址
     * @param command 命令
     * @param content 操作内容
     */
    void save(String mac, String command, String content);
}

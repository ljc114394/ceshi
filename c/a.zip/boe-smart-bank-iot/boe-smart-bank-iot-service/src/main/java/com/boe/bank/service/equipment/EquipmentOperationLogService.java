package com.boe.bank.service.equipment;

import java.util.List;

import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.equipment.EquipmentOperationLogQO;
import com.boe.bank.common.bean.equipment.EquipmentOperationLogVO;
import com.boe.bank.common.entity.equipment.EquipmentOperationLog;

/**
 * 设备运维日志 Service
 * @author 10085188
 *
 */
public interface EquipmentOperationLogService{

    /**
     * 分页获取设备运维日志
     * @param qo
     * @return
     */
	PageInfo<EquipmentOperationLogVO> page(EquipmentOperationLogQO qo);
	
	List<EquipmentOperationLogVO> list(EquipmentOperationLogQO qo);
	
	List<EquipmentOperationLogVO> getByOrgId(Integer orgId);
	
	List<EquipmentOperationLogVO> getByTypeId(Integer typeId);
	
	void saveBatch(List<EquipmentOperationLog> list);


	List<EquipmentOperationLogVO> getEquipmentLogList();
}

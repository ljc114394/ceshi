package com.boe.bank.service.planmanageService;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.boe.bank.beanconverter.PlanManageCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.equipment.EquipmentQO;
import com.boe.bank.common.bean.equipment.EquipmentVO;
import com.boe.bank.common.bean.planmanagebean.*;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.entity.equipment.EquipmentAndEnameConfig;
import com.boe.bank.common.entity.equipment.EquipmentPlan;
import com.boe.bank.common.entity.planmanage.PlanManage;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.mapper.planmanageMapper.PlanManageMapper;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.cloud.megarock.user.javabean.dto.OrganizationDTO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author 吕佳程
 * @version 1.0
 * @data 2020/10/12
 */
@Service
@Slf4j
public class PlanManageService {

    @Resource
    private PlanManageMapper planManageMapper;

    @Resource
    private PlanManageCoverter planManageCoverter;

    @Resource
    private ActivitiOptionService activitiOptionService;

    @Resource
    private OrganizationService organizationService;

    @Autowired
    private ActivitiOuterRelationService activitiOuterRelationService;

    @Autowired
    private RedissionUtils redissionUtils;

    @Autowired
    private EquipmentService equipmentService;

    @Value("${material.path:}")
    private String path;

    /**
     * 计划管理-添加
     *
     * @param planManage
     * @return int
     */
    @Transactional
    public Integer add(PlanManageSaveBean planManage) {
                if (StringUtils.isEmpty (planManage.getTitle())) {
                    throw new BusinessException (MsgReturnEnum.PLAN_NAME);
                }
                if (planManage.getBeginTime() == null ) {
                    throw new BusinessException (MsgReturnEnum.PLAN_BEGIN_TIME);
                }
                if (planManage.getEndTime() == null ) {
                    throw new BusinessException (MsgReturnEnum.PLAN_END_TIME);
                }
                if (StringUtils.isEmpty (planManage.getPlanTime())) {
                    throw new BusinessException (MsgReturnEnum.PLAN_TIME);
                }
                if(DateUtil.parse1(planManage.getBeginTime()).getTime()>DateUtil.parse1(planManage.getEndTime()).getTime()){
                    throw new BusinessException (MsgReturnEnum.PLAN_START_TIME);
                }
                PlanManage planManagea = planManageCoverter.getPlanManage (planManage);
                //判断播放状态
//                String week =DateUtil.formatWeek(new Date()).replaceAll("星期","周");
//                if(new Date().getTime()>DateUtil.parse(planManage.getBeginTime()).getTime()&&new Date().getTime()<DateUtil.parse(planManage.getEndTime()).getTime()&&planManage.getPlanTime().contains(week)){
//                    planManagea.setPlayStatus("在播");
//                }else{
//                    planManagea.setPlayStatus("未播");
//                }
                String createBy = UserInfo.getCurrentUserInfo().getUsername();
                LocalDateTime createTime = LocalDateTime.now();
                Long createUserId = UserInfo.getCurrentUserId();
                if(StringUtils.isNotEmpty(redissionUtils.createNo(RedisPrefix.PLAN_KEY))){
                    planManagea.setId(Integer.valueOf(redissionUtils.createNo(RedisPrefix.PLAN_KEY)));
                }
                planManagea.setCreateBy (createBy);
                planManagea.setCreateTime (createTime);
                planManagea.setCreateUserId (createUserId);
                if(UserInfo.getCurrentUserInfo().getOrgId() !=null &&UserInfo.getCurrentUserInfo().getOrgId()>0){
                    planManagea.setOrgId(UserInfo.getCurrentUserInfo().getOrgId().intValue());
                }
                int id = planManageMapper.insertPlanManage (planManagea);
                if(id<1){
                    throw new BusinessException (MsgReturnEnum.PLAN_ADD_FAILS);

                }
                log.info ("计划管理-添加-返回结果 res:{}", id);
                    if (CollectionUtils.isEmpty(planManage.getList())) {
                        throw new BusinessException(MsgReturnEnum.PLAN_PLAY_MATERIAL);
                    }
                        planManage.getList().stream().forEach(o->{
                            if(o.getScreenArea() ==null || o.getScreenArea() <=0){
                                throw new BusinessException(MsgReturnEnum.PLAN_SCREE_AREA);
                            }
                            if(o.getPlayOperation() ==null || o.getPlayOperation() <=0){
                                throw new BusinessException(MsgReturnEnum.PLAN_PLAY_TIMES);
                            }
                        });
                        List<PlanMaterialManageSaveBean> list = planManage.getList().stream().distinct().collect(Collectors.toList());
                        int res = planManageMapper.insertPlanMaterialId(planManagea.getId(), createBy, createTime, createUserId.intValue(), list);
                        if (res < 1) {
                            throw new BusinessException(MsgReturnEnum.UPDATE_FAILURE);
                        }
                        //调用审批流
                        if(createUserId !=null && createUserId>0) {
                            Result re = activitiOptionService.submit(String.valueOf(createUserId), ActivitiConstants.BusniessType.plan, null, planManagea.getId(), null);
                            log.info("计划管理-审批-返回结果 res:{}", re);
                            if(!re.isSuccess()){
                                if (MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR.code().equals(re.getCode()) || MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE.code().equals(re.getCode()) ) {//没有查到对应的审批流 就默认通过
                                    int ren = planManageMapper.updatePlanManageState(planManagea.getId(),createBy,createTime, ActivitiConstants.ExamineStatus.pass);
                                    if(ren<1){
                                        throw new BusinessException (MsgReturnEnum.PLAN_STATE_FAIL);
                                    }
                                }else{
                                    throw new BusinessException(MsgReturnEnum.PLAN_SUBMIT_ACTIVITI);

                                }
                            }
                        }

                return planManagea.getId();
    }


    /**
     * 计划管理-复制
     *
     * @param planManage
     * @return int
     */
    @Transactional
    public List<PlanManage> batchadd(List<PlanManageSaveBean> planManage) {
        List<PlanManage> planManageList = planManageCoverter.getPlanManageList (planManage);
        //批量添加计划
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        LocalDateTime createTime = LocalDateTime.now();
        Long createUserId = UserInfo.getCurrentUserId();
        Integer orgId =0;
        if(UserInfo.getCurrentUserInfo().getOrgId() !=null &&UserInfo.getCurrentUserInfo().getOrgId()>0){
            orgId =UserInfo.getCurrentUserInfo().getOrgId().intValue();
        }
        Integer finalOrgId = orgId;
        planManageList.stream().map(item ->{
            Integer id = Integer.valueOf(redissionUtils.createNo(RedisPrefix.PLAN_KEY));
            if(id != null && id !=0){
                item.setId(id);
            }
            item.setCreateBy(createBy);
            item.setCreateTime(createTime);
            item.setCreateUserId(createUserId);
            item.setOrgId(finalOrgId);
            return item;
        }).collect(Collectors.toList());
        int res = planManageMapper.batchInsertPlanManage (planManageList);//批量添加
        log.info ("计划管理-添加-返回结果 res:{}", res);
        if(res<1){
            throw new BusinessException (MsgReturnEnum.PLAN_ADD_FAILS);
        }
        List<PlanMaterialManageBean> pList = new ArrayList<PlanMaterialManageBean>();
        planManageList.stream().forEach(item ->{
                    if (!CollectionUtils.isEmpty(item.getList())) {
                        item.getList().stream().map(it -> {
                            it.setPlanId(item.getId());
                            return it;
                        }).collect(Collectors.toList());  //去重
                    }
            pList.addAll(item.getList());
        });
        if (!CollectionUtils.isEmpty(planManageList)) {
            int ress = planManageMapper.batchInsertPlanMaterialId(createBy, createTime, createUserId, pList);
            if (ress < 1) {
                throw new BusinessException(MsgReturnEnum.UPDATE_FAILURE);
            }
            //调用审批流
//            if(createUserId !=null && createUserId>0) {
//                Result re = activitiOptionService.submit(String.valueOf(createUserId), ActivitiConstants.BusniessType.plan, null, id, null);
//                log.info("计划管理-审批-返回结果 res:{}", re);
//                if (re.getCode() == 13015) {//没有查到对应的审批流 就默认通过
//                    int ren = planManageMapper.updatePlanManageState(id, ActivitiConstants.ExamineStatus.pass);
//                    if(ren<1){
//                        throw new BusinessException (MsgReturnEnum.PLAN_STATE_FAIL);
//                    }
//                } else if (re.getCode().intValue() !=MsgReturnEnum.SUCCESS.code()) {//失败
//                    throw new BusinessException(MsgReturnEnum.PLAN_SUBMIT_ACTIVITI);
//                }
//            }
        }

        return planManageList;
    }

    /**
     * 计划管理-编辑计划
     *
     * @param id
     * @param planManage
     * @return
     */
    @Transactional
    public Integer updatePlanManage(Integer id, PlanManageSaveBean planManage) {
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        if (StringUtils.isEmpty (planManage.getTitle())) {
            throw new BusinessException (MsgReturnEnum.PLAN_NAME);
        }
        if (planManage.getBeginTime() == null ) {
            throw new BusinessException (MsgReturnEnum.PLAN_BEGIN_TIME);
        }
        if (planManage.getEndTime() == null ) {
            throw new BusinessException (MsgReturnEnum.PLAN_END_TIME);
        }
        if (StringUtils.isEmpty (planManage.getPlanTime())) {
            throw new BusinessException (MsgReturnEnum.PLAN_TIME);
        }
        if(DateUtil.parse1(planManage.getBeginTime()).getTime()>DateUtil.parse1(planManage.getEndTime()).getTime()){
            throw new BusinessException (MsgReturnEnum.PLAN_START_TIME);
        }
        PlanManage planManagea = planManageCoverter.getPlanManage (planManage);
        planManagea.setId (id);
        planManagea.setUpdateBy (UserInfo.getCurrentUserInfo().getUsername());
        planManagea.setUpdateTime (LocalDateTime.now ());
        log.info ("计划管理-编辑计划-转化后bean planManagea:{}", planManagea);
        return  planManageMapper.updatePlanManage (planManagea);
    }

    //比较两个list是否完全相同 忽略位置
    private boolean compareList2(List<Integer> oldList ,List<Integer> newList){
        if (oldList.size() != newList.size()) {
            return false;
        }
        Collections.sort(oldList);
        Collections.sort(newList);
        for (int i = 0; i < oldList.size(); i++) {
            if (!oldList.get(i).equals(newList.get(i))) {
                return false;
            }
        }
        return true;
    }


    /**
     * 计划管理-编辑内容
     *
     * @param planManage
     * @return
     */
    @Transactional
    public Integer updatePlanMaterial(Integer id,PlanManageSaveBean planManage) {
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
//        if (StringUtils.isEmpty (planManage.getTitle())) {
//            throw new BusinessException (MsgReturnEnum.PLAN_NAME);
//        }
//        if (planManage.getBeginTime() == null ) {
//            throw new BusinessException (MsgReturnEnum.PLAN_BEGIN_TIME);
//        }
//        if (planManage.getEndTime() == null ) {
//            throw new BusinessException (MsgReturnEnum.PLAN_END_TIME);
//        }
        if (CollectionUtils.isEmpty(planManage.getList())) {
            throw new BusinessException(MsgReturnEnum.PLAN_PLAY_MATERIAL);
        }
        //查询当前计划档原有素材
        List<PlanMaterialManageBean> oldlist = planManageMapper.getMaterialIdByPlanId(id);
        if(!CollectionUtils.isEmpty(oldlist)){//计划中的素材是否有改变,没有改变直接返回成功
            List<Integer> oldlistid =oldlist.stream().map(PlanMaterialManageBean::getId).collect(Collectors.toList());
            List<Integer> newListid = planManage.getList().stream().map(PlanMaterialManageSaveBean::getId).collect(Collectors.toList());
            List<Integer> oldlistp =oldlist.stream().map(PlanMaterialManageBean::getPlayOperation).collect(Collectors.toList());
            List<Integer> newListp = planManage.getList().stream().map(PlanMaterialManageSaveBean::getPlayOperation).collect(Collectors.toList());
            List<Integer> oldlists =oldlist.stream().map(PlanMaterialManageBean::getScreenArea).collect(Collectors.toList());
            List<Integer> newLists = planManage.getList().stream().map(PlanMaterialManageSaveBean::getScreenArea).collect(Collectors.toList());
            if(!CollectionUtils.isEmpty(oldlistid)&&!CollectionUtils.isEmpty(newListid)&&!CollectionUtils.isEmpty(oldlistp)&&!CollectionUtils.isEmpty(newListp)&&!CollectionUtils.isEmpty(oldlists)&&!CollectionUtils.isEmpty(newLists)){
                if(compareList2(oldlistid,newListid)&& compareList2(oldlistp,newListp)&& compareList2(oldlists,newLists)){
                    return 1;
                }
            }
        }
        PlanManage planManagea = planManageCoverter.getPlanManage (planManage);
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        LocalDateTime createTime = LocalDateTime.now();
        Long createUserId = UserInfo.getCurrentUserId();
        planManagea.setId (id);
//        planManagea.setUpdateBy (createBy);
//        planManagea.setCreateUserId (createUserId);
//        planManagea.setUpdateTime (createTime);
//        planManagea.setState(ActivitiConstants.ExamineStatus.undo);
//        int ret = planManageMapper.updatePlanManage(planManagea);
//        log.info ("计划管理-修改计划-返回值 ret:{}", ret);
//        if(ret<1){
//            throw new BusinessException (MsgReturnEnum.PLAN_UPDATE_FAILS);
//        }
            //添加之前先全部删除
            int reta = planManageMapper.deletePlanMaterialByPlanId(planManagea.getId());
            log.info ("计划管理-删除计划素材关联表-返回值 reta:{}", reta);
            planManagea.setCreateBy (createBy);
            planManagea.setCreateTime (createTime);

                planManage.getList().stream().forEach(o->{
                    if(o.getScreenArea() ==null || o.getScreenArea() <=0){
                        throw new BusinessException(MsgReturnEnum.PLAN_SCREE_AREA);
                    }
                    if(o.getPlayOperation() ==null || o.getPlayOperation() <=0){
                        throw new BusinessException(MsgReturnEnum.PLAN_PLAY_TIMES);
                    }
                });
                List<PlanMaterialManageSaveBean> list = planManage.getList().stream().distinct().collect(Collectors.toList());
                int res = planManageMapper.insertPlanMaterialId(planManagea.getId(),createBy,createTime,createUserId.intValue(),list);
                if (res < 1) {
                    throw new BusinessException(MsgReturnEnum.UPDATE_FAILURE);
                }
                //调用审批流
                if(createUserId !=null && createUserId>0) {
                    activitiOuterRelationService.abandon(ActivitiConstants.BusniessType.plan, Integer.valueOf(planManagea.getId()), null);
                    Result re = activitiOptionService.submit(String.valueOf(createUserId), ActivitiConstants.BusniessType.plan, null, planManagea.getId(), null);
                    log.info("计划管理-审批-返回结果 res:{}", re);
                    if(!re.isSuccess()){
                        if (MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR.code().equals(re.getCode()) || MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE.code().equals(re.getCode())) {//没有查到对应的审批流 就默认通过
                            int ren = planManageMapper.updatePlanManageState(planManagea.getId(),createBy,createTime, ActivitiConstants.ExamineStatus.pass);
                            if(ren<1){
                                throw new BusinessException (MsgReturnEnum.PLAN_STATE_FAIL);
                            }
                        }else{
                            throw new BusinessException(MsgReturnEnum.PLAN_SUBMIT_ACTIVITI);
                        }
                    } else{
                        planManageMapper.updatePlanManageState(planManagea.getId(),createBy,createTime, ActivitiConstants.ExamineStatus.undo);
                    }
                }

        return res;
    }

    /**
     * 计划管理-分页
     *
     * @param planManage
     * @return
     */
    public PageInfo<PlanManageBean> getPlanManageList(PlanManageSearchBean planManage) {
        ObjectUtil.setPageNumAndPageSizeDefault(planManage);
        Page page = PageHelper.startPage (planManage.getPageNum (), planManage.getPageSize (), true);
        List<PlanManage> planManageList = planManageMapper.getPlanManageList (planManage);
        List<PlanManageBean> planManageBeanList = planManageCoverter.getPlanManageBeanList (planManageList);
        PageInfo<PlanManageBean> pageInfo = new PageInfo<PlanManageBean> (planManageBeanList, page);
        log.info("计划管理-分页list pageNum:{},pageSize:{}size:{}", planManage.getPageNum(), planManage.getPageSize(), planManageBeanList.size());
        return pageInfo;
    }
    /**
     * 计划管理-删除
     *
     * @param id
     * @return
     */
    @Transactional
    public Integer deletePlanManageById(String[] id) {
        if(id == null || id.length == 0){
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        int ret = planManageMapper.updatePlanManageDel(id);
        if (ret > 0) {//删除计划表信息的同时删除计划和素材的关联表
            planManageMapper.deletePlanMaterial(id);

            //废弃审批流
            for (String i: id) {
                activitiOuterRelationService.abandon(ActivitiConstants.BusniessType.plan, Integer.valueOf(i), null);
            }
         }
     return ret;
    }


    /**
     * 计划管理-根据id获取详细系信息
     *
     * @param id
     * @return
     */
    public PlanManageBean getPlanById(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        PlanManage planManage = planManageMapper.getPlanManageById(id);
        if (planManage == null) {
            return PlanManageBean.builder ().build ();
        }
        PlanManageBean planManageBean = planManageCoverter.getPlanManageBean (planManage);
        if(planManageBean.getOrgId() !=null && planManageBean.getOrgId() >0){
            OrganizationDTO org = organizationService.get(planManageBean.getOrgId().longValue());
            if(org !=null){
                planManageBean.setOrgName(org.getName());
            }
        }
        log.info ("计划管理-根据id获取详细信息 planManageBean:{}", planManageBean);
        return planManageBean;
    }
    /**
     * 计划管理-根据id获取计划和素材 获取审批通过的素材
     *
     * @param id
     * @return
     */
    public PlanManageBean getPlanAndMaterialById(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        PlanManage planManage = planManageMapper.getPlanManageById(id);
        if (planManage == null) {
            return PlanManageBean.builder ().build ();
        }
        PlanManageBean planManageBean = planManageCoverter.getPlanManageBean (planManage);
        //根据计划id获取素材
        List<PlanMaterialManageBean> list = planManageMapper.getPlanMaterialByPlanId(planManage.getId());
//        for(PlanMaterialManageBean mbean : list) {//处理素材链接
//            if(mbean.getFileType().intValue() == MaterialTypeEnum.TYPE_MATERIAL.getCode()) {
//                if (MaterialTypeEnum.TEXT.getCode() != mbean.getType().intValue()
//                        && MaterialTypeEnum.WEB.getCode() != mbean.getType().intValue()){
////                if(mbean.getType().intValue() == MaterialTypeEnum.PIC.getCode()
////                        || MaterialTypeEnum.VIDEO.getCode() == mbean.getType().intValue()) {
////                    String mpath = "";
////                    if(MaterialTypeEnum.PIC.getCode() == mbean.getType().intValue()) {
////                        mpath = MaterialDir.PIC;
////                    }else if(MaterialTypeEnum.VIDEO.getCode() == mbean.getType().intValue()){
////                        mpath = MaterialDir.VIDEO;
////                    }
//                    String content = path + mbean.getContent();
//                    mbean.setContent(content);
//                }
//            }
//        }
        planManageBean.setList(list);
        log.info ("计划管理-根据id获取素材 planManageBean:{}", planManageBean);
        return planManageBean;
    }

    /**
     * 计划管理-根据素材id查询计划素材关联表是否存在数据
     *
     * @param id
     * @return
     */
    public Boolean getPlanAndMaterialCount(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        int count = planManageMapper.getPlanAndMaterialCount(id);
        log.info ("计划管理-根据素材id获取关联表的数量 count:{}", count);
        if(count>0){
            return true;
        }else {
            return false;
        }
    }

    /**
     * 计划管理-根据多个素材id查询计划素材关联表是否存在数据
     *
     * @param ids
     * @return
     */
    public Boolean getManyPlanAndMaterialCount(List<Integer> ids) {
        if (ids.size() <= 0 || ids==null) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        int count = planManageMapper.getManyPlanAndMaterialCount(ids);
        log.info ("计划管理-根据素材id获取关联表的数量 count:{}", count);
        if(count>0){
            return true;
        }else {
            return false;
        }
    }


    /**
     * 查询计划列表
     * @param idList 计划id串
     * @param relateMaterial 是否关联素材 true：是，false：否
     * @return
     */
    public List<PlanManage> listByIds(List<Integer> idList, boolean relateMaterial) {
        List<PlanManage> planList = planManageMapper.listByIds(idList);
        if (relateMaterial) {
            for (PlanManage plan : planList) {
                //根据计划id获取素材
                plan.setList(planManageMapper.getPlanMaterialByPlanId(plan.getId()));
            }
        }
        return planList;
    }

    public List<Integer> getLikeName(String name){
        List<Integer> list = planManageMapper.getLikeName(name);
        if(CollectionUtils.isEmpty(list))
            return Lists.newArrayList();


        return list;
    }




    /**
     * 计划管理-计划关联设备-添加
     *
     * @param id
     * @param planManage
     * @return
     */
    @Transactional
    public Integer editEquipment(Integer id, PlanEquipmentBean planManage) {
        Integer type =1; //正常计划
        if (id == null || id <= 0) {
            throw new BusinessException (MsgReturnEnum.ID_NOFAND);
        }
        int res =0;
        //根据计划id删除计划设备关联表
        if(!CollectionUtils.isEmpty(planManage.getDelEquipMac()) ){
            res=  planManageMapper.delEquipment(id,planManage.getDelEquipMac());
            if(res<1){
                throw new BusinessException (MsgReturnEnum.PLAN_EQUIPMENT_DELETE_FAILS);
            }
        }
        //计划id播放区域的数量
        PlanMaterialManageBean planBean = planManageMapper.getScreenCountByPlanId(id);
        if(planBean==null){
            throw new BusinessException (MsgReturnEnum.PLAN_Material_NULL);
        }
        if(CollectionUtils.isEmpty(planManage.getEquipMac())){
            return 1;
        }
            //批量获取设备的屏幕区域
            List<EquipmentAndEnameConfig> entityList = planManageMapper.batGetByMac(planManage.getEquipMac());
            if(!CollectionUtils.isEmpty(entityList)){
                //List<String> macs = Lists.newArrayList();
                StringJoiner macs = new StringJoiner(",");
                entityList.stream().forEach(item ->{
                    if(planBean.getScreenArea()< JSON.parseArray(item.getScreenLayout()).size()){//计划屏幕的数量大于等于设备屏幕的数量那么可以添加否则不可添加
                        //macs.add(item.getMac());
                        macs.add(item.getName());
                    }
                });
                if(StringUtils.isNotEmpty(macs.toString())){
                    throw new BusinessException (1234, "关联失败，名称为"+macs+"的设备大于计划的播放区域数");
                }
            }
//            else{
//                throw new BusinessException (1234, JSON.toJSONString(planManage.getEquipMac()));
//            }
            String createBy = UserInfo.getCurrentUserInfo().getUsername();
            LocalDateTime createTime = LocalDateTime.now();
            Long createUserId = UserInfo.getCurrentUserId();
            //添加计划设备关联表
            return  planManageMapper.editEquipment(planManage.getEquipMac(),id,createBy,createTime,createUserId,type);
    }

    /**
     * 计划管理-关联设备-分页
     *
     * @param qo
     * @return
     */
    public IPage<EquipmentVO> epage(EquipmentQO qo,Integer id) {
        qo.setAuditStatus(ActivitiConstants.ExamineStatus.pass);//获取审批通过的信息
        IPage<EquipmentVO> pageInfo = equipmentService.page(qo);//设备分页
//        // 设备的屏幕区域数
//        int areaNum = 0;
//        EquipmentConfig ec = equipmentConfigService.getByMac(mac);
//        if (ec == null) {
//            return Result.failure("设备不存在");
//        }
//        if (StringUtils.isNotBlank(ec.getScreenLayout())) {
//            areaNum = JSONArray.parseArray(ec.getScreenLayout()).size();
//        }
//        // 显示本机构和数据授权功能中勾选的机构的 审核过的 计划，且每个计划的屏幕区域数应大于等于此设备的屏幕区域数
//        bean.setAreaNum(areaNum);
       // List<DataRoleOrgBean> orgList = dataRoleService.getDataRoleByRoleList();
       // bean.setState(ActivitiConstants.ExamineStatus.pass);
       // bean.setOrgIdList(orgList.stream().map(DataRoleOrgBean::getId).collect(Collectors.toList()));
       // PageInfo<PlanManageBean> pageInfo = planManageService.getPlanManageList(bean);
        List<EquipmentPlan> epList = planManageMapper.getByPlanIdAndType(id);
        List<EquipmentVO> records = pageInfo.getRecords();
        for (EquipmentPlan ep : epList) {
            for (EquipmentVO record : records) {
                if (ep.getMac().equals(record.getMac())) {
                    record.setIsSelected(1);
                    break;
                }
            }
        }
        return pageInfo;
    }

   public Integer updatePlanManageState(Integer id ,Integer pass){
       String createBy = UserInfo.getCurrentUserInfo().getUsername();
       LocalDateTime createTime = LocalDateTime.now();
       return planManageMapper.updatePlanManageState(id,createBy,createTime, pass);
   }
}

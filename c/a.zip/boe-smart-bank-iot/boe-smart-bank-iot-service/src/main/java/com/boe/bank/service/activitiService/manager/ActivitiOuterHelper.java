package com.boe.bank.service.activitiService.manager;

import com.boe.bank.common.bean.activiti.ActivitiProcessOrgVo;

/**
 * 具有按模块填充页面数据能力
 */
@FunctionalInterface
public interface ActivitiOuterHelper {

	/**
	 * 填充外部数据
	 * @param outerId	业务对象id
	 * @param t			被填充的对象（已经包含了审核数据，需要填充业务数据）
	 * @param outerType			二级类型的id
	 * @return
	 */
	boolean addOuterData(int outerId, ActivitiProcessOrgVo t, Integer outerType);
}

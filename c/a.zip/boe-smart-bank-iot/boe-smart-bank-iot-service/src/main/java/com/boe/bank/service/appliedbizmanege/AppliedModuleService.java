package com.boe.bank.service.appliedbizmanege;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.util.TypeUtils;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.appliedbizmanege.*;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.AppliedBizConstants;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.appliedbizmanege.AppliedBizManege;
import com.boe.bank.common.entity.dict.SysDictionaries;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.mapper.appliedbizmanege.AppliedBizManegeMapper;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.dictService.SysDictionariesService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

/**
 * 模块组件
 *
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Service
@Slf4j
public class AppliedModuleService {

    @Resource
    private AppliedBizManegeMapper appliedBizManegeMapper;
    @Resource
    private ObjectMapper objectMapper;
    @Resource
    private SysDictionariesService sysDictionariesService;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private ActivitiOptionService activitiOptionService;
    @Value("${image.root-path}")
    private String imageRootPath;
    @Resource
    private RedissionUtils redissionUtils;



    /**
     * 保存
     *
     * @param requestMap
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean save(Integer bizId, Map<String, Object> requestMap) throws Exception {

        if (StringUtils.isEmpty(bizId)) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }

        AppliedBizManege appBiz = getAppliedBizManegeById(bizId);
        verifyRequestParameter(requestMap, appBiz);

        LinkedHashMap<String, Object> parameters = sortMap(requestMap, appBiz);
        setPublicColumnValueForInsert(parameters,appBiz);
        Integer resId = saveData(prepareInsertSql(appBiz), parameters);
        log.info("应用模块-保存-成功 resId:{}", resId);
        return true;

    }

    /**
     * 准备表的公共字段
     *
     * @return
     */
    private List<AppliedBizManegeFieldBean> preparePublicColumn(AppliedBizManege appBiz) {
        List<AppliedBizManegeFieldBean> fields = new ArrayList<>();

        String[]  publicColumn = new String[]{"examine_status","create_user_id", "create_by", "create_time"};
        for (int i = 0; i < publicColumn.length; i++) {
            AppliedBizManegeFieldBean fieldBean = new AppliedBizManegeFieldBean(publicColumn[i]);
            fields.add(fieldBean);
        }
        log.info("应用模块-保存-准备公共字段列明 {}", fields);
        return fields;
    }

    /**
     * 新增时准备表的公共字段的值
     */
    private void setPublicColumnValueForInsert(LinkedHashMap<String, Object> requestMap,AppliedBizManege appBiz) {
        if(appBiz.getExamineId() != null) {
            requestMap.put("examine_status", AppliedBizConstants.AppliedExamineStatus.NOT_SUBMIT);
        } else {
            requestMap.put("examine_status", null);
        }
        requestMap.put("create_user_id", UserInfo.getCurrentUserInfo().getId());
        requestMap.put("create_by", UserInfo.getCurrentUserInfo().getName());
        requestMap.put("create_time", LocalDateTime.now());
        log.info("应用模块-保存-准备公共字段值 {}", requestMap);

    }

    /**
     * 修改时准备表的公共字段的值
     */
    private void setPublicColumnValueForUpdate(Integer id, LinkedHashMap<String, Object> requestMap) {

        requestMap.put("update_by", UserInfo.getCurrentUserInfo().getName());
        requestMap.put("update_time", LocalDateTime.now());
        requestMap.put("id", id);
        log.info("应用模块-修改-准备公共字段值 {}", requestMap);
    }


    /**
     * 排序map
     *
     * @param requestMap
     * @param appBiz
     * @return
     * @throws JsonProcessingException
     */
    private LinkedHashMap<String, Object> sortMap(Map<String, Object> requestMap, AppliedBizManege appBiz) throws JsonProcessingException {
        log.info("应用模块-保存或修改-排序map参数 ");
        LinkedHashMap<String, Object> parameters = new LinkedHashMap<>();
        List<AppliedBizManegeFieldBean> bizFields = getFieldsByAppBizManege(appBiz);
        bizFields.forEach((field) -> {
            parameters.put(field.getColumnCode(), castParam(field.getColumnType(), requestMap.get(field.getColumnCode())));
        });

        return parameters;
    }

    /**
     * 设置参数类型
     *
     * @param sqlType
     * @param object
     * @return
     */
    private Object castParam(String sqlType,
                             Object object) {

        log.info("应用模块-保存或修改-转换map参数:{} to:{} 类型", object, sqlType);
        Object parameter = null;
        sqlType = sqlType.toLowerCase();
        switch (sqlType) {
            case "varchar":
                parameter = TypeUtils.castToString(object);
                break;
            case "int":
                parameter = TypeUtils.castToInt(object);
                break;
            case "bigint":
                parameter = TypeUtils.castToBigInteger(object);
                break;
            case "decimal":
                parameter = TypeUtils.castToBigDecimal(object);
                break;
            case "datetime":
                parameter = TypeUtils.castToString(object);
                break;
            default:
                parameter = TypeUtils.castToString(object);
        }
        return parameter;
    }

    /**
     * 准备insert 语句
     *
     * @param appBiz
     * @return
     * @throws JsonProcessingException
     */
    private String prepareInsertSql(AppliedBizManege appBiz) throws JsonProcessingException {

        log.info("应用模块-保存-准备sql语句");
        String tableName = appBiz.getBizTableName();
        List<AppliedBizManegeFieldBean> fields = getFieldsByAppBizManege(appBiz);

        StringBuilder insertSql = new StringBuilder();
        insertSql.append("insert into ");
        insertSql.append(tableName);
        insertSql.append(" ( ");

        StringJoiner columnCode = new StringJoiner(",");
        StringJoiner value = new StringJoiner(",");
        //加入公共字段列
        fields.addAll(preparePublicColumn(appBiz));
        fields.stream().forEach((field) -> {
            columnCode.add(field.getColumnCode());
            value.add("?");
        });

        insertSql.append(columnCode);
        insertSql.append(" ) ");
        insertSql.append(" values ");
        insertSql.append(" ( ");
        insertSql.append(value);
        insertSql.append(" ) ");

        return insertSql.toString();

    }


    /**
     * 准备update 语句
     *
     * @param appliedBizManege
     * @return
     * @throws JsonProcessingException
     */
    private String prepareUpdateSql(AppliedBizManege appliedBizManege) throws JsonProcessingException {

        log.info("应用模块-修改-准备sql语句");
        String tableName = appliedBizManege.getBizTableName();
        List<AppliedBizManegeFieldBean> fields = getFieldsByAppBizManege(appliedBizManege);

        StringBuilder updateSql = new StringBuilder();
        updateSql.append("update ");
        updateSql.append(tableName);
        updateSql.append(" set ");

        fields.stream().forEach((field) -> {
            updateSql.append(field.getColumnCode());
            updateSql.append("=?");
            updateSql.append(", ");
        });

        updateSql.append("update_by=?");
        updateSql.append(", ");
        updateSql.append("update_time=? ");
        updateSql.append(" where id=?");

        return updateSql.toString();

    }

    /**
     * jdbc方式保存
     *
     * @param sql
     * @param parameters
     * @return
     */
    private Integer saveData(String sql, Map<String, Object> parameters) {

        log.info("应用模块-保存-jdbc方式执行保存 sql语句为: {}", sql);
        log.info("应用模块-保存-jdbc方式执行保存 参数为: {}", parameters);
        KeyHolder key = new GeneratedKeyHolder();
//        int count = jdbcTemplate.update(sql, new PreparedStatementSetter() {
//            @Override
//            public void setValues(PreparedStatement pstmt) throws SQLException {
//                int index = 1;
//                for (Map.Entry<String, Object> entry : parameters.entrySet()) {
//                    pstmt.setObject(index, entry.getValue());
//                    index++;
//                }
//
//            }
//        }, key);


        int count = jdbcTemplate.update(new PreparedStatementCreator(){

            @Override
            public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
                PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                int index = 1;
                for (Map.Entry<String, Object> entry : parameters.entrySet()) {
                    pstmt.setObject(index, entry.getValue());
                    index++;
                }
                return pstmt;
            }
        }, key);

        if (sql.indexOf("insert") != -1) {
            return (Integer) key.getKey().intValue();
        }
        return count;
    }

    /**
     * 应用模块-详情
     *
     * @param bizId
     * @param id
     * @return
     */
    public Map<String, Object> findInfoById(Integer bizId, Integer id) throws JsonProcessingException {

        AppliedBizManege appBiz = getAppliedBizManegeById(bizId);
        Map<String, Object> result = appliedBizManegeMapper.selectModuleDataById(appBiz.getBizTableName(), id);
        prepareReturnDataForMap(result,appBiz);
        log.info("应用模块-详情-查询成功");
        return result;
    }

    /**
     * 应用模块-分页
     *
     * @param searchBean
     * @return
     */
    public PageInfo<Map> selectAppliedModuleForPage(AppliedModuleSearchBean searchBean) throws Exception {
        //验证参数
        if (searchBean.getPageNum() == 0) {
            searchBean.setPageNum(Const.PAGE_NUM_DEFAULT);
        }

        if (searchBean.getPageSize() == 0) {
            searchBean.setPageSize(Const.PAGE_SIZE_DEFAULT);
        }

        if (checkSqlInjection(searchBean.getSearchConditions())) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_SQL_INJECTION);
        }

        Integer bizId = searchBean.getBizId();
        if (bizId == null || bizId <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }

        AppliedBizManege appBiz = getAppliedBizManegeById(bizId);

        Page page = PageHelper.startPage(searchBean.getPageNum(), searchBean.getPageSize(), true);
        List<Map<String, Object>> result = appliedBizManegeMapper.selectModuleOfData(buildPageQuerySql(appBiz, searchBean));
        PageInfo<Map> pageInfo = new PageInfo(prepareReturnDataForList(result, appBiz), page);
        log.info("应用模块-分页list pageNum:{},pageSize:{}size:{}", searchBean.getPageNum(), searchBean.getPageSize(), result.size());
        return pageInfo;

    }



    /**
     * 查询sql
     *
     * @param appBiz
     * @param searchBean
     * @return
     */
    private String buildPageQuerySql(AppliedBizManege appBiz, AppliedModuleSearchBean searchBean) throws JsonProcessingException {

        List<AppliedBizManegeFieldBean> bizFields = getFieldsByAppBizManege(appBiz);
        verifySearchParameterName(searchBean.getSearchConditions(), bizFields);

        StringBuilder sql = new StringBuilder();
        sql.append("select ");
        sql.append(assembleColumnListSql(bizFields,appBiz));
        sql.append(" from ");
        sql.append(appBiz.getBizTableName());

        if (searchBean.getSearchConditions() != null) {

            String[] conditions = searchBean.getSearchConditions().split(",");
            sql.append(" where 1=1 ");
            for (int i = 0; i < conditions.length; i++) {

                int index = i;
                bizFields.forEach((field) -> {

                    if (!"1".equals(field.getIsQueryCriteria())) {
                        return;
                    }
                    String conditionSegment = conditions[index];
                    String[] conditionAndValue = conditionSegment.split("=");
                    if (conditionAndValue != null) {

                        if (field.getColumnCode().trim().equals(conditionAndValue[0].trim())) {

                            sql.append(" and ");
                            if ("varchar".equals(field.getColumnType())) {

                                sql.append(field.getColumnCode());
                                sql.append(" like concat('%', '" + conditionAndValue[1].trim() + "', '%')");

                            } else if(("int".equals(field.getColumnType()))) {
                                sql.append(field.getColumnCode());
                                sql.append("=");
                                sql.append(conditionAndValue[1].trim());
                            } else {
                                sql.append(field.getColumnCode());
                                sql.append("=");
                                sql.append("\'");
                                sql.append(conditionAndValue[1].trim());
                                sql.append("\'");

                            }

                        }

                    }

                });

            }

        }
        sql.append(" order by id desc ");
        log.info("应用模块-分页-查询语句 sql:{}", sql.toString());
        return sql.toString();

    }

    /**
     * 拼装查询字段
     *
     * @param bizFields
     * @return
     */
    private String assembleColumnListSql(List<AppliedBizManegeFieldBean> bizFields,AppliedBizManege appBiz) {
        log.info("应用模块-分页-拼接查询字段");
        StringJoiner columnSql = new StringJoiner(",");
        bizFields.forEach((field) -> {
            if ("1".equals(field.getIsListShow())) {
                columnSql.add(field.getColumnCode());
            }
        });

        if (!columnSql.toString().equals("")) {
            columnSql.add("id");
            columnSql.add("examine_status");

        }
        return columnSql.toString().equals("") ? " * " : columnSql.toString();
    }

    /**
     * sql 注入检查
     *
     * @param containsSql
     * @return
     */
    private boolean checkSqlInjection(String containsSql) {
        log.info("应用模块-SQL注入检，请求参数{}", containsSql);
        if (StringUtils.isEmpty(containsSql)) {
            return false;
        }
        Matcher matcher = AppliedBizConstants.pattern.matcher(containsSql);
        boolean reslut = matcher.find();
        if (reslut) {
            log.error("sql注入！！！--->> {}", containsSql);
        }
        return reslut;
    }

    /**
     * 准备返回的数据格式
     *
     * @param result
     * @return
     */
    private List<Map<String, Object>> prepareReturnDataForList(List<Map<String, Object>> result, AppliedBizManege appBiz) throws JsonProcessingException {
        log.info("应用模块-分页-准备返回数据");
        List<AppliedBizManegeFieldBean> fieldBeans = getFieldsByAppBizManege(appBiz);
        List<SysDictionaries> dictionariesRedis = new ArrayList<>();
        result.forEach(map -> {
            map.forEach((k, v) -> {
                //回显数据字典
                String dict = setDictValue(k, v, fieldBeans, dictionariesRedis);
                if (!StringUtils.isEmpty(dict)) {
                    map.put(k, dict);
                }
                //回显时间
                if (v instanceof Timestamp) {
                    map.put(k, DateUtil.format((Date) v));
                }
                //回显审核状态
                if(k.equals("examine_status")){
                    if(!StringUtils.isEmpty(v)){
                        Integer status = (Integer) v;
                        map.put(k, AppliedBizConstants.AppliedExamineStatus.get(status));
                    }
                }
                //回显图片和视频的全路径
                String path = setImagePath(k, v, fieldBeans);
                if (!StringUtils.isEmpty(path)) {
                    map.put(k, path);
                }
            });
        });

        return result;
    }

    /**
     * 数据字典code转文本
     *
     * @param columnCode
     * @param value
     * @param fieldBeans
     * @return
     */
    private String setImagePath(String columnCode, Object value, List<AppliedBizManegeFieldBean> fieldBeans) {
        StringJoiner text = new StringJoiner(",");
        fieldBeans.forEach((field) -> {
            if ((!StringUtils.isEmpty(field.getIsImage()) && !"0".equals(field.getIsImage()))
                    ||(!StringUtils.isEmpty(field.getIsVideo()) && !"0".equals(field.getIsVideo()))) {
                if (columnCode.equals(field.getColumnCode())) {

                    if (imageRootPath != null) {
                        String[] paths = ((String)value).split(",");
                        for (int i=0; i<paths.length;i++){
                            if(!StringUtils.isEmpty(paths[i])){
                                text.add(getImagePath()+paths[i]);
                            }
                        }

                    }
                }
            }
        });
        return text.toString();
    }


    /**
     * 数据字典code转文本
     *
     * @param columnCode
     * @param value
     * @param fieldBeans
     * @return
     */
    private String setDictValue(String columnCode, Object value, List<AppliedBizManegeFieldBean> fieldBeans, List<SysDictionaries> dictionariesRedis) {
        StringBuilder text = new StringBuilder();
        fieldBeans.forEach((field) -> {
            if (!StringUtils.isEmpty(field.getDictId()) && !"0".equals(field.getDictId())) {
                if (columnCode.equals(field.getColumnCode())) {
                    String codeValue = filterDict(field.getDictId(), (String) value, dictionariesRedis);
                    if (codeValue != null) {
                        text.append(codeValue);
                    }
                }
            }
        });
        return text.toString();
    }
    /**
     * 筛选数据字典
     *
     * @param parentCode
     * @param code
     * @return
     */
    private String filterDict(String parentCode, String code, List<SysDictionaries> dictionariesRedis) {

        StringBuilder text = new StringBuilder();
        dictionariesRedis.forEach((dict) -> {
            if (dict.getCode().equals(code)) {
                text.append(dict.getCodeValue());
            }
        });

        if (StringUtils.isEmpty(text.toString())) {
            dictionariesRedis.addAll(queryDictForRedisbyParentCode(parentCode));
            dictionariesRedis.forEach((dict) -> {
                if (dict.getCode().equals(code)) {
                    text.append(dict.getCodeValue());
                }
            });
        }

        return text.toString();
    }

    /**
     * 查询数据
     *
     * @param parentCode
     * @return
     */
    private List<SysDictionaries> queryDictForRedisbyParentCode(String parentCode) {
        List<SysDictionaries> dictionariesRedis = sysDictionariesService.getDictionariesRedis(parentCode);
        return dictionariesRedis;
    }

    /**
     * 准备返回的数据格式
     *
     * @param map
     */
    private void prepareReturnDataForMap(Map<String, Object> map,AppliedBizManege appBiz) throws JsonProcessingException {
        log.info("应用模块-详情-准备返回数据");
        List<AppliedBizManegeFieldBean> fieldBeans = getFieldsByAppBizManege(appBiz);
        List<SysDictionaries> dictionariesRedis = new ArrayList<>();
        map.forEach((k, v) -> {
            //回显数据字典
            String dict = setDictValue(k, v, fieldBeans, dictionariesRedis);
            if (!StringUtils.isEmpty(dict)) {
                map.put(k, dict);
            }

            if (v instanceof Timestamp) {
                map.put(k, DateUtil.format((Date) v));
            }
            if(k.equals("examine_status")) {
                if(StringUtils.isEmpty(v)){
                    Integer status = (Integer) v;
                    map.put(k, AppliedBizConstants.AppliedExamineStatus.get(status));
                }
            }
            //回显图片和视频的全路径
            String path = setImagePath(k, v, fieldBeans);
            if (!StringUtils.isEmpty(path)) {
                map.put(k, path);
            }
        });
    }

    /**
     * 删除
     *
     * @param bizId
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(Integer bizId, Integer id) {
        if (bizId == null || bizId == 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        if (id == null || id == 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }

        if (null == UserInfo.getCurrentUserInfo()) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_USER_LOGIN);
        }
        //应用管理数据是否存在
        AppliedBizManege result = getAppliedBizManegeById(bizId);
        verifyExamineStatus(result, id);
        String tableName = result.getBizTableName();
        int row = appliedBizManegeMapper.deleteModuleData(tableName, id);
        log.info("应用模块-删除-结果 row:{}", row);
        return true;
    }

    /**
     * 批量删除
     *
     * @param bizId
     * @param ids
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean batchDelete(Integer bizId, Integer[] ids) {
        if (bizId == null || bizId == 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        if (ids == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }

        if (null == UserInfo.getCurrentUserInfo()) {
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_USER_LOGIN);
        }
        //应用管理数据是否存在
        AppliedBizManege result = getAppliedBizManegeById(bizId);
        verifyExamineStatus(result, ids);
        String tableName = result.getBizTableName();
        List<Integer> idArray = new ArrayList<>(Arrays.asList(ids));
        Map map = new HashMap<>();
        map.put("tableName", tableName);
        map.put("ids", idArray);
        int row = appliedBizManegeMapper.batchDeletes(map);
        log.info("应用模块-批量删除-结果 row:{}", row);
        return true;
    }


    /**
     * 字段对象集合
     *
     * @param appBiz
     * @return
     * @throws JsonProcessingException
     */
    private List<AppliedBizManegeFieldBean> getFieldsByAppBizManege(AppliedBizManege appBiz) throws JsonProcessingException {
        List<AppliedBizManegeFieldBean> bizFields = objectMapper.readValue(appBiz.getBizFields(), new TypeReference<List<AppliedBizManegeFieldBean>>() {
        });
        return bizFields;
    }

    /**
     * 查询应用管理数据是否存在
     *
     * @param bizId
     * @return
     */
    public AppliedBizManege getAppliedBizManegeById(Integer bizId) {
        log.info("应用模块-查询应用业务数据 bizId:{}", bizId);
        AppliedBizManege result = appliedBizManegeMapper.selectByPrimaryKey(bizId);
        if (result == null) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        return result;
    }

    /**
     * 修改
     *
     * @param bizId
     * @param id
     * @param updateMap
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean update(Integer bizId, Integer id, Map<String, Object> updateMap) throws Exception {

        if (bizId == null || bizId == 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        if (id == null || id == 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }

        AppliedBizManege appBiz = getAppliedBizManegeById(bizId);
        verifyExamineStatus(appBiz, id);
        verifyRequestParameter(updateMap, appBiz);

        LinkedHashMap<String, Object> parameters = sortMap(updateMap, appBiz);
        setPublicColumnValueForUpdate(id, parameters);

        int res = saveData(prepareUpdateSql(appBiz), parameters);
        log.info("应用模块-修改-结果 res:{}", res);
        return true;
    }

    /**
     * 验证请求参数
     *
     * @param requestMap
     * @param appliedBizManege
     * @return
     * @throws JsonProcessingException
     */
    private boolean verifyRequestParameter(Map<String, Object> requestMap, AppliedBizManege appliedBizManege) throws JsonProcessingException {

        List<AppliedBizManegeFieldBean> fields = getFieldsByAppBizManege(appliedBizManege);
        verifyParameterName(requestMap, fields);
        verifyParameterIsNotEmpty(requestMap, fields);
        verifyParameterLength(requestMap, fields);
        return true;
    }

    /**
     * 验证参数是否为空
     *
     * @param requestMap
     * @return
     */
    private boolean verifyParameterIsNotEmpty(Map<String, Object> requestMap, List<AppliedBizManegeFieldBean> fields) throws JsonProcessingException {

        fields.forEach((field) -> {
            if ("1".equals(field.getRequired()) && StringUtils.isEmpty(requestMap.get(field.getColumnCode()))) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-参数验证：" + field.getColumnName() + "参数是必填");
            }
        });
        return true;
    }

    /**
     * 验证参数长度
     *
     * @param requestMap
     * @return
     */
    private boolean verifyParameterLength(Map<String, Object> requestMap, List<AppliedBizManegeFieldBean> fields) throws JsonProcessingException {

        fields.forEach((field) -> {

            String lengthStr = field.getColumnLength();
            int length = 0;
            if (StringUtils.isEmpty(lengthStr)) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-参数验证：" + field.getColumnName() + "参数长度长度为NULL");
            } else if ("0".equals(lengthStr)) {
                //date类型等参数没有设定长度
                return;
            } else if (lengthStr.indexOf(",") == -1) {
                length = Integer.valueOf(lengthStr);
            } else {
                String[] len = lengthStr.split(",");
                length = Integer.sum(Integer.valueOf(len[0]), Integer.valueOf(len[1]));
                length++;//小数点
            }

            Object value = requestMap.get(field.getColumnCode());
            if (value != null && value.toString().length() > length) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-参数验证：" + field.getColumnName() + "参数长度不应超过" + length);
            }
        });

        return true;
    }

    /**
     * 验证参数名称是否和数据库一致
     *
     * @param requestMap
     * @return
     */
    private boolean verifyParameterName(Map<String, Object> requestMap, List<AppliedBizManegeFieldBean> fields) {

        List<String> columnCodes = getColumnCodeByFields(fields);
        requestMap.forEach((k, v) -> {
            if (!columnCodes.contains(k)) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-参数验证：" + k + "字段不存在数据库中");
            }
        });

        return true;
    }


    /**
     * 验证查询字段名称
     *
     * @param searchConditions
     * @return
     */
    private boolean verifySearchParameterName(String searchConditions, List<AppliedBizManegeFieldBean> fields) {

        log.info("应用模块-查询参数验证");
        if (searchConditions != null) {
            List<String> columnCodes = getSearchColumnCodeByFields(fields);
            String[] conditions = searchConditions.split(",");
            if (conditions == null) {
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-查询参数验证：" + searchConditions + "格式不正确");
            }
            for (int i = 0; i < conditions.length; i++) {
                String conditionSegment = conditions[i];
                String[] conditionAndValue = conditionSegment.split("=");
                if (conditionAndValue == null) {
                    throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-查询参数验证：" + conditionSegment + "格式不正确");
                } else if (conditionAndValue.length != 2) {
                    throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-查询参数验证：" + conditionSegment + "格式不正确");
                } else {
                    if (!columnCodes.contains(conditionAndValue[0])) {
                        throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_CHECK_MESSAGE.code(), "应用模块-查询参数验证：" + conditionAndValue[0] + "该字段不是查询条件");
                    }
                }

            }
        }

        return true;
    }

    /**
     * 查询字段code
     *
     * @param fields
     * @return
     */
    private List<String> getSearchColumnCodeByFields(List<AppliedBizManegeFieldBean> fields) {
        List<String> columnCodes = new ArrayList<>();
        fields.forEach((field) -> {
            if ("1".equals(field.getIsQueryCriteria())) {
                columnCodes.add(field.getColumnCode());
            }
        });
        return columnCodes;
    }

    /**
     * 详情字段code
     *
     * @param fields
     * @return
     */
    private List<String> getColumnCodeByFields(List<AppliedBizManegeFieldBean> fields) {
        List<String> columnCodes = new ArrayList<>();
        fields.forEach((field) -> {
            columnCodes.add(field.getColumnCode());
        });
        return columnCodes;
    }


    /**
     * 提交审批
     *
     * @param bizId
     * @param id
     * @param examineId
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean submitExamine(Integer bizId, Integer id, Integer examineId) throws Exception {
        log.info("应用模块-提交审批流");
        AppliedBizManege appBiz = getAppliedBizManegeById(bizId);
        verifyExamineStatus(appBiz, id);
        Result<?> result = activitiOptionService.submit(UserInfo.getCurrentUserId().toString(), ActivitiConstants.BusniessType.application, examineId, id, bizId);
        if (result == null || result.getCode().intValue() != 0) {//提交失败
            log.info("应用模块-提交审批失败，结果{}",result);
            throw new BusinessException(MsgReturnEnum.APPLIED_SUBMIT_ACTIVITI);
        }
        updateExamineStatus(bizId,id,ActivitiConstants.ExamineStatus.undo);
        log.info("应用模块-提交审批流成功");
        return true;

    }

    /**
     * 验证审批状态
     * @param appBiz
     * @param ids
     */
    private void verifyExamineStatus(AppliedBizManege appBiz, Integer... ids) {
        if (appBiz != null) {
            if (!StringUtils.isEmpty(appBiz.getExamineId())) {
                for (int i = 0; i < ids.length; i++) {
                    Map<String, Object> result = appliedBizManegeMapper.selectModuleDataById(appBiz.getBizTableName(), ids[i]);
                    Integer status = ((Integer) result.get("examine_status"));
                    if (status != ActivitiConstants.ExamineStatus.reject && status != 0) {
                        log.info("应用模块-数据已审批通过，不可修改，不可删除");
                        throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_EXAMINE_STATUS_NO_OPERATE);
                    }
                }

            }
        }
    }

    /**
     * 修改审批状态
     * @param bizId
     * @param id
     * @param examineStatus
     */
    public boolean updateExamineStatus(Integer bizId, Integer id, Integer examineStatus) {
        log.info("应用模块-更新审批状态");
        AppliedBizManege appBiz = getAppliedBizManegeById(bizId);
        if (StringUtils.isEmpty(appBiz.getExamineId())) {
            throw new BusinessException(MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR);
        }

        Map<String, Object> parameter = new HashMap();
        parameter.put("tableName", appBiz.getBizTableName());
        parameter.put("examineStatus", examineStatus);
        parameter.put("id", id);
        int row = appliedBizManegeMapper.updateExamineStatus(parameter);
        if (row < 0) {
            log.error("应用审批结果更新失败");
            throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_EXAMINE_STATUS);
        }

        return true;
    }

    private String getImagePath(){
        int lastIndex = imageRootPath.lastIndexOf("/");
        if (lastIndex == imageRootPath.length()-1){
            return imageRootPath.substring(0,imageRootPath.length()-1);
        }
        return imageRootPath;
    }


    /**
     * 修改审批状态
     * @param bizId
     * @param response
     * @throws IOException
     */
    public void export(Integer bizId, HttpServletResponse response) throws Exception {

        //获取锁(登录用户锁)
        RLock lock = redissionUtils.getRLock("appExport"+UserInfo.getCurrentUserId());
        ExcelWriter excelWriter = null;
        try {
            log.info("应用模块-导出-获取锁");
            boolean res = lock.tryLock(Const.WAIT_TIME,Const.LEASE_TIME, TimeUnit.SECONDS);
            if(!res) {
                log.error("获取不到锁，请排查日志");
                throw new BusinessException(MsgReturnEnum.LOCK_FALSE);
            }

            log.info("应用模块-导出-查询数据");
            AppliedBizManege appBiz = getAppliedBizManegeById(bizId);
            List<String> fieldCodes = getFieldCodes(appBiz);
            PageHelper.startPage(1, 50000, false);
            String sql = getSqlByExport(appBiz,fieldCodes);
            List<Map<String, Object>> result = appliedBizManegeMapper.selectExportData(sql);
            if (CollectionUtils.isEmpty(result)) {
                log.error("查询不到数据无法导出，请排查日志");
                throw new BusinessException(MsgReturnEnum.APPLIED_BIZ_MANEGE_BIZ_APP_ID);
            }

            log.info("应用模块-导出-配置Excel");
            String name = "app_" + System.currentTimeMillis() + "";
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("utf-8");
            // 这里URLEncoder.encode可以防止中文乱码
            String fileName = URLEncoder.encode(name, "UTF-8");
            log.info("fileName:{}", fileName);
            response.setHeader("Pragma", "public");
            response.setHeader("Cache-Control", "public");
            response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");

            List<List<String>> headList = getHeadByBizFileds(appBiz);
            List<List<Map<String, Object>>> partition = Lists.partition(result, 20000);//指定长度切割list
            excelWriter = EasyExcel.write(response.getOutputStream()).build();
            for (int i = 0; i < partition.size(); i++) {
                WriteSheet mainSheet = EasyExcel.writerSheet(i, "Sheet"+i).head(headList).build();
                excelWriter.write(loadData(partition.get(i),appBiz),mainSheet);
            }

        } catch (Exception e) {
            log.error("导出数据错误：{}",e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {

            if(excelWriter != null){
                excelWriter.finish();
            }

            lock.unlock();

        }

    }


    /**
     * 查询head头信息
     * @param appBiz
     * @return
     * @throws JsonProcessingException
     */
    private List<List<String>> getHeadByBizFileds(AppliedBizManege appBiz) throws JsonProcessingException {

        log.info("应用模块-导出-查询head头信息");
        //生成表格头
        List<List<String>> headList = new ArrayList<List<String>>();
        List<String> headId = new ArrayList<String>();
        headId.add(AppliedBizConstants.ID_FIELD.getColumnName());
        headList.add(headId);


        List<AppliedBizManegeFieldBean> bizFields = objectMapper.readValue(appBiz.getBizFields(), new TypeReference<List<AppliedBizManegeFieldBean>>() {});
        bizFields.forEach((field)->{
            List<String> head0 = new ArrayList<String>();
            head0.add(field.getColumnName());
            headList.add(head0);
        });

        List<AppliedBizManegeFieldBean> publicBizFields = AppliedBizConstants.PUBLIC_BIZ_FIELDS;
        publicBizFields.forEach((publicBizField)->{
            List<String> head0 = new ArrayList<String>();
            head0.add(publicBizField.getColumnName());
            headList.add(head0);
        });

        return headList;
    }

    /**
     * 字段的code
     * @param appBiz
     * @return
     */
    private List<String> getFieldCodes(AppliedBizManege appBiz) throws JsonProcessingException {

        log.info("应用模块-导出-查询字段code");
        //生成表格头
        List<String> headCodeList = new ArrayList<String>();
        headCodeList.add(AppliedBizConstants.ID_FIELD.getColumnCode());

        //表字段生成list集合
        List<AppliedBizManegeFieldBean> bizFields = objectMapper.readValue(appBiz.getBizFields(), new TypeReference<List<AppliedBizManegeFieldBean>>() {});
        bizFields.forEach((field)->{
            StringBuilder columnCode = new StringBuilder();
            columnCode.append("IFNULL(");
            columnCode.append(field.getColumnCode());
            columnCode.append(", ''");
            columnCode.append(") as ");
            columnCode.append(field.getColumnCode());
            headCodeList.add(columnCode.toString());
        });

        List<AppliedBizManegeFieldBean> publicBizFields = AppliedBizConstants.PUBLIC_BIZ_FIELDS;
        publicBizFields.forEach((publicBizField)->{
            StringBuilder columnCode = new StringBuilder();
            columnCode.append("IFNULL(");
            columnCode.append(publicBizField.getColumnCode());
            columnCode.append(", ''");
            columnCode.append(") as ");
            columnCode.append(publicBizField.getColumnCode());
            headCodeList.add(columnCode.toString());
        });

        return headCodeList;
    }

    /**
     * 格式化成excel可以使用的数据
     * @param dataResult
     * @return
     */
    private List<List<String>> loadData(List<Map<String, Object>> dataResult, AppliedBizManege appBiz) throws JsonProcessingException {

        log.info("应用模块-导出-准备数据");
        List<List<String>> dateList = new ArrayList<List<String>>();
        List<AppliedBizManegeFieldBean> fieldBeans = getFieldsByAppBizManege(appBiz);
        List<SysDictionaries> dictionariesRedis = new ArrayList<>();
        dataResult.forEach((map) -> {
            List<String> items = new ArrayList<>();
            map.forEach((k, v) -> {

                String dict = setDictValue(k, v, fieldBeans, dictionariesRedis);
                String path = setImagePath(k, v, fieldBeans);

                //回显时间
                if (v instanceof Timestamp) {
                    items.add(DateUtil.format((Date) v));
                }
                //回显审核状态
                else if (k.equals("examine_status")) {
                    if (!StringUtils.isEmpty(v)) {
                        Integer status = null;
                        if (v instanceof String) {
                            status = Integer.valueOf((String) v);
                        } else {
                            status = (Integer) v;
                        }

                        items.add(AppliedBizConstants.AppliedExamineStatus.get(status));
                    }
                }
                //回显图片和视频的全路径
                else if (!StringUtils.isEmpty(path)) {
                    items.add(path);
                }
                //回显数据字典
                else if (!StringUtils.isEmpty(dict)) {
                    items.add(dict);
                } else {
                    items.add(String.valueOf(v));
                }

            });
            dateList.add(items);
        });

        return dateList;
    }

    /**
     * 导出数据的sql
     * @param appBiz
     * @param fieldCodes
     * @return
     */
    private String getSqlByExport(AppliedBizManege appBiz,List<String> fieldCodes){

        log.info("应用模块-导出-导出数据的sql");
        StringBuilder sql = new StringBuilder();
        sql.append("select ");
        sql.append(fieldCodes.stream().collect(Collectors.joining(",")));
        sql.append(" from ");
        sql.append(appBiz.getBizTableName());
        log.info("应用模块-导出-sql "+sql.toString());

        return sql.toString();

    }
}

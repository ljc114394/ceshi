package com.boe.bank.service.material;

import com.alibaba.fastjson.JSON;
import com.boe.bank.beanconverter.ActivitiExamineCoverter;
import com.boe.bank.beanconverter.LabelCoverter;
import com.boe.bank.beanconverter.MaterialCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.datarolebean.DataRoleOrgBean;
import com.boe.bank.common.bean.labelBean.LabelBaseBean;
import com.boe.bank.common.bean.labelBean.LabelSearchBean;
import com.boe.bank.common.bean.material.*;
import com.boe.bank.common.constant.*;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.entity.label.Label;
import com.boe.bank.common.entity.material.MaterialManage;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.mapper.labelMapper.LabelMapper;
import com.boe.bank.mapper.material.MaterialManageMapper;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.activitiService.base.ActivitiExamineService;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.bank.service.dataroleService.DataRoleService;
import com.boe.bank.service.planmanageService.PlanManageService;
import com.boe.bank.service.userInfoService.UserInfoService;
import com.boe.bank.util.UploadUtil;
import com.boe.cloud.megarock.security.common.Organization;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:素材管理业务层
 * @author: zhaohaixia
 * @date: 2020年10月13日 下午2:27:08
 */
@Service
@Slf4j
public class MaterialManageService {

    @Resource
    private MaterialManageMapper materialManageMapper;

    @Resource
    private RedissionUtils redissionUtils;

    @Resource
    private MaterialCoverter materialCoverter;

    @Autowired
    private Environment env;

    @Autowired
    private PlanManageService planManageService;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private DataRoleService dataRoleService;

    @Resource
    private LabelMapper labelMapper;

    @Resource
    private LabelCoverter labelCoverter;

    @Autowired
    private ActivitiOptionService activitiOptionService;

    @Autowired
    private ActivitiExamineService activitiExamineService;

    @Autowired
    private ActivitiOuterRelationService activitiOuterRelationService;

    @Resource
    private ActivitiExamineCoverter activitiExamineCoverter;

    @Resource
    private OrganizationService organizationService;

    @Value("${material.path:}")
    private String path;

    /**
     * @param bean
     * @return
     * @Description:分页获取素材
     * @author: zhaohaixia
     * @date: 2020年10月20日 上午10:56:28
     */
    public PageInfo<MaterialListBean> getList(MaterialConBean bean) {
        ObjectUtil.setPageNumAndPageSizeDefault(bean);//设置分页默认值
        Map map = myOrgINorgList();
        List<Integer> myOrgList = (List<Integer>) map.get("orgList");
        //前端初始化的时候orgid为-1
        if (bean.getOrgId()!=null){
            if (bean.getOrgId()==-1){
                boolean res = (boolean) map.get("res");
                if (res==false){
                    Page page = PageHelper.startPage(bean.getPageNum(), bean.getPageSize(), true);
                    List<MaterialListBean> lst = new ArrayList<>();
                    PageInfo<MaterialListBean> pageInfo = new PageInfo<MaterialListBean>(lst, page);
                    return pageInfo;
                }
                bean.setOrgId(Long.parseLong(map.get("departId").toString()));
            }
        }
        try {
            Page page = PageHelper.startPage(bean.getPageNum(), bean.getPageSize(), true);
            List<MaterialListBean> lst = materialManageMapper.getList(bean,myOrgList);
            if (CollectionUtils.isEmpty(lst)) {
                lst = Lists.newArrayList();
            }
            PageInfo<MaterialListBean> pageInfo = new PageInfo<MaterialListBean>(lst, page);
            log.info("素材分页列表 getList pageNum:{},pageSize:{}size:{}", bean.getPageNum(), bean.getPageSize(), lst.size());
            return pageInfo;
        } finally {
            PageHelper.clearPage();
        }
    }

//    /**
//     *
//     * @param formId
//     * @param toId
//     * @param orgId
//     * @return
//     */
//    @Transactional
//    public Integer paste(Integer formId, Integer toId,Integer orgId) {
//        //根据id查出来一条数据
//        MaterialManage fromMaterialManage = materialManageMapper.selectByPrimaryKey(formId);
//        MaterialManage toMaterialManage = materialManageMapper.selectByPrimaryKey(toId);
//        if (fromMaterialManage == null) {//粘贴的文件文件夹不存在
//            throw new BusinessException(MsgReturnEnum.MATERIAL_NOT_EXIST);
//        }
//        if (toId !=0){
//            //只能复制到文件夹
//            if ((toMaterialManage.getFileType().intValue() != MaterialTypeEnum.TYPE_FOLDER.getCode())){
//                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_COPYEMPTY);
//            }
//            //如果toid 是二级文件夹，formId是文件夹 不让粘贴文件夹
//            if ((toMaterialManage.getLevel()==MaterialTypeEnum.LEVEL_TWO.getCode())&&(fromMaterialManage.getFileType() ==MaterialTypeEnum.TYPE_FOLDER.getCode()) ){
//                throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_LEVEL);
//            }
//            //如果toid是一级文件夹，formid是一级文件夹（如果里面有文件夹不让粘贴）
//            if ((toMaterialManage.getLevel()==MaterialTypeEnum.LEVEL_ONE.getCode())&&(fromMaterialManage.getLevel() ==MaterialTypeEnum.LEVEL_ONE.getCode()) ){
//                List<Integer> lst = materialManageMapper.getFolderIds(formId);
//                if (lst.size()!=0){
//                    throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_LEVEL);
//                }
//            }
//        }
//
//        Integer res;
//        Integer currentid = fromMaterialManage.getId();
//        MaterialManage materialManage =  fromMaterialManage;
//        materialManage.setId(null);
//        materialManage.setParentId(toId);
//        materialManage.setOrgId(orgId.longValue());
//        materialManage.setStatus(ActivitiConstants.ExamineStatus.undo);
//        setMaterialGeneral(materialManage);
//
//        //如果是素材直接插入文件类型，1文件夹，2素材
//        if(fromMaterialManage.getFileType() == MaterialTypeEnum.TYPE_FOLDER.getCode()){
//            if (toId==0){
//                materialManage.setLevel(1);
//            }else {
//                materialManage.setLevel(toMaterialManage.getLevel()+1);
//            }
//            res = materialManageMapper.insertSelective(materialManage);
//            if (res<1){
//                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_COPYFAIL);
//            }
//            //如果是文件夹也插入，然后调用递归,插入文件夹然后获取id，为toid 调用递归循环插入
//            getMaterialManage(currentid, materialManage.getId(),materialManage.getOrgId().intValue());
//        }else {
//            res = materialManageMapper.insertSelective(materialManage);
//            if (res<1){
//                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_COPYFAIL);
//            }
//            log.info("添加素材 结果 res：{}", res);
//            //1.插入素材成功 直接调用工作流
//            Result<?> result = activitiOptionService.submit(UserInfo.getCurrentUserId().toString(), ActivitiConstants.BusniessType.material, materialManage.getApprovalType(), materialManage.getId(), null);
//            if (result == null || result.getCode().intValue() != 0) {//提交失败
//                //如果提交审批流失败，则抛出，通知用户即可 20201022 路延确认
//                throw new BusinessException(MsgReturnEnum.MATERIAL_SUBMIT_ACTIVITI);
//            }
//        }
//        return res;
//    }

    /**
     *
     * @param formId
     * @param toId
     * @param orgId
     * @return
     */
    @Transactional
    public List<MaterialManage> paste(Integer formId, Integer toId,Integer orgId) {
        //根据id查出来一条数据
        MaterialManage fromMaterialManage = materialManageMapper.selectByPrimaryKey(formId);
        MaterialManage toMaterialManage = materialManageMapper.selectByPrimaryKey(toId);
        if (fromMaterialManage == null) {//粘贴的文件文件夹不存在
            throw new BusinessException(MsgReturnEnum.MATERIAL_NOT_EXIST);
        }
        if (toId !=0){
            //只能复制到文件夹
            if ((toMaterialManage.getFileType().intValue() != MaterialTypeEnum.TYPE_FOLDER.getCode())){
                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_COPYEMPTY);
            }
            //如果toid 是二级文件夹，formId是文件夹 不让粘贴文件夹
            if ((toMaterialManage.getLevel()==MaterialTypeEnum.LEVEL_TWO.getCode())&&(fromMaterialManage.getFileType() ==MaterialTypeEnum.TYPE_FOLDER.getCode()) ){
                throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_LEVEL);
            }
            //如果toid是一级文件夹，formid是一级文件夹（如果里面有文件夹不让粘贴）
            if ((toMaterialManage.getLevel()==MaterialTypeEnum.LEVEL_ONE.getCode())&&(fromMaterialManage.getLevel() ==MaterialTypeEnum.LEVEL_ONE.getCode()) ){
                List<Integer> lst = materialManageMapper.getFolderIds(formId);
                if (lst.size()!=0){
                    throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_LEVEL);
                }
            }
        }
        Integer currentid = fromMaterialManage.getId();
        MaterialManage materialManage =  fromMaterialManage;
        materialManage.setId(Integer.valueOf(redissionUtils.createNo(RedisPrefix.Material_KEY)));
        materialManage.setParentId(toId);
        materialManage.setOrgId(orgId.longValue());
        materialManage.setStatus(ActivitiConstants.ExamineStatus.undo);
        setMaterialGeneral(materialManage);

        List<MaterialManage> sumMaterialList = new ArrayList<MaterialManage>();
        //如果是素材直接插入文件类型，1文件夹，2素材
        if(fromMaterialManage.getFileType() == MaterialTypeEnum.TYPE_MATERIAL.getCode()){
            //如果是素材
            sumMaterialList.add(materialManage);
        }else {
            //如果是文件夹
            if (toId==0){
                materialManage.setLevel(1);
            }else {
                materialManage.setLevel(toMaterialManage.getLevel()+1);
            }
            sumMaterialList.add(materialManage);
            //如果是文件夹也插入，然后调用递归,插入文件夹然后获取id，为toid 调用递归循环插入
            getMaterialManage(currentid, materialManage.getId(),materialManage.getOrgId().intValue(),sumMaterialList);
        }
        Integer res = materialManageMapper.insertMaterialList(sumMaterialList);
        if (res<1) {
              throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_COPYFAIL);
        }
        return sumMaterialList;
    }
    public void getMaterialManage(Integer fromId,Integer toId ,Integer orgId,List<MaterialManage> SumMaterialList){
        //根据父id 查询子的里面的文件夹和素材
        List<MaterialManage> materialList= materialManageMapper.getSubListByParentId(fromId);
        if(materialList.size()!=0){
            //遍历查出来的子文件夹和素材，素材直接插数据库，文件夹也插入数据库然后递归遍历里面的儿子，直到里面没有数据了
            for(MaterialManage materialManage:materialList){
                Integer currentid = materialManage.getId();
                MaterialManage newmaterialManage = materialManage;
                newmaterialManage.setId(Integer.valueOf(redissionUtils.createNo(RedisPrefix.Material_KEY)));
                newmaterialManage.setParentId(toId);
                newmaterialManage.setOrgId(orgId.longValue());
                newmaterialManage.setStatus(ActivitiConstants.ExamineStatus.undo);
                setMaterialGeneral(newmaterialManage);

                if(materialManage.getFileType() == MaterialTypeEnum.TYPE_FOLDER.getCode()){
                    //如果是文件夹也插入，然后调用递归,插入文件夹然后获取id，为toid 调用递归循环插入
                    newmaterialManage.setLevel(materialManage.getLevel()+1);
                    SumMaterialList.add(newmaterialManage);
                    getMaterialManage(currentid, newmaterialManage.getId(),newmaterialManage.getOrgId().intValue(),materialList);
                }else {
                    SumMaterialList.add(newmaterialManage);
                }
            }
        }
    }


    /**
     * @param bean
     * @param mfile
     * @return
     * @Description:添加素材
     * @author: zhaohaixia
     * @date: 2020年10月20日 上午10:55:38
     */
    @Transactional
    public Integer add(MaterialBean bean, MultipartFile mfile) {
        //type为1,2,5,6时，mfile必须传
        if (MaterialTypeEnum.PIC.getCode() == bean.getType().intValue() || MaterialTypeEnum.VIDEO.getCode() == bean.getType().intValue()
                || MaterialTypeEnum.DOCUMENT.getCode() == bean.getType().intValue()
                || MaterialTypeEnum.PROGRAM.getCode() == bean.getType().intValue()) {
            if (mfile == null || mfile.isEmpty()) {//文件不能为空
                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_EMPTY);
            }
        }
        //处理上传的文件
        handleFile(mfile, bean);
        MaterialManage materialManage = materialCoverter.getMaterial(bean);
        setMaterial(materialManage);
        Integer res = materialManageMapper.insertSelective(materialManage);
        log.info("添加素材 结果 res：{}", res);
        if (res > 0) {//添加成功，提交审批流
            Result<?> result = activitiOptionService.submit(UserInfo.getCurrentUserId().toString(), ActivitiConstants.BusniessType.material, materialManage.getApprovalType(), materialManage.getId(), null);
            if (result == null || result.getCode().intValue() != 0) {//提交失败
                //如果提交审批流失败，则抛出，通知用户即可 20201022 路延确认
                throw new BusinessException(MsgReturnEnum.MATERIAL_SUBMIT_ACTIVITI);
            }
        }
        return res;
    }

    /**
     * @param beans
     * @return
     * @Description:批量添加素材
     * @author: zhaohaixia
     * @date: 2020年10月20日 上午10:55:38
     */
    public List<MaterialManage> addmaterials(List<MaterialBean> beans) {
        List<MaterialManage> materialManages = materialCoverter.getMaterialsInfoList(beans);
        for (MaterialManage materialManage :materialManages) {
            materialManage.setId(Integer.valueOf(redissionUtils.createNo(RedisPrefix.Material_KEY)));
            setMaterial(materialManage);
        }
        Integer res = materialManageMapper.insertMaterialList(materialManages);

        if (res<0){
            throw new BusinessException(MsgReturnEnum.MATERIAL_SUBMIT_ACTIVITI);
        }
        return materialManages ;
    }

    public void setMaterial(MaterialManage materialManage) {
        materialManage.setStatus(ActivitiConstants.ExamineStatus.undo);//默认审批中
        materialManage.setFileType(MaterialTypeEnum.TYPE_MATERIAL.getCode());//1文件夹 2素材
        materialManage.setLevel(MaterialTypeEnum.LEVEL_ZERO.getCode());//level是0
        materialManage.setIsDelete(false);//删除是1，未删除是0
        if (MaterialTypeEnum.LEVEL_ZERO.getCode() == materialManage.getParentId().intValue()) {//素材不在文件夹下
            materialManage.setFlag(false);
        }
        setMaterialGeneral(materialManage);
    }

    public void setMaterialGeneral(MaterialManage materialManage) {
        materialManage.setCreateUserId(UserInfo.getCurrentUserId());
        materialManage.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());
        materialManage.setCreateTime(LocalDateTime.now());
        materialManage.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());
        materialManage.setUpdateTime(LocalDateTime.now());
    }

    /**
     * @param id
     * @return
     * @Description:查看素材
     * @author: zhaohaixia
     * @date: 2020年10月20日 上午10:55:25
     */
    public MaterialInfoBean getMaterialInfo(Integer id) {
        MaterialInfoBean bean = materialManageMapper.getMaterialInfo(id);
        if(bean == null) {//素材不存在
        	throw new BusinessException(MsgReturnEnum.MATERIAL_NOT_EXIST);
        }
        return bean;
    }
    
    /**
     * @param id
     * @return
     * @Description:查看素材
     * @author: caoxuhao
     */
    public MaterialInfoBean getMaterialInfoWithDelete(Integer id) {
    	MaterialInfoBean bean = materialManageMapper.getMaterialInfoWithDelete(id);
        if(bean == null) {//素材不存在
            throw new BusinessException(MsgReturnEnum.MATERIAL_NOT_EXIST);
        }
    	return bean;
    }

    /**
     * @param id
     * @return
     * @Description:删除素材
     * @author: zhaohaixia
     * @date: 2020年10月20日 上午10:55:10
     */
    public Integer delete(Integer id) {
        /**
         * 需要判断素材是否在节目（计划管理）中使用，如果在使用，则不可以删除
         */
        boolean resP = planManageService.getPlanAndMaterialCount(id);
        if (resP) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_DELETE);
        }
        Integer res = materialManageMapper.updateDel(id);//逻辑删除

        if(res > 0)
            //废弃审批流
            activitiOuterRelationService.abandon(ActivitiConstants.BusniessType.material, id, null);

        log.info("删除素材结果 res：{}", res);
        return res;
    }

    //审批流更新状态
    public Integer updateMaterialActiveState(Integer id ,Integer pass){
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        LocalDateTime createTime = LocalDateTime.now();
        return materialManageMapper.updateMaterialActiveState(id,createBy,createTime, pass);
    }



    /**
     * @return
     * @Description:编辑素材
     * @author: zhaohaixia
     * @date: 2020年10月20日 上午10:54:59
     */
    @SneakyThrows
    @Transactional
    public Integer update(MaterialBean bean) {
        MaterialManage materialManage = materialManageMapper.selectByPrimaryKey(bean.getId());
        if (bean.getApprovalType()==null){
           bean.setApprovalType(materialManage.getApprovalType());
        }
        boolean updateFlag = false;
        //文档和视频和图片 校验审批类型和二进制流
        if (bean.getType().intValue() == MaterialTypeEnum.PIC.getCode()||
                bean.getType().intValue() == MaterialTypeEnum.VIDEO.getCode()||
                bean.getType().intValue() == MaterialTypeEnum.DOCUMENT.getCode()
        ){
            if (!(bean.getApprovalType().equals(materialManage.getApprovalType()))||!(bean.getContent().equals(materialManage.getContent()))){
                updateFlag = true;
            }
        }
        //web和文本 审批类型和content
        if (bean.getType().intValue() == MaterialTypeEnum.WEB.getCode()||
                bean.getType().intValue() == MaterialTypeEnum.TEXT.getCode()
        ){
            if (!(bean.getApprovalType().equals(materialManage.getApprovalType()))||!(bean.getContent().equals(materialManage.getContent()))){
                updateFlag = true;
            }
        }
        //程序 审批类型和视频二进制流和程序参数
        if (bean.getType().intValue() == MaterialTypeEnum.PROGRAM.getCode()){
            if (!(bean.getProgramEntry().equals(materialManage.getProgramEntry()))||!(bean.getApprovalType().equals(materialManage.getApprovalType()))||!(bean.getContent().equals(materialManage.getContent()))){
                updateFlag = true;
            }
        }
//		BeanUtil.copyProperties(bean, materialManage, CopyOptions.create().setIgnoreNullValue(true).setIgnoreError(true));
        materialManage = materialCoverter.getMaterial(bean);
        //编辑完素材状态改为待审核，然后重新提交审批流
        if (updateFlag) {
            materialManage.setStatus(ActivitiConstants.ExamineStatus.undo);
        }
        materialManage.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());
        materialManage.setUpdateTime(LocalDateTime.now());
        Integer res = materialManageMapper.updateByPrimaryKeySelective(materialManage);

        log.info("编辑素材 结果 res：{}", res);
        if (res > 0&&updateFlag) {//修改成功，重新提交审批流
            //废弃审批流
            activitiOuterRelationService.abandon(ActivitiConstants.BusniessType.material, bean.getId(), null);
            Result<?> result = activitiOptionService.submit(UserInfo.getCurrentUserId().toString(), ActivitiConstants.BusniessType.material, materialManage.getApprovalType(), materialManage.getId(), null);

            if (!result.isSuccess()) {
                if ((result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR.code())||
                        (result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE.code()))  {
                    // 没有审批流，则将设备的状态直接改为审批通过
                    materialManage.setStatus(ActivitiConstants.ExamineStatus.pass);
                    materialManageMapper.updateByPrimaryKeySelective(materialManage);
                }else {
                    throw new Exception("审批异常,请重新添加");
                }
            }
//            if (result == null || result.getCode().intValue() != 0) {//提交失败
//                //如果提交审批流失败，则抛出，通知用户即可 20201022 路延确认
//                throw new BusinessException(MsgReturnEnum.MATERIAL_SUBMIT_ACTIVITI);
//            }
        }
        return res;
    }

    /**
     * 处理上传的文件
     */
    public void handleFile(MultipartFile mfile, MaterialBean bean) {
        //处理上传的文件
        if (mfile != null && !mfile.isEmpty()) {
            /**
             * 文档，应用程序名称不能重复
             */
            String originFileName = mfile.getOriginalFilename();
            if (MaterialTypeEnum.DOCUMENT.getCode() == bean.getType().intValue()
                    || MaterialTypeEnum.PROGRAM.getCode() == bean.getType().intValue()) {
                MaterialManage material = materialManageMapper.selectByContent(originFileName, bean.getType());
                if (material != null) {
                    throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_CONTENT);
                }
            }
            //type为5时，文档只能为PDF格式
            if (MaterialTypeEnum.DOCUMENT.getCode() == bean.getType().intValue() && !originFileName.endsWith("pdf")) {
                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_PDF);
            }
            //文件大小
            bean.setSize((int) mfile.getSize());
            //文件md5值
            try {
                bean.setMd5(DigestUtils.md5Hex(mfile.getInputStream()));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            //上传文件到服务器
            // 获取文件后缀
            String subfix = originFileName.substring(originFileName.indexOf('.') + 1, originFileName.length());
            // type为1或者2时，创建文件唯一名称
//            String fileName = "";
//            if (MaterialTypeEnum.PIC.getCode() == bean.getType().intValue()
//                    || MaterialTypeEnum.VIDEO.getCode() == bean.getType().intValue()) {
//                String uuid = UUID.randomUUID().toString() + "." + subfix;
//                fileName = uuid.toString().replaceAll("\\-", "");
//            } else {//文档，应用程序采用上传的名字
//                fileName = originFileName;
//            }
            String uuid = UUID.randomUUID().toString() + "." + subfix;
            String fileName = uuid.toString().replaceAll("\\-", "");

            //上传路径
            String dirPathRoot = env.getProperty("material.path");
            String mpath = "";
            if (MaterialTypeEnum.PIC.getCode() == bean.getType().intValue()) {
                mpath = MaterialDir.PIC;
            } else if (MaterialTypeEnum.VIDEO.getCode() == bean.getType().intValue()) {
                mpath = MaterialDir.VIDEO;
            } else if (MaterialTypeEnum.DOCUMENT.getCode() == bean.getType().intValue()) {
                mpath = MaterialDir.DOCUMENT;
            } else if (MaterialTypeEnum.PROGRAM.getCode() == bean.getType().intValue()) {
                mpath = MaterialDir.PROGRAM;
            }
            String dirPath = dirPathRoot + mpath;
            if (UploadUtil.saveMaterialFile(mfile, dirPath, fileName)) {
                if(dirPathRoot.contains(":")){
                    String up = dirPathRoot.substring(dirPathRoot.indexOf(":")+1);
                    bean.setContent(up + mpath + "/" + fileName);
                }
                // 返回文件名称
                bean.setContent(dirPath+"/"+fileName);
            } else {
                throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_EXCEP);
            }

        }

    }
    public List<DataRoleOrgBean> getOrgList() {
        List<DataRoleOrgBean> lst = dataRoleService.getDataRoleByRoleList();
        if (CollectionUtils.isEmpty(lst)) {
            lst = Lists.newArrayList();
        }
        return lst;
    }

    public Map myOrgINorgList(){
        List<Integer> orgList = new ArrayList<>();
        Map map = new HashMap();
        boolean res = false;
        //获取部门id
        Integer departId = userInfoService.getDepartmentIdByUserId();
        Integer myorgId = UserInfo.getCurrentUserInfo().getOrgId().intValue();
        List<DataRoleOrgBean> lst = dataRoleService.getDataRoleByRoleList();
        //如果部门为null直接查机构
        if (departId==null){
            map.put("departId",myorgId);
            res = true;
        }else {
            for (DataRoleOrgBean dataRoleOrgBean :lst) {
                if (myorgId.equals(dataRoleOrgBean.getId()) ){
                    res = true;
                    map.put("departId",myorgId);
                }
                if (departId.equals(dataRoleOrgBean.getId()) ){
                    res = true;
                    map.put("departId",departId);
                }
                orgList.add(dataRoleOrgBean.getId());
            }
        }

        map.put("res",res);
        map.put("orgList",orgList);
        return map;
    }



    /**
     * @param response
     * @param id
     * @Description:下载文档
     * @author: zhaohaixia
     * @date: 2020年10月20日 下午4:23:46
     */
    public void export(HttpServletResponse response, Integer id) throws IOException {
        MaterialManage materialManage = materialManageMapper.selectByPrimaryKey(id);
        if (materialManage == null) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_NOT_EXIST);
        }
        //上传路径
        String fileName =  "";
        String filePath =  materialManage.getContent();
        String[] fileNameArr = filePath.split("/");
        if (fileNameArr.length>0){
            fileName = fileNameArr[fileNameArr.length-1];
        }
        File f = new File(filePath);
        if (!f.exists()) {
            response.sendError(404, "File not found!");
            return;
        }
        BufferedInputStream br = new BufferedInputStream(new FileInputStream(f));
        byte[] bs = new byte[1024];
        int len = 0;
        response.reset(); // 非常重要
        // 纯下载方式
        response.setContentType("application/x-msdownload");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        OutputStream out = response.getOutputStream();
        try{
            while ((len = br.read(bs)) > 0) {
                out.write(bs, 0, len);
            }
        }catch (Exception e){
            throw new BusinessException(MsgReturnEnum.MATERIAL_DOWNLOAD_ERROR);
        }finally {
            out.flush();
            out.close();
            br.close();
        }
    }

    public List<LabelBaseBean> getLabelList() {
        LabelSearchBean labelSearchBean = new LabelSearchBean();
        List<Label> list = labelMapper.getLabelList(labelSearchBean);
        List<LabelBaseBean> lst = labelCoverter.getLabelBaseBean(list);
        if (CollectionUtils.isEmpty(lst)) {
            lst = Lists.newArrayList();
        }
        return lst;
    }

    /**
     * @param folderId 文件夹id
     * @return
     * @Description:素材文件夹删除
     * @author: zhaohaixia
     * @date: 2020年10月22日 上午10:33:25
     */
    @Transactional
    public Integer deleteFolder(Integer folderId) {
        //获取文件夹信息
        MaterialManage materialManage = materialManageMapper.selectByPrimaryKey(folderId);
        if (materialManage == null) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_NOTEXIST);
        }
        //删除二级文件夹的素材
        List<Integer> lst = materialManageMapper.getFolderIds(folderId);
        Integer resl = materialManageMapper.updateByFolder(lst);
        log.info("删除二级文件夹下的素材 结果 resl：{}", resl);
        if (resl < 1) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_FAIL);
        }
        //删除一级文件夹，及子文件夹，素材
        Integer res = materialManageMapper.updateById(folderId);
        if (res < 1) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_FAIL);
        }
        log.info("删除文件夹 结果 res：{}", res);
        return res;
    }
    /**
     * @param folderId 文件夹id
     * @return
     * @Description:素材文件夹删除
     * @author: 005
     * @date: 2020年10月22日 上午10:33:25
     */
    public Integer  deleteFolderAndMa(Integer folderId){
        MaterialManage materialManage = materialManageMapper.selectByPrimaryKey(folderId);
        if (materialManage == null) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_NOTEXIST);
        }
        List<Integer> allFoldIds = new ArrayList<Integer>();
        List<Integer> allMaIds = new ArrayList<Integer>();
        allFoldIds.add(folderId);
        //查询当前文件夹里面的素材
        List<Integer> materlst = materialManageMapper.getSubMatListByParentId(folderId);
        allMaIds.addAll(materlst);
        //查询二级文件夹
        List<Integer> foldlst = materialManageMapper.getFolderIds(folderId);
        if(foldlst.size()!=0){
            allFoldIds.addAll(foldlst);
            //查询文件夹下的所有素材
            List<Integer> levelmalst = materialManageMapper.getFolderAndMaterIds(foldlst);
            allMaIds.addAll(levelmalst);
        }
        boolean resP = planManageService.getManyPlanAndMaterialCount(allMaIds);
        if (resP) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_DELETE);
        }
        allFoldIds.addAll(allMaIds);
        Integer res = materialManageMapper.updateBatchDel(allFoldIds);//逻辑删除
        if (res < 1) {
            throw new BusinessException(MsgReturnEnum.MATERIAL_FOLDER_FAIL);
        }
//       查出文件夹，全部删除
//       查出所有文件夹下的素材，全部删除，然后判断是否有素材在使用。是抛错，否都删除，然后走工作流
//        activitiOuterRelationService.abandon(ActivitiConstants.BusniessType.material, id, null);
        return res;
    }


    /**
     * @return
     * @Description:获取审批类型列表
     * @author: zhaohaixia
     * @date: 2020年10月22日 下午2:53:50
     */
    public List<ActivitiExamineBean> getExamineList() {
        List<ActivitiExamine> list = activitiExamineService.getActivitiExamineListByBusniessType(ActivitiConstants.BusniessType.material);
        List<ActivitiExamineBean> lst = activitiExamineCoverter.getExamineListBean(list);
        if (CollectionUtils.isEmpty(lst)) {
            lst = Lists.newArrayList();
        }
        return lst;
    }

    /**
     * @return
     * @Description:应用业务类型审批列表
     * @author: zw
     * @date: 2020年12月2日 下午2:53:50
     */
    public List<ActivitiExamineBean> getAppBizExamineList() {
        List<ActivitiExamine> list = activitiExamineService.getActivitiExamineListByBusniessType(ActivitiConstants.BusniessType.application);
        if(CollectionUtils.isEmpty(list)){
            return Lists.newArrayList();
        }
        List<ActivitiExamineBean> lst = activitiExamineCoverter.getExamineListBean(list);
        if (CollectionUtils.isEmpty(lst)) {
            lst = Lists.newArrayList();
        }
        return lst;
    }

    /**
     * @param bean
     * @return
     * @Description:新建文件夹
     * @author: zhaohaixia
     * @date: 2020年10月22日 下午3:50:15
     */
    public Integer addFolder(FolderBean bean) {
        MaterialManage materialManage = materialCoverter.getMaterialFolder(bean);
        materialManage.setId(Integer.valueOf(redissionUtils.createNo(RedisPrefix.Material_KEY)));
        //1文件夹 2素材
        materialManage.setFileType(MaterialTypeEnum.TYPE_FOLDER.getCode());
        //类型，0文件夹，1图片资源，2视频资源 3web资源 4文本信息 5文档管理 6.应用程序
        materialManage.setType(MaterialTypeEnum.FOLDER.getCode());
        setMaterialGeneral(materialManage);
        Integer res = materialManageMapper.insertSelective(materialManage);
        log.info("新建文件夹结果  res：{}", res);
        return res;
    }

    /**
     * @param bean
     * @return
     * @Description:素材管理分页
     * @author: zhaohaixia
     * @date: 2020年10月23日 下午3:34:03
     * 初始化默认查询用户部门的，没部门查询机构的，如果没在数据授权里面，都是空，在数据授权里面有部门查部门的，有机构查机构的，点左侧各个机构，查当前机构的
     */
    public PageInfo<MaterialFolderListBean> mfpage(MaterialFolderConBean bean) {
        ObjectUtil.setPageNumAndPageSizeDefault(bean);//设置分页默认值
        Map map = myOrgINorgList();
        List<Integer> myOrgList = (List<Integer>) map.get("orgList");
        //前端初始化的时候orgid为-1
        if (bean.getOrgId()!=null){
            if (bean.getOrgId()==-1){
                boolean res = (boolean) map.get("res");
                if (res==false){
                    Page page = PageHelper.startPage(bean.getPageNum(), bean.getPageSize(), true);
                    List<MaterialFolderListBean> lst = new ArrayList<>();
                    PageInfo<MaterialFolderListBean> pageInfo = new PageInfo<MaterialFolderListBean>(lst, page);
                    return pageInfo;
                }
                bean.setOrgId(Long.parseLong(map.get("departId").toString()));
            }
        }
        try {
            Page page = PageHelper.startPage(bean.getPageNum(), bean.getPageSize(), true);
            List<MaterialFolderListBean> lst = materialManageMapper.mfpage(bean,myOrgList);
            if (CollectionUtils.isEmpty(lst)) {
                lst = Lists.newArrayList();
            }
            PageInfo<MaterialFolderListBean> pageInfo = new PageInfo<MaterialFolderListBean>(lst, page);
            log.info("素材管理 分页列表 getList pageNum:{},pageSize:{}size:{}", bean.getPageNum(), bean.getPageSize(), lst.size());
            return pageInfo;
        } finally {
            PageHelper.clearPage();
        }

    }

    /**
     * @param bean
     * @return
     * @Description:素材管理分页-计划管理-添加素材
     * @author: lvjiacheng
     * @date: 2020年11月30日
     */
    public PageInfo<MaterialFolderListBean> pfpage(MaterialPlanBean bean) {
        try {
            if(bean.getOrgId()==null || bean.getOrgId()<=0){
                throw new BusinessException (MsgReturnEnum.ID_NOFAND);
            }
            ObjectUtil.setPageNumAndPageSizeDefault(bean);//设置分页默认值
            List<Long> orgIds = Lists.newArrayList ();
            List<OrganizationDO> organizationDTOList = organizationService.listSelfAndChildren (bean.getOrgId().longValue ());
            if(!CollectionUtils.isEmpty(organizationDTOList)){
                orgIds = organizationDTOList.stream ().map (OrganizationDO::getId).distinct().collect (Collectors.toList ());
            }
            Page page = PageHelper.startPage(bean.getPageNum(), bean.getPageSize(), true);
            List<MaterialFolderListBean> lst = materialManageMapper.pfpage(bean,orgIds);
//            if (!CollectionUtils.isEmpty(lst)) {
//                for (MaterialFolderListBean mbean : lst) {//处理素材链接
//                    if (mbean.getFileType().intValue() == MaterialTypeEnum.TYPE_MATERIAL.getCode()) {
//                        if (MaterialTypeEnum.TEXT.getCode() != mbean.getType().intValue()
//                                && MaterialTypeEnum.WEB.getCode() != mbean.getType().intValue()){
//                            String content = path  + mbean.getContent();
//                            mbean.setContent(content);
//                        }
//                    }
//                }
//            }
            PageInfo<MaterialFolderListBean> pageInfo = new PageInfo<MaterialFolderListBean>(lst, page);
            log.info("素材管理 分页列表 getList pageNum:{},pageSize:{}size:{}", bean.getPageNum(), bean.getPageSize(), lst.size());
            return pageInfo;
        }  finally {
            PageHelper.clearPage();
        }
    }

    /**
     * @param bean
     * @return
     * @Description:修改文件夹
     * @author: zhaohaixia
     * @date: 2020年10月28日 上午11:06:59
     */
    public Integer updateFolder(FolderBean bean) {
        MaterialManage materialManage = materialManageMapper.selectByPrimaryKey(bean.getId());
//		BeanUtil.copyProperties(bean, materialManage, CopyOptions.create().setIgnoreNullValue(true).setIgnoreError(true));
        materialManage = materialCoverter.getMaterialFolder(bean);
        materialManage.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());
        materialManage.setUpdateTime(LocalDateTime.now());
        Integer res = materialManageMapper.updateByPrimaryKeySelective(materialManage);
        log.info("修改文件夹 结果 res：{}", res);
        return res;
    }

    /**
     * @return
     * @Description 获取当前用户的各类素材统计数量及总数（不包含文件夹和应用程序）
     * @params []
     * @author 10507807
     * @date 2020/11/17 9:33
     */
    public MaterialStatsBean getMaterialStats() {
        Long userId = UserInfo.getCurrentUserId();
        if (userId == null)
            throw new BusinessException(MsgReturnEnum.DATA_ROLE_POWER);
        List<Map<Integer, Integer>> list = materialManageMapper.getMaterialStats(userId);
        Integer total = 0;
        MaterialStatsBean bean = new MaterialStatsBean();
        for (Map<Integer, Integer> map : list) {
            if (map.get("type") == 0 || map.get("type") == 6)
                continue;
            Integer count = Integer.valueOf(String.valueOf(map.get("count")));
            if (map.get("type") == MaterialTypeEnum.PIC.getCode())
                bean.setPicture(count);
            else if (map.get("type") == MaterialTypeEnum.VIDEO.getCode())
                bean.setVideo(count);
            else if (map.get("type") == MaterialTypeEnum.TEXT.getCode())
                bean.setText(count);
            else if (map.get("type") == MaterialTypeEnum.WEB.getCode())
                bean.setWeb(count);
            else if (map.get("type") == MaterialTypeEnum.DOCUMENT.getCode())
                bean.setDocument(count);
            total += count;
        }
        bean.setTotal(total);
        return bean;
    }

    public List<Integer> getLikeName(String name){
        List<Integer> list = materialManageMapper.getLikeName(name);
        if(CollectionUtils.isEmpty(list))
            return Lists.newArrayList();
        return list;
    }
}

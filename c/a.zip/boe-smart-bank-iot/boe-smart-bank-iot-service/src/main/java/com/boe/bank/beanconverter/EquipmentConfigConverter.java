package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.equipment.EquipmentConfigDTO;
import com.boe.bank.common.bean.equipment.EquipmentConfigVO;
import com.boe.bank.common.entity.equipment.EquipmentConfig;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * 设备相关类转换器
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Mapper
public interface EquipmentConfigConverter {

    EquipmentConfigConverter INSTANCE = Mappers.getMapper(EquipmentConfigConverter.class);

    /**
     * dto转为entity
     *
     * @param dto
     * @return
     */
    EquipmentConfig dtoToEntity(EquipmentConfigDTO dto);

    /**
     * entity转为vo
     *
     * @param entity
     * @return
     */
    EquipmentConfigVO entityToVo(EquipmentConfig entity);
}

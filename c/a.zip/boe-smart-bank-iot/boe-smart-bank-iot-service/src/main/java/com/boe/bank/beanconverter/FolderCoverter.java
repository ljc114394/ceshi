package com.boe.bank.beanconverter;

import org.mapstruct.Mapper;

import com.boe.bank.common.bean.material.FolderBean;
import com.boe.bank.common.entity.material.Folder;
/**
* @Description:素材文件夹
* @author: zhaohaixia
* @date: 2020年10月22日 下午3:52:30
 */
@Mapper(componentModel = "spring")
public interface FolderCoverter {

	Folder getFolder(FolderBean bean);
    
}

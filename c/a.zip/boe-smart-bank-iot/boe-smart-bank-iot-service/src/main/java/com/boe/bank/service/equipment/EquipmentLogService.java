package com.boe.bank.service.equipment;

import java.util.List;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipmentlogbean.EquipmentLogSaveBean;
import com.boe.bank.common.entity.equipment.EquipmentLog;
import com.boe.bank.common.entity.equipment.EquipmentLogExportResultBean;
import com.boe.bank.common.entity.equipment.EquipmentLogResultBean;
import com.boe.bank.common.entity.equipment.EquipmentLogSearchBean;

/**
 * 设备日志 Service
 *
 * @author 10085188
 * @date 2020/11/5
 */
public interface EquipmentLogService extends IService<EquipmentLog> {

    /**
     * 保存设备日志
     * @param saveBean
     */
    void save(EquipmentLogSaveBean saveBean);
    
    /**
     * 获取设备日志
     * @param searchBean
     * @return
     */
    IPage<EquipmentLogResultBean> page(EquipmentLogSearchBean searchBean);
    
    /**
     * 分页获取设备日志
     * @param searchBean
     * @return
     */
    List<EquipmentLogResultBean> listEquipmentLog(EquipmentLogSearchBean searchBean);
    
    /**
     * 分页获取设备日志
     * @param searchBean
     * @return
     */
    List<EquipmentLogExportResultBean> listEquipmentLogExport(EquipmentLogSearchBean searchBean);
}

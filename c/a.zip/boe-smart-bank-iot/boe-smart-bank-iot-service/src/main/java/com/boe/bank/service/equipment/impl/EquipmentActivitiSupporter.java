package com.boe.bank.service.equipment.impl;

import com.boe.bank.beanconverter.EquipmentConverter;
import com.boe.bank.common.bean.activiti.ActivitiProcessDevVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessOrgVo;
import com.boe.bank.common.bean.equipment.EquipmentVO;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.common.entity.equipment.EquipmentType;
import com.boe.bank.mapper.equipment.EquipmentMapper;
import com.boe.bank.service.activitiService.manager.ActivitiSupport;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.bank.service.equipment.EquipmentTypeService;
import com.boe.cloud.megarock.user.javabean.dto.OrganizationDTO;
import com.boe.cloud.megarock.user.service.OrganizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 设备模块-提供审核能力
 * @author caoxuhao
 */
@Component
public class EquipmentActivitiSupporter implements ActivitiSupport {

    @Autowired
    private EquipmentMapper equipmentMapper;

    @Autowired
    private EquipmentTypeService equipmentTypeService;

    @Autowired
    private OrganizationService organizationService;

    @Override
    public int getBusniessType() {
        return ActivitiConstants.BusniessType.device;
    }

    @Override
    public boolean updateExamineStatus(int outerId, int examineStatus, Integer outerType) {
        Equipment equipment = new Equipment();
        equipment.setId(outerId);
        equipment.setAuditStatus(examineStatus);
        return equipmentMapper.updateById(equipment) > 0;
    }

    @Override
    public boolean addOuterData(int outerId, ActivitiProcessOrgVo t, Integer outerType) {

        Equipment entity = equipmentMapper.selectById(outerId);
        if (entity == null)
            return false;

        if (t instanceof ActivitiProcessDevVo) {
            ActivitiProcessDevVo vo = (ActivitiProcessDevVo) t;

            EquipmentType equipmentType = equipmentTypeService.getById(entity.getTypeId());
            if(equipmentType != null)
                vo.setDeviceType(equipmentType.getName());

            OrganizationDTO organizationDTO = organizationService.get(entity.getOrgId());
            if(organizationDTO != null)
                vo.setOrgName(organizationDTO.getName());

            vo.setDeviceName(entity.getName());
            return true;
        }

        return false;
    }
}

package com.boe.bank.mapper.equipment;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.boe.bank.common.entity.equipment.EquipmentType;

/**
 * 设备类型 Mapper
 *
 * @author 10183279
 * @date 2020/12/1
 */
public interface EquipmentTypeMapper extends BaseMapper<EquipmentType> {

}

package com.boe.bank.mapper.userStayLogMapper;

import org.apache.ibatis.annotations.Insert;

import com.boe.bank.common.entity.userStayLog.UserStayLog;

/**
 * @Author: caoxuhao
 */
public interface UserStayLogMapper {
	
    @Insert({ "insert into user_stay_log(face_id, create_time, create_at) values(#{faceId}, #{createTime, jdbcType=TIMESTAMP}, #{createAt})" })
    public int insert(UserStayLog userStayLog);
    
    
}

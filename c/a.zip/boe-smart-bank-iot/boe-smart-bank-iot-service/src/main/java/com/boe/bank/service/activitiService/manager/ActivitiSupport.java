package com.boe.bank.service.activitiService.manager;

/**
 * 具有审核能力的模块
 */
public interface ActivitiSupport extends ActivitiOuterHelper {

    /**定义此模块的业务类型*/
    int getBusniessType();

    /**根据id更新业务表中的审核状态*/
    boolean updateExamineStatus(int outerId, int examineStatus, Integer outerType);

}

package com.boe.bank.service.activitiService.org.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import com.boe.bank.common.bean.activiti.*;
import com.google.common.collect.Lists;
import org.activiti.engine.HistoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.task.Comment;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.bank.service.activitiService.org.ActivitiQueryOrgService;
import com.boe.bank.util.ActivitiUtil.ActivitiStatus;
import com.boe.bank.util.ActivitiUtil.ProcessStatus;
import com.boe.cloud.megarock.user.javabean.vo.UserVO;
import com.boe.cloud.megarock.user.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ActivitiQueryOrgServiceImpl implements ActivitiQueryOrgService {
	
	@Autowired
	private TaskService taskService;

	@Autowired
	private HistoryService historyService;

	@Autowired
	private ActivitiOuterRelationService activitiOuterRelationService;

	@Resource
    private UserService userService;

	/**
	 * 我提交的
	 */
	@Override
	public PageInfoDto<ActivitiProcessOrgVo> mySubmit(ActivitiProcessQueryReqExtBo req) {


		return changePage2Vo(req,

				//查我提交的
				q -> activitiOuterRelationService.getMyProcessList(q),

				//转化成页面要的结果
				l -> l.stream().map(pi -> changeDo2ActivitiProcessOrgVo(pi)).collect(Collectors.toList())
			);
	}

	/**
	 * 我审批的已处理的
	 */
	@Override
	public PageInfoDto<ActivitiProcessOrgVo> myExamined(ActivitiProcessQueryReqExtBo req) {

		return changePage2Vo(req,

				//查我审批的
				q -> activitiOuterRelationService.getExaminedProcessList(q),

				//转化成页面要的结果
				l -> l.stream().map(pi -> changeDo2ActivitiProcessOrgVo(pi)).collect(Collectors.toList())
			);
	}

	/**
	 * 待我审批的
	 */
	@Override
	public PageInfoDto<ActivitiProcessOrgVo> myToDo(ActivitiProcessQueryReqExtBo req) {

		return changePage2Vo(req,

				//查待我审批的
				q -> activitiOuterRelationService.getTodoProcessList(q),

				//转化成页面要的结果
				l -> l.stream().map(pi -> changeDo2ActivitiProcessOrgVo(pi)).collect(Collectors.toList())
			);
	}

	private ActivitiProcessOrgVo changeDo2ActivitiProcessOrgVo(
			ActivitiProcessOrgDo activitiProcessOrgDo) {

		String remark = "";
		String activitiStatus = null;
		String processStatus = activitiProcessOrgDo.getProcessStatus();
		if(StringUtils.isEmpty(processStatus))
			//待处理（默认几个不需要返回的页面，都写待处理）
			processStatus = ProcessStatus.undo;
		else if(processStatus.startsWith(ActivitiOptionOrgServiceImpl.EXAMINE_FAIL)){
			//拒绝
			remark = processStatus.substring(3);
			processStatus = ProcessStatus.reject;
		}

		ActivitiProcessOrgVo vo = new ActivitiProcessOrgVo();
		String endActivityId = activitiProcessOrgDo.getEai();

		if (StringUtils.isEmpty(endActivityId)) {
			activitiStatus = ActivitiStatus.doing;

		} else if (ActivitiConstants.Node.successEnd.equals(endActivityId)) {
			activitiStatus = ActivitiStatus.end;

		} else if (ActivitiConstants.Node.rejectEnd.equals(endActivityId)) {
			activitiStatus = ActivitiStatus.end;

		} else if (ActivitiConstants.Node.abandonedEnd.equals(endActivityId)) {
			activitiStatus = ActivitiStatus.abandon;
		}

		vo.setActivitiStatus(activitiStatus);
		vo.setProcessStatus(processStatus);
		vo.setProcessInstanceId(activitiProcessOrgDo.getProcessInstanceId());
		vo.setOuterId(activitiProcessOrgDo.getOuterId());
		vo.setOuterType(activitiProcessOrgDo.getOuterType());
		vo.setShowId(activitiProcessOrgDo.getShowId());

		vo.setCreateTime(DateUtil.format(activitiProcessOrgDo.getCreateTime()));

		String creator = "";
		UserVO user = userService.get(activitiProcessOrgDo.getCreateUserId());
		if(user != null)
			creator = user.getName();

		vo.setCreator(creator);
		vo.setRemark(remark);

		String taskId = activitiProcessOrgDo.getTaskId();
		if(!StringUtils.isEmpty(taskId))
			vo.setTaskId(taskId);

		return vo;
	}

	/**
	 * 审批流的详情
	 * @param processInstanceId
	 * @return
	 */
	@Override
	public List<ActivitiDetailVo> detail(String processInstanceId) {
		List<HistoricTaskInstance> list = historyService.createHistoricTaskInstanceQuery().processInstanceId(processInstanceId)
				.orderByTaskCreateTime().asc().list();

		List<ActivitiDetailVo> l = new ArrayList<>();

		for (HistoricTaskInstance ti : list) {

			ActivitiDetailVo vo = new ActivitiDetailVo();

			List<Comment> taskComments = taskService.getTaskComments(ti.getId());
			if (CollectionUtils.isEmpty(taskComments)) {
				continue;
			}else {
				Comment comment = taskComments.get(0);// 只有一条评论
				String fullMessage = comment.getFullMessage();
				String opt = fullMessage.substring(0, 2);// 前2位是拒绝和同意
				String com = fullMessage.substring(3, fullMessage.length());
				vo.setComment(com);//备注
				vo.setOpt(opt);//操作
			}

			vo.setName(ti.getName());//节点名称
			vo.setOpter(ti.getAssignee());//操作人
			vo.setTime(DateUtil.format(ti.getEndTime()));//审批日期
			l.add(vo);
		}

		return l;
	}

	/**
	 * 将数据库查到的page封装成前端需要的
	 * @param <T>	目标类型（前端接收类型）
	 * @param <R>	中间类型（数据库查出的类型）
	 * @param req	入参数
	 * @param f		数据库查询语句
	 * @param c		数据库查出的类型 -> 前端接收类型 list转化方法
	 * @return
	 */
	private <T,R> PageInfoDto<T> changePage2Vo(ActivitiProcessQueryReqExt req,
			Function<ActivitiProcessQueryReqExtBo, PageInfoDto<R>> f,
			Function<List<R>, List<T>> c){
//			ChangePage2VoHelper changePage2VoHelper){

		ActivitiProcessQueryReqExtBo bo = new ActivitiProcessQueryReqExtBo();
		BeanUtils.copyProperties(req, bo);

		List<String> endActIds = Lists.newArrayList();
		bo.setEndActIds(endActIds);
		//单据状态：流转，结束，作废
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null){
			switch (activitiStatus){
				case ActivitiConstants.ActivitiStatusType.liuZhuan:
					endActIds.add("todo");
					break;
				case ActivitiConstants.ActivitiStatusType.jieShu:
					endActIds.add("successEnd");
					endActIds.add("rejectEnd");
					break;
				case ActivitiConstants.ActivitiStatusType.zuoFei:
					endActIds.add("abandonedEnd");
					break;
				default:
					break;
			}
		}

		PageInfoDto<R> oldPage = f.apply(bo);

		List<R> records = oldPage.getRecords();

		if(CollectionUtils.isEmpty(records))
			return PageInfoDto.getEmptyPage(oldPage);

		List<T> l = c.apply(records);
//		List<T> l = changePage2VoHelper.run(req.getUserId(), records);
		return PageInfoDto.getNewPage(l, oldPage);
	}

	public interface ChangePage2VoHelper{
		<R, T> List<T> run(long userId, List<R> l);
	}
}

package com.boe.bank.util;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
/**
* @Description:Ipage转化PageInfo
* @author: zhaohaixia
* @date: 2020年9月28日 上午10:37:28
 */
public class PageResultAnalyzer {
	
	@SuppressWarnings("unchecked")
	public static <T> PageInfo<T> getPageData(IPage<?> result, Class<T> clazz) throws Exception {
		 	if(result !=null && !CollectionUtils.isEmpty(result.getRecords())) {
		 		Long total = result.getTotal();//总条数
		 		Integer pageNum = (int) result.getCurrent();//当前页
		 		Integer pageSize = (int) result.getSize();//每页显示条数
		 		List<T> list = (List<T>) result.getRecords();//列表
		 		PageInfo<T> pageInfo = new PageInfo<>(list);
		 		pageInfo.setTotal(total);
		 		pageInfo.setPageSize(pageSize);
		 		pageInfo.setPageNum(pageNum);
		 		return pageInfo;
		 	}
	        return new PageInfo<>(Lists.newArrayList());
	 }


}

package com.boe.bank.service.labelService;

import com.boe.bank.beanconverter.LabelCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.labelBean.LabelBean;
import com.boe.bank.common.bean.labelBean.LabelInfoBean;
import com.boe.bank.common.bean.labelBean.LabelSearchBean;
import com.boe.bank.common.constant.Const;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.label.Label;
import com.boe.bank.mapper.labelMapper.LabelMapper;
import com.boe.bank.mapper.material.MaterialManageMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * TODO
 * 标签管理serviceImpl
 *
 * @author lijianglong
 * @data 2020/10/13
 */

@Service
@Slf4j
public class LabelService {

    @Autowired
    private LabelMapper labelMapper;
    @Autowired
    private LabelCoverter labelCoverter;
    @Autowired
    private MaterialManageMapper materialManageMapper;

    public PageInfo<LabelBean> getLabelList(LabelSearchBean labelSearchBean) {
        log.info("标签管理查询条件:{}", labelSearchBean);
        if (labelSearchBean.getPageNum() == null || labelSearchBean.getPageNum() < 1) {
            labelSearchBean.setPageNum(Const.PAGE_NUM_DEFAULT);
        }
        if (labelSearchBean.getPageSize() == null || labelSearchBean.getPageSize() < 0) {
            labelSearchBean.setPageSize(Const.PAGE_SIZE_DEFAULT);
        }
        Page page = PageHelper.startPage(labelSearchBean.getPageNum(), labelSearchBean.getPageSize(), true);
        List<LabelBean> labelBeans = labelCoverter.getLabelBean(labelMapper.getLabelList(labelSearchBean));
        log.info("标签管理返回值:{}", labelBeans.size());
        PageInfo<LabelBean> pageInfo = new PageInfo<LabelBean>(labelBeans, page);
        return pageInfo;
    }

    @Transactional
    public int addLabel(LabelInfoBean labelInfoBean) {
        log.info("add label:{}", labelInfoBean);
        if (StringUtils.isAllBlank(labelInfoBean.getTitle())) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE);
        }
        //根据title做判断
        if (labelMapper.queryLabel(labelInfoBean) > 0) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_HAS);
        }
        Label label1 = labelCoverter.getLabelInfoBean(labelInfoBean);
        label1.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());
        label1.setCreateTime(LocalDateTime.now());
        log.info("add label:{}", label1);
        return labelMapper.addLabel(label1);
    }

    @Transactional
    public int updateLabel(LabelInfoBean labelInfoBean) {

        log.info("update label:{}", labelInfoBean);
        Integer nums = materialManageMapper.selectByLabelId(labelInfoBean.getId().toString());
        if (nums > 0) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_UPDATE);
        }
        if (StringUtils.isAllBlank(labelInfoBean.getTitle())) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE);
        }
        //根据title做判断
        if (labelMapper.queryLabel(labelInfoBean) > 0) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_HAS);
        }
        Label label1 = labelCoverter.getLabelInfoBean(labelInfoBean);
        label1.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());
        label1.setUpdateTime(LocalDateTime.now());
        log.info("update label:{}", label1);
        return labelMapper.updateLabel(label1);
    }

    @Transactional
    public int deleteLabel(String ids) {
        log.info("delete label:{}", ids);
        if (ids == null || ids.equals("")) {
            throw new BusinessException(MsgReturnEnum.LABEL_TITLE_ID);
        }
        String[] id = ids.split(",");
        for (String labelId : id) {
            Integer nums = materialManageMapper.selectByLabelId(labelId);
            if (nums > 0) {
                throw new BusinessException(MsgReturnEnum.LABEL_TITLE_DETEDE.code(), MsgReturnEnum.LABEL_TITLE_DETEDE.message() + " id:" + labelId);
            }
        }
        log.info("delete label:{}", id);
        return labelMapper.deleteLabelById(id);
    }
}

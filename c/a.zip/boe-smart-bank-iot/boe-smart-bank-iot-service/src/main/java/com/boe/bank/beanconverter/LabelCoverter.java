package com.boe.bank.beanconverter;

import com.boe.bank.common.bean.labelBean.LabelBaseBean;
import com.boe.bank.common.bean.labelBean.LabelBean;
import com.boe.bank.common.bean.labelBean.LabelInfoBean;
import com.boe.bank.common.entity.label.Label;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * TODO
 * 标签管理coverter
 * @author lijianglong
 * @data 2020/10/13
 */

@Mapper(componentModel = "spring")
public interface LabelCoverter {

    Label getLabel(LabelBean labelBean);

    Label getLabelInfoBean(LabelInfoBean labelInfoBean);

    @Mappings({
            @Mapping(target = "createTime", expression = "java(com.boe.bank.common.utils.DateUtil.localTimeParse(label.getCreateTime()))")
    })
    LabelBean getLabelBean(Label label);

    List<LabelBean> getLabelBean(List<Label> label);
    
    List<LabelBaseBean> getLabelBaseBean(List<Label> label);
    
}

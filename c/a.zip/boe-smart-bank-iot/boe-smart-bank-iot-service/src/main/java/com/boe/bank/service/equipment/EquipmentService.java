package com.boe.bank.service.equipment;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.bean.equipment.*;
import com.boe.bank.common.entity.equipment.Equipment;

import java.util.List;

/**
 * 设备 Service
 *
 * @author 10183279
 * @date 2020/10/13
 */
public interface EquipmentService extends IService<Equipment> {

    /**
     * 保存设备信息，同时，如果没有审批流，则将设备的状态直接改为审批通过
     * @param entity
     * @return
     */
    @Override
    boolean save(Equipment entity);


    /**
     * 更新设备
     * @param dto
     * @param id
     * @return
     */
    boolean update(EquipmentDTO dto, Integer id);



    /**
     * 分页获取设备
     * @param qo
     * @return
     */
    IPage<EquipmentVO> page(EquipmentQO qo);

    /**
     * 根据mac获取设备信息
     * @param mac
     * @return
     */
    Equipment getByMac(String mac);

    List<Equipment> getLikeName(String name);

    /**
     * 发送设备操作命令
     * @param commandDTO
     */
    void sendCommand(EquipmentCommandDTO commandDTO);

    /**
     * 设备升级
     * @param dto
     * @return
     */
    void upgradeVersion(EquipmentUpgradeDTO dto);

    /**
     * 截屏
     * @param mac
     */
    void printScreen(String mac);

    /**
     * 根据mac获取设备id
     * @param mac
     * @return
     */
    Integer getEquId(String mac);


    /**
     * 统计设备在线离线数量
     * @return
     */
    List<EquipmentCount> countByIsOnline();
}

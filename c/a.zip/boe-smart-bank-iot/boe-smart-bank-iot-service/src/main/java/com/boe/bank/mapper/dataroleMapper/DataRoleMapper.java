package com.boe.bank.mapper.dataroleMapper;

import com.boe.bank.common.bean.datarolebean.DataRoleOrgBean;
import com.boe.bank.common.bean.datarolebean.UserAndData;
import com.boe.bank.common.entity.datarolebean.DataRole;
import com.boe.cloud.megarock.security.common.Role;
import com.boe.cloud.megarock.user.javabean.entity.OrganizationDO;
import com.boe.cloud.megarock.user.javabean.vo.OrganizationVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description:数据权限
 * @author: lvjiacheng
 * @date: 2020年10月16日 9:17
 */
@Mapper
public interface DataRoleMapper  {



    int insertDataRole(@Param("roleId") Integer roleId ,@Param ("list") List<DataRole> list);

    List<DataRole> getDataRoleByRoleId(Integer id);

    int deleteDataRoleByRoleId(Integer roleId);

    List<DataRoleOrgBean> getDataRoleByRoleList(List<Role> list);

    //List<DataRoleOrgBean> getOrgNameListByOrgId(List<DataRole> list);

    List<Integer> getDataRoleList(List<Role> list);

    List<Integer> getDataRoleParentIdByOrgIds(@Param("orgIds") List<Integer> orgIds);

    List<UserAndData> getUserByOrgId(@Param("orgId") Long orgId);
}

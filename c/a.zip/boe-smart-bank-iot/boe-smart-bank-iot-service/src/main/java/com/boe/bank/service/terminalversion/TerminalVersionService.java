package com.boe.bank.service.terminalversion;

import com.baomidou.mybatisplus.extension.service.IService;
import com.boe.bank.common.entity.terminalversion.TerminalVersion;

/**
 * 客户端版本 Service
 *
 * @author 10183279
 * @date 2020/10/29
 */
public interface TerminalVersionService extends IService<TerminalVersion> {

}

package com.boe.bank.service.terminalversion.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.boe.bank.common.entity.terminalversion.TerminalVersion;
import com.boe.bank.mapper.terminalversion.TerminalVersionMapper;
import com.boe.bank.service.terminalversion.TerminalVersionService;
import org.springframework.stereotype.Service;

/**
 * 客户端版本 ServiceImpl
 *
 * @author 10183279
 * @date 2020/10/29
 */
@Service("terminalVersionService")
public class TerminalVersionServiceImpl extends ServiceImpl<TerminalVersionMapper, TerminalVersion> implements TerminalVersionService {

}

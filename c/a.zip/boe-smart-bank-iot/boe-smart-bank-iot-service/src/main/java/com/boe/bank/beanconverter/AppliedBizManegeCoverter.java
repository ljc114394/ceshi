package com.boe.bank.beanconverter;


import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeInfoBean;
import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeListBean;
import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeSaveBean;
import com.boe.bank.common.entity.appliedbizmanege.AppliedBizManege;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AppliedBizManegeCoverter {

    @Mappings({
            @Mapping(source = "createTime", target = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "updateTime", target = "updateTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "bizComponents", ignore = true),
            @Mapping(target = "bizFieldList", ignore = true)
    })
    AppliedBizManegeInfoBean model2InforVO(AppliedBizManege pojo);


    @Mappings({
            @Mapping(source = "createTime", target = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "updateTime", target = "updateTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    AppliedBizManegeListBean model2ListVO(AppliedBizManege pojo);

    List<AppliedBizManegeListBean> model2List(List<AppliedBizManege> result);

    @Mappings({
            @Mapping(target = "bizComponents", ignore = true),
            @Mapping(target = "bizFields", ignore = true)
    })
    AppliedBizManege DTO2Mode(AppliedBizManegeSaveBean dto);




}

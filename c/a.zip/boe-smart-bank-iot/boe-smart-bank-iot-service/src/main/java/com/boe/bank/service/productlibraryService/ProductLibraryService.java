package com.boe.bank.service.productlibraryService;

import com.alibaba.excel.EasyExcel;
import com.boe.bank.beanconverter.ProductLibraryCoverter;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.bean.productlibrarybean.*;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.productlibrary.ProductLibrary;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.common.utils.ObjectUtil;
import com.boe.bank.mapper.productlibraryMapper.ProductLibraryMapper;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/21
 */
@Service
@Slf4j
public class ProductLibraryService {

    @Resource
    private ProductLibraryMapper productLibraryMapper;

    @Resource
    private ProductLibraryCoverter productLibraryCoverter;

    @Value("${url.server:}")
    private String serverUrl;

    /**
     * 产品库-添加
     *
     * @param productLibrary
     * @return int
     */
    @Transactional
    public Integer add(ProductLibrarySaveBean productLibrary) {
        if (StringUtils.isEmpty(productLibrary.getProductName()) || productLibrary.getEnable() == null
                 || StringUtils.isEmpty(productLibrary.getProductType()) || StringUtils.isEmpty(productLibrary.getPortraitImgUrl())) {
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
        ProductLibrary productLibrarya = productLibraryCoverter.getProductLibrary(productLibrary);
        productLibrarya.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());
        productLibrarya.setCreateTime(LocalDateTime.now());
        productLibrarya.setCreateUserId(UserInfo.getCurrentUserId());
        productLibrarya.setProductNo("P"+DateUtil.formatlong2(new Date()));//产品编号
        int res = productLibraryMapper.insertProductLibrary(productLibrarya);
        log.info("产品库-添加-返回结果 res:{}", res);
        return res;
    }

    /**
     * 产品库-编辑
     *
     * @param productLibrary
     * @return int
     */
    @Transactional
    public Integer updateProductLibrary(Integer id, ProductLibrarySaveBean productLibrary) {
        if (StringUtils.isEmpty(productLibrary.getProductName()) || productLibrary.getEnable() == null
                || StringUtils.isEmpty(productLibrary.getProductType()) || StringUtils.isEmpty(productLibrary.getPortraitImgUrl())) {
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
        ProductLibrary productLibrarya = productLibraryCoverter.getProductLibrary(productLibrary);
        productLibrarya.setId(id);
        productLibrarya.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());
        productLibrarya.setUpdateTime(LocalDateTime.now());
        log.info("产品库-编辑计划-转化后bean productLibrary:{}", productLibrarya);
        return productLibraryMapper.updateProductLibrary(productLibrarya);
    }

    /**
     * 产品库-分页
     *
     * @param productLibrary
     * @return int
     */
    public PageInfo<ProductLibraryBean> getProductLibraryList(ProductLibrarySearchBean productLibrary) {
        ObjectUtil.setPageNumAndPageSizeDefault(productLibrary);
        Page page = PageHelper.startPage(productLibrary.getPageNum(), productLibrary.getPageSize());
        List<ProductLibrary> productLibraryList = productLibraryMapper.getProductLibraryList(productLibrary);
        List<ProductLibraryBean> productLibraryBeanList = productLibraryCoverter.getProductLibraryList(productLibraryList);
        PageInfo<ProductLibraryBean> pageInfo = new PageInfo<ProductLibraryBean>(productLibraryBeanList, page);
        log.info("产品库-分页list pageNum:{},pageSize:{}size:{}", productLibrary.getPageNum(), productLibrary.getPageSize(), productLibraryBeanList.size());
        return pageInfo;
    }

    /**
     * 产品库-删除
     *
     * @param id
     * @return int
     */
    @Transactional
    public Integer updateProductLibraryDel(String[] id) {

        int res = productLibraryMapper.updateProductLibraryDel(id);
        if(res>0){
           int count = productLibraryMapper.findMarketingPortraitCountByProudctId(id);//判断产品画像中间表是否存在该产品id
            if(count>0){
              return  productLibraryMapper.marketingPortraitDelete(id);
            }
        }
        return res;
    }

    /**
     * 产品库-根据id获取产品库信息
     *
     * @param id
     * @return
     */
    public ProductLibraryBean getProductLibraryById(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        ProductLibrary productLibrary = productLibraryMapper.getProductLibraryById(id);
        if (productLibrary == null) {
            return ProductLibraryBean.builder().build();
        }
        ProductLibraryBean productLibraryBean = productLibraryCoverter.getProductLibraryBean(productLibrary);
        log.info("产品库-根据id获取详细信息 productLibraryBean:{}", productLibraryBean);
        return productLibraryBean;
    }

    /**
     * 产品库-导出
     * @param response
     * @param productLibrary
     * @return
     */
    public void productLibraryExportExport(HttpServletResponse response,ProductLibrarySearchExportBean productLibrary) throws IOException {
        //ObjectUtil.setPageNumAndPageSizeDefault(productLibrary);
//        if(productLibrary.getEnable()==2){//查询全部
//            productLibrary.setEnable(null);
//        }
        //PageHelper.startPage(productLibrary.getPageNum(), productLibrary.getPageSize());
        List<ProductLibrary> productLibraryList = productLibraryMapper.getProductLibraryExportList(productLibrary);
        List<ProductLibraryExportBean> productLibraryBeanList = productLibraryCoverter.getProductLibraryExportList(productLibraryList);
        productLibraryBeanList.stream().map(item ->{
            try {
                item.setUrl(new URL(serverUrl.substring(0,serverUrl.length()-1)+item.getPortraitImgUrl()));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            return  item;
        }).collect(Collectors.toList());
        //导出
        String name = "product_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), ProductLibraryExportBean.class).sheet("excel").doWrite(productLibraryBeanList);
    }

    /**
     * 营销策略-分页
     *
     * @param marketingStrategy
     * @return int
     */
    public PageInfo<MarketingStrategyBean> getMarketingStrategyList(ProductLibrarySearchBean marketingStrategy) {
        ObjectUtil.setPageNumAndPageSizeDefault(marketingStrategy);
        Page page = PageHelper.startPage(marketingStrategy.getPageNum(), marketingStrategy.getPageSize(), true);
        List<ProductLibrary> productLibraryList = productLibraryMapper.getMarketingStrategyList(marketingStrategy);
        List<MarketingStrategyBean> marketingStrategyBeannList = productLibraryCoverter.getMarketingStrategyList(productLibraryList);
        PageInfo<MarketingStrategyBean> pageInfo = new PageInfo<MarketingStrategyBean>(marketingStrategyBeannList, page);
        log.info("营销策略-分页list pageNum:{},pageSize:{}size:{}", marketingStrategy.getPageNum(), marketingStrategy.getPageSize(), marketingStrategyBeannList.size());
        return pageInfo;
    }


    /**
     * 营销策略-根据id获取营销策略
     *
     * @param id
     * @return Map
     */
    public MarketingStrategyOneBean getMarketingStrategyById(Integer id) {
        if (id == null || id <= 0) {
            throw new BusinessException(MsgReturnEnum.ID_NOFAND);
        }
        //根据id获取策略营销信息
        ProductLibrary productLibrary = productLibraryMapper.getProductLibraryById(id);
        MarketingStrategyOneBean marketingStrategy = productLibraryCoverter.getMarketingStrategyOneBean(productLibrary);
        //根据id获取图像list
        List<MarketingPortraitBean> plist =  productLibraryMapper.getMarketingPortraitBeanById(id);
        marketingStrategy.setPortraitList(plist);
        return marketingStrategy;
    }

    /**
     * 营销策略-编辑
     *
     * @param id
     * @param marketingStrategy
     * @return Integer
     */
    @Transactional
    public Integer updateMarketingStrategy(Integer id, MarketingStrategyEditBean marketingStrategy) {
        if ( marketingStrategy.getProductTactics() == null ||  marketingStrategy.getProductTactics()<0 ) {
            throw new BusinessException(MsgReturnEnum.PARAMETER_EMPTY);
        }
        String createBy = UserInfo.getCurrentUserInfo().getUsername();
        LocalDateTime createTime = LocalDateTime.now();
        Integer createUserId = UserInfo.getCurrentUserId().intValue();
        ProductLibrary productLibrary = ProductLibrary.builder().productTactics(marketingStrategy.getProductTactics()).build();
        productLibrary.setId(id);
        productLibrary.setUpdateBy(createBy);
        productLibrary.setUpdateTime(createTime);
        int res = productLibraryMapper.updateProductLibrary(productLibrary);
        if(res<1){
            throw new BusinessException (MsgReturnEnum.UPDATE_FAILURE);
         }
         //批量删除图像中间表
         productLibraryMapper.deleteMarketingPortrait(id);
        if(!CollectionUtils.isEmpty(marketingStrategy.getPortraitIds())){
            return productLibraryMapper.insertMarketingPortrait(id,createBy,createTime,createUserId,marketingStrategy.getPortraitIds());
        }
         return res;
    }

    /**
     * 营销策略-导出
     * @param response
     * @param marketingStrategy
     * @return
     */
    public void productMarketingStrategyExport(HttpServletResponse response,ProductLibrarySearchExportBean marketingStrategy) throws IOException {
        //ObjectUtil.setPageNumAndPageSizeDefault(marketingStrategy);
//        if(marketingStrategy.getEnable()==2){//查询全部
//            marketingStrategy.setEnable(null);
//        }
        //PageHelper.startPage(marketingStrategy.getPageNum(), marketingStrategy.getPageSize(), true);
        List<ProductLibrary> productLibraryList = productLibraryMapper.getMarketingStrategyExportList(marketingStrategy);
        List<MarketingStrategyExportBean> marketingStrategyBeannList = productLibraryCoverter.getMarketingStrategyExportList(productLibraryList);
        //导出
        String name = "strategy_" + System.currentTimeMillis() + "";
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(name, "UTF-8");
        log.info("fileName:{}", fileName);
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "public");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), MarketingStrategyExportBean.class).sheet("excel").doWrite(marketingStrategyBeannList);
    }

}

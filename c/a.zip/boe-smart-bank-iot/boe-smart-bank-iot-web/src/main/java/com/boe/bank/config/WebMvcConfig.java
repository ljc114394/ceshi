package com.boe.bank.config;

import com.boe.bank.common.utils.StringUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * TODO
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/10/22 18:09
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value ("${material.path}")
    private String path;

    @Value ("${upload.upath}")
    private String upath;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/*")
                .allowedOrigins("*")
                .allowCredentials(true)
                .allowedMethods("GET", "POST", "DELETE", "PUT","PATCH")
                .maxAge(3600);

    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 需要配置1：----------- 需要告知系统，这是要被当成静态文件的！
        // 第一个方法设置访问路径前缀，第二个方法设置资源路径
//	        registry.addResourceHandler("/**").addResourceLocations("/nas/webresource");
        registry.addResourceHandler("doc.html").addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
        registry.addResourceHandler("/metPath/**").addResourceLocations(StringUtil.appendToStr ("file:",path));
        registry.addResourceHandler("/upPath/**").addResourceLocations(StringUtil.appendToStr ("file:",upath));
    }

}

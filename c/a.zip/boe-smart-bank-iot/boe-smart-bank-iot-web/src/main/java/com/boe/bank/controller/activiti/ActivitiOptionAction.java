package com.boe.bank.controller.activiti;

import com.boe.cloud.megarock.security.common.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.activiti.ActivitiOptUser;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.utils.ParamUtil;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.activitiService.log.ActivitiLogService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 审批操作
 * 提交，通过，拒绝
 * @author caoxuhao
 */
@Api(value = "ActivitiQueryAction", tags = "审批操作")
@RestController
@RequestMapping("/activitiOption")
public class ActivitiOptionAction {
	
	@Autowired
	private ActivitiOptionService activitiOptionService;
	
	@Autowired
	private ActivitiLogService activitiLogService;
	
	@ApiOperation(value = " 提交流程(仅测试用，service层给其他模块调用，前端开发不用看)")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "userId", value = "用户id", example = "1"),
			@ApiImplicitParam(name = "busniessType", value = "业务分类", example = "1"),
			@ApiImplicitParam(name = "examineId", value = "审核类型id", example = "1"),
			@ApiImplicitParam(name = "outerId", value = "外部关联表主键id", example = "1")
	})
	@GetMapping("/submit")
	public Result<?> submit(String userId, Integer busniessType, Integer examineId, Integer outerId) {
		
		// 必传参数为空
		if (userId == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}

		Result<?> result = activitiOptionService.submit(userId, busniessType, examineId, outerId, null);
		return result;
	}
	
	@ApiOperation(value = "通过")
	@PostMapping("/pass")
	public Result<?> pass(@RequestBody ActivitiOptUser acticitiOptUser) {

		if(StringUtils.isEmpty(acticitiOptUser.getReviewer()))
			acticitiOptUser.setReviewer(UserInfo.getCurrentUserId().toString());
		
		if(ParamUtil.isNullOrEmpty(acticitiOptUser.getProcessInstanceId()))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);

		String comment = acticitiOptUser.getComment();
		if(StringUtils.isEmpty(comment) || "null".equals(comment))
			acticitiOptUser.setComment("");
		
		Result<?> result = activitiOptionService.pass(acticitiOptUser);
		
		if(result.isSuccess()) {
			activitiLogService.info(acticitiOptUser.getProcessInstanceId(), true);
		}
		
		return result;
	}
	
	@ApiOperation(value = "拒绝")
	@PostMapping("/fail")
	public Result<?> fail(@RequestBody ActivitiOptUser acticitiOptUser) {

		if(StringUtils.isEmpty(acticitiOptUser.getReviewer()))
			acticitiOptUser.setReviewer(UserInfo.getCurrentUserId().toString());
		
		if(ParamUtil.isNullOrEmpty(acticitiOptUser.getProcessInstanceId()))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);

		String comment = acticitiOptUser.getComment();
		if(StringUtils.isEmpty(comment) || "null".equals(comment))
			acticitiOptUser.setComment("");

		Result<?> result = activitiOptionService.fail(acticitiOptUser);
		
		if(result.isSuccess()) {
			activitiLogService.info(acticitiOptUser.getProcessInstanceId(), false);
		}
		
		return result;
	}
	
	@ApiOperation(value = "转办")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "userId", value = "发起人id", example = "1"),
			@ApiImplicitParam(name = "taskId", value = "任务id", example = "1", required = false),
			@ApiImplicitParam(name = "processInstanceId", value = "流程实例id", example = "1", required = true),
			@ApiImplicitParam(name = "targetUserId", value = "目标人id", example = "1", required = true)
	})
	@GetMapping("/transferAssignee")
    public Result<?> transferAssignee(String taskId, String processInstanceId, String userId, String targetUserId) {

		if(StringUtils.isEmpty(userId))
			userId = UserInfo.getCurrentUserId().toString();

    	if(ParamUtil.isNullOrEmpty(processInstanceId, userId, targetUserId))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);

    	if(userId.equals(targetUserId))
			return Result.failure(MsgReturnEnum.ACTIVITI_CAN_NOT_TRANSFER_SELF);

		Result<?> result = activitiOptionService.transferAssignee(taskId, processInstanceId, userId, targetUserId);
		
		return result;
    }
	
}

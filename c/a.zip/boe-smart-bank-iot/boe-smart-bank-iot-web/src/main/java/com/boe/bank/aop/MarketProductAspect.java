package com.boe.bank.aop;

import com.boe.bank.common.constant.RedisPrefix;
import com.boe.bank.common.utils.RedissionUtils;
import com.boe.bank.service.marketLabel.MarketLabelService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description:监听产品/用户画像、标签的变动
 * @Author: lijianglong
 * @Data:2020/10/29
 */

@Aspect
@Component
@Slf4j
public class MarketProductAspect {

    @Autowired
    private MarketLabelService marketLabelService;

    @Autowired
    private RedissionUtils redissionUtils;


    @Pointcut("execution(public * com.boe.bank.service.marketLabel.MarketLabelService.addMarketLabel(..)) || " +
              "execution(public * com.boe.bank.service.marketLabel.MarketLabelService.deleteMarketLabel(..)) || " +
              "execution(public * com.boe.bank.service.marketLabel.MarketLabelService.deleteMarketLabelNature(..)) || " +
              "execution(public * com.boe.bank.service.marketLabel.MarketLabelService.editMarketLabel(..)) || " +
              "execution(public * com.boe.bank.service.userPortrait.UserPortraitService.addUserPortrait(..)) || " +
              "execution(public * com.boe.bank.service.userPortrait.UserPortraitService.editUserPortrait(..)) || " +
              "execution(public * com.boe.bank.service.userPortrait.UserPortraitService.deleteUserPortrait(..)) || " +
              "execution(public * com.boe.bank.service.productlibraryService.ProductLibraryService.updateProductLibraryDel(..)) || " +
              "execution(public * com.boe.bank.service.productlibraryService.ProductLibraryService.updateMarketingStrategy(..))"
    )
    public void marketProductAspect(){}

    @AfterReturning(returning = "ret",pointcut = "marketProductAspect()")
    public void doAfterReturning(Object ret){
        if(new Integer(ret.toString()) > 0){
            if(redissionUtils.isExist (RedisPrefix.PRODUCT_PORTRAIT_MARKET)){
                marketLabelService.deleteProductPortraitMarketRedis();
                log.info("删除缓存key:"+RedisPrefix.PRODUCT_PORTRAIT_MARKET+" 成功");
            }
        }
    }
}

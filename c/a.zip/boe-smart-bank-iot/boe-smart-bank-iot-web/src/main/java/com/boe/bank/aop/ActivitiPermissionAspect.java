package com.boe.bank.aop;

import com.boe.bank.common.base.Result;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.service.dataroleService.DataRoleService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * @Description: 审核数据权限校验
 * @Author: caoxuhao
 */
@Aspect
@Component
@Slf4j
public class ActivitiPermissionAspect {

    @Autowired
    private DataRoleService dataRoleService;


    @Pointcut("execution(public * com.boe.bank.controller.activiti.ActivitiManageAction.*(..))")
    public void activitiPermissionAspect(){}

    @Around("activitiPermissionAspect()")
    public Object aroundAction(ProceedingJoinPoint pjp) throws Throwable{

        //校验权限
        if(CollectionUtils.isEmpty(dataRoleService.getDataRoleByRoleList()))
            return Result.failure(MsgReturnEnum.DATA_ROLE_POWER);

        return pjp.proceed();
    }

}

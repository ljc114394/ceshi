package com.boe.bank.consumers;

import com.alibaba.fastjson.JSON;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.material.ActivitiSubmitBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.service.activitiService.api.ActivitiOptionService;
import com.boe.bank.service.planmanageService.PlanManageService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.boe.middleware.mq.stream.bean.MqMessage;
import com.boe.middleware.mq.stream.bean.MqMessageListener;
import com.boe.middleware.mq.stream.utils.MQListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * @Author: lvjiacheng
 * @Description:
 * @Date Created in 2020-12-14 13:37
 * @Modified By:
 */
@Slf4j
@MqMessageListener(queueName="${stream-mq.queues.queue7.name}")
public class ActivitiMqPlanListener implements MQListener<ActivitiSubmitBean> {

    @Autowired
    private ActivitiOptionService activitiOptionService;

    @Resource
    private PlanManageService PlanManageService;

    @Override
    public void onMessage(MqMessage<ActivitiSubmitBean> mqMessage) throws Exception {
        ActivitiSubmitBean value = mqMessage.getValue();
        Result<?> result = activitiOptionService.submit(value.getUserId(), value.getBusniessType(), value.getExamineId(), value.getOuterId(), value.getOuterType());
        if (!result.isSuccess()) {//提交失败
            log.info("ActivitiMqListener调用activitiOptionService失败：:" + JSON.toJSONString(value));
            if ((result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_NOT_FOUND_ERROR.code())||
                    (result.getCode().intValue()== MsgReturnEnum.ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE.code())) {//没有查到对应的审批流 就默认通过
                int ren = PlanManageService.updatePlanManageState(value.getOuterId(),ActivitiConstants.ExamineStatus.pass);
                if(ren<1){
                    log.info("更新计划审批状态失败 ren:{}",ren);
                    //throw new BusinessException(MsgReturnEnum.PLAN_STATE_FAIL);
                }
            }else{
                int ren = PlanManageService.updatePlanManageState(value.getOuterId(),-1);
                if(ren<1){
                    log.info("更新计划审批状态失败 ren:{}",ren);
                    //throw new BusinessException(MsgReturnEnum.PLAN_STATE_FAIL);
                }
            }
        }
    }
}

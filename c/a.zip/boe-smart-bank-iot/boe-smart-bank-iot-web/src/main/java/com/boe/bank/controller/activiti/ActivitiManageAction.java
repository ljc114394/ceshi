package com.boe.bank.controller.activiti;

import java.util.List;
import java.util.stream.Collectors;

import com.boe.cloud.megarock.security.common.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boe.bank.beanconverter.ActivitiExamineVoCoverter;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.activiti.ActivitiExamineQueryBean;
import com.boe.bank.common.bean.activiti.ActivitiExamineSaveBean;
import com.boe.bank.common.bean.activiti.ActivitiExamineVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessDo;
import com.boe.bank.common.bean.activiti.ActivitiProcessInsertBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessQueryBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessUpdateBean;
import com.boe.bank.common.bean.activiti.ActivitiProcessUpdateVo;
import com.boe.bank.common.bean.activiti.ActivitiProcessVo;
import com.boe.bank.common.bean.activiti.ActivitiUserTaskDto;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.activiti.ActivitiExamine;
import com.boe.bank.common.utils.ParamUtil;
import com.boe.bank.common.utils.StringUtil;
import com.boe.bank.service.activitiService.api.ActivitiManageService;
import com.boe.bank.service.activitiService.base.ActivitiExamineService;
import com.boe.bank.service.activitiService.base.ActivitiProcessService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 审批管理 1. 审批类型 crud 2. 审批流 crud
 * 
 * @author caoxuhao
 */
@Api(value = "ActivitiQueryAction", tags = "审批管理")
@RestController
@RequestMapping("/activitiManage")
public class ActivitiManageAction {

	@Autowired
	private ActivitiExamineService activitiExamineService;

	@Autowired
	private ActivitiManageService activitiManageService;

	@Autowired
	private ActivitiProcessService activitiProcessService;
	
	@Autowired
    private ActivitiExamineVoCoverter activitiExamineVoCoverter;
	
	/********************************************************************************************************************
	 * 审批流
	 ********************************************************************************************************************/

	/**
	 * 新建审批流
	 * @param activitiProcessInsertBean
	 * @return
	 */
	@ApiOperation(value = "审批流-添加")
	@PostMapping("activitiProcessInsert")
	public Result<?> activitiProcessInsert(@RequestBody ActivitiProcessInsertBean activitiProcessInsertBean) {

		List<ActivitiUserTaskDto> userTaskList = activitiProcessInsertBean.getList();
		if (CollectionUtils.isEmpty(userTaskList)) {
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_LIST_EMPTY);
		}

		Integer busniessType = activitiProcessInsertBean.getBusniessType();

		// 获取审批类型id
		Integer examineId = activitiProcessInsertBean.getExamineId();
		if (examineId == null) {
			List<ActivitiExamine> ActivitiExamineList = activitiExamineService
					.getActivitiExamineListByBusniessType(busniessType);
			if (CollectionUtils.isEmpty(ActivitiExamineList)) {
				return Result.failure(MsgReturnEnum.ACTIVITI_EXAMINE_NOT_EXIST);
			}

			examineId = ActivitiExamineList.get(0).getId();
			activitiProcessInsertBean.setExamineId(examineId);
		}

		// 必传参数为空
		if (busniessType == null || examineId == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}

		activitiProcessInsertBean.setCreateUserId(UserInfo.getCurrentUserId());
		activitiProcessInsertBean.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());

		// 创建审批流程
		return activitiManageService.insertActivitiProcess(activitiProcessInsertBean);
	}

	/**
	 * 删除审批流
	 * 
	 * @param activitiProcessId
	 * @return
	 */
	@ApiOperation(value = "审批流-删除")
	@GetMapping("activitiProcessDelete")
	public Result<?> activitiProcessDelete(Integer activitiProcessId) {

		if (activitiProcessId == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		Result<?> result = null;
		try {
			result = activitiManageService.deleteActivitiProcess(activitiProcessId);
		} catch (Exception e) {
			result = Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_UNFINISHED_ERROR);
		}

		return result;
	}
	
	/**
	 * 删除审批流（批量）
	 * @return
	 */
	@ApiOperation(value = "审批流-删除（批量）")
	@GetMapping("activitiProcessDeleteBatch")
	public Result<?> activitiProcessDelete(String activitiProcessIds) {
		
		if (StringUtils.isEmpty(activitiProcessIds)) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		List<Integer> list = StringUtil.str2IntList(activitiProcessIds, ",");
		
		Result<?> result = null;
		try {
			for (Integer activitiProcessId : list) {
				result = activitiManageService.deleteActivitiProcess(activitiProcessId);
				if(!result.isSuccess()) {
					result.setMessage("流程编码为:" + activitiProcessId + "的审批流删除失败。" + result.getMessage());
					return result;
				}
			}
		} catch (Exception e) {
			result = Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_UNFINISHED_ERROR);
		}
		
		return result;
	}

	/**
	 * 分页查询审批流
	 * 
	 * @param activitiProcessQueryBean
	 * @return
	 */
	@ApiOperation(value = "审批流-列表查询")
	@PostMapping("activitiProcessList")
	public Result<PageInfo<ActivitiProcessVo>> activitiProcessList(@RequestBody ActivitiProcessQueryBean activitiProcessQueryBean) {
		PageInfoDto<ActivitiProcessDo> pageInfoDto = activitiProcessService.getList(activitiProcessQueryBean);

		List<ActivitiProcessVo> list = pageInfoDto.getRecords().stream().map(d -> changeActivitiProcessDo2Vo(d))
				.collect(Collectors.toList());
		
		PageInfo<ActivitiProcessVo> pageInfo = new PageInfo<>(list, pageInfoDto.getPage());

		return Result.successWithData(pageInfo);
	}
	
	/**
	 * 更新审批流
	 * @param activitiProcessUpdateBean
	 * @return
	 */
	@ApiOperation(value = "审批流-编辑")
	@PostMapping("activitiProcessUpdate")
	public Result<?> activitiProcessUpdate(@RequestBody ActivitiProcessUpdateBean activitiProcessUpdateBean) {
		
		// 必传参数为空
		if (activitiProcessUpdateBean.getBusniessType() == null || activitiProcessUpdateBean.getExamineId() == null
				|| activitiProcessUpdateBean.getProcessId() == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		if (CollectionUtils.isEmpty(activitiProcessUpdateBean.getList())) {
			return Result.failure(MsgReturnEnum.ACTIVITI_PROCESS_LIST_EMPTY);
		}

		activitiProcessUpdateBean.setUpdateBy(UserInfo.getCurrentUserInfo().getUsername());

		Result<?> res = activitiManageService.updateActivitiProcess(activitiProcessUpdateBean);
		return res;
	}
	
	/**
	 * 审批流详情
	 * @param activitiProcessId
	 * @return
	 */
	@ApiOperation(value = "审批流-详情")
	@GetMapping("activitiProcessDetail")
	public Result<ActivitiProcessUpdateVo> activitiProcessDetail(Integer activitiProcessId) {
		ActivitiProcessUpdateVo vo = activitiManageService.getActivitiProcess(activitiProcessId);
		return Result.successWithData(vo);
	}
	
	/**
	 * 停用审批流
	 * @param activitiProcessId
	 * @return
	 */
	@ApiOperation(value = "审批流-停用")
	@GetMapping("activitiProcessSuspend")
	public Result<?> activitiProcessSuspend(Integer activitiProcessId) {
		Result<?> result = activitiManageService.suspendActivitiProcess(activitiProcessId);
		return result;
	}
	
	/**
	 * 启用审批流
	 * @param activitiProcessId
	 * @return
	 */
	@ApiOperation(value = "审批流-启用")
	@GetMapping("activitiProcessActive")
	public Result<?> activitiProcessActive(Integer activitiProcessId) {
		Result<?> result = activitiManageService.activeActivitiProcess(activitiProcessId);
		return result;
	}

	private static ActivitiProcessVo changeActivitiProcessDo2Vo(ActivitiProcessDo activitiProcessDo) {

		ActivitiProcessVo activitiProcessVo = new ActivitiProcessVo();
		activitiProcessVo.setBusniessType(ActivitiConstants.BusniessType.get(activitiProcessDo.getBusniessType()));
		activitiProcessVo.setCreateBy(activitiProcessDo.getCreateBy());
		activitiProcessVo.setId(activitiProcessDo.getId());
		activitiProcessVo.setName(activitiProcessDo.getName());
		activitiProcessVo.setStatus(ActivitiConstants.Status.get(activitiProcessDo.getStatus()));
		return activitiProcessVo;
	}
	
	/********************************************************************************************************************
	 * 审批类型
	 ********************************************************************************************************************/
	/**
	 * 新建审批类型
	 * @param activitiExamineSaveBean
	 * @return
	 */
	@ApiOperation(value = "审批类型-新建")
	@PostMapping("activitiExamineInsert")
	public Result<?> activitiExamineInsert(@RequestBody ActivitiExamineSaveBean activitiExamineSaveBean) {
		
		if(ParamUtil.isNullOrEmpty(activitiExamineSaveBean.getExamineType()))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);

		if(StringUtils.isEmpty(activitiExamineSaveBean.getCreateBy()))
			activitiExamineSaveBean.setCreateBy(UserInfo.getCurrentUserInfo().getUsername());

		Long userId = activitiExamineSaveBean.getCreateUserId();
		if(userId == null || userId <= 0)
			activitiExamineSaveBean.setCreateUserId(UserInfo.getCurrentUserId());

		Result<?> result = activitiManageService.insertActivitiExamine(activitiExamineSaveBean);
		return result;
	}
	
	/**
	 * 更新审批类型
	 * @param activitiExamineSaveBean
	 * @return
	 */
	@ApiOperation(value = "审批类型-更新")
	@PostMapping("activitiExamineUpdate")
	public Result<?> activitiExamineUpdate(@RequestBody ActivitiExamineSaveBean activitiExamineSaveBean) {
		
		if(ParamUtil.isNullOrEmpty(activitiExamineSaveBean.getId(), activitiExamineSaveBean.getExamineType()))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);

		Result<?> result = activitiManageService.updateActivitiExamine(activitiExamineSaveBean);
		return result;
	}
	
	/**
	 * 删除审批类型
	 * @param examineId
	 * @return
	 */
	@ApiOperation(value = "审批类型-删除")
	@GetMapping("activitiExamineDelete")
	public Result<?> activitiExamineDelete(Integer examineId) {

		if (examineId == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		Result<?> result = activitiManageService.deleteActivitiExamine(examineId);
		return result;
	}
	
	/**
	 * 删除审批类型（批量）
	 */
	@ApiOperation(value = "审批类型-删除（批量）")
	@GetMapping("activitiExamineDeleteBatch")
	public Result<?> activitiExamineDelete(String examineIds) {
		
		if (StringUtils.isEmpty(examineIds)) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		List<Integer> list = StringUtil.str2IntList(examineIds, ",");
		
		Result<?> result = null;
		for (Integer examineId : list) {
			result = activitiManageService.deleteActivitiExamine(examineId);
			if(!result.isSuccess()) {
				result.setMessage("审批类型编码为:" + examineId + "的审批类型删除失败。" + result.getMessage());
				return result;
			}
		}
		
		return result;
	}
	
	/**
	 * 停用审批类型
	 * @param examineId
	 * @return
	 */
	@ApiOperation(value = "审批类型-停用")
	@GetMapping("activitiExamineSuspend")
	public Result<?> activitiExamineSuspend(Integer examineId) {
		
		if (examineId == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		Result<?> result = activitiManageService.suspendActivitiExamine(examineId);
		return result;
	}
	
	/**
	 * 启用审批类型
	 * @param examineId
	 * @return
	 */
	@ApiOperation(value = "审批类型-启用")
	@GetMapping("activitiExamineActive")
	public Result<?> activitiExamineActive(Integer examineId) {
		
		if (examineId == null) {
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		
		Result<?> result = activitiManageService.activeActivitiExamine(examineId);
		return result;
	}
	
	@ApiOperation(value = "审批类型-列表查询")
	@PostMapping("activitiExamineList")
	public Result<PageInfo<ActivitiExamineVo>> activitiExamineList(@RequestBody ActivitiExamineQueryBean query) {
		PageInfoDto<ActivitiExamine> pageInfoDto = activitiExamineService.getList(query);
		
		List<ActivitiExamineVo> list = activitiExamineVoCoverter.getExamineVoList(pageInfoDto.getRecords());
		
		PageInfo<ActivitiExamineVo> pageInfo = new PageInfo<>(list, pageInfoDto.getPage());
		
		return Result.successWithData(pageInfo);
	}
}

package com.boe.bank.controller.activiti;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.boe.bank.common.bean.activiti.*;
import com.boe.bank.service.activitiService.manager.ActivitiOuterHelper;
import com.boe.bank.service.activitiService.manager.ActivitiSupport;
import com.boe.bank.service.activitiService.manager.ActivitiSupportManager;
import com.boe.bank.service.appliedbizmanege.AppliedBizManegeService;
import com.boe.bank.util.ActivitiUtil;
import com.boe.cloud.megarock.user.javabean.vo.UserVO;
import com.boe.cloud.megarock.user.service.UserService;
import com.google.common.collect.Sets;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boe.bank.beanconverter.EquipmentConverter;
import com.boe.bank.common.base.PageInfo;
import com.boe.bank.common.base.PageInfoDto;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.equipment.EquipmentVO;
import com.boe.bank.common.bean.material.MaterialInfoBean;
import com.boe.bank.common.bean.planmanagebean.PlanManageBean;
import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.common.utils.ParamUtil;
import com.boe.bank.service.activitiService.base.ActivitiOuterRelationService;
import com.boe.bank.service.activitiService.org.ActivitiQueryOrgService;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.bank.service.material.MaterialManageService;
import com.boe.bank.service.planmanageService.PlanManageService;
import com.boe.cloud.megarock.security.common.UserInfo;
import com.github.pagehelper.Page;
import com.google.common.collect.Lists;

/**
 * 我提交，待我审批，我审批过的 (action层拼接了其他服务的数据，service层提供纯工作流数据(最好把userName在action配置))
 * 
 * @author caoxuhao
 */
@Slf4j
@Api(value = "ActivitiQueryAction", tags = "审批列表查询")
@RestController
@RequestMapping("/activitiQuery")
public class ActivitiQueryAction {

	@Autowired
	private ActivitiQueryOrgService activitiQueryOrgService;

	@Autowired
	private EquipmentService equipmentService;

	@Autowired
	private MaterialManageService materialManageService;

	@Autowired
	private PlanManageService planManageService;

	@Autowired
	private ActivitiSupportManager activitiSupportManager;

	@Autowired
	private ActivitiOuterRelationService activitiOuterRelationService;

	@Autowired
	private AppliedBizManegeService appliedBizManegeService;

	@Autowired
	private UserService userService;

	@Value("${spring.activiti.auto-pass-user-id:-1}")
	private String autoPassUserId;

	private static Set<Integer> activitiStatusSet = Sets.newHashSet(ActivitiConstants.ActivitiStatusType.liuZhuan, ActivitiConstants.ActivitiStatusType.jieShu, ActivitiConstants.ActivitiStatusType.zuoFei);
	private static Set<Integer> processStatusEndSet = Sets.newHashSet(ActivitiConstants.ProcessStatusType.tongGuo, ActivitiConstants.ProcessStatusType.juJue,ActivitiConstants.ProcessStatusType.zhuanBan);

///////////////////////////////////////////////我提交/////////////////////////////////////////////////////////////////////////////

	@ApiOperation(value = "设备-我提交的")
	@PostMapping("/mySubmitDevice")
	public Result<PageInfo<ActivitiProcessDevVo>> mySubmitDevice(@RequestBody ActivitiProcessQueryReq req) {

		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.mySubmit(ext), ActivitiProcessDevVo.class);
	}

	@ApiOperation(value = "素材-我提交的")
	@PostMapping("/mySubmitMaterial")
	public Result<PageInfo<ActivitiProcessMaterialVo>> mySubmitMaterial(@RequestBody ActivitiProcessQueryReq req) {

		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.mySubmit(ext), ActivitiProcessMaterialVo.class);
	}

	@ApiOperation(value = "计划-我提交的")
	@PostMapping("/mySubmitPlan")
	public Result<PageInfo<ActivitiProcessPlanVo>> mySubmitPlan(@RequestBody ActivitiProcessQueryReq req) {

		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.mySubmit(ext), ActivitiProcessPlanVo.class);
	}

	@ApiOperation(value = "应用-我提交的")
	@PostMapping("/mySubmitApplication")
	public Result<PageInfo<ActivitiProcessApplicationVo>> mySubmitApplication(@RequestBody ActivitiProcessQueryReq req) {

		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.mySubmit(ext), ActivitiProcessApplicationVo.class);
	}

///////////////////////////////////////////////已处理/////////////////////////////////////////////////////////////////////////////
	@ApiOperation(value = "设备-已处理")
	@PostMapping("/myExaminedDevice")
	public Result<PageInfo<ActivitiProcessDevVo>> myExaminedDevice(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转, 结束, 作废
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能通过，拒绝， 转办
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && !processStatusEndSet.contains(processStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myExamined(ext), ActivitiProcessDevVo.class);
	}

	@ApiOperation(value = "计划-已处理")
	@PostMapping("/myExaminedPlan")
	public Result<PageInfo<ActivitiProcessPlanVo>> myExaminedPlan(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转, 结束, 作废
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能通过，拒绝， 转办
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && !processStatusEndSet.contains(processStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myExamined(ext), ActivitiProcessPlanVo.class);
	}

	@ApiOperation(value = "素材-已处理")
	@PostMapping("/myExaminedMaterial")
	public Result<PageInfo<ActivitiProcessMaterialVo>> myExaminedMaterial(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转, 结束, 作废
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能通过，拒绝， 转办
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && !processStatusEndSet.contains(processStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myExamined(ext), ActivitiProcessMaterialVo.class);
	}

	@ApiOperation(value = "应用-已处理")
	@PostMapping("/myExaminedApplication")
	public Result<PageInfo<ActivitiProcessApplicationVo>> myExaminedApplication(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转, 结束, 作废
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && !activitiStatusSet.contains(activitiStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能通过，拒绝， 转办
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && !processStatusEndSet.contains(processStatus))
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myExamined(ext), ActivitiProcessApplicationVo.class);
	}

//////////////////////////////////////////////////待处理//////////////////////////////////////////////////////////////////////////

	@ApiOperation(value = "设备-待处理")
	@PostMapping("/myToDoDevice")
	public Result<PageInfo<ActivitiProcessDevVo>> myToDoDevice(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && activitiStatus != ActivitiConstants.ActivitiStatusType.liuZhuan)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能未处理
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && processStatus != ActivitiConstants.ProcessStatusType.daiChuLi)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myToDo(ext), ActivitiProcessDevVo.class);
	}

	@ApiOperation(value = "计划-待处理")
	@PostMapping("/myToDoPlan")
	public Result<PageInfo<ActivitiProcessPlanVo>> myToDoPlan(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && activitiStatus != ActivitiConstants.ActivitiStatusType.liuZhuan)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能未处理
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && processStatus != ActivitiConstants.ProcessStatusType.daiChuLi)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myToDo(ext), ActivitiProcessPlanVo.class);
	}

	@ApiOperation(value = "素材-待处理")
	@PostMapping("/myToDoMaterial")
	public Result<PageInfo<ActivitiProcessMaterialVo>> myToDoMaterial(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && activitiStatus != ActivitiConstants.ActivitiStatusType.liuZhuan)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能未处理
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && processStatus != ActivitiConstants.ProcessStatusType.daiChuLi)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myToDo(ext), ActivitiProcessMaterialVo.class);
	}

	@ApiOperation(value = "应用-待处理")
	@PostMapping("/myToDoApplication")
	public Result<PageInfo<ActivitiProcessApplicationVo>> myToDoApplication(@RequestBody ActivitiProcessQueryReq req) {

		//只能流转
		Integer activitiStatus = req.getActivitiStatus();
		if(activitiStatus != null && activitiStatus != ActivitiConstants.ActivitiStatusType.liuZhuan)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		//只能未处理
		Integer processStatus = req.getProcessStatus();
		if(processStatus != null && processStatus != ActivitiConstants.ProcessStatusType.daiChuLi)
			return Result.failure(MsgReturnEnum.PARAMETER_TYPE_ERROR);

		return getResult(req, ext -> activitiQueryOrgService.myToDo(ext), ActivitiProcessApplicationVo.class);
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@ApiOperation(value = "审批的流程详情")
	@ApiImplicitParams(
			{@ApiImplicitParam(name = "processInstanceId", value = "审批流程实例id", example = "1")}
    )
	@GetMapping("/detail")
	public Result<List<ActivitiDetailVo>> detail(String processInstanceId) {
		if (processInstanceId == null)
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);

		List<ActivitiDetailVo> res = activitiQueryOrgService.detail(processInstanceId);
		res.stream().map(t -> {
			String opter = t.getOpter();
			if(!StringUtils.isEmpty(opter)){
				if(autoPassUserId.equals(opter)){
					t.setOpter("自动审核");
				}else {
					UserVO userVO = userService.get(Long.valueOf(opter));
					if(userVO != null)
						t.setOpter(userVO.getName());
				}
			}
			return t;
		}).collect(Collectors.toList());

		return Result.successWithData(res);
	}

	@ApiOperation(value = "首页-审批统计")
	@ApiImplicitParams(
			{@ApiImplicitParam(name = "userId", value = "用户id", example = "1")}
    )
	@GetMapping("/statistics")
	public Result<ActivitiStatisticsVo> statistics(Long userId) {
		
		if(userId == null)
			userId = UserInfo.getCurrentUserId();
		
		if (userId == null)
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		
		ActivitiStatisticsVo res = new ActivitiStatisticsVo();
		res.setAllExaminedCount(activitiOuterRelationService.getExaminedCount(null, userId));
		res.setAllToDoCount(activitiOuterRelationService.getTodoCount(null, userId));

		return Result.successWithData(res);
	}

	@ApiOperation(value = "是否有未完成的审批流",
			notes = "返回有未完成审批流用户id和姓名列表。如果返回列表为空，说明所有用户都可以删除/停用。")
	@PostMapping("/hasUnfinishedActiviti")
	public Result<List<ActivitiUserVo>> hasUnfinishedActiviti(@RequestBody  List<ActivitiUserVo> userIds) {

		List<ActivitiUserVo> list = Lists.newArrayList();

		if(CollectionUtils.isEmpty(userIds))
			return Result.successWithData(list);

		Map<Long, ActivitiUserVo> map = userIds.stream().collect(Collectors.toMap(ActivitiUserVo::getId, t -> t));

		for (Long userId: map.keySet()) {
			if(activitiOuterRelationService.getTodoCount(null, userId) > 0){
				list.add(map.get(userId));
			}
		}

		return Result.successWithData(list);
	}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	private <T extends ActivitiProcessOrgVo> Result<PageInfo<T>> getResult(ActivitiProcessQueryReq req,
			Function<ActivitiProcessQueryReqExtBo, PageInfoDto<ActivitiProcessOrgVo>> f, Class<T> clz) {

		if(req.getUserId() == null)
			req.setUserId(UserInfo.getCurrentUserId());

		if (ParamUtil.isNullOrEmpty(req.getUserId()))
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		
		int busniessType = -1;
		List<Integer> outerIds = Lists.newArrayList();
		List<Integer> outerTypes = null;
		String key = req.getKey();
		
		if (clz == ActivitiProcessDevVo.class) {
			busniessType = ActivitiConstants.BusniessType.device;
			if(!StringUtils.isEmpty(key)){
				//按名字查ids
				List<Equipment> list = equipmentService.getLikeName(key);
				if(!CollectionUtils.isEmpty(list)){
					outerIds = list.stream().map(Equipment::getId).collect(Collectors.toList());
				}else{
					//模糊搜不到，直接返回
					return Result.successWithData(new PageInfo<>(new ArrayList<>(), new Page()));
				}
			}
		} else if (clz == ActivitiProcessMaterialVo.class) {
			busniessType = ActivitiConstants.BusniessType.material;

			if(!StringUtils.isEmpty(key)){
				//按名字查ids
				outerIds = materialManageService.getLikeName(key);
				//模糊搜不到，直接返回
				if(outerIds.size() == 0)
					return Result.successWithData(new PageInfo<>(new ArrayList<>(), new Page()));
			}

		} else if (clz == ActivitiProcessPlanVo.class) {
			busniessType = ActivitiConstants.BusniessType.plan;

			if(!StringUtils.isEmpty(key)){
				//按名字查ids
				outerIds = planManageService.getLikeName(key);
				//模糊搜不到，直接返回
				if(outerIds.size() == 0)
					return Result.successWithData(new PageInfo<>(new ArrayList<>(), new Page()));
			}
		}else if(clz == ActivitiProcessApplicationVo.class){
			busniessType = ActivitiConstants.BusniessType.application;
			//没有搜索
			if(!StringUtils.isEmpty(key)){
				//按名字查ids
				outerTypes = appliedBizManegeService.getLikeName(key);
				//模糊搜不到，直接返回
				if(outerTypes.size() == 0)
					return Result.successWithData(new PageInfo<>(new ArrayList<>(), new Page()));
			}
		}

		ActivitiProcessQueryReqExtBo ext = changeActivitiProcessQueryReq2Ext(req,
				busniessType, outerIds, outerTypes);
		return fildOuterData(f.apply(ext), clz, busniessType);
	}

	private <T extends ActivitiProcessOrgVo> Result<PageInfo<T>> fildOuterData(PageInfoDto<ActivitiProcessOrgVo> pageInfo,
																			   Class<T> clz, int busniessType) {

		List<T> addFinalVo = Lists.newArrayList();

		//获取support
		ActivitiSupport activitiSupport = activitiSupportManager.getActivitiSupport(busniessType);
		if(activitiSupport == null){
			log.error("返回审核数据列表失败,没有获取到support。busniessType:" + busniessType);
			PageInfo<T> page = new PageInfo<T>(addFinalVo, pageInfo.getPage());
			return Result.successWithData(page);
		}

		//添加外部数据
		addFinalVo = addFinalVo(pageInfo.getRecords(), clz,
				(outerId, t, outerType) -> activitiSupport.addOuterData(outerId, t, outerType)
		);

		PageInfo<T> page = new PageInfo<T>(addFinalVo, pageInfo.getPage());
		return Result.successWithData(page);
	}

	private <T extends ActivitiProcessOrgVo> List<T> addFinalVo(List<ActivitiProcessOrgVo> res,
			Class<T> clz, ActivitiOuterHelper activitiOuterHelper) {
		List<T> list = new ArrayList<>();
		for (ActivitiProcessOrgVo activitiProcessOrgVo : res) {
			// 审核
			T vo;
			try {
				vo = clz.newInstance();
			} catch (Exception e) {
				continue;
			}

			BeanUtils.copyProperties(activitiProcessOrgVo, vo);

			Integer outerId = activitiProcessOrgVo.getOuterId();
			Integer outerType = activitiProcessOrgVo.getOuterType();

			// 外部数据添加失败
			if (!activitiOuterHelper.addOuterData(outerId, vo, outerType)) {
				continue;
			}

			list.add(vo);
		}

		return list;
	}

	private static ActivitiProcessQueryReqExtBo changeActivitiProcessQueryReq2Ext(ActivitiProcessQueryReq req,
			int busniessType, List<Integer> outerIds, List<Integer> outerTypes) {
		ActivitiProcessQueryReqExtBo ext = new ActivitiProcessQueryReqExtBo();
		ext.setBusniessType(busniessType);
		BeanUtils.copyProperties(req, ext);
		ext.setOuterIds(outerIds);
		ext.setOuterTypes(outerTypes);

		return ext;
	}
}

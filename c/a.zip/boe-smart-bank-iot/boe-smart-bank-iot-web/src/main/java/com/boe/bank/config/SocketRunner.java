package com.boe.bank.config;

import com.alibaba.fastjson.JSON;
import com.boe.bank.netty.NettyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.net.InetSocketAddress;

/**
 * 启动Socket
 *
 * @author 10183279
 * @date 2020/10/21
 */
@Component
@Slf4j
public class SocketRunner implements CommandLineRunner {

    @Autowired
    private SocketProperties socketProperties;
    @Autowired
    private NettyService nettyService;

    @Override
    public void run(String... args) throws Exception {
        InetSocketAddress socketAddress = new InetSocketAddress(socketProperties.getPort());
        log.info("Netty服务器启动地址：" + JSON.toJSONString(socketAddress));
        nettyService.start(socketAddress);
    }
}

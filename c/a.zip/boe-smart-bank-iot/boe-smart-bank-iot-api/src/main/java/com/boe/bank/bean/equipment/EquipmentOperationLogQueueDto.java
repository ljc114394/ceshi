package com.boe.bank.bean.equipment;

import java.util.List;

import lombok.Data;

@Data
public class EquipmentOperationLogQueueDto {
	private String mac;
	private String logUrl;
	private List<EquipmentOperationLogDto> equipmentOperationLogDtos;
}

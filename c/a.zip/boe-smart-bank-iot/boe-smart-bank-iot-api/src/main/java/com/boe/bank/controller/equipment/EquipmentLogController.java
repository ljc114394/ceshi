package com.boe.bank.controller.equipment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.boe.bank.bean.equipment.EquipmentLogDto;
import com.boe.bank.bean.equipment.EquipmentLogQueueDto;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.constant.MaterialDir;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.controller.BaseController;
import com.boe.bank.util.FileUploadUtil;
import com.boe.middleware.mq.stream.utils.StreamMQTemplate;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import jodd.util.StringUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * 设备日志 Controller
 *
 * @author 10085188
 * @date 2020/11/05
 */
@Api(tags = "设备日志管理")
@RequestMapping("/equipment/log/")
@RestController
@Slf4j
public class EquipmentLogController extends BaseController {
	@Autowired
	private Environment env;
	
	@Autowired
    private StreamMQTemplate streamMQTemplate;
	
	@Value("${stream-mq.queues.queue3.name}")
    private String equipmentLogQueue;
	
	@ApiOperation(value = "保存设备日志")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "MAC", value = "header里面设置MAC地址", example = "08:00:20:0A:8C:6D", paramType = "header"),
    	@ApiImplicitParam(name = "jsonString", dataType = "String", value = "json字符串")
	})
    @PostMapping("/saveEquipmentLogWithJsonString")
    public Result<?> saveEquipmentLogWithJsonString(@RequestBody String jsonString) {
		String mac = super.getMac();
		if (StringUtils.isEmpty(mac)) {
    		log.info("mac为空");
    		return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
    	}
		if (StringUtils.isEmpty(jsonString)) {
			log.info("json字符串为空");
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}

    	String logUrl = saveLocalFile(jsonString);
    	if (StringUtils.isEmpty(logUrl)) {
			log.info("上传设备日志失败");
			return Result.failure(MsgReturnEnum.FILE_EXCEP);
		}
    	
		List<EquipmentLogDto> equipmentLogDtos = JSONArray.parseArray(jsonString, EquipmentLogDto.class);
		if (!CollectionUtils.isEmpty(equipmentLogDtos)) {
			EquipmentLogQueueDto queueDto = new EquipmentLogQueueDto();
			queueDto.setEquipmentLogDtos(equipmentLogDtos);
			queueDto.setMac(mac);
			queueDto.setLogUrl(logUrl);
			streamMQTemplate.sendAsync(equipmentLogQueue, queueDto, (success)->{
				if(!success)
					log.error("添加equipmentLogQueue队列失败");
			});
			return Result.success();
		}
    	
    	return Result.failure();
    }
	
	private String saveLocalFile(String jsonString) {
		if (StringUtil.isEmpty(jsonString)) {
			log.info("jsonString为空");
			return null;
		}
		//文件路径
		String uuid = UUID.randomUUID().toString();
		String rootPath = env.getProperty("upload.upath");
		String mPath = MaterialDir.TEXT;
		String fileName = uuid + ".txt";
		String path =  rootPath + mPath + "/" + fileName;
		//判断文件是否存在
		File file = new File(path);
        if (file.exists()) {
            log.info("文件[{}]已存在", path);
        } else {
            try {
            	// 检测是否存在目录
            	if (!file.getParentFile().exists()) {
            		file.getParentFile().mkdirs();
            	}
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
            log.info("文件[{}]创建成功", path);
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(jsonString.getBytes());
            fileOutputStream.close();
            log.info("json数据保存到文件[{}]成功", path);
        } catch (Exception e) {
        	log.info("json数据保存到文件[{}]失败", path);
            e.printStackTrace();
            return null;
        }
        return fileName;
	}
	
	@ApiOperation(value = "保存设备日志")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "MAC", value = "header里面设置MAC地址", example = "08:00:20:0A:8C:6D", paramType = "header"),
		@ApiImplicitParam(name = "mfile", dataType = "MultipartFile", value = "json文件，txt格式")
	})
	@PostMapping("/saveEquipmentLogWithJsonFile")
	public Result<?> saveEquipmentLogWithJsonFile(@RequestParam MultipartFile mfile) {
		String mac = super.getMac();
		if (StringUtils.isEmpty(mac)) {
			log.info("mac为空");
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		if (mfile == null || mfile.isEmpty()) {
			log.info("json文件为空");
			return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
		}
		String originFileName = mfile.getOriginalFilename();
		if (!originFileName.endsWith("txt")) {
			log.info("json文件不是txt格式");
			return Result.failure(MsgReturnEnum.MATERIAL_FILE_TXT);
		}
		String rootPath = env.getProperty("upload.upath");
		String logUrl = FileUploadUtil.uploadMultipartFile(mfile, 2, rootPath);
		if (StringUtils.isEmpty(logUrl)) {
			log.info("上传设备日志失败");
			return Result.failure(MsgReturnEnum.FILE_EXCEP);
		}
		
		List<EquipmentLogDto> equipmentLogDtos = FileUploadUtil.readJsonTxt2ObjectList(mfile, EquipmentLogDto.class);
		if (!CollectionUtils.isEmpty(equipmentLogDtos)) {
			EquipmentLogQueueDto queueDto = new EquipmentLogQueueDto();
			queueDto.setEquipmentLogDtos(equipmentLogDtos);
			queueDto.setMac(mac);
			queueDto.setLogUrl(logUrl);
			streamMQTemplate.sendAsync(equipmentLogQueue, queueDto, (success)->{
				if(!success)
					log.error("添加equipmentLogQueue队列失败");
			});
			return Result.success();
		}
		
		return Result.failure();
	}
	
}

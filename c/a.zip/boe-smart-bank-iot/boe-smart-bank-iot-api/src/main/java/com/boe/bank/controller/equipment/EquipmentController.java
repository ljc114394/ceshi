package com.boe.bank.controller.equipment;

import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.equipment.EquipmentInitConfigVO;
import com.boe.bank.common.bean.equipment.ProgramConfigVO;
import com.boe.bank.common.bean.equipment.SocketVO;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.config.SocketProperties;
import com.boe.bank.controller.BaseController;
import com.boe.bank.service.equipment.EquipmentConfigService;
import com.boe.bank.service.equipment.EquipmentPlanService;
import com.boe.bank.service.equipment.EquipmentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 设备Api接口
 *
 * @author 10183279
 * @date 2020/10/23
 */
@Api(tags = {"设备Api接口"})
@RequestMapping(value = "/equipment")
@RestController
public class EquipmentController extends BaseController {

    @Value(value = "${file.url.prefix}")
    private String fileUrlPrefix;

    @Autowired
    private SocketProperties socketProperties;
    @Autowired
    private EquipmentService equipmentService;
    @Autowired
    private EquipmentConfigService equipmentConfigService;
    @Autowired
    private EquipmentPlanService equipmentPlanService;

    @ApiOperation(value = "获取设备初始化信息接口")
    @ApiImplicitParam(name = "MAC", paramType = "header")
    @GetMapping(value = "/init")
    public Result<EquipmentInitConfigVO> getInit() {
        String mac = super.getMac();
        if (StringUtils.isBlank(mac)) {
            return Result.failure();
        }
        Equipment equ = equipmentService.getByMac(mac);
        if (equ == null) {
            return Result.failure("设备不存在");
        }
        EquipmentInitConfigVO configVO = equipmentConfigService.getInitInfo(mac);
        SocketVO socketVO = new SocketVO();
        socketVO.setHost(socketProperties.getHostname());
        socketVO.setPort(socketProperties.getPort());
        configVO.setSocketServer(socketVO);
        return Result.successWithData(configVO);
    }

    @ApiOperation(value = "获取设备播放节目信息接口")
    @ApiImplicitParam(name = "MAC", paramType = "header")
    @GetMapping(value = "/program")
    public Result<List<ProgramConfigVO>> getProgram() {
        String mac = super.getMac();
        if (StringUtils.isBlank(mac)) {
            return Result.failure();
        }
        Equipment equ = equipmentService.getByMac(mac);
        if (equ == null) {
            return Result.failure("设备不存在");
        }
        return Result.successWithData(equipmentPlanService.getProgram(mac, fileUrlPrefix));
    }
}

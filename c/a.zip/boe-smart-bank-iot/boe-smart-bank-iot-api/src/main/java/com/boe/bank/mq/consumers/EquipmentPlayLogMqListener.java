package com.boe.bank.mq.consumers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.boe.bank.bean.equipment.EquipmentPlayLogDto;
import com.boe.bank.bean.equipment.EquipmentPlayLogQueueDto;
import com.boe.bank.common.entity.equipment.EquipmentPlayLog;
import com.boe.bank.service.equipment.EquipmentPlayLogService;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.middleware.mq.stream.bean.MqMessage;
import com.boe.middleware.mq.stream.bean.MqMessageListener;
import com.boe.middleware.mq.stream.utils.MQListener;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@MqMessageListener(queueName="${stream-mq.queues.queue4.name}")
public class EquipmentPlayLogMqListener implements MQListener<EquipmentPlayLogQueueDto>{
	@Autowired
	private EquipmentPlayLogService equipmentPlayLogService;
	
	@Autowired
	private EquipmentService equipmentService;
	
	@Override
	public void onMessage(MqMessage<EquipmentPlayLogQueueDto> message) throws Exception {
		if (message == null || message.getValue() == null) {
			return;
		}
		EquipmentPlayLogQueueDto queueDto = message.getValue();
		String mac = queueDto.getMac();
		String logUrl = queueDto.getLogUrl();
		List<EquipmentPlayLogDto> playLogDtos = queueDto.getEquipmentPlayLogDtos();
		if (!CollectionUtils.isEmpty(playLogDtos)) {
    		List<EquipmentPlayLog> list = Lists.newArrayList();
    		log.info("EquipmentPlayLogMqListener:" + list.size());
    		for (EquipmentPlayLogDto dto : playLogDtos) {
    			EquipmentPlayLog entity = new EquipmentPlayLog();
    			entity.setMac(mac);
    			if (!StringUtils.isEmpty(dto.getProgramId())) {
					entity.setProgramId(Integer.parseInt(dto.getProgramId()));
				}
				if (!StringUtils.isEmpty(dto.getProgramType())) {
					entity.setProgramType(Integer.parseInt(dto.getProgramType()));
				}
    			entity.setPlayTime(dto.getTime());
    			entity.setLogUrl(logUrl);
    			Integer equipmentId = equipmentService.getEquId(mac);
    			if (equipmentId != null && equipmentId > 0) {
    				entity.setEquipmentId(equipmentId);
    			}
				list.add(entity);
    		}
			equipmentPlayLogService.saveBatch(list);
    	}
	}
}

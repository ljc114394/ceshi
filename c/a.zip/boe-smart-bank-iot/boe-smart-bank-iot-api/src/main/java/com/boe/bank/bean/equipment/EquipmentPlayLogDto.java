package com.boe.bank.bean.equipment;

import lombok.Data;

@Data
public class EquipmentPlayLogDto {
	//节目ID
	private String programId;
	//普通节目:0,插播:1
	private String programType;
	//播放时间
	private String time;
}

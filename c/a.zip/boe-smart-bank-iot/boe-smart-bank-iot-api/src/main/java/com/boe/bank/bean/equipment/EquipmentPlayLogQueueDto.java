package com.boe.bank.bean.equipment;

import java.util.List;

import lombok.Data;

@Data
public class EquipmentPlayLogQueueDto {
	private String mac;
	private String logUrl;
	private List<EquipmentPlayLogDto> equipmentPlayLogDtos;
}

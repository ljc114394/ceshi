package com.boe.bank.jobs;

import com.boe.bank.service.logService.LogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 定时任务:接口日志定时清理
 * @author lvjiacheng
 */
@Slf4j
@Component
public class LogJob {
	@Autowired
	private LogService logService;


	/**
	 * 每天凌晨自动保留一周内的数据
	 */
	@Scheduled(cron = "0 0 0 * * ?")
	public void delectCronLog() {
		log.info("LogJob start");

		logService.delectCronLog();

		log.info("LogJob end");
	}

}

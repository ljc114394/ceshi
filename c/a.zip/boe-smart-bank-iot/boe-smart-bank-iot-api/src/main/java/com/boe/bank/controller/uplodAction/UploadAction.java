package com.boe.bank.controller.uplodAction;

import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.common.constant.UploadTypeEnum;
import com.boe.bank.service.uploadService.UploadService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * TODO
 *
 * @author lvjiahceng
 * @version 1.0
 * @data 2020/10/26
 */
@RestController
@Slf4j
@Api(value = "UploadAction", tags = "上传功能")
@RequestMapping(value = "/upload")
public class UploadAction {

    @Resource
    private UploadService uploadService;

    @ApiOperation(value = "上传")
    @PostMapping("/{type}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "mfile",dataType = "MultipartFile",allowMultiple = true),
            @ApiImplicitParam(name = "type",value = "type为1表示图片,type为2表示视频,type为3，表示文档文件，只支持PDF文件;type为4，表示程序文件;type为5,为xml格式"),
    })
    public Result upload(@PathVariable("type") Integer type, @RequestParam(value = "mfile", required = false) MultipartFile mfile) {
        try {
            log.info("上传-开始 type:{}", type);
            String  url = uploadService.upload(type, mfile);
            log.info("上传-结束 url:{}", url);
            return Result.success(url);
        } catch (BusinessException e) {
            log.info("上传-业务异常 type:{}error:{}", type, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("上传-异常 type:{}error:{}", type, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    @ApiOperation(value = "产品库上传")
    @PostMapping("/product/{type}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "mfile",dataType = "MultipartFile",allowMultiple = true),
            @ApiImplicitParam(name = "type",value = "type为1表示图片,type为2表示视频,type为3，表示文档文件，只支持PDF文件;type为4，表示程序文件;type为5,为xml格式"),
    })
    public Result productUpload(@PathVariable("type") Integer type, @RequestParam(value = "mfile", required = false) MultipartFile mfile) {
        try {
            log.info("上传-开始 type:{}", type);
            String  url = uploadService.productUpload(mfile, UploadTypeEnum.PRODUCT.getName(),type);
            log.info("上传-结束 url:{}", url);
            return Result.success(url);
        } catch (BusinessException e) {
            log.info("上传-业务异常 type:{}error:{}", type, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("上传-异常 type:{}error:{}", type, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    @ApiOperation(value = "多文件上传")
    @PostMapping("/uploadList/{type}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "mfiles",dataType = "MultipartFile",allowMultiple = true),
            @ApiImplicitParam(name = "type",value = "type为1表示图片,type为2表示视频,type为3，表示文档文件，只支持PDF文件;type为4，表示程序文件;type为5,为xml格式"),
    })
    public Result uploadList(@PathVariable("type") Integer type, @RequestParam(value = "mfiles", required = false) MultipartFile[] mfiles, String customPath) {
        try {
            log.info("上传-开始 type:{}", type);
            List<Map> filePathListUrl =  uploadService.uploadList(type, mfiles);
            log.info("上传-结束 url:{}", filePathListUrl);
            return Result.successWithData(filePathListUrl);
        } catch (BusinessException e) {
            log.info("上传-业务异常 type:{}error:{}", type, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("上传-异常 type:{}error:{}", type, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }
}

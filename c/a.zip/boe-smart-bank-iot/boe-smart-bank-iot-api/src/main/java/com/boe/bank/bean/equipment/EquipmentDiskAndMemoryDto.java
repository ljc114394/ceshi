package com.boe.bank.bean.equipment;

import lombok.Data;

@Data
public class EquipmentDiskAndMemoryDto {
	//已用
	private long free;
	//总共
	private long total;
}

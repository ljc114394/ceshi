package com.boe.bank.controller.appliedbizmanege;

import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.service.appliedbizmanege.AppliedExcelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@RestController
@Slf4j
@Api(value = "AppliedReadExcelAction", tags = "应用模块组件下载和读取")
@RequestMapping(value = "/appliedmodule")
public class AppliedReadExcelAction {

    @Autowired
    private AppliedExcelService appliedExcelService;

    @ApiOperation(value = "生成Excel模板")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1")})
    @GetMapping(value ="/exportExcel/{id}")
    public void downLoadAppliedExcelTemplateById(HttpServletResponse response,@PathVariable("id") Integer id) {
        try {
            appliedExcelService.downLoadAppliedExcelTemplateById(response,id);
            log.info("id:{}下载excel模板:{}",id);
        }catch(BusinessException e) {
            log.error("下载excel--业务异常 id:{} error:{}", id, e.getMessage());
        }catch (Exception e) {
            log.error("下载excel:{} error:{}",id, ExceptionUtils.getMessage(e.fillInStackTrace()));
        }
    }

    @ApiOperation(value = "读取Excel")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "应用业务id", example = "1"),
            @ApiImplicitParam(name = "mfile",dataType = "MultipartFile",allowMultiple = true, value = "excel文件")
    }
    )
    @PostMapping(value = "/uploadExcel/{id}")
    public Result upload(@RequestParam(value = "mfile", required = false) MultipartFile file, @PathVariable("id") Integer id) throws IOException {
        try {
            appliedExcelService.importExcelTemplateData(file,id);
            log.info("导入excel数据:---------------------");
            return Result.success();
        }catch(BusinessException e) {
            log.error("导入excel数据--业务异常 id:{} error:{}",id, e.getMessage());
            return Result.failure(e.getMessage());
        }catch (Exception e) {
            log.error("导入excel数据:id:{} error:{}", id,ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(e.getMessage());
        }
    }
}

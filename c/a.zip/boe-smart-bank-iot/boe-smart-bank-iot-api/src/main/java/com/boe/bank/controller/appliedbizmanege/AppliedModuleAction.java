package com.boe.bank.controller.appliedbizmanege;

import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeInfoBean;
import com.boe.bank.common.bean.appliedbizmanege.AppliedModuleSearchBean;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.service.appliedbizmanege.AppliedBizManegeService;
import com.boe.bank.service.appliedbizmanege.AppliedModuleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@RestController
@Slf4j
@Api(value = "AppliedModuleAction", tags = "应用模块组件")
@RequestMapping(value = "/appliedmodule")
public class AppliedModuleAction {

    @Resource
    AppliedModuleService appliedModuleService;
    @Resource
    AppliedBizManegeService appliedBizManegeService;

    /**
     * 详情
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "详情")
    @GetMapping("/{bizId}/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "bizId", value = "应用业务id", example = "1", required = true), @ApiImplicitParam(name = "id", value = "数据id", example = "1", required = true)})
    public Result findInfoById(@PathVariable("bizId") Integer bizId, @PathVariable("id") Integer id) {
        try {
            return Result.successWithData(appliedModuleService.findInfoById(bizId, id));
        } catch (BusinessException e) {
            log.error("应用模块组件-详情-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-详情-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 新增
     *
     * @param saveMap
     * @return
     */
    @ApiOperation(value = "添加")
    @PostMapping("/{bizId}")
    @ApiImplicitParams({@ApiImplicitParam(name = "bizId", value = "应用业务id", example = "1", required = true)})
    public Result add(@PathVariable("bizId") Integer bizId, @RequestBody Map<String, Object> saveMap) {
        try {
            boolean result = appliedModuleService.save(bizId, saveMap);
            if (result) {
                return Result.success();
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_SAVE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_SAVE_FAILURE.message());
        } catch (BusinessException e) {
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-添加-异常 数据:{} error:{}", saveMap, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    /**
     * 修改
     *
     * @param bizId
     * @param id
     * @param updateMap
     * @return
     */
    @ApiOperation(value = "修改")
    @PutMapping("/{bizId}/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "bizId", value = "应用业务id", example = "1", required = true), @ApiImplicitParam(name = "id", value = "数据id", example = "1", required = true)})
    public Result updateAppliedBiz(@PathVariable("bizId") Integer bizId, @PathVariable("id") Integer id, @RequestBody Map<String, Object> updateMap) {
        try {
            boolean result = appliedModuleService.update(bizId, id, updateMap);
            if (result) {
                return Result.success();
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_UPDATE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_UPDATE_FAILURE.message());
        } catch (BusinessException e) {
            log.error("应用模块组件-修改-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-修改-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "删除")
    @DeleteMapping("/{bizId}/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "bizId", value = "应用业务id", example = "1", required = true), @ApiImplicitParam(name = "id", value = "数据id", example = "1", required = true)})
    public Result deleteAppliedModuleById(@PathVariable("bizId") Integer bizId, @PathVariable("id") Integer id) {
        try {
            boolean result = appliedModuleService.delete(bizId, id);
            if (result) {
                return Result.success();
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.message());
        } catch (BusinessException e) {
            log.error("应用模块组件-删除-业务异常 bizId:{} id:{} error:{}", bizId, id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-删除-异常 bizId:{} id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    /**
     * 批量删除
     *
     * @param bizId
     * @param ids
     * @return
     */
    @ApiOperation(value = "批量删除")
    @DeleteMapping("/batch/{bizId}")
    @ApiImplicitParams({@ApiImplicitParam(name = "bizId", value = "应用业务id", example = "1", required = true), @ApiImplicitParam(name = "ids", value = "批量数据id", example = "1,2", required = true)})
    public Result batchDelete(@PathVariable("bizId") Integer bizId, Integer[] ids) {
        try {
            boolean result = appliedModuleService.batchDelete(bizId, ids);
            if (result) {
                return Result.success();
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.message());
        } catch (BusinessException e) {
            log.error("应用模块组件-删除-业务异常 bizId:{} ids:{} error:{}", bizId, ids, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-删除-异常 bizId:{} ids:{} error:{}", ids, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    /**
     * 分页
     *
     * @param searchBean
     * @return
     */
    @ApiOperation(value = "分页")
    @GetMapping("/page")
    public Result page(AppliedModuleSearchBean searchBean) {
        try {
            return Result.successWithData(appliedModuleService.selectAppliedModuleForPage(searchBean));
        } catch (BusinessException e) {
            log.error("应用模块组件-分页-业务异常 appliedBizManege:{}error:{}", searchBean, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-分页-异常 appliedBizManege:{} error:{}", searchBean, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    /**
     * 提交审批
     *
     * @param bizId
     * @param id
     * @param examineId
     * @return
     */
    @ApiOperation(value = "提交审批")
    @GetMapping("/submitExamine")
    @ApiImplicitParams({@ApiImplicitParam(name = "bizId", value = "应用业务id", example = "1", required = true),
            @ApiImplicitParam(name = "id", value = "数据id", example = "1", required = true),
            @ApiImplicitParam(name = "examineId", value = "审批id", example = "1", required = true)})
    public Result submitExamine(@RequestParam(value = "bizId", required = true) Integer bizId, @RequestParam(value = "id", required = true) Integer id, @RequestParam(value = "examineId", required = true) Integer examineId) {
        try {
            return Result.successWithData(appliedModuleService.submitExamine(bizId, id, examineId));
        } catch (BusinessException e) {
            log.error("应用模块组件-提交审批-业务异常 id:{}error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用模块组件-提交审批-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 详情
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "应用配置详情")
    @GetMapping("/appconfig/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1", required = true)})
    public Result<AppliedBizManegeInfoBean> getAppliedBizInfoById(@PathVariable("id") Integer id) {
        try {
            return Result.successWithData(appliedBizManegeService.getAppliedBizInfoById(id));
        } catch (BusinessException e) {
            log.error("应用业务管理-详情-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-详情-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


}


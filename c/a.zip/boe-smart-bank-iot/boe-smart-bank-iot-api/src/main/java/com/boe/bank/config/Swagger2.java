package com.boe.bank.config;

import cn.hutool.core.util.StrUtil;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.RequestHandler;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.List;


/**
 * @ClassName Swagger2
 * @Description Swagger2 configuration
 * @Author shaozhenjun
 * @Date 19-7-10 下午6:35
 * @Version 1.0
 */
@Configuration
@EnableSwagger2
public class Swagger2 {
    @Value("${swagger.enable}")
    private boolean swaggerOn;
    @Value("${swagger.only-show-app-config.enable}")
    private boolean onlyShowAppConfig;
    @Bean
    public Docket createRestApi(){

        ParameterBuilder token = new ParameterBuilder();
        List<Parameter> pars = Lists.newArrayList();
        token.name("MAC").description("设备mac")
                .modelRef(new ModelRef("string")).parameterType("header")
                .required(false).build(); //header中的ticket参数非必填，传空也可以
        pars.add(token.build());

        String docketScanPaths = null;
        Predicate<String> predicate = null;
        if (onlyShowAppConfig) {
            docketScanPaths = "com.boe.bank.controller.appliedbizmanege;com.boe.bank.controller.uplodAction";
            //predicate = PathSelectors.regex("(/appliedmodule/.*)|(/upload/product/.*)");
            predicate = PathSelectors.regex("(/appliedmodule/.*)");
        } else {
            docketScanPaths = "com.boe.bank.controller";
            predicate = PathSelectors.any();
        }

        return new Docket(DocumentationType.SWAGGER_2)
                .enable(swaggerOn)
                .apiInfo(apiInfo())
                .select()
                .apis(scanBasePackage(docketScanPaths))
                .paths(predicate)
                .build()
                .globalOperationParameters(pars);

    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("智慧银行设备 api文档")
                .description("智慧银行设备 api文档")
                .version("1.0")
                .build();
    }

    /**
     * 切割扫描的包生成Predicate<RequestHandler>
     * @param basePackage
     * @return
     */
    public static Predicate<RequestHandler> scanBasePackage(final String basePackage) {
        if(StrUtil.isBlank(basePackage)){
            throw new NullPointerException("basePackage不能为空，多个包扫描使用分隔");
        }
        String[] controllerPack = basePackage.split(";");
        Predicate<RequestHandler> predicate = null;
        for (int i = controllerPack.length -1; i >= 0 ; i--) {
            String strBasePackage = controllerPack[i];
            if(StrUtil.isNotBlank(strBasePackage)){
                Predicate<RequestHandler> tempPredicate = RequestHandlerSelectors.basePackage(strBasePackage);
                predicate = predicate == null ? tempPredicate : Predicates.or(tempPredicate,predicate);
            }
        }
        if(predicate == null){
            throw new NullPointerException("basePackage配置不正确，多个包扫描使用分隔");
        }
        return predicate;
    }
}

package com.boe.bank.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Description
 *
 * @author 10183279
 * @date 2020/10/21
 */
@Component
@ConfigurationProperties(prefix = "netty.socket")
@Data
public class SocketProperties {

    private String hostname;

    private int port;
}

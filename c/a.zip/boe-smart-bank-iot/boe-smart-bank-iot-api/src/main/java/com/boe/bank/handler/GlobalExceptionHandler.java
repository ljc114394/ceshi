package com.boe.bank.handler;

import com.boe.bank.common.base.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result handleBindException(MethodArgumentNotValidException e) {
        log.error("参数错误： {}", e);
        String messge = "";
        for (ObjectError allError : e.getBindingResult().getAllErrors()) {
            messge = e.getBindingResult().getFieldError().getField() + " "
                    + e.getBindingResult().getFieldError().getDefaultMessage();
        }
        return Result.paramError("参数错误：" + messge);
    }

    /**
     * 系统异常
     */
    @ExceptionHandler(Exception.class)
    public Result handleException(Exception e) {
        log.error(e.getMessage(), e);
        return Result.failure("服务器错误，请联系管理员 " + e.getMessage());
    }
}

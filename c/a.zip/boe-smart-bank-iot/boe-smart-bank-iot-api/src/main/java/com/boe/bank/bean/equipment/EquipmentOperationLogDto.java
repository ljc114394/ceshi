package com.boe.bank.bean.equipment;

import lombok.Data;

@Data
public class EquipmentOperationLogDto {
	//cpu占用率
	private String cpu;
	//内存可用量
	private EquipmentDiskAndMemoryDto memory;
	//磁盘可用空间
	private EquipmentDiskAndMemoryDto disk;
	//日志产生时间
	private String logTime;
}

package com.boe.bank.controller.labelProductPortrait;

import java.util.List;

import com.boe.bank.common.bean.productlibrarybean.ProductPortraitDTO;
import com.boe.bank.controller.BaseController;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import com.alibaba.fastjson.JSON;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.userPortrait.MarketLogsBean;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.service.userPortrait.UserPortraitService;
import com.boe.middleware.mq.stream.utils.StreamMQTemplate;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description:存储用户画像相关属性值controller
 * @Author: lijianglong
 * @Data:2020/10/30
 */

@RestController
@Slf4j
@Api(value = "LabelProductPortraitController", tags = "存储用户画像相关属性值")
@RequestMapping(value = "/smartMarketing")
public class LabelProductPortraitController extends BaseController {

    @Autowired
    private UserPortraitService userPortraitService;
    
    @Autowired
    private StreamMQTemplate streamMQTemplate;
    
    @Value("${stream-mq.queues.queue1.name}")
    private String behaviorValueQueue;
    
    @Value("${stream-mq.queues.queue2.name}")
    private String attributeValueQueue;

    @ApiOperation(value = "用户画像-存储用户画像相关属性值-并返回对应的产品id")
    @PostMapping("")
    public Result<List<Integer>> addlLabelProductPortrait(@RequestBody MarketLogsBean marketLogsBean){
        marketLogsBean.setMac (this.getMac ());
    	log.info("addAttributeValue 存储属性条件相关值:{}", marketLogsBean);
    	streamMQTemplate.sendAsync(attributeValueQueue, marketLogsBean, (success)->{
    		if(!success)
    			log.error("添加attributeValueQueue队列失败"+ JSON.toJSONString(marketLogsBean));
    	});
    	
        try{
            log.info("add 用户画像相关属性值:{}",marketLogsBean);
            return Result.successWithData(userPortraitService.addMarketLogs(marketLogsBean));
        }catch (BusinessException e){
            log.info("add 用户画像相关属性值:{} error:{}",marketLogsBean, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        }catch (Exception e){
            log.error("add 用户画像相关属性值:{} error:{}",marketLogsBean, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }
    
    @ApiOperation(value = "存储行为条件相关值")
    @PostMapping("/addBehaviorValue")
    public Result<?> addBehaviorValue(@RequestBody MarketLogsBean marketLogsBean){
        marketLogsBean.setMac (this.getMac ());
    	log.info("addBehaviorValue 存储行为条件相关值:{}", marketLogsBean);
    	
    	streamMQTemplate.sendAsync(behaviorValueQueue, marketLogsBean, (success)->{
    		if(!success)
    			log.error("添加behaviorValueQueue队列失败"+ JSON.toJSONString(marketLogsBean));
    	});
    	
    	return Result.success();
    }

    @ApiOperation(value = "获取产品、画像、属性数据")
    @GetMapping
    public Result<List<ProductPortraitDTO>> getProductPortrait(){
        try{
            log.info("获取产品、画像、属性数据:{}");
            return Result.successWithData(userPortraitService.getProductPortraitDTOS());
        }catch (BusinessException e){
            log.info("产品、画像、属性  error:{}", e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        }catch (Exception e){
            log.error("产品、画像、属性 error:{}", ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }
}

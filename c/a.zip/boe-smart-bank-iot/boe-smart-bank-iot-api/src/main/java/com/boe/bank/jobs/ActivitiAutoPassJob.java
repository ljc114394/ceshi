package com.boe.bank.jobs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.boe.bank.service.activitiService.job.ActivitiAutoPassJobService;

import lombok.extern.slf4j.Slf4j;

/**
 * 定时任务:自动审批
 * @author caoxuhao
 */
@Slf4j
@Component
public class ActivitiAutoPassJob {
	@Autowired
	private ActivitiAutoPassJobService activitiAutoPassJobService;
	
	@Scheduled(cron = "0 0/1 * * * ?")
	public void autoPass() {
		log.info("ActivitiAutoPassJob start");
		
		activitiAutoPassJobService.autoPass();
		
		log.info("ActivitiAutoPassJob end");
	}
}

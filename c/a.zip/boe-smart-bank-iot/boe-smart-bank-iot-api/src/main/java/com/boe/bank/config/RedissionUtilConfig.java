package com.boe.bank.config;

import com.boe.bank.common.utils.RedissionUtils;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RedissionUtil 初始化
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/11 15:40
 */
@Configuration
@ConditionalOnClass({ RedissionUtils.class })
public class RedissionUtilConfig {

    @Autowired
    private RedissonClient redissonClient;

    @Bean
    public RedissionUtils getRedissionUtils() {
        return new RedissionUtils(redissonClient);
    }
}

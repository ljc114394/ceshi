package com.boe.bank.controller.equipment;

import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.controller.BaseController;
import com.boe.bank.service.equipment.EquipmentScreenshotService;
import com.boe.bank.util.FileUploadUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * 设备截屏 Controller
 *
 * @author 10085188
 * @date 2020/11/02
 */
@Api(tags = "设备截屏管理")
@RequestMapping("/equipment/screenshot/")
@RestController
@Slf4j
public class EquipmentScreenshotController extends BaseController {

	@Autowired
	private Environment env;
	
    @Autowired
    private EquipmentScreenshotService equipmentScreenshotService;

    @ApiOperation(value = "上传截屏图片")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "MAC", value = "设备mac地址", example = "00:00:00:00:00:00", paramType = "header"),
    	@ApiImplicitParam(name = "mfile", dataType = "MultipartFile", value = "图片文件")
	})
    @PostMapping("/uploadScreenshot")
    public Result<?> uploadScreenshot(@RequestParam("mfile") MultipartFile mfile) {
		String mac = super.getMac();
    	if (StringUtils.isEmpty(mac)) {
    		log.info("设备mac地址为空");
    		return Result.failure(MsgReturnEnum.PARAMETER_EMPTY);
    	}
    	if (mfile == null || mfile.isEmpty()) {
    		log.info("上传文件为空");
    		return Result.failure(MsgReturnEnum.FILE_EMPTY);
    	}
    	
    	try {
    		// 上传路径
    		String rootPath = env.getProperty("upload.upath");
    		String picUrl = FileUploadUtil.uploadMultipartFile(mfile, 1, rootPath);
    		if (StringUtils.isEmpty(picUrl)) {
    			log.info("上传设备截屏失败");
    			return Result.failure(MsgReturnEnum.FILE_EXCEP);
    		}
    		boolean res = equipmentScreenshotService.save(mac, picUrl);
    		if (res) {
    			return Result.success();
    		}
    	} catch (BusinessException e1) {
 			log.info("上传设备截屏  业务异常 ：{}", e1.getMessage());
 			return Result.failure(e1.getExceptionCode(),e1.getMessage());
 		} catch (Exception e) {
 			log.error("上传设备截屏  异常 ：{}", ExceptionUtils.getMessage(e.fillInStackTrace()));
 		}
    	return Result.failure();
    }
	
}

package com.boe.bank.mq.consumers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.boe.bank.bean.equipment.EquipmentOperationLogDto;
import com.boe.bank.bean.equipment.EquipmentOperationLogQueueDto;
import com.boe.bank.common.entity.equipment.Equipment;
import com.boe.bank.common.entity.equipment.EquipmentOperationLog;
import com.boe.bank.common.utils.DateUtil;
import com.boe.bank.service.equipment.EquipmentOperationLogService;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.middleware.mq.stream.bean.MqMessage;
import com.boe.middleware.mq.stream.bean.MqMessageListener;
import com.boe.middleware.mq.stream.utils.MQListener;
import com.google.common.collect.Lists;

import jodd.util.StringUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@MqMessageListener(queueName="${stream-mq.queues.queue5.name}")
public class EquipmentOperationLogMqListener implements MQListener<EquipmentOperationLogQueueDto>{
	
	@Autowired
	private EquipmentOperationLogService equipmentOperationLogService;
	
	@Autowired
	private EquipmentService equipmentService;
	
	@Override
	public void onMessage(MqMessage<EquipmentOperationLogQueueDto> message) throws Exception {
		if (message == null || message.getValue() == null) {
			return;
		}
		EquipmentOperationLogQueueDto queueDto = message.getValue();
		String mac = queueDto.getMac();
		String logUrl = queueDto.getLogUrl();
		List<EquipmentOperationLogDto> equipmentLogDtos = queueDto.getEquipmentOperationLogDtos();
		if (!CollectionUtils.isEmpty(equipmentLogDtos)) {
			List<EquipmentOperationLog> list = Lists.newArrayList();
			log.info("EquipmentOperationLogMqListener:" + list.size());
			for (EquipmentOperationLogDto dto : equipmentLogDtos) {
				EquipmentOperationLog entity = new EquipmentOperationLog();
    			entity.setMac(mac);
    			entity.setLogUrl(logUrl);
    			entity.setCpu(dto.getCpu());
    			if (dto.getMemory() != null) {
    				entity.setMemoryFree(dto.getMemory().getFree());
    				entity.setMemoryTotal(dto.getMemory().getTotal());
    			}
    			if (dto.getDisk() != null) {
    				entity.setDiskFree(dto.getDisk().getFree());
    				entity.setDiskTotal(dto.getDisk().getTotal());
    			}
    			if (StringUtil.isNotEmpty(dto.getLogTime())) {
    				entity.setLogTime(DateUtil.parse(dto.getLogTime()));
    				entity.setLogTimeAt((int) (entity.getLogTime().getTime() / 1000));
    			}
    			Equipment equipment = equipmentService.getByMac(mac);
    			if (equipment != null && equipment.getId() != null && equipment.getId() > 0) {
    				entity.setEquId(equipment.getId());
    				entity.setName(equipment.getName());
    				entity.setAddressIp(equipment.getAddressIp());
    				entity.setOrgId(equipment.getOrgId() != null ? equipment.getOrgId().intValue() : null);
    				entity.setAreaId(equipment.getAreaId());
    				entity.setTypeId(equipment.getTypeId());
    			}
    			entity.setCreateTime(new Date());
				list.add(entity);
			}
			equipmentOperationLogService.saveBatch(list);
		}
	}

}

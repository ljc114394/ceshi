package com.boe.bank.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;

/**
 * TODO
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/11/5 13:23
 */
@Slf4j
public class BaseController {
    @Autowired
    private HttpServletRequest request;

    protected String getMac() {
        return this.getRequest().getHeader("MAC");
    }

    /**
     * @return
     * @description：获取Request
     * @see： 需要参见的其它内容
     */
    public HttpServletRequest getRequest() {
        return request;
    }


}

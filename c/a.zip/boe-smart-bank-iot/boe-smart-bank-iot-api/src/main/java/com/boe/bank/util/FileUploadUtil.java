package com.boe.bank.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.constant.MaterialDir;
import com.boe.bank.common.constant.MsgReturnEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.List;
import java.util.UUID;

/**
* @Description:保存文件工具类
* @author: 10085188
* @date: 2020年11月03日
 */
@Slf4j
public class FileUploadUtil {
	
	/**
	 * 功能描述：上传文件到服务器
	 * mfile：file文件
	 * mediaType: 1  是上传 图片  2 是上传节目日志  3 是上传运维日志
	 * rootPath: 上传路径
	 */
	public static String uploadMultipartFile(MultipartFile mfile, Integer mediaType, String rootPath) {
		if (mfile != null && !mfile.isEmpty() || mediaType == null) {
			// 获取文件名
			String originFileName = mfile.getOriginalFilename();
			String fileName = originFileName;
			// 分类目录
			String mPath = "";
			if (mediaType == 1) {
				mPath = MaterialDir.PIC;
				// 获取文件后缀
				String subfix = originFileName.substring(originFileName.indexOf('.') + 1, originFileName.length());
				// 创建文件唯一名称
				String uuid = UUID.randomUUID().toString() + "." + subfix;
				fileName = uuid.toString().replaceAll("\\-", "");
			} else if (mediaType == 2 || mediaType == 3) {
				mPath = MaterialDir.TEXT;
			}
			String dirPath = rootPath + mPath;
			if (saveMaterialFile(mfile, dirPath, fileName)) {
				return mPath + "/" + fileName;
			} else {
				throw new BusinessException(MsgReturnEnum.MATERIAL_FILE_EXCEP);
			}
		}
		return null;
	}
	
	public static boolean saveMaterialFile(MultipartFile pic,String dirPath,String fileName) {
		log.info("=======saveMaterialFile======上传原始文件到服务器开始======");
		log.info("====文件上传的路径为：======" + dirPath + "/" +fileName);
		// 创建图片文件
		File destOrigin = new File(dirPath + "/" +fileName);
		// 检测是否存在目录
		if (!destOrigin.getParentFile().exists()) {
			destOrigin.getParentFile().mkdirs();
		}
		try {
			// 上传文件
			pic.transferTo(destOrigin);
			log.info("=======saveMaterialFile======上传原始文件到服务器结束======");
			return true;
		} catch (Exception e) {
			log.error("保存文件时发生异常：{}",ExceptionUtils.getMessage(e.fillInStackTrace()));
			return false;
		} 
		
	}
    
	public static MultipartFile file2MultipartFile(File file) {
        try {
        	InputStream inputStream = new FileInputStream(file);
        	MultipartFile multipartFile = new MockMultipartFile(file.getName(), inputStream);
        	log.info("file转multipartFile成功. {}", multipartFile);
        	return multipartFile;
        } catch(Exception e) {
        	log.error("file转multipartFile 异常 ：{}", ExceptionUtils.getMessage(e.fillInStackTrace()));
        }
        return null;
    }
	
	/**
	 * 功能描述：上传文件到服务器
	 * mfile：file文件
	 * mediaType: 1  是上传 图片  2 是上传节目日志  3 是上传运维日志
	 * rootPath: 上传路径
	 */
	public static String uploadMultipartFile(File file, Integer mediaType, String rootPath) {
		MultipartFile mFile = file2MultipartFile(file);
		return uploadMultipartFile(mFile, mediaType, rootPath);
	}
	
	public static JSONArray readTxt2JsonArray(String filePath) {
		String jsonStr = "";
		File file = new File(filePath);
		//File file = new File("C:/Users/10085188.BOE/Desktop/文件夹/icbc/精准营销系统/ttt.txt");
		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		try {
			fis = new FileInputStream(file);//文件输入流
			isr = new InputStreamReader(fis, "utf-8");//包装为字符流
			br = new BufferedReader(isr);//包装为缓冲流
			String line = null;
			while ((line = br.readLine()) != null) {
				jsonStr += line;
			}
			JSONArray jArray = JSONObject.parseArray(jsonStr);
			return jArray;
		} catch(IOException e) {
			log.error("从txt文件读取json数据异常：{}", ExceptionUtils.getMessage(e.fillInStackTrace()));
			return null;
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (isr != null) {
				try {
					isr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static <T> List<T> readJsonTxt2ObjectList(MultipartFile file, Class<T> pojoClass) {
		String jsonStr = "";
		InputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		try {
			fis = file.getInputStream();//文件输入流
			isr = new InputStreamReader(fis, "utf-8");//包装为字符流
			br = new BufferedReader(isr);//包装为缓冲流
			String line = null;
			while ((line = br.readLine()) != null) {
				jsonStr += line;
			}
			return JSONObject.parseArray(jsonStr, pojoClass);
		} catch(IOException e) {
			log.error("从txt文件读取json数据异常：{}", ExceptionUtils.getMessage(e.fillInStackTrace()));
			return null;
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (isr != null) {
				try {
					isr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

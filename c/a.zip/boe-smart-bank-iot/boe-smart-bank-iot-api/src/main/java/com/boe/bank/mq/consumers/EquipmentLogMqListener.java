package com.boe.bank.mq.consumers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.boe.bank.bean.equipment.EquipmentLogDto;
import com.boe.bank.bean.equipment.EquipmentLogQueueDto;
import com.boe.bank.common.entity.equipment.EquipmentLog;
import com.boe.bank.service.equipment.EquipmentLogService;
import com.boe.bank.service.equipment.EquipmentService;
import com.boe.middleware.mq.stream.bean.MqMessage;
import com.boe.middleware.mq.stream.bean.MqMessageListener;
import com.boe.middleware.mq.stream.utils.MQListener;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@MqMessageListener(queueName="${stream-mq.queues.queue3.name}")
public class EquipmentLogMqListener implements MQListener<EquipmentLogQueueDto>{
	
	@Autowired
	private EquipmentLogService equipmentLogService;
	
	@Autowired
	private EquipmentService equipmentService;
	
	@Override
	public void onMessage(MqMessage<EquipmentLogQueueDto> message) throws Exception {
		if (message == null || message.getValue() == null) {
			return;
		}
		EquipmentLogQueueDto queueDto = message.getValue();
		String mac = queueDto.getMac();
		String logUrl = queueDto.getLogUrl();
		List<EquipmentLogDto> equipmentLogDtos = queueDto.getEquipmentLogDtos();
		if (!CollectionUtils.isEmpty(equipmentLogDtos)) {
			List<EquipmentLog> list = Lists.newArrayList();
			log.info("EquipmentLogMqListener:" + list.size());
			for (EquipmentLogDto dto : equipmentLogDtos) {
				EquipmentLog entity = new EquipmentLog();
    			entity.setMac(mac);
    			if (!StringUtils.isEmpty(dto.getLevel())) {
    				entity.setLevel(Integer.parseInt(dto.getLevel()));
    			}
    			entity.setMessage(dto.getMessage());
    			entity.setTime(dto.getTime());
    			entity.setLogUrl(logUrl);
    			Integer equipmentId = equipmentService.getEquId(mac);
    			if (equipmentId != null && equipmentId > 0) {
    				entity.setEquipmentId(equipmentId);
    			}
				list.add(entity);

			}
			equipmentLogService.saveBatch(list);
		}
	}

}

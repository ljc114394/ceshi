package com.boe.bank.bean.equipment;

import lombok.Data;

@Data
public class EquipmentLogDto {
	//日志级别
	private String level;
	//日志内容
	private String message;
	//日志时间
	private String time;
}

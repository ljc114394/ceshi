package com.boe.bank.controller.appliedbizmanege;

import com.boe.bank.common.base.BusinessException;
import com.boe.bank.common.base.Result;
import com.boe.bank.common.bean.appliedbizmanege.*;
import com.boe.bank.common.constant.MsgReturnEnum;
import com.boe.bank.service.appliedbizmanege.AppliedBizManegeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.Map;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@RestController
@Slf4j
@Api(value = "AppliedBizManegeAction", tags = "应用业务管理")
@RequestMapping(value = "/appliedbizmanege")
public class AppliedBizManegeAction {

    @Resource
    AppliedBizManegeService appliedBizManegeService;


    /**
     * 详情
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "详情")
    @GetMapping("/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1", required = true)})
    public Result<AppliedBizManegeInfoBean> getAppliedBizInfoById(@PathVariable("id") Integer id) {
        try {
            return Result.successWithData(appliedBizManegeService.getAppliedBizInfoById(id));
        } catch (BusinessException e) {
            log.error("应用业务管理-详情-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-详情-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    /**
     * 修改
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "修改")
    @PutMapping("/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1", required = true)})
    public Result updateAppliedBiz(@PathVariable("id") Integer id, @RequestBody AppliedBizManegeSaveBean saveBean) {
        try {
            Map result = appliedBizManegeService.updateAppliedBiz(id, saveBean);
            if (result != null) {
                return Result.successWithData(result);
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_UPDATE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.message());
        } catch (BusinessException e) {
            log.error("应用业务管理-修改-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-修改-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 修改
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "已有数据的修改")
    @PutMapping("/updateForUse/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1", required = true)})
    public Result update(@PathVariable("id") Integer id, @RequestBody AppliedBizManegeUpdateBean updateBean) {
        try {
            Map result = appliedBizManegeService.update(id, updateBean);
            if (result != null) {
                return Result.successWithData(result);
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_UPDATE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.message());
        } catch (BusinessException e) {
            log.error("应用业务管理-已有数据的修改-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-已有数据的修改-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "删除")
    @DeleteMapping("/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1", required = true)})
    public Result deletegetAppliedBizById(@PathVariable("id") Integer id) {
        try {
            boolean result = appliedBizManegeService.deleteAppliedBizById(id);
            if (result) {
                return Result.success();
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_DELETE_FAILURE.message());
        } catch (BusinessException e) {
            log.error("应用业务管理-删除-业务异常 id:{} error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-删除-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


    /**
     * 新增
     *
     * @param saveBean
     * @return
     */
    @ApiOperation(value = "添加")
    @PostMapping("")
    public Result add(@RequestBody AppliedBizManegeSaveBean saveBean) {
        try {
            Map result = appliedBizManegeService.saveAppliedBiz(saveBean);
            if (result != null) {
                return Result.successWithData(result);
            }
            return Result.failure(MsgReturnEnum.APPLIED_BIZ_MANEGE_SAVE_FAILURE.code(), MsgReturnEnum.APPLIED_BIZ_MANEGE_SAVE_FAILURE.message());
        } catch (BusinessException e) {
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-添加-异常 id:{} error:{}", saveBean, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 分页
     *
     * @param searchBean
     * @return
     */
    @ApiOperation(value = "分页")
    @GetMapping("/page")
    public Result<AppliedBizManegeListBean> page(@Valid AppliedBizManegeSearchBean searchBean) {
        try {
            return Result.successWithData(appliedBizManegeService.selectAppliedBizManegeForPage(searchBean));
        } catch (BusinessException e) {
            log.error("应用业务管理-分页-业务异常 appliedBizManege:{}error:{}", searchBean, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-分页-异常 appliedBizManege:{} error:{}", searchBean, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }

    /**
     * 应用产品是否被使用
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "应用产品是否被使用")
    @GetMapping("/use/{id}")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "应用业务id", example = "1", required = true)})
    public Result queryUse(@PathVariable("id") Integer id) {
        try {
            return Result.successWithData(appliedBizManegeService.queryProductIsUsed(id));
        } catch (BusinessException e) {
            log.error("应用业务管理-应用产品是否被使用-业务异常 id:{}error:{}", id, e.getMessage());
            return Result.failure(e.getExceptionCode(), e.getMessage());
        } catch (Exception e) {
            log.error("应用业务管理-应用产品是否被使用-异常 id:{} error:{}", id, ExceptionUtils.getMessage(e.fillInStackTrace()));
            return Result.failure(MsgReturnEnum.FAILURE);
        }
    }


}


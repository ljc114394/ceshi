package com.boe.bank.mq.consumers;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.boe.bank.common.bean.userPortrait.MarketLogsBean;
import com.boe.bank.service.marketLogService.MarketLogService;
import com.boe.middleware.mq.stream.bean.MqMessage;
import com.boe.middleware.mq.stream.bean.MqMessageListener;
import com.boe.middleware.mq.stream.utils.MQListener;
import com.fasterxml.jackson.core.JsonProcessingException;

@MqMessageListener(queueName="${stream-mq.queues.queue1.name}")
public class BehaviorValueMqListener implements MQListener<MarketLogsBean>{
	
	@Autowired
	private MarketLogService marketLogService;

	@Override
	public void onMessage(MqMessage<MarketLogsBean> message) throws JsonProcessingException {
		
		System.out.println("BehaviorValueMqListener:" + JSON.toJSONString(message));
		
		MarketLogsBean value = message.getValue();
		marketLogService.saveBehaviorValue(value);
	}

}

package com.boe.bank.common.bean.productlibrarybean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description:存于缓存
 * @Author: lijianglong
 * @Data:2020/10/29
 */

@Data
public class ProductPortraitDTO {

    @ApiModelProperty(value = "产品主键id")
    private Integer productId;

    @ApiModelProperty(value = "用户画像属性集合")
    private List<PortraitDTO> portraitDTOList;

}

package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description:用户群画像关联标签添加、删除选中标签
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Data
public class UserPortraitLabelDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "画像名称")
    private String portraitName;

    @ApiModelProperty(value = "备注")
    private String remark;

//    @ApiModelProperty(value = "用户群画像关联标签标主键id；将删除的标签id用英文逗号拼接")
//    private String portraitLabelIds;// 主键id

    @ApiModelProperty(value = "条件判断：0或  1且")
    private Integer conditionType;

    @ApiModelProperty(value = "权重")
    private Integer weight;

    @ApiModelProperty(value = "用户群画像关联标签List添加")
    private List<UserPortraitLabelBean> userPortraitLabelBeanList;//添加选中数据

    @ApiModelProperty(value = "用户群画像关联标签数(仅用于回显)")
    private String labelTrees;

    @ApiModelProperty(value = "用户群画像关联标签数(仅用于回显)From")
    private String labelTreesFrom;

}

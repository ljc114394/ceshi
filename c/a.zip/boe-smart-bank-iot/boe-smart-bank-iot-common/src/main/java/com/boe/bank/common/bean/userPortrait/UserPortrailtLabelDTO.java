package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用于接收用户画像获取属性标签区分
 * @Author: lijianglong
 * @Data:2020/11/24
 */

@Data
public class UserPortrailtLabelDTO {

    @ApiModelProperty(value = "标签属性区分：0属性标签、1行为标签")
    private Integer labelType;//标签属性区分：0属性标签、1行为标签

    @ApiModelProperty(value = "用户画像主键id")
    private Integer portraitId;
}

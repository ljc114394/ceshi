package com.boe.bank.common.constant;


import com.boe.bank.common.bean.appliedbizmanege.AppliedBizManegeFieldBean;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 应用配置管理常量
 * @author chenchenghu
 * @version 1.0
 * @date 2020/12/10
 */
public class AppliedBizConstants {

    public static long TIMEOUT = 10000L;

    public static int MAX_FIELD_SIZE = 20;

    public static int BIZNAME_LENGTH = 100;

    public static int BIZCOMPONENTS_LENGTH = 200;

    public static int FIELD_LENGTH = 50;

    public static int FIELD_SUM_LENGTH = 12000;

    public static int BIZREMARK_LENGTH=300;

    public static String ID_STR = "id";

    public static String BIZ_URI = "bizUri";

    public static String MENU_URI = "/appliedmodule/";

    public static AppliedBizManegeFieldBean ID_FIELD = new AppliedBizManegeFieldBean("id","ID");

    public static List<AppliedBizManegeFieldBean> PUBLIC_BIZ_FIELDS = new ArrayList<>();

    /**
     * 应用模块表名前缀
     */
    public static final String APPLIED_TABLE_NAME_PREFIX = "t_applied";

    public static Pattern pattern = Pattern.compile("\\b(?i)(and|exec|insert|select|grant|alter|delete|update|count|chr|mid|master|truncate|char|declare|or)\\b|(\\*|;|\\+|'|%)");


    public static String[] SQL_KEY_WORD = {
            "ADD", "ALL", "ALTER",
            "ANALYZE", "AND", "AS",
            "ASC", "ASENSITIVE", "BEFORE",
            "BETWEEN", "BIGINT", "BINARY",
            "BLOB", "BOTH", "BY",
            "CALL", "CASCADE", "CASE",
            "CHANGE", "CHAR", "CHARACTER",
            "CHECK", "COLLATE", "COLUMN",
            "CONDITION", "CONNECTION", "CONSTRAINT",
            "CONTINUE", "CONVERT", "CREATE",
            "CROSS", "CURRENT_DATE", "CURRENT_TIME",
            "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR",
            "DATABASE", "DATABASES", "DAY_HOUR",
            "DAY_MICROSECOND", "DAY_MINUTE", "DAY_SECOND",
            "DEC", "DECIMAL", "DECLARE",
            "DEFAULT", "DELAYED", "DELETE",
            "DESC", "DESCRIBE", "DETERMINISTIC",
            "DISTINCT", "DISTINCTROW", "DIV",
            "DOUBLE", "DROP", "DUAL",
            "EACH", "ELSE", "ELSEIF",
            "ENCLOSED", "ESCAPED", "EXISTS",
            "EXIT", "EXPLAIN", "FALSE",
            "FETCH", "FLOAT", "FLOAT4",
            "FLOAT8", "FOR", "FORCE",
            "FOREIGN", "FROM", "FULLTEXT",
            "GOTO", "GRANT", "GROUP",
            "HAVING", "HIGH_PRIORITY", "HOUR_MICROSECOND",
            "HOUR_MINUTE", "HOUR_SECOND", "IF",
            "IGNORE", "IN", "INDEX",
            "INFILE", "INNER", "INOUT",
            "INSENSITIVE", "INSERT", "INT",
            "INT1", "INT2", "INT3",
            "INT4", "INT8", "INTEGER",
            "INTERVAL", "INTO", "IS",
            "ITERATE", "JOIN", "KEY",
            "KEYS", "KILL", "LABEL",
            "LEADING", "LEAVE", "LEFT",
            "LIKE", "LIMIT", "LINEAR",
            "LINES", "LOAD", "LOCALTIME",
            "LOCALTIMESTAMP", "LOCK", "LONG",
            "LONGBLOB", "LONGTEXT", "LOOP",
            "LOW_PRIORITY", "MATCH", "MEDIUMBLOB",
            "MEDIUMINT", "MEDIUMTEXT", "MIDDLEINT",
            "MINUTE_MICROSECOND", "MINUTE_SECOND", "MOD",
            "MODIFIES", "NATURAL", "NOT",
            "NO_WRITE_TO_BINLOG", "NULL", "NUMERIC",
            "ON", "OPTIMIZE", "OPTION",
            "OPTIONALLY", "OR", "ORDER",
            "OUT", "OUTER", "OUTFILE",
            "PRECISION", "PRIMARY", "PROCEDURE",
            "PURGE", "RAID0", "RANGE",
            "READ", "READS", "REAL",
            "REFERENCES", "REGEXP", "RELEASE",
            "RENAME", "REPEAT", "REPLACE",
            "REQUIRE", "RESTRICT", "RETURN",
            "REVOKE", "RIGHT", "RLIKE",
            "SCHEMA", "SCHEMAS", "SECOND_MICROSECOND",
            "SELECT", "SENSITIVE", "SEPARATOR",
            "SET", "SHOW", "SMALLINT",
            "SPATIAL", "SPECIFIC", "SQL",
            "SQLEXCEPTION", "SQLSTATE", "SQLWARNING",
            "SQL_BIG_RESULT", "SQL_CALC_FOUND_ROWS", "SQL_SMALL_RESULT",
            "SSL", "STARTING", "STRAIGHT_JOIN",
            "TABLE", "TERMINATED", "THEN",
            "TINYBLOB", "TINYINT", "TINYTEXT",
            "TO", "TRAILING", "TRIGGER",
            "TRUE", "UNDO", "UNION",
            "UNIQUE", "UNLOCK", "UNSIGNED",
            "UPDATE", "USAGE", "USE",
            "USING", "UTC_DATE", "UTC_TIME",
            "UTC_TIMESTAMP", "VALUES", "VARBINARY",
            "VARCHAR", "VARCHARACTER", "VARYING",
            "WHEN", "WHERE", "WHILE",
            "WITH", "WRITE", "X509",
            "XOR","YEAR_MONTH", "ZEROFILL"
    };

    /**
     * 审批类型
     */
    public final static class AppliedExamineStatus {

        /**
         * 审批未提交
         */
        public final static int NOT_SUBMIT = 0;


        public static String get(int type) {

            if (type == NOT_SUBMIT) {
                return "未提交审批";
            } else {
                return ActivitiConstants.ExamineStatus.get(type);
            }

        }
    }

    static {
        PUBLIC_BIZ_FIELDS.add(new AppliedBizManegeFieldBean("examine_status","审批状态"));
        PUBLIC_BIZ_FIELDS.add(new AppliedBizManegeFieldBean("create_user_id","创建人ID"));
        PUBLIC_BIZ_FIELDS.add(new AppliedBizManegeFieldBean("create_by","创建人"));
        PUBLIC_BIZ_FIELDS.add(new AppliedBizManegeFieldBean("create_time","创建时间"));
        PUBLIC_BIZ_FIELDS.add(new AppliedBizManegeFieldBean("update_by","修改人"));
        PUBLIC_BIZ_FIELDS.add(new AppliedBizManegeFieldBean("update_time","修改时间"));
    }
}

package com.boe.bank.common.bean.activiti;

import lombok.Data;

/**
 * 已经执行的task中description字段前会加上描述标志，做辅助功能
 * @author caoxuhao
 */
@Data
public class ActivitiTaskDescriptionFlag {
	private boolean autoPass;
	private int passType;
}

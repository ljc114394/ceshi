package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
* @Description:文件件bean
* @author: zhaohaixia
* @date: 2020年10月22日 下午3:46:26
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "文件夹添加bean")
public class FolderBean {
	
	@ApiModelProperty(value = "主键id 修改时必传")
    private Integer id;
	
	@ApiModelProperty(value = "文件夹名称 必传")
    private String title;
	
	@ApiModelProperty(value = "文件夹级别，1一级，2二级  必传")
    private Integer level;
	
	@ApiModelProperty(value = "父文件夹id 一级文件夹传0即可  必传")
    private Integer parentId;
	
	@ApiModelProperty(value = "机构id 必传")
	private Long orgId;

}
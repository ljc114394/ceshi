package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * 设备计划DTO
 *
 * @author 10183279
 * @date 2020/10/19
 */
@ApiModel(value = "设备计划DTO")
@Data
public class EquipmentPlanDTO implements Serializable {

    private static final long serialVersionUID = -134593343441244758L;

    @ApiModelProperty(value = "计划id列表")
    private List<Integer> planIds;

    @ApiModelProperty(value = "删除的计划id列表")
    private List<Integer> delPlanIds;

    @ApiModelProperty(value = "类型 1：正常计划，2：插播计划")
    @NotNull(message = "类型不能为空")
    @Min(value = 1, message = "类型不正确")
    @Max(value = 2, message = "类型不正确")
    private Integer type;
}

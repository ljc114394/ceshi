package com.boe.bank.common.bean.productlibrarybean;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.net.URL;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/21 15:30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductLibraryExportBean {

    @ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "产品编号", index = 1)
    private String productNo;

    @ExcelProperty(value = "产品名称", index = 2)
    private String productName;

    @ExcelProperty(value = "产品类型", index = 3)
    private String productType;

    @ExcelProperty(value = "产品状态", index = 4)
    private String enableName;

    @ExcelIgnore
    private String portraitImgUrl;

    @ExcelProperty(value = "图片", index = 5)
    private URL url;






}

package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ActivitiOptUser {
	
	@ApiModelProperty(value = "流程实例id")
	private String processInstanceId;

	@ApiModelProperty(value = "任务id")
	private String taskId;

	@ApiModelProperty(value = "操作者id")
	private String reviewer;
	
	@ApiModelProperty(value = "意见")
	private String comment;
	
//	/**操作者所在组*/
//	private List<String> candidateGroups;
	
}

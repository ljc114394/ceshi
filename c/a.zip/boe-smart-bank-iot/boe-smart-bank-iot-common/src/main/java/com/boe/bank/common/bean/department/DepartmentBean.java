package com.boe.bank.common.bean.department;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:
* @author: zhaohaixia
* @date: 2020年9月28日 下午4:36:09
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "部门bean")
public class DepartmentBean {

	@ApiModelProperty(value = "部门主键id")
    private Integer id;
	
    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "所在机构id")
    private Integer orgId;
    
    @ApiModelProperty(value = "所在机构名称")
    private String orgName;

    @ApiModelProperty(value = "上级部门id")
    private Integer departmentId;
    
    @ApiModelProperty(value = "上级部门名称")
    private String departmentName;
    
    @ApiModelProperty(value = "是否有审批权限，0没有 1有")
    private Integer isAudit; 
    
    @ApiModelProperty(value = "备注")
    private String remark;
    
}

package com.boe.bank.common.bean.productlibrarybean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/21 15:30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MarketingStrategyOneBean {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "产品名称")
    private String productName;

    @ApiModelProperty(value = "启用状态 0禁用 1启用")
    private Integer enable;

    @ApiModelProperty(value = "产品类型：p001信用卡 p002借记卡")
    private String productType;

    @ApiModelProperty(value = "产品编号")
    private String productNo;

    @ApiModelProperty(value = "产品推荐策略  0智能算法推荐  1手动关联推荐")
    private Integer productTactics;

    @ApiModelProperty(value = "画像list")
    private List<MarketingPortraitBean> portraitList;

}

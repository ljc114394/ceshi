package com.boe.bank.common.bean.equipment;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.excel.annotation.ExcelIgnoreUnannotated;
import com.alibaba.excel.annotation.ExcelProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "设备运维日志显示对象")
@Data
@ExcelIgnoreUnannotated
public class EquipmentOperationLogVO implements Serializable {
	private static final long serialVersionUID = -7657959182892603430L;

	@ApiModelProperty(value = "id")
    private Integer id;
    
	@ApiModelProperty(value = "设备mac")
	@ExcelProperty(value = "设备名称", index = 2)
    private String mac;
    
	@ApiModelProperty(value = "CPU占用率")
	@ExcelProperty(value = "CPU占用率", index = 6)
    private String cpu;
    
	@ApiModelProperty(value = "内存可用量")
	@ExcelProperty(value = "内存可用量", index = 7)
    private String memory;
    
	@ApiModelProperty(value = "磁盘可用空间")
	@ExcelProperty(value = "磁盘可用空间", index = 8)
    private String disk;
    
	@ApiModelProperty(value = "设备名称")
	@ExcelProperty(value = "设备名称", index = 0)
    private String name;
    
	@ApiModelProperty(value = "IP地址")
	@ExcelProperty(value = "IP地址", index = 1)
    private String ipAddress;
    
	@ApiModelProperty(value = "机构名称")
	@ExcelProperty(value = "所属机构", index = 3)
    private String orgName;
    
	@ApiModelProperty(value = "区域名称")
	@ExcelProperty(value = "所属区域", index = 4)
    private String areaName;
    
	@ApiModelProperty(value = "设备类型名称")
	@ExcelProperty(value = "设备类型", index = 5)
    private String equType;
    
	@ApiModelProperty(value = "日志产生时间")
    private String logTime;
    
	@ApiModelProperty(value = "日志存储在服务器上面的地址")
    private String logUrl;
    
	@ApiModelProperty(value = "创建时间")
    private Date createTime;
    
}

package com.boe.bank.common.base;

import com.boe.bank.common.constant.BaseEnums;
import com.boe.bank.common.constant.MsgReturnEnum;

import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName Result
 * @Description TODO
 * @Author shaozhenjun
 * @Date 19-7-9 下午4:13
 * @Version 1.0
 */
@Data
public class Result<T> implements Serializable {

    private static final long serialVersionUID = 397032924074207632L;
    private boolean success = true;
    private Integer status;
    private Integer code;
    private String message;
    private T data;

    public Result(){}

    public Result(boolean success) {
        this.success = success;
    }

    public Result(boolean success, Integer code) {
        this.success = success;
        this.code = code;
    }

    public Result(boolean success, Integer  code, String message) {
        this.success = success;
        this.code = code;
        this.message = message;
    }

    public Result(boolean success, Integer status, Integer code, String message) {
        this.success = success;
        this.status = status;
        this.code = code;
        this.message = message;
    }

    public Result(boolean success, Integer status, Integer code, String message, T data) {
        this.success = success;
        this.status = status;
        this.code = code;
        this.message = message;
        this.data = data;
    }
    public static <T> Result<T> success() {
        return new Result<T>(true, BaseEnums.SUCCESS.code(),BaseEnums.SUCCESS.message());
    }

    public static <T> Result<T> success(String msg) {
        return new Result<T>(true, BaseEnums.SUCCESS.code(), msg);
    }

    public static <T> Result<T> success(Integer code, String msg) {
        return new Result<T>(true, code, msg);
    }

    public static <T> Result<T> successWithStatus(Integer status) {
        return new Result<T>(true, status);
    }

    public static <T> Result<T> successWithStatus(Integer status, String msg) {
        return new Result<T>(true, status, BaseEnums.SUCCESS.code(), msg);
    }

    public static <T> Result successWithData(T data) {
        return new Result<T>(true, null, BaseEnums.SUCCESS.code(), BaseEnums.SUCCESS.message(), data);
    }

    public static <T> Result<T> successWithData(String msg, T data) {
        return new Result<T>(true, null, BaseEnums.SUCCESS.code(), msg, data);
    }

    public static <T> Result<T> successWithData(Integer code, String msg, T data) {
        return new Result<T>(true, null, code, msg, data);
    }

    //failure
    public static <T> Result<T> failure() {
        return new Result<T>(false,BaseEnums.FAILURE.code(),BaseEnums.FAILURE.message ());
    }

    public static <T> Result<T> failure(String msg) {
        return new Result<T>(false, BaseEnums.FAILURE.code(), msg);
    }

    public static <T> Result<T> failure(Integer code, String msg) {
        return new Result<T>(false, code, msg);
    }

    public static <T> Result<T> failure(MsgReturnEnum en) {
        return new Result<T>(false, en.code(), en.message());
    }
    
    public static <T> Result<T> failureWithStatus(Integer status) {
        return new Result<T>(false, status, BaseEnums.FAILURE.code(), null);
    }

    public static <T> Result<T> failureWithStatus(Integer status, String msg) {
        return new Result<T>(false, status, null, msg);
    }

    public static <T> Result<T> failureWithData(T data) {
        return new Result<T>(false, null, null, BaseEnums.FAILURE.message(), data);
    }

    public static <T> Result<T> failureWithData(T data, Integer code, String msg) {
        return new Result<T>(false, null, code, msg, data);
    }

    public static <T> Result<T> paramError(String msg) {
        return new Result<T>(false, null, BaseEnums.PARAMETER_INVALID.code(), msg);
    }



}

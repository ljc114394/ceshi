package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 流程图结合计划业务的类
 * @author caoxuhao
 */
@Data
public class ActivitiProcessPlanVo extends ActivitiProcessOrgVo {
	
	@ApiModelProperty(value = "计划名称")
	private String planName;
	
	@ApiModelProperty(value = "所属机构")
	private String orgName;
	
	@ApiModelProperty(value = "计划的备注")
	private String planRemark;
}

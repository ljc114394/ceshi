package com.boe.bank.common.bean.logbean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/13 14:26
 */
@Data
@ApiModel(description = "首页-系统日志bean")
public class SysLogBean {

    @ApiModelProperty(value = "用户账号")
    private String  userName;

    @ApiModelProperty(value = "机构名称")
    private String  orgName;

    @ApiModelProperty(value = "调用时间")
    private String createTime;

    @ApiModelProperty(value = "操作")
    private String  operation;


}

package com.boe.bank.common.bean.dictbean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SysDictionariesInfoBean {

	@ApiModelProperty(value = "主键id")
	private Integer id;

	/**
	 * 字典名称
	 */
	@ApiModelProperty(value = "字典名称")
	private String title;
	/**
	 * 编码
	 */
	@ApiModelProperty(value = "编码")
	private String code;
	/**
	 * 值
	 */
	@ApiModelProperty(value = "值")
	private String codeValue;

	/**
	 * 禁用启用
	 */
	@ApiModelProperty(value = "禁用启用")
	private Integer isEnabled;

	/**
	 * 父级ID
	 */
	@ApiModelProperty(value = "父id")
	private Integer parentId;

	 /**
	  * 备注
	  */
	@ApiModelProperty(value = "备注")
	private String remark;
	@ApiModelProperty(value = "创建人")
	private String createBy;
	@ApiModelProperty(value = "创建时间")
	private String createTime;
	@ApiModelProperty(value = "修改人")
	private String updateBy;
	@ApiModelProperty(value = "修改时间")
	private String updateTime;

}

package com.boe.bank.common.entity.equipment;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.Data;

/**
 * 设备日志
 *
 * @author 10085188
 * @date 2020/11/5
 */
@Data
@TableName("t_equipment_log")
public class EquipmentLog implements Serializable {

	private static final long serialVersionUID = -4326789453089193665L;
	
	@TableId(type = IdType.AUTO)
    private Integer id;
	
    /**
     * 日志级别
     * 0:Debug 1:Info 2:Warn 3:Error 4:Fatal
     */
    @TableField(value = "level")
    private Integer level;
    
    /**
     * 日志内容
     */
    @TableField(value = "message")
    private String message;
    
    /**
     * 日志产生时间
     */
    @TableField(value = "time")
    private String time;
    
    /**
     * 日志存储在服务器上面的地址
     */
    @TableField(value = "log_url")
    private String logUrl;
    
    /**
     * 设备id
     */
    @TableField(value = "equipment_id")
    private Integer equipmentId;
    
    /**
     * 设备mac
     */
    @TableField(value = "mac")
    private String mac;
    
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime createTime;
    
}

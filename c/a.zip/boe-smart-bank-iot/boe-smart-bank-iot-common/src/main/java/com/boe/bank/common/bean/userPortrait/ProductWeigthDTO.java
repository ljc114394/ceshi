package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用户画像-权重修改 交互页面
 * @Author: lijianglong
 * @Data:2020/12/7
 */
@Data
public class ProductWeigthDTO {

    @ApiModelProperty(value = "用户画像主键id")
    private Integer id;

    @ApiModelProperty(value = "权重")
    private Integer weight;

    @ApiModelProperty(value = "被替换的用户画像主键id")
    private Integer replaceId;

    @ApiModelProperty(value = "权重被替换的值")
    private Integer weigthReplace;

}

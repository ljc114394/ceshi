package com.boe.bank.common.bean.activiti;

import lombok.Data;

/**
 * 审批流程分页查询数据库查出的实体类
 * @author caoxuhao
 */
@Data
public class ActivitiProcessDo {
	private Integer busniessType;
	private String name;
	private Integer id;
	private String createBy;
	private Integer status;
}

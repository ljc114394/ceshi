package com.boe.bank.common.constant;

/**
* @Description:字典管理常量
* @author: lvjiacheng
* @date: 2021年1月26日 16:58:06
 */
public class DictConst {
	/**
	 * 禁用
	 */
    public static final int IS_DISABLE = 0;
    /**
     * 启用
     */
    public static final int IS_ENABLE = 1;


}

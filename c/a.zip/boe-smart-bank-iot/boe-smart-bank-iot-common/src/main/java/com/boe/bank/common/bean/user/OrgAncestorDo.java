package com.boe.bank.common.bean.user;

import lombok.Data;

@Data
public class OrgAncestorDo {
	private Long parent;
	private String ancestor;
}

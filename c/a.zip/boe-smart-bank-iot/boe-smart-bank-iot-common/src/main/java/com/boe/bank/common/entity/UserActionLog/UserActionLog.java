package com.boe.bank.common.entity.UserActionLog;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserActionLog extends BaseEntity implements Serializable {

    private Integer id;//主键id

    private String faceId;//人脸id
    
    private Integer conditonActionType;//属性行为 1:访问网点数 2:查看应用累计时间 3:点击应用二维码次数

    private Integer actionProductId;//操作行为对应的产品id
    
}
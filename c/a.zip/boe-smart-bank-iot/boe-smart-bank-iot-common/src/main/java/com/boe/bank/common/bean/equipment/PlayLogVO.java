package com.boe.bank.common.bean.equipment;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 播放日志
 *
 * @author 10183279
 * @date 2020/11/6
 */
@ApiModel(value = "播放日志")
@Data
public class PlayLogVO implements Serializable {

    private static final long serialVersionUID = 5518331121479872989L;

    @ApiModelProperty(value = "计划名称")
    @ExcelProperty("计划名称")
    private String title;

    @ApiModelProperty(value = "计划开始时间")
    @ExcelProperty("计划开始时间")
    private String beginTime;

    @ApiModelProperty(value = "计划结束时间")
    @ExcelProperty("计划结束时间")
    private String endTime;

    @ApiModelProperty(value = "计划时间")
    @ExcelProperty("计划时间")
    private String planTime;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty("创建人")
    private String createBy;

    @ApiModelProperty(value = "创建时间")
    @ExcelProperty("创建时间")
    private String createTime;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty("修改人")
    private String updateBy;

    @ApiModelProperty(value = "修改时间")
    @ExcelProperty("修改时间")
    private String updateTime;

    @ApiModelProperty(value = "实际播放时间")
    @ExcelProperty("实际播放时间")
    private String playTime;
}

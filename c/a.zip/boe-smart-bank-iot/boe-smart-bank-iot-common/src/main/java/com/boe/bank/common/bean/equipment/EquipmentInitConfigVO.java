package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备初始化配置
 *
 * @author 10183279
 * @date 2020/10/23
 */
@ApiModel(value = "设备初始化配置")
@Data
public class EquipmentInitConfigVO implements Serializable {

    private static final long serialVersionUID = -7433932515304080414L;

    @ApiModelProperty(value = "开机时间")
    private String startupTime;

    @ApiModelProperty(value = "关机时间")
    private String shutdownTime;

    @ApiModelProperty(value = "音量")
    private Integer volume;

    @ApiModelProperty(value = "下载速度，kb/s")
    private Integer downloadSpeed;

    @ApiModelProperty(value = "下载时间设置")
    private DownloadTimeVO downloadTime;

    @ApiModelProperty(value = "上传时间设置")
    private UploadTimeVO uploadTime;

    @ApiModelProperty(value = "socket配置")
    private SocketVO socketServer;
}

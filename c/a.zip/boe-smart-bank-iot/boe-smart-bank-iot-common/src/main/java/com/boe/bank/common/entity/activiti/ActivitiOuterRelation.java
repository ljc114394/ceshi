package com.boe.bank.common.entity.activiti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.boe.bank.common.base.BaseEntity;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 审批单关联表
 * @author caoxuhao
 */
@Data
public class ActivitiOuterRelation implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5305461770259135321L;
	
	private Integer id;
	private Integer busniessType;//业务类型 类别 1素材 2计划 3设备 4应用
	private Integer outerId;//其他表主键id
	private String processInstanceId;//activiti流程实例id
    private Integer outerType;//二级类型
    private String showId;//展示用id

	/**
     * 创建时间
     */
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime createTime;
    
    /**
     * 创建人id
     */
    private Long createUserId;
    
    /**
     * 是否删除 0 否 1 是
     */
    private Boolean isDelete;
    
    /**审批类型id*/
    private Integer examineId;
}

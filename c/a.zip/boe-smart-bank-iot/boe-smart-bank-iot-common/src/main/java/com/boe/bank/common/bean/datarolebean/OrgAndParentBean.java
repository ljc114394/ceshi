package com.boe.bank.common.bean.datarolebean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/3 9:56
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrgAndParentBean {

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "机构层级的全路径")
    private String ancestor;


}

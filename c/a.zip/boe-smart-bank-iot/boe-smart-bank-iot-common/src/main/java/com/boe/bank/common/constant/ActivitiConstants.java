package com.boe.bank.common.constant;

import com.google.common.collect.Sets;

import java.util.Set;

/**
 * 流程图常量
 * @author caoxuhao
 */
public class ActivitiConstants {
	
	public final static class PassType {
		/**任意一人通过*/
		public final static int any = 1;
		
		/**所有人都通过*/
		public final static int all = 2;
		
		/**每个部门任意1人通过*/
		public final static int department = 3;
	}
	
	public final static class ReviewerType {
		/**按选定的人或组织架构*/
		public final static int userOrGroup = 1;
		
		/**按角色*/
		public final static int role = 2;
		
	}
	
	public final static class Status {
		/**启用*/
		public final static int ok = 0;
		
		/**停用*/
		public final static int suspend = 1;
		
		public static String get(int status) {
			switch (status) {
			case ok:
				return "启用";
			case suspend:
				return "停用";
			default:
				break;
			}
			return "";
		}
	}
	
	/**业务类型 */
	public final static class BusniessType {
		/**素材*/
		public final static int material = 1;
		/**计划*/
		public final static int plan = 2;
		/**设备*/
		public final static int device = 3;
		/**应用*/
		public final static int application = 4;

		public static String get(int type) {
			switch (type) {
			case material:
				return "素材审批";
			case plan:
				return "计划审批";
			case device:
				return "设备审批";
			case application:
				return "应用审批";
			default:
				break;
			}
			return "";
		}
	}
	
	/**审核状态*/
	public static class ExamineStatus{
		/**待审核、审核中*/
		public static final int undo = 1;
		
		/**通过*/
		public static final int pass = 2;
		
		/**拒绝*/
		public static final int reject = 3;

		public static String get(int type) {
			switch (type) {
				case undo:
					return "审核中";
				case pass:
					return "通过";
				case reject:
					return "拒绝";
				default:
					break;
			}
			return "";
		}
	}
	
	/**选角色后的附加条件*/
	public static class RoleAdditional{
		
		/**1与发起人同一部门*/
		public static final int sameDep = 1;
		
		/**2与发起人同一机构*/
		public static final int sameOrg = 2;
		
		/**3发起人的上级机构*/
		public static final int allUp = 3;
		
		/**4发起人的下级机构*/
		public static final int allDown = 4;
	}
	
	/**activiti 系统节点*/
	public static class Node{
		public static final String start = "start";
		public static final String successEnd = "successEnd";
		public static final String rejectEnd = "rejectEnd";
		public static final String abandonedEnd = "abandonedEnd";
	}

	public static class ActivitiStatusType{

		/**1流转*/
		public static final int liuZhuan = 1;

		/**2结束*/
		public static final int jieShu = 2;

		/**3作废*/
		public static final int zuoFei = 3;

		public static String get(int type) {
			switch (type) {
				case liuZhuan:
					return "流转";
				case jieShu:
					return "结束";
				case zuoFei:
					return "作废";
				default:
					break;
			}
			return "";
		}
	}

	public static class ProcessStatusType{

		/**1通过*/
		public static final int tongGuo = 1;

		/**2拒绝*/
		public static final int juJue = 2;

		/**3待处理*/
		public static final int daiChuLi = 3;

		/**4转办*/
		public static final int zhuanBan = 4;

		public static String get(int type) {
			switch (type) {
				case tongGuo:
					return "通过";
				case juJue:
					return "拒绝";
				case daiChuLi:
					return "待处理";
				case zhuanBan:
					return "转办";
				default:
					break;
			}
			return "";
		}

	}
	
}

package com.boe.bank.common.bean.logbean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/5 18:10
 */
@Data
@ApiModel(description = "登录日志bean")
public class LoginlogSearchBean extends PageBean {

    @ApiModelProperty(value = "登录ip")
    @Emoticon
    private String  ip;

    @ApiModelProperty(value = "登录用户")
    @Emoticon
    private String  userName;

    @ApiModelProperty(value = "机构id")
    private Integer  orgId;

    @JsonIgnore
    private List<String> orgIdList;

    //限定导出的时间戳
    @JsonIgnore
    private Long exportTime;


}

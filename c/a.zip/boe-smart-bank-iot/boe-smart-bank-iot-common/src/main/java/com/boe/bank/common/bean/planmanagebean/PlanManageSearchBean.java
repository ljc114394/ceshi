package com.boe.bank.common.bean.planmanagebean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/13 8:53
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "计划管理-查询bean")
public class PlanManageSearchBean extends PageBean {

    @ApiModelProperty(value = "计划名称")
    @Emoticon
    private String title;

    @ApiModelProperty(value = "提交人")
    @Emoticon
    private String createBy;

    @ApiModelProperty(value = "修改人")
    @Emoticon
    private String updateBy;

    @ApiModelProperty(value = "审核状态", hidden = true)
    private Integer state;

    @ApiModelProperty(value = "计划的屏幕区域数", hidden = true)
    private Integer areaNum;

    @ApiModelProperty(value = "机构ids", hidden = true)
    private List<Integer> orgIdList;

    @ApiModelProperty(value = "计划ids", hidden = true)
    private List<Integer> idList;

    @ApiModelProperty(value = "mac集合")
    private List<String> mac;

    @ApiModelProperty(value = "设置计划传1，插播计划传2")
    private Integer type;
    
}

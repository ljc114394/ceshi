package com.boe.bank.common.bean.logbean;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 审批导出
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:27
 */
@Data
@ApiModel(description = "审批导出bean")
public class LogExportApprovalBean {

    @ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "操作用户", index = 1)
    private String createBy;

    @ExcelIgnore
    private Integer orgId;

    @ExcelProperty(value = "所属机构", index = 2)
    private String orgName;

    @ExcelProperty(value = "业务类型", index = 3)
    private String  busniessType;

    @ExcelProperty(value = "审批单号", index = 4)
    private String approvalNo;

    @ExcelProperty(value = "审批类型", index = 5)
    private String approvalType;

    @ExcelProperty(value = "操作内容", index = 6)
    private String operationContent;

    @ExcelProperty(value = "审批结果", index = 7)
    private String approvalResult;

    @ExcelProperty(value = "操作时间", index = 8)
    private String createTime;
}

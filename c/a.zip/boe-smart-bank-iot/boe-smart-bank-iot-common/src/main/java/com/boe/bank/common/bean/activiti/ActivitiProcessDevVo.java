package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 流程图结合设备业务的类
 * @author caoxuhao
 */
@Data
public class ActivitiProcessDevVo extends ActivitiProcessOrgVo {
	
	@ApiModelProperty(value = "设备名称")
	private String deviceName;
	
	@ApiModelProperty(value = "组织名称")
	private String orgName;
	
	@ApiModelProperty(value = "设备类型")
	private String deviceType;
}

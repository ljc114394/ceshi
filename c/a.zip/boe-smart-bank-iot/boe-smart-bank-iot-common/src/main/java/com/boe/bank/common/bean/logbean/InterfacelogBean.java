package com.boe.bank.common.bean.logbean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/5 18:10
 */
@Data
@ApiModel(description = "日志bean")
public class InterfacelogBean {

    @ApiModelProperty(value = "接口名称")
    private String  title;

    @ApiModelProperty(value = "调用时间")
    private String createTime;

    @ApiModelProperty(value = "调用ip")
    private String  ip;

    @ApiModelProperty(value = "接口关键参数")
    private String  param;
}

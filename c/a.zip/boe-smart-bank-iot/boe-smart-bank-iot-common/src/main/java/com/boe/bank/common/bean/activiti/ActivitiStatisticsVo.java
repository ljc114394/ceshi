package com.boe.bank.common.bean.activiti;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ActivitiStatisticsVo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 657444822531909552L;

	@ApiModelProperty(value = "已审核总数量")
	private Integer allExaminedCount;
	
	@ApiModelProperty(value = "待审核总数量")
	private Integer allToDoCount;
	
	@ApiModelProperty(value = "各业务审核详情")
	private List<ActivitiStatisticsBusniessVo> list;
}

package com.boe.bank.common.entity.userStayLog;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserStayLog extends BaseEntity implements Serializable {

    private Integer id;//主键id

    private String faceId;//人脸id

    private Integer createAt;//时间戳 秒

}
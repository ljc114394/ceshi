package com.boe.bank.common.bean.dictbean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class SysDictionariesBean {

	/**
	 * 字典名称
	 */
	@ApiModelProperty(value = "字典名称")
	private String title;
	/**
	 * 编码
	 */
	@ApiModelProperty(value = "编码")
	private String code;
	/**
	 * 值
	 */
	@ApiModelProperty(value = "值")
	private String codeValue;

	/**
	  * 父级ID
	  */
	@ApiModelProperty(value = "父级ID")
	private Integer parentId;
	 /**
	  * 备注
	  */
	@ApiModelProperty(value = "备注")
	private String remark;

 

}

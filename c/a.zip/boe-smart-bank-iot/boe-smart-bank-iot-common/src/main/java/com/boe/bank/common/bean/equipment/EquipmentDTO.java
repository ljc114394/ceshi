package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 设备DTO
 *
 * @author 10183279
 * @date 2020/10/13
 */
@ApiModel(value = "设备DTO")
@Data
public class EquipmentDTO implements Serializable {

    private static final long serialVersionUID = 2105881042877278905L;

    @ApiModelProperty(value = "设备名称")
    @NotBlank(message = "设备名称不能为空")
    private String name;

    @ApiModelProperty(value = "ip地址")
    private String addressIp;

    @ApiModelProperty(value = "MAC地址")
    @NotBlank(message = "MAC地址不能为空")
    private String mac;

    @ApiModelProperty(value = "机构id")
    @NotNull(message = "机构不能为空")
    private Long orgId;

    @ApiModelProperty(value = "区域id")
    @NotNull(message = "区域不能为空")
    private Integer areaId;

    @ApiModelProperty(value = "设备类型id")
    @NotNull(message = "设备类型id不能为空")
    private Integer typeId;

    @ApiModelProperty(value = "厂商信息")
    private String equipInfo;
}

package com.boe.bank.common.bean.material;

import com.boe.bank.common.annotation.Emoticon;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:素材管理分页-计划管理-添加素材bean
* @author: lvjiacheng
* @date: 2020年12月09日 下午17:20:09
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材管理分页-计划管理-添加素材bean")
public class MaterialPlanBean {

    @ApiModelProperty(value = "素材名称")
    @Emoticon
    private String title;

    @ApiModelProperty(value = "标签名称")
    @Emoticon
    private String labelTitle;

    @ApiModelProperty(value = "审核状态，1审批中 2通过 3.拒绝")
    private Integer status;
    
    @ApiModelProperty(value = "页码")
    private Integer pageNum;
    
    @ApiModelProperty(value = "页长度")
    private Integer pageSize;
    
    @ApiModelProperty(value = "机构id")
	private Long orgId;
    
    @ApiModelProperty(value = "父文件夹id 如果不属于文件夹下的素材，则传0即可 必传")
    private Integer parentId;

    @ApiModelProperty(value = "计划id")
    private Integer planId;
    
}

package com.boe.bank.common.entity.userinfo;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo  extends BaseEntity implements Serializable {

    //用户id
    private Integer id;

    //姓名
    private String name;

    //账号
    private String username;

    //所属角色
    private String role;

    //所属角色id
    private String roleId;

    //部门名称
    private String departmentName;

    //部门id
    private Integer  departmentId;

    //岗位名称
    private String postName;

    //机构id
    private Integer orgId;

    //机构名称
    private String orgName;

    //手机号码
    private String  phoneNum;

    //状态 禁用启用
    private Integer isEnabled;

    //工号
    private String  workNum;

    //备注
    private String remark;

    //密码
    private String password;

}

package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用户画像-权重修改校验 交互页面
 * @Author: lijianglong
 * @Data:2020/12/7
 */
@Data
public class ProductWeigthVO {

    @ApiModelProperty(value = "已有用户画像主键id")
    private Integer replaceId;

    @ApiModelProperty(value = "用户画像名称")
    private String portraitName;

    @ApiModelProperty(value = "已有权重值")
    private Integer weightReplace;

    @ApiModelProperty(value = "是否重复：true：重复   false：不重复")
    private boolean isReplace;

}

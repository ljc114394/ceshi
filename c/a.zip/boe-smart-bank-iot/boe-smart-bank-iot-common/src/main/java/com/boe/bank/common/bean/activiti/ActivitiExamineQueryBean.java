package com.boe.bank.common.bean.activiti;

import com.boe.bank.common.base.PageBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ActivitiExamineQueryBean extends PageBean{
	
	@ApiModelProperty(value = "业务类型:  1素材 2计划 3设备 4应用")
	private Integer busniessType;//
	
	@ApiModelProperty(value = "审批类型")
	private String examineType;
	
	@ApiModelProperty(value = "审批类型状态： 0启用 1停用")
	private Integer status;
	
	@ApiModelProperty(value = "审批类型编码")
	private Integer id;
	
	@ApiModelProperty(value = "制定人员")
	private String createBy;
}

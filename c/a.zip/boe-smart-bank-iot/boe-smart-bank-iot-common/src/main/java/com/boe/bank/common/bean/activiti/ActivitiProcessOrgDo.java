package com.boe.bank.common.bean.activiti;

import java.util.Date;

import lombok.Data;

/**
 * activiti流程返回结果数据库查出给service用
 * @author caoxuhao
 */
@Data
public class ActivitiProcessOrgDo {
	
	/**流程结束状态*/
	private String eai;
	
	/**审批单号*/
	private String processInstanceId;
	
	/**提交时间*/
	private Date createTime;
	
	/**创建人id*/
	private Long createUserId;
	
	/**备注*/
	private String remark;
	
	/**外部表id*/
	private Integer outerId;

	/**处理状态*/
	private String processStatus;

	/**二级类型*/
	private Integer outerType;

	/**展示用id*/
	private String showId;

	/**展示用id*/
	private String taskId;

}

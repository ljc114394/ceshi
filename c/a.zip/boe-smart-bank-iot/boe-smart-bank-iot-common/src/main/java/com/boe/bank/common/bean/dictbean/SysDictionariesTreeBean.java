package com.boe.bank.common.bean.dictbean;


import cn.hutool.core.date.DateTime;
import com.boe.cloud.megarock.javabean.TreeNode;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SysDictionariesTreeBean implements TreeNode<SysDictionariesTreeBean> {
	/**
	 * 主键ID
	 */
	@ApiModelProperty(value = "主键ID")
	private Long id;
	/**
	 * 字典名称
	 */
	@ApiModelProperty(value = "字典名称")
	private String title;
	/**
	 * 值
	 */
	@ApiModelProperty(value = "值")
	private String codeValue;

	@ApiModelProperty(value = "子节点字典信息")
	private List<SysDictionariesTreeBean> children;

	/**
	 * 父id
	 */
	@ApiModelProperty(value = "父id")
	private Long parentId;

	/**
	 * 水平
	 */
	@ApiModelProperty(value = "水平")
	private Integer level;
}

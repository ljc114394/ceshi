package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
* @Description:素材管理添加、修改bean
* @author: zhaohaixia
* @date: 2020年10月13日 上午11:25:10
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材添加、编辑bean")
public class MaterialBean {
	
	@ApiModelProperty(value = "素材主键id 编辑时必传")
    private Integer id;
	
	@ApiModelProperty(value = "标签id")
    private Integer lableId;

	@ApiModelProperty(value = "素材名称")
    private String title;
	
	@ApiModelProperty(value = "类型，1图片资源，2视频资源 3文本信息  4web资源5文档管理 6.应用程序")
    private Integer type;
	
	@ApiModelProperty(value = "type为6时，表示程序参数  其他素材类型无需传")
    private String programEntry;
	
	@ApiModelProperty(value = "审批类型id")
    private Integer approvalType;
    /**
     * type为1或者2，表示缩略图名称，前台不需要传；type为3，表示web地址；type为4，表示文本内容；type为5，表示文档名称；type为6，表示程序入口
     */
	@ApiModelProperty(value = "图片，pdf，视频，应用传路径，web传web地址，文本内容传内容")
    private String content;
	
	@ApiModelProperty(value = "机构id")
	private Long orgId;
	
	@ApiModelProperty(value = "父文件夹id")
    private Integer parentId;
	/**
	 * 文件大小
	 */
	@ApiModelProperty(value = "上传文件返回的size")
    private Integer size;
    /**
     * 文件md5值
     */
	@ApiModelProperty(value = "上传文件返回的md5")
    private String md5;

	/**
	 * 自定义过期时间
	 */
	@ApiModelProperty(value = "过期时间 永久有效传‘--’，时间传字符串2020-11-11")
	private String valTime;
	
}
package com.boe.bank.common.bean.activiti;

import com.boe.bank.common.base.PageBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 查询activiti流程的请求参数
 * @author caoxuhao
 */
@Data
public class ActivitiProcessQueryReq  extends PageBean{
	
	@ApiModelProperty(value = "用户id")
	private Long userId;

	@ApiModelProperty(value = "单据状态：1流转，2结束，3作废。 全部则不传")
	private Integer activitiStatus;

	@ApiModelProperty(value = "处理状态：1通过，2拒绝，3待处理，4转办。 全部则不传")
	private Integer processStatus;

	@ApiModelProperty(value = "模糊查询")
	private String key;
}

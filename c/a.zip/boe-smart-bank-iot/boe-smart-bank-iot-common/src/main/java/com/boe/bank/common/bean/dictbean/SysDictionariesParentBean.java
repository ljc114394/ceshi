package com.boe.bank.common.bean.dictbean;

import lombok.Data;

@Data
public class SysDictionariesParentBean {

    private Integer id;

	private String code;

	private String codeValue;

	private Integer childId;

	private String childValue;
 

}

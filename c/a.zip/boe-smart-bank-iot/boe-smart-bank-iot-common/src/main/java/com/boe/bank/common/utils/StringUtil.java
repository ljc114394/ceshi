package com.boe.bank.common.utils;

import com.google.common.collect.Lists;

import cn.hutool.core.lang.UUID;

import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Type;
import java.util.List;
import java.util.function.Function;

/**
 * 字符串操作工具类
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/11 14:17
 */
public class StringUtil {

    /**
     * 把字符串按 分隔符 转换成int 数组
     *
     * @param str 拼接的字符串
     * @param tag 分隔符
     * @return
     */
    public static List<Integer> str2IntList(String str, String tag) {
        List<Integer> list = Lists.newArrayList();
        if (StringUtils.isNotBlank(str)) {
            String[] strArr = str.split(tag);
            for (int i = 0; i < strArr.length; i++) {
                if (StringUtils.isNotBlank(strArr[i])) {
                    list.add(Integer.parseInt(strArr[i]));
                }
            }
        }
        return list;
    }

    /**
     * 将obj转换成非null的字符串
     *
     * @param obj
     * @return
     */
    public static String getNotBlankStr(Object obj) {
        if (obj == null) {
            return "";
        }
        if (obj instanceof Boolean) {
            if (Boolean.parseBoolean(String.valueOf(obj))) {
                return "1";
            } else {
                return "0";
            }
        } else {
            return String.valueOf(obj);
        }
    }

    /**
     * 将动态参数拼接为字符串
     * @param args
     * @return
     */
    public static String appendToStr(Object... args) {
        StringBuffer sb = new StringBuffer();
        for (Object obj : args) {
            sb.append(obj);
        }
        return sb.toString();
    }
    
    /**
     * 获取uuid
     * @return
     */
    public static String getUUID() {
    	return UUID.randomUUID().toString().replaceAll("-", "");
    }
    
    /**
     * 把字符串按 分隔符 转换成指定类型 数组, 目前仅支持 （String, Long, Integer）
     * @param str 拼接的字符串
     * @param tag 分隔符		默认","号
     * @return
     * @throws Exception 
     */
    public static <T> List<T> str2List(String str, Class<T> clz) {
    	return str2List(str, ",", clz, null);
    }
    
    /**
     * 把字符串按 分隔符 转换成指定类型 数组, 目前仅支持 （String, Long, Integer）
     * @param str 拼接的字符串
     * @param tag 分隔符
     * @return
     * @throws Exception 
     */
    public static <T> List<T> str2List(String str, String tag, Class<T> clz) {
    	return str2List(str, tag, clz, null);
    }
    
    /**
     * 把字符串按 分隔符 转换成指定类型 数组, 支持自定义转化方式
     * @param str 拼接的字符串
     * @param tag 分隔符
     * @return
     */
    @SuppressWarnings("unchecked")
	public static <T> List<T> str2List(String str, String tag, Class<T> clz, Function<String, T> f) {
    	
    	if(clz == null || StringUtils.isEmpty(tag) || StringUtils.isEmpty(str))
    		return Lists.newArrayList();
    	
        List<T> list = Lists.newArrayList();
        String[] strArr = str.split(tag);
        for (int i = 0; i < strArr.length; i++) {
            if (StringUtils.isEmpty(strArr[i])) {
                continue;
            }
            
            String s = strArr[i];
            if(StringUtils.isEmpty(s))
            	continue;
            
            Type type = (Type)clz;
            if(type == String.class)
            	list.add((T)s);
            else if(type == Integer.class)
            	list.add((T)(Integer.valueOf(s)));
            else if(type == Long.class)
            	list.add((T)(Long.valueOf(s)));
            else {
            	if(f == null)
            		throw new RuntimeException("str2List change error, no custom function");
            	list.add(f.apply(s));
            }
        }
        
        return list;
    }
    
}

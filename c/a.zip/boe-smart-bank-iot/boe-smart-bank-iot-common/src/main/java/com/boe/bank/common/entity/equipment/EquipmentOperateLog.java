package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备操作日志
 *
 * @author 10183279
 * @date 2020/10/28
 */
@Data
@TableName("t_equipment_operate_log")
public class EquipmentOperateLog implements Serializable {

    private static final long serialVersionUID = 1220954734388291179L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 操作用户
     */
    @TableField(value = "operate_user")
    private String operateUser;
    /**
     * 所属机构
     */
    @TableField(value = "org_name")
    private String orgName;
    /**
     * 操作类型
     */
    @TableField(value = "type")
    private String type;
    /**
     * 操作内容
     */
    @TableField(value = "content")
    private String content;
    /**
     * 操作时间
     */
    @TableField(value = "operate_time")
    private String operateTime;
}

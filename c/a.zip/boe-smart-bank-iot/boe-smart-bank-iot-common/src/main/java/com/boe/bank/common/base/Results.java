package com.boe.bank.common.base;

import com.boe.bank.common.constant.BaseEnums;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @ClassName Result
 * @Description TODO
 * @Author shaozhenjun
 * @Date 19-7-9 下午4:13
 * @Version 1.0
 */
@Data
public class Results<T> implements Serializable {

    private static final long serialVersionUID = 397032924074207632L;
    private boolean success = true;
    private Integer status;
    private Integer code;
    private String message;
    private List<T> data;

    public Results(){}

    public Results(boolean success) {
        this.success = success;
    }

    public Results(boolean success, Integer code) {
        this.success = success;
        this.code = code;
    }

    public Results(boolean success, Integer  code, String message) {
        this.success = success;
        this.code = code;
        this.message = message;
    }

    public Results(boolean success, Integer status, Integer code, String message) {
        this.success = success;
        this.status = status;
        this.code = code;
        this.message = message;
    }


    public void setData(List<T> data) {
        this.data = data;
    }



    public static Results<?> success() {
        Results<?> t = new Results(true,BaseEnums.SUCCESS.code());
        return t;
    }

    public static Results<?> fail(Integer code, String msg) {
        Results<?> t = new Results(false, code,msg);
        return t;
    }


    /**
     * 正确返回带数据
     *
     * @param   <T>
     * @return
     */
    public static <T> Results<T> success(List<T> data) {
        Results<T> t = new Results(true,BaseEnums.SUCCESS.code());
        t.setData(data);
        return t;
    }



}

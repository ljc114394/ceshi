package com.boe.bank.common.constant;




import com.boe.bank.common.base.BaseEnum;

import java.util.HashMap;
import java.util.Map;

public enum BaseEnums implements BaseEnum<Integer, String> {

    SUCCESS(0, "request success"),
    FAILURE(9999, "request failure"),
    NOT_FOUND(4001, "resource not found"),
    FORBIDDEN(4002, "forbidden access"),
    VERSION_NOT_MATCH(4003, "record is not exist or version not match"),
    PARAMETER_NOT_NULL(2001, "parameter cannot be null"),
    PARAMETER_INVALID(2002, "parameter invalid");


    private static Map<Integer, String> allMap = new HashMap<Integer, String>();
    private Integer code;
    private String message;

    BaseEnums(Integer code, String message){
        this.code = code;
        this.message = message;
    }

    static {
        for (BaseEnums baseEnums:BaseEnums.values()) {
            allMap.put(baseEnums.code, baseEnums.message);
        }
    }

    @Override
    public Integer code() {
        return this.code;
    }

    @Override
    public String message() {
        return this.message;
    }

    public String message(String code){
        return allMap.get(code);
    }
}

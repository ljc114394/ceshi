package com.boe.bank.common.bean.marketLabel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @Description:精准营销-标签库 页面交互
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Data
public class MarketLabelInfoBean {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "标签类型：0属性标签、1行为标签")
    private Integer labelType;

    @ApiModelProperty(value = "标签名称")
    private String labelName;

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "标签备注")
    private String remark;

    @ApiModelProperty(value = "标签级别：1 一级，2 二级，3 三级 以此类推")
    private Integer level;

    @ApiModelProperty(value = "属性值")
    private MarketLabelNatureInfoBean marketLabelNatureInfoBean;

}

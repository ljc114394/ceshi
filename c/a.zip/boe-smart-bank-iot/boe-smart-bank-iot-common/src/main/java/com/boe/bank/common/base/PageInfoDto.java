package com.boe.bank.common.base;

import com.github.pagehelper.Page;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;

/**
 * 用于保存需要转化pageInfo泛型的中间类
 * @author caoxuhao
 * @param <T>
 */
@Data
public class PageInfoDto<T>{

    private List<T> records;
    private Page<T> page;

    public PageInfoDto(List<T> list,Page<T> page) {
        this.records = list;
        this.page = page;
    }
    
    public static <T> PageInfoDto<T> getEmptyPage(PageInfoDto<?> pageInfoDto){
    	
    	Page<T> p = new Page<T>();
    	BeanUtils.copyProperties(pageInfoDto.getPage(), p);
    	
    	return new PageInfoDto<>(new ArrayList<>(), p);
    }
    
    public static <T> PageInfoDto<T> getNewPage(List<T> list, PageInfoDto<?> pageInfoDto){
    	
    	Page<T> p = new Page<T>();
    	BeanUtils.copyProperties(pageInfoDto.getPage(), p);
    	return new PageInfoDto<>(list, p);
    }
}

package com.boe.bank.common.bean.productlibrarybean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/22 11:34
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MarketingPortraitBean {


    @ApiModelProperty(value = "画像id")
    private Integer id;

    @ApiModelProperty(value = "画像名称")
    private String portraitName;



}

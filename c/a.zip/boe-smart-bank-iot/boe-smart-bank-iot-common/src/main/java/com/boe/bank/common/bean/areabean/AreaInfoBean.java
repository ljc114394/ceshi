package com.boe.bank.common.bean.areabean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * TODO
 *
 * @author lu
 * @version 1.0
 * @data 2020/9/29
 */
@Data
public class AreaInfoBean {

    @ApiModelProperty(value = "主键id")
    private Integer  id;

    @ApiModelProperty(value = "区域名称")
    private String title;

    @ApiModelProperty(value = "机构名称")
    private String orgName;

    //机构id
    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    //部门id
    @ApiModelProperty(value = "部门id")
    private Integer departmentId;

    @ApiModelProperty(value = "部门名称")
    private String departmentName;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "备注")
    private String remark;

}

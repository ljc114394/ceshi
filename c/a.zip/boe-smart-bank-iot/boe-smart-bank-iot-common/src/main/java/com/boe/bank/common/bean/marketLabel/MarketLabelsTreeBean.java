package com.boe.bank.common.bean.marketLabel;

import com.boe.cloud.megarock.javabean.TreeNode;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Description:精准营销-标签表  数据库交互
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MarketLabelsTreeBean implements TreeNode<MarketLabelsTreeBean> {

    @ApiModelProperty(value = "主键id")
    private Long id;

    @ApiModelProperty(value = "父类id")
    private Long parentId;

    @ApiModelProperty(value = "标签名称")
    private String labelName;

    @ApiModelProperty(value = "标签属性区分：0属性标签、1行为标签")
    private Integer labelType;//标签属性区分：0属性标签、1行为标签

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;//启用状态：0否  1是

    @ApiModelProperty(value = "子节点信息")
    private List<MarketLabelsTreeBean> children;

    @ApiModelProperty(value = "水平")
    private Integer level;
}

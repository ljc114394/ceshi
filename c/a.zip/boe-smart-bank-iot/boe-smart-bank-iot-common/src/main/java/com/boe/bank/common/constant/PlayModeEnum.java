package com.boe.bank.common.constant;

/**
 * 计划播放模式枚举
 *
 * @author 10183279
 * @date 2020/10/19
 */
public enum PlayModeEnum {

    NORMAL(1, "正常计划"),
    SPOTS(2, "插播计划");

    private Integer code;

    private String message;

    PlayModeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}

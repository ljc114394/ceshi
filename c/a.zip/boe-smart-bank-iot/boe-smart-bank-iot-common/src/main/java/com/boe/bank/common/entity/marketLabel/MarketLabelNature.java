package com.boe.bank.common.entity.marketLabel;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description:精准营销-标签属性表
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MarketLabelNature extends BaseEntity implements Serializable {

    private Integer natureId; // 标签属性表主键id

    private Integer labelId;//标签id

    private String conditionValue;//条件    ：运算符需特殊标识

    private Integer isDelete;//删除 0 否 1 是
}

package com.boe.bank.common.bean.userNature;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description:数据统计-页面交互
 * @Author: lijianglong
 * @Data:2020/12/16
 */
@Data
public class UserNatureDTO {

    @ApiModelProperty("人脸id")
    private String faceId;//

    @ApiModelProperty("年龄")
    private Integer recoAge;//年龄

    @ApiModelProperty("性别：1男 2女")
    private Integer recoSex;//性别 1:男 2:女

    @ApiModelProperty("是否首次访问 0 否 1是")
    private Integer firstVisit;//是否首次访问 0:否 1:是

    @ApiModelProperty("创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;

    @ApiModelProperty("更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;

}

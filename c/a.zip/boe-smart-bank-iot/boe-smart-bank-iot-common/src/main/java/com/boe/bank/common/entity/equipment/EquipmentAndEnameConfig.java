package com.boe.bank.common.entity.equipment;

import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备配置
 *
 * @author 10183279
 * @date 2020/10/19
 */
@Data
public class EquipmentAndEnameConfig extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -6788582142871836944L;

    /**
     * 设备名称
     */
    private String name;
    /**
     * mac地址
     */
    private String mac;

    /**
     * 屏幕区域布局
     */
    private String screenLayout;
}

package com.boe.bank.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 * TODO
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/10 19:42
 */
public class DateUtil {
    /**
     * 英文简写（默认）如：2010-12-01
     */
    public static String FORMAT_SHORT = "yyyy-MM-dd";
    /**
     * 英文全称 如：2010-12-01 23:15:06
     */
    public static String FORMAT_LONG = "yyyy-MM-dd HH:mm:ss";

    /**
     * 精确到毫秒的完整时间 如：yyyy-MM-dd HH:mm:ss.S
     */
    public static String FORMAT_FULL = "yyyy-MM-dd HH:mm:ss.S";

    /**
     * 英文简写月 如：2010-05
     */
    public static String FORMAT_MONTH_FULL = "yyyy-MM";

    /**
     * 英文简写月 如：2010-5
     */
    public static String FORMAT_MONTH = "yyyy-M";

    /**
     * 中文简写 如：2010年12月01日
     */
    public static String FORMAT_SHORT_CN = "yyyy年MM月dd日";
    /**
     * 中文全称 如：2010年12月01日 23时15分06秒
     */
    public static String FORMAT_LONG_CN = "yyyy年MM月dd日  HH时mm分ss秒";
    /**
     * 精确到毫秒的完整中文时间
     */
    public static String FORMAT_FULL_CN = "yyyy年MM月dd日  HH时mm分ss秒SSS毫秒";
    /**
     * 简写 yyyymmdd
     */
    public static String FORMAT_SHORT_2 = "yyyyMMdd";

    /**
     * 英文全称去横杠 如：20101201231506
     */
    public static String FORMAT_LONG_2 = "yyyyMMddHHmmss";

    /**
     * 英文全称去横杠 毫秒 如：20101201231506111
     */
    public static String FORMAT_LONG_3 = "yyyyMMddHHmmssSSS";

    /**
     * 星期几
     */
    public static String WEEK = "EEEE";

    /**
     * 获取当天凌晨的时间戳(秒)
     */
    public static Long todayTimeStamp() {
        LocalDateTime today = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        Long second = today.toInstant(ZoneOffset.of("+8")).toEpochMilli() / 1000;
        return second;
    }

    /**
     * 获取当前时间的时间戳(毫秒)
     */
    public static LocalDateTime current() {
    	return LocalDateTime.now();
    }
    
    /**
     * 获取当前时间的时间戳(毫秒)
     */
    public static Long currentTimeStamp() {
        Long second = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
        return second;
    }

    /**
     * 获取当前时间的时间戳(秒)
     */
    public static Long currentTimeStampMillisecond() {
        Long second = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli() / 1000;
        return second;
    }

    /**
     * 获取当前系统时间
     */
    public static Date getNowDate() {
        LocalDateTime localDateTime = LocalDateTime.now();
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = localDateTime.atZone(zone).toInstant();
        return Date.from(instant);
    }

    public static String getNowDateStr(String format) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(format);
        return LocalDateTime.now().format(dateTimeFormatter);
    }

    /**
     * 获取本月的结束时间
     *
     * @return
     */
    public static Date getCurrentMonthEndTime() {
        Calendar c = Calendar.getInstance();
        Date now = null;
        SimpleDateFormat longSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat shortSdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            c.set(Calendar.DATE, 1);
            c.add(Calendar.MONTH, 1);
            c.add(Calendar.DATE, -1);
            now = longSdf.parse(shortSdf.format(c.getTime()) + " 23:59:59");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return now;
    }

    /**
     * 获取今年的开始时间
     *
     * @return
     */
    public static Date getCurrentYearStartTime() {
        Date result = null;
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            GregorianCalendar gc2 = (GregorianCalendar) Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            gc2.setTime(new Date());
            gc2.set(Calendar.MONTH, Calendar.JANUARY);
            gc2.set(Calendar.DAY_OF_MONTH, 1);// 设置该月的第一天
            String b_day_first = df.format(gc2.getTime());
            StringBuffer str_b = new StringBuffer().append(b_day_first).append(" 00:00:00");// 拼接 时分秒
            b_day_first = str_b.toString();
            result = df.parse(b_day_first);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 获取本月的开始时间
     *
     * @return
     */
    public static Date getCurrentMonthStartTime() {
        Date result = null;
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            GregorianCalendar gc2 = (GregorianCalendar) Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            gc2.setTime(new Date());
            gc2.set(Calendar.DAY_OF_MONTH, 1);// 设置该月的第一天
            String b_day_first = df.format(gc2.getTime());
            StringBuffer str_b = new StringBuffer().append(b_day_first).append(" 00:00:00");// 拼接 时分秒
            b_day_first = str_b.toString();
            result = df.parse(b_day_first);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 使用预设格式格式化日期
     *
     * @param date
     * @return
     */
    public static String format(Date date) {
        return format(date, FORMAT_LONG);
    }

    /**
     * 使用用户格式格式化日期
     *
     * @param date    日期
     * @param pattern 日期格式
     * @return
     */
    public static String format(Date date, String pattern) {
        String returnValue = "";
        if (date != null) {
            SimpleDateFormat df = new SimpleDateFormat(pattern);
            returnValue = df.format(date);
        }
        return (returnValue);
    }

    /**
     * 使用用户格式格式化日期 成int型
     *
     * @param date    日期
     * @return
     */
    public static Integer formatInt(Date date) {
        String returnValue = "";
        String pattern = FORMAT_SHORT_2;
        if (date != null) {
            SimpleDateFormat df = new SimpleDateFormat(pattern);
            returnValue = df.format(date);
        }
        return Integer.parseInt(returnValue);
    }

    /**
     * 使用预设格式提取字符串日期
     *
     * @param strDate 日期字符串
     * @return
     */
    public static Date parse(String strDate) {
        return parse(strDate, FORMAT_LONG);
    }
    /**
     * 使用预设格式提取字符串日期 YYYY-MM-dd
     *
     * @param strDate 日期字符串
     * @return
     */
    public static Date parse1(String strDate) {
        return parse(strDate, FORMAT_SHORT);
    }
    /**
     * 使用预设格式提取字符串 LocalDateTime
     *
     * @param strDate 日期字符串
     * @return
     */
    public static LocalDateTime parseLocalDate(String strDate) {
        if (StringUtils.isEmpty(strDate)) {
            return null;
        }
        Date date = parse(strDate, FORMAT_LONG);
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(date.toInstant(), zoneId);
        return localDateTime;
    }


    /**
     * 使用预设格式提取字符串 LocalDateTime YYYY-MM-dd
     *
     * @param strDate 日期字符串
     * @return
     */
    public static LocalDateTime parseLocalDate1(String strDate) {
        if (StringUtils.isEmpty(strDate)) {
            return null;
        }
        Date date = parse(strDate, FORMAT_SHORT);
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(date.toInstant(), zoneId);
        return localDateTime;
    }


    /**
     * 使用用户格式提取字符串日期
     *
     * @param strDate 日期字符串
     * @param pattern 日期格式
     * @return
     */
    public static Date parse(String strDate, String pattern) {

        if (strDate == null || strDate.equals("")) {
            return null;
        }

        SimpleDateFormat df = new SimpleDateFormat(pattern);
        try {
            return df.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 取系统日期
     */
    public static String getUTCTimeStr() {
        Calendar cal = Calendar.getInstance();
        return String.valueOf(cal.getTimeInMillis());
    }

    /**
     * 获取一天的结束时间
     *
     * @param date
     * @return
     */
    public static Date getEndTimeOfDay(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    
    /**
     * LocalDateTime转时间戳（秒）
     * @param localDateTime
     * @return
     */
    public static int asSecond(LocalDateTime localDateTime) {
    	return (int)LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"));
    }
    
    /**
     * LocalDateTime转时间戳（毫秒）
     * @param localDateTime
     * @return
     */
    public static long asMilliSecond(LocalDateTime localDateTime) {
    	return LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static Date asDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }


    public static String localTimeParse(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return "";
        }
        return format(asDate(localDateTime));
    }

    /**
     * 时间转换YYYY-MM-dd 字符串
     *
     * @param localDateTime
     * @return
     */
    public static String dateParse(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return "";
        }
        return format(asDate(localDateTime), FORMAT_SHORT);
    }


    /**
     * 获取一天的开始时间
     *
     * @param date
     * @return
     */
    public static Date getStartTimeOfDay(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * 获取一个月的开始时间
     *
     * @param date
     * @return
     */
    public static Date getStartTimeOfMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * 获取一个月的结束时间
     *
     * @param date
     * @return
     */
    public static Date getEndTimeOfMonth(Date date) {
        return addSecond(addMonth(getStartTimeOfMonth(date), 1), -1);
    }

    /**
     * 获取两个时间点之间的日期
     *
     * @param dBegin 包括开始日期
     * @param dEnd   包括结束日期
     * @return
     */
    public static List<Date> findDates(Date dBegin, Date dEnd) {
        List<Date> lDate = new ArrayList<Date>();
        lDate.add(dBegin);
        Calendar calBegin = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calEnd.setTime(dEnd);
        // 测试此日期是否在指定日期之后
        while (dEnd.after(calBegin.getTime())) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            calBegin.add(Calendar.DAY_OF_MONTH, 1);
            lDate.add(calBegin.getTime());
        }

        return lDate;
    }

    /**
     * 获取两个时间点之间的日期
     *
     * @param dBegin 包括开始日期
     * @param dEnd   包括结束日期
     * @return
     */
    public static List<String> findDatesContainStartAndEnd(Date dBegin, Date dEnd, String format) {
        List<String> lDate = new ArrayList<>();
        lDate.add(format(dBegin, format));
        Calendar calBegin = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calEnd.setTime(dEnd);
        // 测试此日期是否在指定日期之后
        while (dEnd.after(calBegin.getTime())) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            calBegin.add(Calendar.DAY_OF_MONTH, 1);
            lDate.add(format(calBegin.getTime(), format));
        }
        return lDate;
    }

    /**
     * 获取两个时间点之间的月份
     *
     * @param dBegin 包括开始日期
     * @param dEnd   包括结束日期
     * @return
     */
    public static List<Date> findMonths(Date dBegin, Date dEnd) {

        dBegin = getStartTimeOfMonth(dBegin);
        dEnd = getLastDayOfMonth(dEnd);

        List<Date> lDate = new ArrayList<>();
        lDate.add(dBegin);
        Calendar calBegin = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calEnd.setTime(dEnd);
        // 测试此日期是否在指定日期之后
        calBegin.add(Calendar.MONTH, 1);

        while (dEnd.after(calBegin.getTime())) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            lDate.add(calBegin.getTime());
            calBegin.add(Calendar.MONTH, 1);
        }
        return lDate;
    }

    /**
     * 获取两个时间点之间的月份
     *
     * @param dBegin 包括开始日期
     * @param dEnd   包括结束日期
     * @return
     */
    public static List<String> findMonthsContainStartAndEnd(Date dBegin, Date dEnd, String format) {

        dBegin = getStartTimeOfMonth(dBegin);
        dEnd = getLastDayOfMonth(dEnd);

        List<String> lDate = new ArrayList<>();
        lDate.add(format(dBegin, format));
        Calendar calBegin = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calEnd.setTime(dEnd);
        // 测试此日期是否在指定日期之后
        calBegin.add(Calendar.MONTH, 1);

        while (dEnd.after(calBegin.getTime())) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            lDate.add(format(calBegin.getTime(), format));
            calBegin.add(Calendar.MONTH, 1);
        }
        return lDate;
    }

    public static List<Date> changeStr2Date(List<String> dates, String format) {
        List<Date> l = new ArrayList<>();

        if (dates == null || dates.size() == 0)
            return l;

        for (String strDate : dates) {

            Date date = parse(strDate, format);
            //有转化失败直接返回
            if (date == null)
                return new ArrayList<>();

            l.add(date);
        }

        return l;

    }

    /**
     * 在日期上增加天数
     *
     * @param date 日期
     * @param n    要增加的天数
     * @return
     */
    public static Date addDay(Date date, int n) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, n);
        return cal.getTime();
    }

    /**
     * 在日期上增加秒数
     *
     * @param date 日期
     * @param n    要增加的秒数
     * @return
     */
    public static Date addSecond(Date date, int n) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.SECOND, n);
        return cal.getTime();
    }

    /**
     * 在日期上增加月
     *
     * @param date 日期
     * @param n    要增加的月数
     * @return
     */
    public static Date addMonth(Date date, int n) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, n);
        return cal.getTime();
    }

    /**
     * 取得当前日期所在月的最后一天
     *
     * @param date
     * @return
     */
    public static Date getLastDayOfMonth(Date date) {
        if (date == null)
            return null;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH), calendar.getActualMaximum(Calendar.DATE));
        return getEndTimeOfDay(calendar.getTime());
    }

    /**
     * 获取当前季度的第一天
     *
     * @param
     */
    public static String getFirstDayofQuarter() {
        Calendar c = Calendar.getInstance();
        int currentMonth = c.get(Calendar.MONTH) + 1;
        int quarter = 0;
        if (currentMonth >= 1 && currentMonth <= 3) {
            quarter = 1;
        } else if (currentMonth >= 4 && currentMonth <= 6) {
            quarter = 2;
        } else if (currentMonth >= 7 && currentMonth <= 9) {
            quarter = 3;
        } else {
            quarter = 4;
        }
        String month = null;
        if (quarter == 1) {
            month = "01";
        } else if (quarter == 2) {
            month = "04";
        } else if (quarter == 3) {
            month = "07";
        } else if (quarter == 4) {
            month = "10";
        }
        return c.get(Calendar.YEAR) + "-" + month + "-01";
    }

    /**
     * 获取当前年份的第一天
     *
     * @param
     */
    public static String getFirstDayofYear() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_YEAR, 1);
        return format.format(c.getTime());
    }

    /**
     * 获取当前日期
     *
     * @param
     */
    public static String getCurrentDay() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        return format.format(c.getTime());
    }

    /**
     * 获取当前日期的前一天
     *
     * @param
     */
    public static String getLastDay() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -1);
        return format.format(c.getTime());
    }

    /**
     * 获取当前日期的上一年
     *
     * @param
     */
    public static String getLastCurrentDay() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.add(Calendar.YEAR, -1);
        return format.format(c.getTime());
    }

    /**
     * 将日期转换为时间戳
     */
    public static long dateToStamp(String s, String fomat) {

        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(fomat);
            Date date = simpleDateFormat.parse(s);
            long ts = date.getTime() / 1000;
            return ts;
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }

    }
    /**
     * 格式格式化日期_yyyyMMddHHmmss
     *
     * @param date
     * @return
     */
    public static String formatlong2(Date date) {
        return format(date, FORMAT_LONG_2);
    }

    /**
     * 格式格式化日期_yyyyMMddHHmmssSSS
     *
     * @param date
     * @return
     */
    public static String formatlong3(Date date) {
        return format(date, FORMAT_LONG_3);
    }


    /**
     * 格式格式化日期_星期几
     *
     * @param date
     * @return
     */
    public static String formatWeek(Date date) {
        return format(date, WEEK);
    }
    
    /**
     * 取得两个日期间隔毫秒数（日期1-日期2）
     * @param one
     *            日期1
     * @param two
     *            日期2
     * @author zhaohaixia
     * @return 间隔毫秒数
     */
    public static long getDiffSeconds(Date one, Date two) {
        Calendar sysDate = new GregorianCalendar();
        sysDate.setTime(one);
        Calendar failDate = new GregorianCalendar();
        failDate.setTime(two);
        return sysDate.getTimeInMillis() - failDate.getTimeInMillis();
    }
    
}

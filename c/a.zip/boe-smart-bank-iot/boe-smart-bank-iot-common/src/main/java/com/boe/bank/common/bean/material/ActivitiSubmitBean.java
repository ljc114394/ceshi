package com.boe.bank.common.bean.material;

import com.boe.bank.common.constant.ActivitiConstants;
import com.boe.cloud.megarock.security.common.UserInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: 005
 * @Description:
 * @Date Created in 2020-12-14 13:50
 * @Modified By:
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ActivitiSubmitBean {
    private String userId;
    private Integer busniessType;
    private Integer examineId;
    private Integer outerId;
    private Integer outerType;

}

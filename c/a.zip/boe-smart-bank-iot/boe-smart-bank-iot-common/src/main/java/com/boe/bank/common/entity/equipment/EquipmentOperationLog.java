package com.boe.bank.common.entity.equipment;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import lombok.Data;

/**
 * 设备运维日志
 * @author 10085188
 *
 */
@Data
public class EquipmentOperationLog implements Serializable {
	private static final long serialVersionUID = -3218658897246993879L;
	
	@TableId(type = IdType.AUTO)
    private Integer id;
	
	/**
     * 设备mac
     */
    private String mac;
    
    /**
     * CPU占用率
     */
    private String cpu;
    
    /**
     * 内存可用量
     */
    private long memoryFree;
    
    /**
     * 磁盘可用空间
     */
    private long diskFree;
    /**
     * 内存总量
     */
    private long memoryTotal;
    
    /**
     * 磁盘总空间
     */
    private long diskTotal;
    
    /**
     * 设备名称
     */
    private String name;
    
    /**
     * IP地址
     */
    private String addressIp;
    
    /**
     * 设备id
     */
    private Integer equId;
    
    /**
     * 机构id
     */
    private Integer orgId;
    
    /**
     * 区域id
     */
    private Integer areaId;
    
    /**
     * 设备类型id
     */
    private Integer typeId;
    
    /**
     * 日志产生时间
     */
    private Date logTime;
    
    /**
     * 日志产生时间
     */
    private Integer logTimeAt;
    
    /**
     * 日志存储在服务器上面的地址
     */
    private String logUrl;
    
    /**
     * 创建时间
     */
    private Date createTime;

}

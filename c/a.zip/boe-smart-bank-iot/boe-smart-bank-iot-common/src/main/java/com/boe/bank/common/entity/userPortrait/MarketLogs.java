package com.boe.bank.common.entity.userPortrait;

import com.boe.bank.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description:vo
 * @Author: lijianglong
 * @Data:2020/10/27
 */

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MarketLogs extends BaseEntity implements Serializable {

    private Integer id;//主键id

    private String faceId;//人脸id

    private String faceFeature;//人脸特征向量

    private String mac;//设备地址

    private String portraitId;//画像id,英文逗号隔开拼接

    private String marketLabelId;//标签id，英文逗号隔开拼接

    private String propertyJson;//存储ai传过来的属性数据或最终的结果


}

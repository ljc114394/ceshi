package com.boe.bank.common.bean.equipment;

import java.io.Serializable;

import com.boe.bank.common.base.PageBean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "设备运维日志查询对象")
@Data
public class EquipmentOperationLogQO  extends PageBean implements Serializable {

	private static final long serialVersionUID = 2925128013488164080L;

	@ApiModelProperty(value = "设备名称、ip、mac信息")
    private String searchInfo;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "设备类型id")
    private Integer typeId;
}

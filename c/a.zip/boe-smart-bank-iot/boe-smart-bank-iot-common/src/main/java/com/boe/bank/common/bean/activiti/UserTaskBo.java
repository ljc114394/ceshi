package com.boe.bank.common.bean.activiti;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.boe.bank.common.constant.ActivitiConstants;

import lombok.Data;

/**
 * userTask模型
 * 在activiti部署时候，描述同一个网关下的同级UserTask
 * @author caoxuhao
 */
@Data
public class UserTaskBo {
	private String name;
	private int number;
	private int passType;
	private int passTypeOld;//原始的passType
	
	/**
	 * 当passType=3时，key:deparmentId value:userIds
	 * 当passType=1 or 2时，不关心部门，key:-1 value:userIds
	 * */
	private Map<Long, Set<Long>> map;
	
	/**角色ids*/
	private List<Integer> roles;
	
	/**选角色后的附加条件： 1与发起人同一部门，2与发起人同一机构，3发起人的上级机构，4发起人的上级机构*/
	private Integer roleAdditional;
	
	public UserTaskBo() {}
	
	public UserTaskBo(String name) {
		this.name = name;
		this.number = 1;
		this.passType = ActivitiConstants.PassType.any;
		this.passTypeOld = ActivitiConstants.PassType.any;
	}
	
	/**
	 * by角色时候用
	 * @param name
	 * @param number
	 * @param passType
	 * @param map
	 */
	public UserTaskBo(String name, int number, int passType, List<Integer> roles, Integer roleAdditional) {
		this.name = name;
		this.number = number;
		this.passType = passType;
		this.passTypeOld = passType;
		this.roleAdditional = roleAdditional;
		this.roles = roles;
	}
	
	/**
	 * by组织架构
	 * @param name
	 * @param number
	 * @param passType
	 * @param map
	 */
	public UserTaskBo(String name, int number, int passType, Map<Long, Set<Long>> map) {
		this.name = name;
		this.number = number;
		this.passType = passType;
		this.passTypeOld = passType;
		this.map = map;
	}
	
	/**
	 * by组织架构
	 * @param name
	 * @param number
	 * @param passType
	 * @param passTypeOld
	 * @param map
	 */
	public UserTaskBo(String name, int number, int passType, int passTypeOld, Map<Long, Set<Long>> map) {
		this.name = name;
		this.number = number;
		this.passType = passType;
		this.passTypeOld = passTypeOld;
		this.map = map;
	}
}

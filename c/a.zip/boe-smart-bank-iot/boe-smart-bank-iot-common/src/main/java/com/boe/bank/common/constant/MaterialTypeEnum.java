package com.boe.bank.common.constant;

/**
* @Description:素材类型
* @author: zhaohaixia
* @date: 2020年10月14日 上午10:30:09
 */
public enum MaterialTypeEnum {

	FOLDER(0, "文件夹"),
    PIC(1, "图片"),
    VIDEO(2, "视频"),
    TEXT(3, "文本"),
    WEB(4, "web"),
    DOCUMENT(5, "文档"),
    PROGRAM(6, "应用程序"),
    
    
    PASS(1, "已通过"),
    EXAMINE(2, "审批中"),
    APPROVE(3, "审查中"),
    REFUSE(4, "已拒绝"),
    
    TYPE_FOLDER(1, "文件夹"),
    TYPE_MATERIAL(2, "素材"),
    
    LEVEL_ZERO(0, "素材"),
    LEVEL_ONE(1, "一级文件夹"),
    LEVEL_TWO(2, "二级文件夹")
    
    ;

    private int code;

    private String name;

    MaterialTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}

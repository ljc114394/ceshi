package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 节目播放设置
 *
 * @author 10183279
 * @date 2020/10/23
 */
@ApiModel(value = "节目播放设置")
@Data
public class ProgramConfigVO implements Serializable {

    private static final long serialVersionUID = -6143237877706501015L;

    @ApiModelProperty(value = "计划id")
    private Integer id;

    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "定义周几播放")
    private String dayOfWeek;

    @ApiModelProperty(value = "1：正常计划，2：插播计划")
    private Integer type;

    @ApiModelProperty(value = "更新时间，后端用于排序")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "屏幕区域布局")
    private List<ScreenLayoutVO> areas;
}

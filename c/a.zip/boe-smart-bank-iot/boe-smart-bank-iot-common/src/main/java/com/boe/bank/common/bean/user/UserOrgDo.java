package com.boe.bank.common.bean.user;

import lombok.Data;

/**
 * 用户和部门的关系
 * @author caoxuhao
 */
@Data
public class UserOrgDo {
	private Long userId;
	private Long orgId;
}

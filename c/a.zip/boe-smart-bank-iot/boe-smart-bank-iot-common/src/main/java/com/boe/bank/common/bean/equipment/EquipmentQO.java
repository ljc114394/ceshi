package com.boe.bank.common.bean.equipment;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * EquipmentQO
 *
 * @author 10183279
 * @date 2020/10/14
 */
@ApiModel(value = "设备查询对象")
@Data
public class EquipmentQO extends PageBean implements Serializable {

    private static final long serialVersionUID = 3439568557293916862L;

    @ApiModelProperty(value = "设备名称")
    private String name;

    @ApiModelProperty(value = "机构id")
    private Long orgId;

    @ApiModelProperty(value = "设备类型id")
    private Integer typeId;

    @ApiModelProperty(value = "状态 1在线 2离线")
    private Integer isOnline;

    @ApiModelProperty(value = "审核状态 1:审核中 2:已通过 3:已拒绝")
    private Integer auditStatus;

    @ApiModelProperty(value = "机构id串", hidden = true)
    private List<Long> orgIds;

}

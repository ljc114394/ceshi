package com.boe.bank.common.entity.planmanage;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanMaterialManage extends BaseEntity implements Serializable {

    //素材id
    private Integer id;

    //播放次数或时间
    private Integer playOperation;

    //屏幕区域
    private Integer screenArea;

    //素材名称
    private String title;

    //type为1或者2，表示缩略图名称，前台不需要传；type为3，表示文本内容；type为4，表示web地址；type为5，表示文档名称；type为6，表示程序入口，即文件名
    private String content;

    //type为6时，表示程序序参数
    private String programEntry;

    //类型，1图片资源，2视频资源 3web资源 4文本信息 5文档管理 6.应用程序
    private Integer type;

    //文件类型，1文件夹，2素材
    private Integer fileType;
}

package com.boe.bank.common.bean.areabean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author lu
 * @version 1.0
 * @data 2020/9/29
 */
@Data
public class AreaNameBean {


    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "区域名称")
    private String name;

}

package com.boe.bank.common.base;

import com.github.pagehelper.Page;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Data
public class PageInfo<T>  implements Serializable{


    private List<T> records;

    /**
     * 总记录数
     */
    private Long total;
    /**
     * 总页数
     */
    private int pages;
    /**
     * 当前页
     */
    private Integer current;

    private Integer size;

    public PageInfo(List<T> list,Page page) {
        this.records = list;
        this.total = page.getTotal();
        this.size = page.getPageSize();
        this.current = page.getPageNum();
        this.pages = page.getPages();

    }

    public static <T> PageInfo<T> of(List<T> list,Page page) {
        return new PageInfo(list,page);
    }


}

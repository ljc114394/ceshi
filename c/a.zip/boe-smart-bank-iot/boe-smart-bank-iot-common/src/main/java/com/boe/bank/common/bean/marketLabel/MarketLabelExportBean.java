package com.boe.bank.common.bean.marketLabel;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:精准营销-标签表 导出
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Data
public class MarketLabelExportBean extends PageBean {

    @ApiModelProperty(value = "标签id")
    private Integer id;

    @ApiModelProperty(value = "标签名称")
    @Emoticon
    private String labelName;

    @ApiModelProperty(value = "标签类型分类：0属性标签、1行为标签")
    private Integer labelType;

    @ApiModelProperty(value = "标签状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "标签级别：1 一级，2 二级，3 三级")
    private Integer level;
}

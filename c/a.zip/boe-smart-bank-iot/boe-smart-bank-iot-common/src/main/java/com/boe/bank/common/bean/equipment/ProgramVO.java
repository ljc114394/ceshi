package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 节目
 *
 * @author 10183279
 * @date 2020/10/23
 */
@ApiModel(value = "节目")
@Data
public class ProgramVO implements Serializable {

    private static final long serialVersionUID = 8237132062348050739L;
    
    @ApiModelProperty(value = "url")
    private String url;

    @ApiModelProperty(value = "类型")
    private Integer type;

    @ApiModelProperty(value = "文件大小")
    private Integer fileSize;

    @ApiModelProperty(value = "md5")
    private String md5;

    @ApiModelProperty(value = "视频：循环次数，图片：展示时间")
    private Integer times;

    @ApiModelProperty(value = "文本内容")
    private String text;

    @ApiModelProperty(value = "应用程序参数")
    private String param;

    @ApiModelProperty(value = "过期时间")
    private String valTime;
}

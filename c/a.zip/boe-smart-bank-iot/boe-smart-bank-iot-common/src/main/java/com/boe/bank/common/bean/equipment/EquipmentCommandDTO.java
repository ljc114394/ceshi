package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * 设备命令DTO
 *
 * @author 10183279
 * @date 2020/10/19
 */
@ApiModel(value = "设备命令DTO")
@Data
public class EquipmentCommandDTO implements Serializable {

    private static final long serialVersionUID = -1456044608518914981L;

    @ApiModelProperty(value = "命令，如：DESKTOP、SHUTDOWN、RESTART、SLEEP、AWAKE、MUTE、VOLUMEUP、VOLUMEDOWN、PAUSE、RESUME")
    @NotBlank(message = "命令不能为空")
    private String command;

    @ApiModelProperty(value = "设备id列表")
    @NotEmpty(message = "设备id不能为空")
    private List<Integer> idList;
}

package com.boe.bank.common.constant;

/**
 * 设备命令枚举
 *
 * @author 10183279
 * @date 2020/10/19
 */
public enum EquipmentCommandEnum {

    SCREENSHOT("Screenshot", "截屏"),
    UPDATE("Update", "更新计划"),
    UPGRADE("Upgrade", "客户端升级");

    private String code;

    private String message;

    EquipmentCommandEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    /**
     * 根据code返回枚举类型
     */
    public static EquipmentCommandEnum getByCode(String code) {
        for (EquipmentCommandEnum commandEnum : values()) {
            if (commandEnum.getCode().equals(code)) {
                return commandEnum;
            }
        }
        return null;
    }
}

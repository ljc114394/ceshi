package com.boe.bank.common.bean.datarolebean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/12/04 09:26
 */
@Data
public class UserAndData {
    @ApiModelProperty(value = "用户id")
    private Integer id;

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "账号")
    private String username;
}

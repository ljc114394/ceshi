package com.boe.bank.common.constant;

/**
* @Description:上传类型
* @author: lvjiacheng
* @date: 2020年11月4日 15:33:09
 */
public enum UploadTypeEnum {

	FOLDER(0, "文件夹"),
    PIC(1, "图片"),
    VIDEO(2, "视频"),
    DOCUMENT(3, "文档"),
    PROGRAM(4, "应用程序"),
    XML(5, "xml格式"),
    PRODUCT(6, "PRODUCT")


    ;

    private int code;

    private String name;

    UploadTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}

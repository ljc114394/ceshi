package com.boe.bank.common.constant;

import java.util.HashMap;
import java.util.Map;

/**
* @Description:日志类型
* @author: lvjiacheng
* @date: 2020年10月30日
 */
public enum logEnum {

    MATERIAL(1, "素材"),
    PLAN(2, "计划"),
    EQUIPMENT(3, "设备"),
    POWER(4, "权限"),
    APPROVAL(5, "审批"),

     MATERIAL_ENGLISH(1, "material"),
    PLAN_ENGLISH(2, "plan"),
    EQUIPMENT_ENGLISH(3, "equipment"),
    POWER_ENGLISH(4, "power"),
    APPROVAL_ENGLISH(5, "approval"),
    LOGIN(6, "login"),
    INTERFACE(7, "interface"),

    //审批结果
    PENDING(1,"待处理"),
    AGREE(2,"同意"),
    REFUSE(3,"拒绝"),
    
    //日志级别；0:Debug 1:Info 2:Warn 3:Error 4:Fatal
    DEBUG(0, "调试"),
    INFO(1, "消息"),
    WARN(2, "警告"),
    ERROR(3, "错误"),
    FATAL(4, "严重错误"),


    ADD(1,"新增"),
    UPDATE(2,"修改"),
    DELETE(3,"删除")

    ;


//    0其它 1后台用户 2手机端用户
//    //操作类型
//    PENDING(0,"待处理"),
//    AGREE(1,"同意"),
//    REFUSE(2,"拒绝");

    private int code;
    private String name;

    logEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
    
    private static Map<Integer, String> allMap = new HashMap<Integer, String>();
    static {
        for (logEnum baseEnums : logEnum.values ()) {
            allMap.put(baseEnums.code, baseEnums.name);
        }
    }
    
    public static String getName(Integer code) {
    	return allMap.get(code);
    }
}

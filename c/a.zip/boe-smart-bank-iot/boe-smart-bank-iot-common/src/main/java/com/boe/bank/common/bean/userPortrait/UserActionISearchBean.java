package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author: lijianglong
 * @Data:2020/11/4
 */
@Data
public class UserActionISearchBean {

    @ApiModelProperty(value = "前置时间条件范围 0:无 1:全部时段 2:近一个月 3:近一周 4:近三天")
    private Integer conditonPreType;

    @ApiModelProperty(value = "属性行为 1:访问网点数 2:查看应用累计时间 3:点击应用二维码次数")
    private Integer conditonActionType;

    @ApiModelProperty(value = "属性结果值")
    private String conditonActionValue;

    @ApiModelProperty(value = "人脸id")
    private String faceId;


}

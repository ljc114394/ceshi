package com.boe.bank.common.bean.areabean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;


/**
 * TODO
 *
 * @author lu
 * @version 1.0
 * @data 2020/9/29
 */
@Data
public class AreaSearchBean extends PageBean {

    @ApiModelProperty(value = "区域名称")
    @Emoticon
    private String title;

    @ApiModelProperty(value = "机构树下的机构id 根据type区分 1：机构 2部门")
    private Long orgId;

    @ApiModelProperty(value = "机构树下的部门id 根据type区分 1：机构 2部门")
    private Long departmentId;

}

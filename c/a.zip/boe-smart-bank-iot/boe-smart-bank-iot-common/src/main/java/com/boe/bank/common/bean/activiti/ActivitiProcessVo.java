package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 审批流程分页查询数据库查出给前端页面用的
 * @author caoxuhao
 */
@Data
public class ActivitiProcessVo {
	
	@ApiModelProperty(value = "业务类型")
	private String busniessType;
	
	@ApiModelProperty(value = "流程名称")
	private String name;
	
	@ApiModelProperty(value = "流程编码")
	private Integer id;
	
	@ApiModelProperty(value = "制定人员")
	private String createBy;
	
	@ApiModelProperty(value = "流程状态")
	private String status;
}

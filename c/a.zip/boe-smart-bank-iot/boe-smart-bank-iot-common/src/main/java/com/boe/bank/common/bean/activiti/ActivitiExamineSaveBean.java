package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 保存审批类型的实例
 * @author caoxuhao
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ActivitiExamineSaveBean {
	
	@ApiModelProperty(value = "审批类型编码(仅更新时必填)")
	private Integer id;
	
	@ApiModelProperty(value = "业务类型： 1素材 2计划 3设备")
	private Integer busniessType;
	
	@ApiModelProperty(value = "审批类型")
	private String examineType;
	
	@ApiModelProperty(value = "制定人员id")
	private Long createUserId;
	
	@ApiModelProperty(value = "制定人员")
	private String createBy;
	
	@ApiModelProperty(value = "审批类型状态： 0启用 1停用。 默认0")
	private Integer status;
}

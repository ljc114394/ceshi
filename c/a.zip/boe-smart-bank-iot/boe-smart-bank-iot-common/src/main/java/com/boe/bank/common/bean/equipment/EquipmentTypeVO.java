package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备类型
 *
 * @author 10183279
 * @date 2020/12/1
 */
@Data
@ApiModel(value = "设备类型")
public class EquipmentTypeVO implements Serializable {

    private static final long serialVersionUID = 4033759097671400021L;

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "设备类型名称")
    private String name;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "修改人")
    private String updateBy;

    @ApiModelProperty(value = "修改时间")
    private String updateTime;
}

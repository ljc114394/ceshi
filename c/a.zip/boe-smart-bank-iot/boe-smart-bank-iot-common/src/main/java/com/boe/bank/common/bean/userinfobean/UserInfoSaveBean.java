package com.boe.bank.common.bean.userinfobean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/9/29 14:53
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoSaveBean  {


    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "密码")
    private String password;

    @ApiModelProperty(value = "部门id")
    private Integer  departmentId;

    @ApiModelProperty(value = "岗位")
    private String postName;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "账号")
    private String username;

    @ApiModelProperty(value = "手机号码")
    private String  phoneNum;

    @ApiModelProperty(value = "工号")
    private String  workNum;

    @ApiModelProperty(value = "备注")
    private String remark;
}

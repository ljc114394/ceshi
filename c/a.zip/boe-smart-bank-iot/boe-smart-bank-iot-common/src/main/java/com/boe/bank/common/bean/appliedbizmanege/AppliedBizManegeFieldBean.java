package com.boe.bank.common.bean.appliedbizmanege;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppliedBizManegeFieldBean {
    @ApiModelProperty(value = "字段code",required = true)
    private String columnCode;
    @ApiModelProperty(value = "字段类型; 数据字典<应用模块字段类型>",required = true)
    private String columnType;
    @ApiModelProperty(value = "字段长度; 填写示例：10 或 10,2",required = true)
    private String columnLength;
    @ApiModelProperty(value = "是否必填; 0：非必填，1：必填",required = true)
    private String required;
    @ApiModelProperty(value = "字段注释",required = true)
    private String columnComment;
    @ApiModelProperty(value = "字段名",required = true)
    private String columnName;
    @ApiModelProperty(value = "是否是字典类型; 是则填字典父code,不是则填0",required = true)
    private String dictId;
    @ApiModelProperty(value = "是否是查询条件; 0：不是，1：是",required = true)
    private String isQueryCriteria;
    @ApiModelProperty(value = "是否列表显示; 0：不是，1：是",required = true)
    private String isListShow;
    @ApiModelProperty(value = "是否是图片字段; 0：不是，1：是",required = true)
    private String isImage;
    @ApiModelProperty(value = "是否是视频字段; 0：不是，1：是",required = true)
    private String isVideo;

    public AppliedBizManegeFieldBean(String columnCode) {
        this.columnCode = columnCode;
    }

    public AppliedBizManegeFieldBean(String columnCode, String columnName) {
        this.columnCode = columnCode;
        this.columnName = columnName;
    }
}

package com.boe.bank.common.bean.userNature;

import com.boe.bank.common.base.PageBean;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description:数据统计-页面交互
 * @Author: lijianglong
 * @Data:2020/12/16
 */
@Data
public class UserNatureSearchDTO extends PageBean {

    @ApiModelProperty("年龄")
    private Integer recoAge;//年龄

    @ApiModelProperty("性别：1男 2女")
    private Integer recoSex;//性别 1:男 2:女

    @ApiModelProperty("是否首次访问 0 否 1是")
    private Integer firstVisit;//是否首次访问 0:否 1:是

}

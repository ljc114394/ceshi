package com.boe.bank.common.bean.productlibrarybean;

import com.boe.bank.common.bean.marketLabel.MarketLabelNatureDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @Description:用户画像dto
 * @Author: lijianglong
 * @Data:2020/11/13
 */

@Data
public class PortraitDTO {

    @ApiModelProperty(value = "用户画像主键id")
    private Integer portraitId;

    @ApiModelProperty(value = "条件判断：0或  1且")
    private Integer conditionType;

    @ApiModelProperty(value = "权重")
    private Integer weight;

    @ApiModelProperty(value = "用户画像创建时间")
    private Date createTime;

    @ApiModelProperty(value = "标签属性参数集合")
    private List<MarketLabelNatureDTO> marketLabelNatureDTOS;
}

package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.*;
import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备类型
 *
 * @author 10183279
 * @date 2020/12/1
 */
@Data
@TableName("t_equipment_type")
public class EquipmentType extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -3589489361679730455L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 设备类型名称
     */
    @TableField(value = "name")
    private String name;
    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;
    /**
     * 0未删除/1已删除
     */
    @TableField(value = "is_delete")
    @TableLogic
    private Integer isDelete;
}

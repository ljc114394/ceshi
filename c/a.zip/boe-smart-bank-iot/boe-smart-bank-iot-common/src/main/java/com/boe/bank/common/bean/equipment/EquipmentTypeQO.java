package com.boe.bank.common.bean.equipment;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备类型查询对象
 *
 * @author 10183279
 * @date 2020/12/1
 */
@ApiModel(value = "设备类型查询对象")
@Data
public class EquipmentTypeQO extends PageBean implements Serializable {

    private static final long serialVersionUID = -7826868935083157712L;

    @ApiModelProperty(value = "设备类型名称")
    private String name;
}

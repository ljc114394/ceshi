package com.boe.bank.common.bean.logbean;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 登录导出
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:27
 */
@Data
@ApiModel(description = "登录导出bean")
public class LogExportLoginBean {

    @ExcelProperty(value = "序号", index = 0)
    private Integer id;

    @ExcelProperty(value = "登录ip", index = 1)
    private String  ip;

    @ExcelProperty(value = "登录时间", index = 2)
    private String createTime;

    @ExcelProperty(value = "登录用户", index = 3)
    private String  userName;

    @ExcelProperty(value = "操作结果", index = 4)
    private String  jsonResult;

    @ExcelProperty(value = "所属机构", index = 5)
    private String  orgName;

    @ExcelIgnore
    private Integer operatorType;

    @ExcelProperty(value = "类型", index = 6)
    private String operatorTypeName;


}

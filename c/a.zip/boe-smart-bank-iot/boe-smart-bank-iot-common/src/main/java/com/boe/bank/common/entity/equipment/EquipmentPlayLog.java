package com.boe.bank.common.entity.equipment;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.Data;

/**
 * 设备播放日志
 *
 * @author 10183279
 * @date 2020/10/28
 */
@Data
@TableName("t_equipment_play_log")
public class EquipmentPlayLog implements Serializable {

    private static final long serialVersionUID = 1396985362028184925L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 设备id
     */
    @TableField(value = "equipment_id")
    private Integer equipmentId;
    /**
     * 节目id
     */
    @TableField(value = "program_id")
    private Integer programId;
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime createTime;
    /**
     * 播放时间
     */
    @TableField(value = "play_time")
    private String playTime;
    /**
     * 日志存储在服务器上面的地址
     */
    @TableField(value = "log_url")
    private String logUrl;
    /**
     * 节目类型；普通节目:1, 插播:2
     */
    @TableField(value = "program_type")
    private Integer programType;
}

package com.boe.bank.common.bean.appliedbizmanege;

public enum AppliedBizManegeComponentBean {

    PAGINATION(1, "分页查询"),
    DETAIL(2, "查看详情"),
    ADD(3, "新增"),
    EDITOR(4, "编辑"),
    DELETION(5, "编辑"),
    UPLOAD(6, "上传"),
    DOWNLOAD(7, "下载");
    private Integer componentcode;
    private String componentName;

    AppliedBizManegeComponentBean(Integer componentcode, String componentName) {
        this.componentcode = componentcode;
        this.componentName = componentName;
    }

}

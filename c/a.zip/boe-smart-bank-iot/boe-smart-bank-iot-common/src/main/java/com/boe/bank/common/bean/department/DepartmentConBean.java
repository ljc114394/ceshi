package com.boe.bank.common.bean.department;

import com.boe.bank.common.base.PageBean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:
* @author: zhaohaixia
* @date: 2020年9月28日 下午4:36:09
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "部门查询bean")
public class DepartmentConBean extends PageBean {

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "所在机构名称")
    private String orgName;

    @ApiModelProperty(value = "上级部门名称")
    private String departmentName;
    
    @ApiModelProperty(value = "机构id或者部门id")
    private Long parent;
    
}

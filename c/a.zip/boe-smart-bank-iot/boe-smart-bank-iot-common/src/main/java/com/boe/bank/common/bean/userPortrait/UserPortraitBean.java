package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用户画像-页面交互
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Data
public class UserPortraitBean {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "画像名称")
    private String portraitName;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "画像人数分布")
    private Integer personNums;

    @ApiModelProperty(value = "启用时长/小时")
    private Integer hourLength;//启用时间

    @ApiModelProperty(value = "用户画像关联标签数量")
    private Integer portraitLabelNums;//用户画像关联标签数量

    @ApiModelProperty(value = "用户画像关联产品数量")
    private Integer portraitProductNums;//用户画像关联产品数量

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "权重")
    private Integer weight;//权重

}

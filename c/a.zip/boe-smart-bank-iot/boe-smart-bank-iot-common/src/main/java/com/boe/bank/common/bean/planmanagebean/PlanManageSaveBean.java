package com.boe.bank.common.bean.planmanagebean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/12 16:53
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "计划管理-添加、修改bean")
public class PlanManageSaveBean {

    @ApiModelProperty(value = "计划名称")
    private String title;

    @ApiModelProperty(value = "计划开始时间 格式:yyyy-MM-dd")
    private String beginTime;

    @ApiModelProperty(value = "计划结束时间 格式:yyyy-MM-dd")
    private String endTime;

    @ApiModelProperty(value = "计划时间,顿号分隔 周一、周二")
    private String planTime;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "素材集合")
    private List<PlanMaterialManageSaveBean> list;

}

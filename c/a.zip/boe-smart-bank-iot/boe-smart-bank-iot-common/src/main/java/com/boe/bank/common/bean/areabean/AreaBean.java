package com.boe.bank.common.bean.areabean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lu
 * @version 1.0
 * @data 2020/9/29
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AreaBean {


    @ApiModelProperty(value = "区域名称")
    private String title;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "部门id")
    private Integer departmentId;

}

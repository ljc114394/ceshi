package com.boe.bank.common.bean.activiti;

import lombok.Data;

/**
 * activiti流程部署实例
 * @author caoxuhao
 */
@Data
public class ActivitiProcessBo {
	
	/**部署id*/
	private String deploymentId;
	
	/**类别*/
	private String category;
	
	/**流程key*/
	private String processKey;
	
	/**流程名称*/
	private String processName;
	
	/**流程部署文件名称*/
	private String resourceName;
}

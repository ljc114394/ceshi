package com.boe.bank.common.bean.equipmentlogbean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "设备日志-添加、修改bean")
public class EquipmentLogSaveBean {
    
    @ApiModelProperty(value = "主键")
    private Integer id;
    
    @ApiModelProperty(value = "日志级别")
    private Integer level;
    
    @ApiModelProperty(value = "日志内容")
    private String message;
    
    @ApiModelProperty(value = "日志产生时间")
    private String time;
    
    @ApiModelProperty(value = "日志存储在服务器上面的地址")
    private String logUrl;
    
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;
    
    @ApiModelProperty(value = "设备mac地址")
    private String mac;
}

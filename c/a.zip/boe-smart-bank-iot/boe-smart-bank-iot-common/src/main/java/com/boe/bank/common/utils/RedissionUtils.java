package com.boe.bank.common.utils;

import com.boe.bank.common.constant.RedisPrefix;
import org.redisson.api.*;
import org.redisson.client.codec.Codec;
import org.redisson.client.codec.StringCodec;
import org.redisson.codec.JsonJacksonCodec;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * redission工具类
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/11 8:53
 */
public class RedissionUtils {

    private static final Integer NO_MAXVALUE =999;


    private final RedissonClient redissonClient;

    public RedissionUtils(RedissonClient redissonClient) {
        super();
        this.redissonClient = redissonClient;
    }

    /**
     *  判断 key 是否存在
     * @param objectName
     * @return
     */
    public  Boolean isExist(String objectName) {
        return getRBucket(objectName).isExists();
    }


    /**
     * 获取字符串对象
     *
     * @param objectName
     * @return
     */
    public <V> RBucket<V> getRBucket(String objectName) {
        RBucket<V> bucket = redissonClient.getBucket(objectName, JsonJacksonCodec.INSTANCE);
        return bucket;
    }

    /**
     * 获取key的值
     * @param key
     * @return
     */
    public Object getRBucketValue(String key) {
        return getRBucket(key).get();
    }

    /**
     * 赋值
     * @param key
     * @param value
     * @param <V>
     */
    public <V> void setRBucket(String key, V value) {
        getRBucket(key).set(value);
    }

    /**
     * 赋值 有效期
     * @param key
     * @param value
     * @param timeToLive
     * @param timeUnit
     * @param <V>
     */
    public <V> void setRBucket(String key, V value, long timeToLive, TimeUnit timeUnit) {
        getRBucket(key).set(value, timeToLive, timeUnit);
    }

    /**
     * 删除
     * @param key
     */
    public boolean deleteRBucket(String key) {
        return getRBucket(key).delete();
    }

    /**
     * 获取Map对象
     *
     * @param objectName
     * @return
     */
    public <K, V> RMap<K, V> getRMap(String objectName) {
        RMap<K, V> map = redissonClient.getMap(objectName,JsonJacksonCodec.INSTANCE);
        return map;
    }

//    /**
//     * 获取Map对象(带本地缓存的map对象，具体使用方法在学习中)
//     *
//     * @param objectName
//     * @return
//     */
//    public <K, V> RLocalCachedMap<K, V> getRLocalCachedMap(String objectName) {
//    	RLocalCachedMap<K, V> map = redissonClient.getLocalCachedMap(objectName, LocalCachedMapOptions.defaults().cacheSize(1).syncStrategy(SyncStrategy.INVALIDATE));
//    	return map;
//    }

    /**
     * 获取有序集合
     *
     * @param objectName
     * @return
     */
    public <V> RSortedSet<V> getRSortedSet(String objectName) {
        RSortedSet<V> sortedSet = redissonClient.getSortedSet(objectName,JsonJacksonCodec.INSTANCE);
        return sortedSet;
    }

    /**
     * 获取集合
     *
     * @param objectName
     * @return
     */
    public <V> RSet<V> getRSet(String objectName) {
        RSet<V> rSet = redissonClient.getSet(objectName,JsonJacksonCodec.INSTANCE);
        return rSet;
    }

    /**
     * 获取列表
     *
     * @param objectName
     * @return
     */
    public <V> RList<V> getRList(String objectName) {
        RList<V> rList = redissonClient.getList(objectName,JsonJacksonCodec.INSTANCE);
        return rList;
    }

    /**
     * 获取锁
     *
     * @param objectName
     * @return
     */
    public RLock getRLock(String objectName) {
        RLock rLock = redissonClient.getLock(objectName);
        return rLock;
    }

    /**
     * 获取原子数
     *
     * @param objectName
     * @return
     */
    public RAtomicLong getRAtomicLong(String objectName) {
        RAtomicLong rAtomicLong = redissonClient.getAtomicLong(objectName);
        return rAtomicLong;
    }

    /**
     * 按用户id和天为维度生成递增的单号
     *
     * @return
     */
    public  String createNo(String idKey) {
        StringBuilder sb = new StringBuilder();
        String dateStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd"));//获取当前时间yyyyMMdd
        sb.append(dateStr);
        String keyPrefix = sb.toString();
        RAtomicLong atomicVar = getRAtomicLong(idKey);
        long keySuffix = atomicVar.incrementAndGet();
        if (keySuffix > NO_MAXVALUE) {
            //log.error("自动生成id失败，序号大于999");
            throw new RuntimeException("生成预约单号失败，序号大于999");
        }
        Long expiresTime = getSecondsNextEarlyMorning();
        atomicVar.expire(expiresTime, TimeUnit.SECONDS);
        //String keySuffixStr = String.format("%03d", keySuffix);
        return keyPrefix + keySuffix;
    }

    /**
     * 判断当前时间距离第二天凌晨的秒数
     *
     * @return 返回值单位为[s:秒]
     */
    private  Long getSecondsNextEarlyMorning() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return (cal.getTimeInMillis() - System.currentTimeMillis()) / 1000;
    }
}

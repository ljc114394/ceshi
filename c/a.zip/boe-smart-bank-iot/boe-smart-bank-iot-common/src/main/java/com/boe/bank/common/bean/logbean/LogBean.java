package com.boe.bank.common.bean.logbean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 9:04
 */
@Data
@ApiModel(description = "日志bean")
public class LogBean  {

    @ApiModelProperty(value = "操作用户")
    private String createBy;

    @ApiModelProperty(value = "机构id")
    private String orgId;

    @ApiModelProperty(value = "所属机构")
    private String orgName;

    @ApiModelProperty(value = "素材类型 图片/视频/文档  --只有素材用")
    private String materialType;

    @ApiModelProperty(value = "操作内容(新增《》/删除《》/编辑《》)")
    private String operationContent;

    @ApiModelProperty(value = "审批单号 --只有审批用")
    private String approvalNo;

    @ApiModelProperty(value = "业务类型 --只有审批用")
    private String busniessType;

    @ApiModelProperty(value = "审批类型 --只有审批用")
    private String approvalType;

    @ApiModelProperty(value = "审批结果  --只有审批用")
    private String approvalResult;

    @ApiModelProperty(value = "操作时间")
    private String createTime;




}

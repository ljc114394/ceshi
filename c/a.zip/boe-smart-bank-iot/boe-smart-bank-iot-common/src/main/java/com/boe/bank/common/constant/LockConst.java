package com.boe.bank.common.constant;

/**
* @Description:锁常量类
* @author: lvjiacheng
* @date: 2020年12月16日 下午1:58:06
 */
public class LockConst {
	/**
	 * 计划和设备默认锁key
	 */
    public static final String PLAN_EQUIOMENT_LOCK = "plan_equipment_lock";




}

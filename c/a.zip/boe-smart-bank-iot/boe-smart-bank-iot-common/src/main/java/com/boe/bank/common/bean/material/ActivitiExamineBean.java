package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:
* @author: zhaohaixia
* @date: 2020年10月22日 下午2:40:30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "审批类型列表bean")
public class ActivitiExamineBean {
	
	@ApiModelProperty(value = "审批类型id")
	private Integer id;
	
	@ApiModelProperty(value = "审批类型名称")
	private String title;//审批类型 素材有，设备和计划没有
	
}

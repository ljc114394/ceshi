package com.boe.bank.common.bean.userinfobean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/9/29 14:53
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoSearchBean extends PageBean {

    @ApiModelProperty(value = "姓名")
    @Emoticon
    private String name;

    @ApiModelProperty(value = "账号")
    @Emoticon
    private String username;

    @ApiModelProperty(value = "机构树下的部门id ")
    private Integer departmentId;

    @ApiModelProperty(value = "机构树下的机构id ")
    private Integer orgId;
}

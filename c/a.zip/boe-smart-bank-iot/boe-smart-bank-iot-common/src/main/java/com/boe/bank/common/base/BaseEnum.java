package com.boe.bank.common.base;

public interface BaseEnum<K,V> {
    K code();
    V message();
}

package com.boe.bank.common.constant;

/**
* @Description:常量类
* @author: zhaohaixia
* @date: 2020年9月29日 下午4:29:06
 */
public class Const {
	/**
	 * 默认第一页
	 */
    public static final int PAGE_NUM_DEFAULT = 1;
    /**
     * 默认每页条数
     */
    public static final int PAGE_SIZE_DEFAULT = 10;

    /**
     * 上锁等待时间
     */
    public static final int WAIT_TIME = 0;

    /**
     * 自动解锁时间
     */
    public static final int LEASE_TIME = 60;

    /**
     * 接口访问默认间隔时间  以秒为单位
     */
    public static final int ACCESS_TIME = 5;


}

package com.boe.bank.common.constant;
/**
* @Description:上传管理的文件夹路径
* @author: lvjiacheng
* @date: 2020年11月4日 3:41:44
 */
public class UploadDir {

	public static String PIC = "pic";
	public static String VIDEO = "video";
	public static String TEXT = "text";
	public static String WEB = "web";
	public static String DOCUMENT = "document";
	public static String PROGRAM = "program";
	public static String XML = "xml";

}

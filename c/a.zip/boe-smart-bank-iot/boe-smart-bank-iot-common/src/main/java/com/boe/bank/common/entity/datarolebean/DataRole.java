package com.boe.bank.common.entity.datarolebean;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/15 17:44
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataRole extends BaseEntity implements Serializable {

    //主键id
    private Integer id;

    //角色id
    private Integer roleId;

    //机构id
    private Integer orgId;


}

package com.boe.bank.common.bean.equipment;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备插播记录查询对象
 *
 * @author 10183279
 * @date 2020/10/13
 */
@ApiModel(value = "设备插播记录查询对象")
@Data
public class EquipmentSpotsQO extends PageBean implements Serializable {

    private static final long serialVersionUID = 3419548708445748945L;

    @ApiModelProperty(value = "mac地址", hidden = true)
    private String mac;

    @ApiModelProperty(value = "计划名称")
    private String planName;

    @ApiModelProperty(value = "所属机构id")
    private Long orgId;

    @ApiModelProperty(value = "插播人")
    private String createBy;
}

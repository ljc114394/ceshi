package com.boe.bank.common.bean.logbean;

import com.boe.bank.common.base.PageBean;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 9:04
 */
@Data
@ApiModel(description = "日志-查询bean")
public class ApprovalLogSearchBean extends PageBean {

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "审批业务类型： a21素材 a22计划 a23设备")
    private String busniessType;

    @ApiModelProperty(value = "审批结果 a11待处理/a12同意/a13拒绝")
    private String approvalResult;

    @JsonIgnore
    private List<String> orgIdList;

    //限定导出的时间戳
    @JsonIgnore
    private Long exportTime;

}

package com.boe.bank.common.bean.terminalversion;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 客户端版本DTO
 *
 * @author 10183279
 * @date 2020/10/29
 */
@ApiModel(value = "客户端版本DTO")
@Data
public class TerminalVersionDTO implements Serializable {

    private static final long serialVersionUID = 875888130467953705L;

    @ApiModelProperty(value = "客户端名称")
    @NotBlank(message = "客户端名称不能为空")
    private String name;

    @ApiModelProperty(value = "客户端版本名称")
    @NotBlank(message = "客户端版本不能为空")
    private String version;

    @ApiModelProperty(value = "类型")
    private Integer type;

    @ApiModelProperty(value = "描述")
    private String remark;

    @ApiModelProperty(value = "安装包")
    private MultipartFile file;
}

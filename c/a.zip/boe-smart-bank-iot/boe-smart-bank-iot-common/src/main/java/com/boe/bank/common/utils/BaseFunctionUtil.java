package com.boe.bank.common.utils;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RList;
import org.redisson.api.RMap;
import org.slf4j.Logger;

import com.google.common.collect.Lists;

/**
 * 数据库与redis存储工具类
 * @author caoxuhao
 */
public class BaseFunctionUtil {
	
	/**
	 * 从redis读，没有则按baseFuncionHelper接口中的函数查，并存入redis（默认90天）
	 * @param <T>
	 * @param log
	 * @param redisPerfix
	 * @param myKey
	 * @param redissionUtils
	 * @param baseFuncionHelper
	 * @return
	 */
	public static <T> T loadFromRedis(Logger log, String redisPerfix, String myKey,
			RedissionUtils redissionUtils, BaseFuncionHelper baseFuncionHelper) {
		return loadFromRedis(log, redisPerfix, myKey, 90, TimeUnit.DAYS, redissionUtils, baseFuncionHelper);
	}
	

	/**
	 * 从redis读，没有则按baseFuncionHelper接口中的函数查，并存入redis
	 * @param <T>
	 * @param logger
	 * @param redisPerfix
	 * @param myKey
	 * @param redisExpiredTime
	 * @param timeUnit
	 * @param redissionUtils
	 * @param baseFuncionHelper
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static <T> T loadFromRedis(Logger log, String redisPerfix, String myKey, long redisExpiredTime,
			TimeUnit timeUnit, RedissionUtils redissionUtils, BaseFuncionHelper baseFuncionHelper) {
		// 入参检测

		if (StringUtils.isEmpty(myKey) || StringUtils.isEmpty(redisPerfix) || redisExpiredTime < 0 || timeUnit == null
				|| redissionUtils == null) {
			return null;
		}

		// 先从缓存取，如果没有，则从数据库取
		String key = StringUtil.appendToStr(redisPerfix, myKey);
		T object = null;
		try {
			object = (T) redissionUtils.getRBucketValue(key);
			if (object == null) {
				object = (T) baseFuncionHelper.run();
				if (object != null) {
					redissionUtils.getRBucket(key).setAsync(object, redisExpiredTime, timeUnit);
				}
			}
		} catch (Exception e) {
			StackTraceElement stackTrace = e.getStackTrace()[1];
			if (log == null) {
				System.out.println(stackTrace.getClassName() + "从redis中获取" + key + "时出现异常，入参key：" + key);
			} else {
				log.info("{} 从redis中获取时出现异常，入参key：{}", stackTrace.getClassName(), key);
			}

			e.printStackTrace();

			object = (T) baseFuncionHelper.run();
		}

		return object;
	}
	
	/**
	 * 同时删除redis数据,同时操作数据库
	 * @param redisPerfix
	 * @param myKey
	 * @param redissionUtils
	 * @return
	 */
	public static boolean deleteRedisAndOptDb(String redisPerfix, String myKey, RedissionUtils redissionUtils, BaseFuncionHelper baseFuncionHelper) {
		if(!deleteRedis(redisPerfix, myKey, redissionUtils))
			return false;
		
		if(!((boolean)baseFuncionHelper.run()))
			return false;
			
		return deleteRedis(redisPerfix, myKey, redissionUtils);
	}
	
	/**
	 * 删redis数据，如果没有直接返回true
	 * @param redisPerfix
	 * @param myKey
	 * @param redissionUtils
	 * @return	是否删除成功
	 */
	public static boolean deleteRedis(String redisPerfix, String myKey, RedissionUtils redissionUtils) {
		String key = StringUtil.appendToStr(redisPerfix, myKey);
		Object value = redissionUtils.getRBucketValue(key);
		//没有缓存，直接返回成功
		if(value == null)
			return true;
		
		return redissionUtils.deleteRBucket(key);
	}

	/**
	 * 从redis读，没有则按baseFuncionHelper接口中的函数查，并存入redis（保存到今天结束）
	 * 
	 * @param <T>
	 * @param log
	 * @param redisKey
	 * @param myKey
	 * @param redissionUtils
	 * @param baseFuncionHelper
	 * @return
	 */
	public static <T> T loadFromRedisTodayEnd(Logger log, String redisKey, String myKey, RedissionUtils redissionUtils,
			BaseFuncionHelper baseFuncionHelper) {
		// 保存到当天结束
		long redisExpiredTime = DateUtil.getEndTimeOfDay(new Date()).getTime() - DateUtil.currentTimeStampMillisecond();
		return loadFromRedis(log, redisKey, myKey, redisExpiredTime, TimeUnit.MILLISECONDS, redissionUtils,
				baseFuncionHelper);
	}

	/**
	 * 从redis读取list，如果没有则存redis的Map。用redisKey作为Key，用redisMapKey作为Map的Key
	 * 
	 * @param <T>
	 * @param log
	 * @param redissionUtils
	 * @param redisKey          redis的Key
	 * @param redisMapKey       redis Map 的Key
	 * @param baseFuncionHelper 数据库需要查list的语句
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> loadListFromRedisMap(Logger log, RedissionUtils redissionUtils, String redisKey,
			Function<? super T, Object> redisMapKey, BaseFuncionHelper baseFuncionHelper) {

		List<T> list = Lists.newArrayList();

		try {
			// 从redis读
			RMap<String, T> rMap = redissionUtils.getRMap(redisKey);
			if (rMap.size() > 0) {
				for (String key : rMap.keySet()) {
					list.add(rMap.get(key));
				}
				return list;
			}

			// 从数据库读
			list = (List<T>) baseFuncionHelper.run();
			if (list != null && list.size() > 0) {
				// 写到redis
				setListInRedisMap(log, redissionUtils, redisKey, list, redisMapKey);
			}

		} catch (Exception e) {
			// 从数据库读
			list = (List<T>) baseFuncionHelper.run();
		}

		if (list == null || list.size() == 0) {
			list = Lists.newArrayList();
		}

		return list;
	}

	/**
	 * 从redis读取list，用redisKey作为Key
	 * 
	 * @param <T>
	 * @param log
	 * @param redissionUtils
	 * @param redisKey          redis的Key
	 * @param baseFuncionHelper 数据库需要查list的语句
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> loadListFromRedis(Logger log, RedissionUtils redissionUtils, String redisKey,
			BaseFuncionHelper baseFuncionHelper) {
		List<T> list;
		try {
			// 从redis读
			RList<T> rList = redissionUtils.getRList(redisKey);
			if (rList != null && rList.size() > 0) {
				return rList;
			}
			// 从数据库读
			list = (List<T>) baseFuncionHelper.run();
		} catch (Exception e) {
			// 从数据库读
			list = (List<T>) baseFuncionHelper.run();
		}
		if (list == null || list.size() == 0) {
			list = Lists.newArrayList();
		} else {
			// 写到redis
			setListInRedis(log, redissionUtils, redisKey, list);
		}
		return list;
	}

	/**
	 * 从redis读取对象（如果没有则存redis的Map。用redisKey作为Key，用redisMapKey作为Map的Key）
	 * 
	 * @param <T>
	 * @param log
	 * @param redissionUtils
	 * @param redisKey          redis的Key
	 * @param redisMapKey       redis Map 的Key
	 * @param baseFuncionHelper 数据库查询语句
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T loadFromRedisMap(Logger log, RedissionUtils redissionUtils, String redisKey, String redisMapKey,
			BaseFuncionHelper baseFuncionHelper) {
		T t = null;
		try {
			// 从redis读
			RMap<String, T> rMap = redissionUtils.getRMap(redisKey);
			t = (T) (rMap.get(redisMapKey));
			if (t != null)
				return t;

			// 从数据库读
			t = (T) baseFuncionHelper.run();

			// 写到redis
			rMap.fastPut(redisMapKey, t);
		} catch (Exception e) {
			// 从数据库读
			t = (T) baseFuncionHelper.run();
		}

		return t;
	}

	/**
	 * 从redis读取对象（如果没有则按listSql存redis的Map。用redisKey作为Key，用redisMapKeyFunction作为Map的Key）
	 * 
	 * @param <T>
	 * @param log
	 * @param redissionUtils
	 * @param redisKey
	 * @param redisMapKey         redis Map 的key
	 * @param redisMapKeyFunction redis Map 的key 的get方法
	 * @param loadSql             读取单独一条数据sql
	 * @param listSql             读取全部数据sql
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T loadFromRedisMapIfNotPutMap(Logger log, RedissionUtils redissionUtils, String redisKey,
			String redisMapKey, Function<? super T, Object> redisMapKeyFunction, BaseFuncionHelper loadSql,
			BaseFuncionHelper listSql) {
		T t = null;
		try {
			// 从redis读
			RMap<String, T> rMap = redissionUtils.getRMap(redisKey);
			t = (T) (rMap.get(redisMapKey));
			if (t != null)
				return t;

			// 从数据库读
			t = (T) loadSql.run();

			// 写到redis
			loadListFromRedisMap(log, redissionUtils, redisKey, redisMapKeyFunction, listSql);

		} catch (Exception e) {
			// 从数据库读
			t = (T) loadSql.run();
		}

		return t;
	}

	private static <T> boolean setListInRedisMap(Logger log, RedissionUtils redissionUtils, String redisKey,
			List<T> list, Function<? super T, Object> redisMapKey) {

		if (redisKey == null || "".equals(redisKey)) {
			log.info("redis存储map异常，redisKey为null");
			return false;
		}

		RMap<String, T> rMap = redissionUtils.getRMap(redisKey);

		List<Object> keys = list.stream().map(redisMapKey).collect(Collectors.toList());
		// 校验空指针
		for (Object object : keys) {
			if (object == null) {
				log.info("redis存储map异常，redisMapKey为null redisKey:{}", redisKey);
				return false;
			}
		}

		for (int i = 0; i < keys.size(); i++) {
			T t = list.get(i);
			Object key = keys.get(i);
			if (key != null)
				rMap.put(key.toString(), t);
		}

		return true;
	}

	private static <T> boolean setListInRedis(Logger log, RedissionUtils redissionUtils, String redisKey,
			List<T> list) {
		if (redisKey == null || "".equals(redisKey)) {
			log.info("redis存储list异常，redisKey为null");
			return false;
		}
		RList<T> rList = redissionUtils.getRList(redisKey);
		return rList.addAll(list);
	}

}

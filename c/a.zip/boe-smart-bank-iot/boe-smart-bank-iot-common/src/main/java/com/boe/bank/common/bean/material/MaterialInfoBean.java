package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
* @Description:素材管理查看bean
* @author: zhaohaixia
* @date: 2020年10月13日 上午11:25:10
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材查看bean")
public class MaterialInfoBean {
	
	@ApiModelProperty(value = "标签名称")
    private String lableTitle;

	@ApiModelProperty(value = "素材名称")
    private String title;
	
	@ApiModelProperty(value = "审批类型名称")
    private String approvalTitle;
	
	@ApiModelProperty(value = "type为6时，表示程序参数")
    private String programEntry;
	
	@ApiModelProperty(value = "type为1或者2，表示缩略图名称；type为3，表示文本内容；type为4，表示web地址；type为5，表示文档名称；type为6，表示程序入口")
    private String content;
	
	@ApiModelProperty(value = "类型，1图片资源，2视频资源 3文本内容 4web 5文档管理 6.应用程序")
    private Integer type;

    @ApiModelProperty(value = "空字符串表示长期，其他表示日期")
    private String valTime;

    
}
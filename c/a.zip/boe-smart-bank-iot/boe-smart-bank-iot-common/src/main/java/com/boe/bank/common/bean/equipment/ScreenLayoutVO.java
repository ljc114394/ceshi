package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 屏幕区域布局
 *
 * @author 10183279
 * @date 2020/11/6
 */
@ApiModel(value = "屏幕区域布局")
@Data
public class ScreenLayoutVO implements Serializable {

    private static final long serialVersionUID = 9017438454350776709L;

    @ApiModelProperty(value = "x轴坐标")
    private Integer x;

    @ApiModelProperty(value = "y轴坐标")
    private Integer y;

    @ApiModelProperty(value = "宽")
    private Integer width;

    @ApiModelProperty(value = "高")
    private Integer height;

    @ApiModelProperty(value = "节目列表")
    private List<ProgramVO> resArr;
}

package com.boe.bank.common.utils;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

/**
 * 参数工具类
 * @author caoxuhao
 */
public class ParamUtil {

	/**
	 * 空参校验
	 * @param params 所有必传参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isNullOrEmpty(Object ... params) {
		//未传参数
		if(params == null)
			return false;
		
		for (Object param : params) {
			//任意一个变量为null，则校验不通过
			if(param == null)
				return true;
			
			if(param instanceof String && ((String) param).isEmpty()) {
				return true;
			}
			
			if(param instanceof List && CollectionUtils.isEmpty((List)param)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * List转Map
	 * @param <R>		R is type of Map's key
	 * @param <T>		T is type of Map's value and type of List
	 * @param list		source list
	 * @param mapper	实体类T中获取Map的Key的方法 如Equipment::getMac
	 * @param map		dest map
	 * @return
	 * @author caoxuhao
	 */
	public static <R,T> boolean List2Map(List<T> list, Function<? super T, ? extends R> mapper, 
			Map<R, T> map) {
		
		if(list == null || list.size() == 0 || mapper == null || map == null) {
			return false;
		}
		
		//这里保证key不为null，且查询出的列也不会为null
		Map<R, T> mapTmp = list.stream().collect(Collectors.toMap(mapper, t -> t));
		map.putAll(mapTmp);
		
		return true;
	}
}

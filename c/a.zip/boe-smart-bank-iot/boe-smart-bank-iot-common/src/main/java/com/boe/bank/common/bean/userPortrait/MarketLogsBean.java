package com.boe.bank.common.bean.userPortrait;

import com.boe.bank.common.bean.marketLabel.MarketLabelNatureAiDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description:dto
 * @Author: lijianglong
 * @Data:2020/10/27
 */

@Data
public class MarketLogsBean {

    @ApiModelProperty(value = "人脸id")
    private String faceId;

    @ApiModelProperty(value = "产品主键id")
    private Integer productId;

    @ApiModelProperty(value = "人脸特征向量")
    private String faceFeature;

    @ApiModelProperty(value = "画像id,英文逗号隔开拼接")
    private String portraitId;//画像id,英文逗号隔开拼接

    @ApiModelProperty(value = "标签id，英文逗号隔开拼接")
    private String marketLabelId;//标签id，英文逗号隔开拼接

    @ApiModelProperty(value = "设备地址")
    private String mac;

    @ApiModelProperty(value = "存储ai传过来的属性数据或最终的结果")
    private List<MarketLabelNatureAiDTO> propertyJsons;//存储ai传过来的属性数据或最终的结果
}

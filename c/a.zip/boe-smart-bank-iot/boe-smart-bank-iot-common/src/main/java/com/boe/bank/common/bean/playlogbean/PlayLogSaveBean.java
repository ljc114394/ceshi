package com.boe.bank.common.bean.playlogbean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "播放日志-添加、修改bean")
public class PlayLogSaveBean {

    @ApiModelProperty(value = "设备mac地址")
    private String mac;
    
    @ApiModelProperty(value = "设备id")
    private Integer equipmentId;

    @ApiModelProperty(value = "播放时间 格式:yyyy-MM-dd HH:mm:ss")
    private String playTime;

    @ApiModelProperty(value = "节目id")
    private String programId;
    
    @ApiModelProperty(value = "日志存储在服务器上的地址")
    private String logUrl;

    @ApiModelProperty(value = "节目类型；普通节目:1, 插播:2")
    private Integer programType;
}

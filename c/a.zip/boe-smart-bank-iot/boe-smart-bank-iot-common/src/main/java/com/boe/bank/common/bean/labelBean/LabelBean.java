package com.boe.bank.common.bean.labelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * TODO
 * 标签管理-添加、修改数据
 * @author lijianglong
 * @data 2020/10/13
 */

@Data
public class LabelBean {

    @ApiModelProperty(value = "标签管理ID")
    private Integer id;

    @ApiModelProperty(value = "标签名称")
    private String title;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "备注")
    private String remark;
}

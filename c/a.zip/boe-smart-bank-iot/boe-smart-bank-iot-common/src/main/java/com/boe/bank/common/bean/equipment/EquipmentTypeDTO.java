package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 设备类型
 *
 * @author 10183279
 * @date 2020/12/1
 */
@Data
@ApiModel(value = "设备类型")
public class EquipmentTypeDTO implements Serializable {

    private static final long serialVersionUID = -6567974767841384665L;

    @ApiModelProperty(value = "设备类型名称")
    @NotBlank(message = "设备类型名称不能为空")
    @Size(max = 20, message = "设备类型名称的长度不能超过20")
    private String name;

    @ApiModelProperty(value = "备注")
    @Size(max = 200, message = "备注的长度不能超过200")
    private String remark;
}

package com.boe.bank.common.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.boe.bank.common.utils.EmojiFilter;
import org.apache.commons.lang3.StringUtils;

/**
* @Description:验证器来实现验证逻辑   针对字段，不能含有表情符
* @author: zhaohaixia
* @date: 2020年12月4日 下午5:09:48
 */
public class EmoticonValidator implements ConstraintValidator<Emoticon,String> {
	
    @Override
    public void initialize(Emoticon constraintAnnotation) {
    }

    @Override
    public boolean isValid(String emo, ConstraintValidatorContext constraintValidatorContext) {

        //之前只判断是否包含emoji字符，现新增是否包含特殊通配符，解决查询输入%，查出所有数据的问题--2021-1-14
		 if((StringUtils.isNotEmpty(emo) &&EmojiFilter.containsEmoji(emo)||(StringUtils.isNotEmpty(emo)&&EmojiFilter.containsWildcard(emo)))) {//含有表情
			 return false;
		 }
		 return true;
    }
}
package com.boe.bank.common.constant;
/**
* @Description:素材管理上传管理的文件夹路径
* @author: zhaohaixia
* @date: 2020年10月14日 下午3:13:44
 */
public class MaterialDir {

	public static String PIC = "pic";
	public static String VIDEO = "video";
	public static String TEXT = "text";
	public static String WEB = "web";
	public static String DOCUMENT = "document";
	public static String PROGRAM = "program";
	
}

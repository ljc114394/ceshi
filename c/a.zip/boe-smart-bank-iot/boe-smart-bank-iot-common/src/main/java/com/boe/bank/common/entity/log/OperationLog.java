package com.boe.bank.common.entity.log;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/29 17:01
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OperationLog extends BaseEntity implements Serializable {

    //主键id
    private Integer id;

    //机构id
    private Integer orgId;

    //机构名称
    private String  orgName;

    //素材类型 图片/视频/文档
    private String materialType;

    //操作类型1新增/2修改/3删除
    private Integer operationType;

    //操作内容(新增《》/删除《》/编辑《》)
    private String operationContent;

    //模块类型-1素材/2计划/3设备/4权限/
    private Integer moduleType;

    //创建时间的时间戳
    private Long createAt;

}

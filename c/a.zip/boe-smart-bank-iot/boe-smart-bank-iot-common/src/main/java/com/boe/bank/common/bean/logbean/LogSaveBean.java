package com.boe.bank.common.bean.logbean;

import com.boe.cloud.megarock.security.common.UserInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import org.springframework.context.ApplicationEvent;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 9:04
 */
@Data
@Builder
@ApiModel(description = "日志-保存bean")
public class LogSaveBean extends ApplicationEvent{

    @ApiModelProperty(value = "素材类型 图片/视频/文档 --只有素材用")
    private String materialType;

    @ApiModelProperty(value = "操作类型1新增/2修改/3删除")
    private Integer operationType;

    @ApiModelProperty(value = "操作内容(新增《》/删除《》/编辑《》)")
    private String operationContent;

    @ApiModelProperty(value = " 模块类型-1素材/2计划/3设备/4权限/5审批类型)")
    private Integer moduleType;

    @ApiModelProperty(value = "审批单号 --只有审批用")
    private String approvalNo;

    @ApiModelProperty(value = "审批类型 --只有审批用")
    private String approvalType;

    @ApiModelProperty(value = "审批结果 a11待处理/a12同意/a13拒绝 --只有审批用")
    private String approvalResult;

    @ApiModelProperty(value = "审批业务类型： a21素材 a22计划 a23设备 --只有审批用")
    private String busniessType;

    private UserInfo userInfo;



    public LogSaveBean( String materialType, Integer operationType, String operationContent, Integer moduleType, String approvalNo, String approvalType, String approvalResult, String busniessType,UserInfo userInfo) {
        super("object");
        this.materialType = materialType;
        this.operationType = operationType;
        this.operationContent = operationContent;
        this.moduleType = moduleType;
        this.approvalNo = approvalNo;
        this.approvalType = approvalType;
        this.approvalResult = approvalResult;
        this.busniessType = busniessType;
        this.busniessType = busniessType;
        this.userInfo = userInfo;
    }

    public LogSaveBean(Object source) {
        super(source);
    }

    public String getMaterialType() {
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public String getOperationContent() {
        return operationContent;
    }

    public void setOperationContent(String operationContent) {
        this.operationContent = operationContent;
    }

    public Integer getModuleType() {
        return moduleType;
    }

    public void setModuleType(Integer moduleType) {
        this.moduleType = moduleType;
    }

    public String getApprovalNo() {
        return approvalNo;
    }

    public void setApprovalNo(String approvalNo) {
        this.approvalNo = approvalNo;
    }

    public String getApprovalType() {
        return approvalType;
    }

    public void setApprovalType(String approvalType) {
        this.approvalType = approvalType;
    }

    public String getApprovalResult() {
        return approvalResult;
    }

    public void setApprovalResult(String approvalResult) {
        this.approvalResult = approvalResult;
    }

    public String getBusniessType() {
        return busniessType;
    }

    public void setBusniessType(String busniessType) {
        this.busniessType = busniessType;
    }

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }
}

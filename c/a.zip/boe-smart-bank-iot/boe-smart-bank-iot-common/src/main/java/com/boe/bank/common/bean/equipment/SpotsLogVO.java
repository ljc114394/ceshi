package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 插播日志
 *
 * @author 10183279
 * @date 2020/11/6
 */
@ApiModel(value = "插播日志")
@Data
public class SpotsLogVO implements Serializable {

    private static final long serialVersionUID = -3889610657217193248L;

    @ApiModelProperty(value = "计划名称")
    private String title;

    @ApiModelProperty(value = "插播人")
    private String spotsBy;

    @ApiModelProperty(value = "实际播放时间")
    private String playTime;
}

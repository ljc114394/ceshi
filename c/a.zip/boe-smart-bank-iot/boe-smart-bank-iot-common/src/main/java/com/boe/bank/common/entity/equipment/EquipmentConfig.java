package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备配置
 *
 * @author 10183279
 * @date 2020/10/19
 */
@Data
@TableName("t_equipment_config")
public class EquipmentConfig extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -6788582142871836944L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 开机时间
     */
    @TableField(value = "on_time")
    private String onTime;
    /**
     * 关机时间
     */
    @TableField(value = "off_time")
    private String offTime;
    /**
     * 刷新间隔
     */
    @TableField(value = "refresh_interval")
    private Integer refreshInterval;
    /**
     * 音量
     */
    @TableField(value = "volume")
    private Integer volume;
    /**
     * 下载时间段
     */
    @TableField(value = "download_time")
    private String downloadTime;
    /**
     * 日志回传时间
     */
    @TableField(value = "log_return_time")
    private String logReturnTime;
    /**
     * 日志保存时间
     */
    @TableField(value = "log_retention_time")
    private Integer logRetentionTime;
    /**
     * 下载速度
     */
    @TableField(value = "download_speed")
    private Integer downloadSpeed;
    /**
     * 屏幕区域布局
     */
    @TableField(value = "screen_layout")
    private String screenLayout;
}

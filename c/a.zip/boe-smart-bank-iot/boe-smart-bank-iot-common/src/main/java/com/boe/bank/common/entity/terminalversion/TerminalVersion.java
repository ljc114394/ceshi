package com.boe.bank.common.entity.terminalversion;

import com.baomidou.mybatisplus.annotation.*;
import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 客户端版本
 *
 * @author 10183279
 * @date 2020/10/29
 */
@Data
@TableName("t_terminal_version")
public class TerminalVersion extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -5571199079572955392L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 客户端名称
     */
    @TableField(value = "name")
    private String name;
    /**
     * 客户端版本
     */
    @TableField(value = "version")
    private String version;
    /**
     * 类型
     */
    @TableField(value = "type")
    private Integer type;
    /**
     * 文件大小
     */
    @TableField(value = "file_size")
    private Integer fileSize;
    /**
     * MD5
     */
    @TableField(value = "md5")
    private String md5;
    /**
     * 客户端路径
     */
    @TableField(value = "url")
    private String url;
    /**
     * 描述
     */
    @TableField(value = "remark")
    private String remark;
    /**
     * 审核状态
     */
    @TableField(value = "audit_status")
    private Integer auditStatus;
    /**
     * 0未删除/1已删除
     */
    @TableField(value = "is_delete")
    @TableLogic
    private Integer isDelete;
}

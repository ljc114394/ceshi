package com.boe.bank.common.entity.userPortrait;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description:用户群画像关联标签标
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPortraitLabel extends BaseEntity implements Serializable {

    private Integer id;//主键id

    private Integer portraitId;//用户画像主键id

    private Integer labelId;//标签id

    private Integer labelParentId;//标签id

    private String labelName;//标签名称
}

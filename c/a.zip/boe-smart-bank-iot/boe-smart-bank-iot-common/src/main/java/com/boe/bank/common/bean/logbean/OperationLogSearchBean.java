package com.boe.bank.common.bean.logbean;

import com.boe.bank.common.base.PageBean;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 9:04
 */
@Data
@ApiModel(description = "日志-查询bean")
public class OperationLogSearchBean extends PageBean {

    @ApiModelProperty(value = " 模块类型-1素材/2计划/3设备/4权限)")
    private Integer moduleType;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "操作类型1新增/2修改/3删除")
    private Integer operationType;


    @JsonIgnore
    private List<String> orgIdList;

    //限定导出的时间戳
    @JsonIgnore
    private Long exportTime;


}

package com.boe.bank.common.bean.datarolebean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/20 15:14
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataRoleOrgBean {

    @ApiModelProperty(value = "机构id")
    private Integer id;

    @ApiModelProperty(value = "机构name")
    private String name;



}

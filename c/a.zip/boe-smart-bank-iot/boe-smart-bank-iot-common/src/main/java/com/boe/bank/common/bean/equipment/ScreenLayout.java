package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 屏幕区域布局
 *
 * @author 10183279
 * @date 2020/11/5
 */
@ApiModel(value = "屏幕区域布局")
@Data
public class ScreenLayout implements Serializable {

    private static final long serialVersionUID = 7017888224322257175L;

    @ApiModelProperty(value = "x轴坐标")
    private int x;

    @ApiModelProperty(value = "y轴坐标")
    private int y;

    @ApiModelProperty(value = "宽")
    private int w;

    @ApiModelProperty(value = "高")
    private int h;
}

package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: caoxuhao
 * @Date: 2020/12/9 9:45
 */
@Data
public class ActivitiUserVo {

    @ApiModelProperty(value = "用户名称")
    private String name;

    @ApiModelProperty(value = "用户id")
    private Long id;
}

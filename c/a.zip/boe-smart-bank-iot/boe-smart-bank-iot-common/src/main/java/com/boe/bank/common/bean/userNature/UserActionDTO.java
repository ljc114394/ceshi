package com.boe.bank.common.bean.userNature;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author: lijianglong
 * @Data:2020/12/17
 */

@Data
public class UserActionDTO {

    @ApiModelProperty("应用名称")
    private String productName;//产品名称

    @ApiModelProperty("点击次数")
    private Integer clicks;//点击次数

    @ApiModelProperty("观看时长")
    private Integer watchTime;//小时

}

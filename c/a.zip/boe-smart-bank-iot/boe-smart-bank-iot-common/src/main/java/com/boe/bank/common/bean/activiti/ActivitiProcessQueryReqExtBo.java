package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 查询activiti流程的请求参数
 * @author caoxuhao
 */
@Data
public class ActivitiProcessQueryReqExtBo extends ActivitiProcessQueryReqExt{
	
	private List<Integer> outerIds;

	private List<Integer> outerTypes;

	private List<String> endActIds;
	
}

package com.boe.bank.common.bean.appliedbizmanege;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import springfox.documentation.service.ApiListing;

import java.util.List;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppliedBizManegeInfoBean {
    @ApiModelProperty(value = "主键")
    private Integer id;
    @ApiModelProperty(value = "菜单名称")
    private String bizName;
    @ApiModelProperty(value = "应用业务uri")
    private String bizUri;
    @ApiModelProperty(value = "组件列表")
    private String[] bizComponents;
    @ApiModelProperty(value = "字段信息列表")
    private List<AppliedBizManegeFieldBean> bizFieldList;
    @ApiModelProperty(value = "审批类型id")
    private Integer examineId;
    @ApiModelProperty(value = "备注")
    private String remark;
    @ApiModelProperty(value = "创建人")
    private String createBy;
    @ApiModelProperty(value = "更新人")
    private String updateBy;
    @ApiModelProperty(value = "创建时间")
    private String createTime;
    @ApiModelProperty(value = "更新时间")
    private String updateTime;


}

package com.boe.bank.common.entity.department;

import java.util.Date;

import lombok.Data;

/**
* @Description:部门审核信息表
* @author: zhaohaixia
* @date: 2020年9月27日 下午2:01:50
 */
@Data
public class SysDepartmentAudit {
	/**
	 * 主键id
	 */
    private Integer id;
    /**
     * 对应的部门id
     */
    private Long departmentId;
    /**
     * 是否有审批权限，0没有 1有
     */
    private Boolean isAudit;
    /**
     * 创建者
     */
    private String createdBy;
    /**
     * 更新人
     */
    private String updatedBy;
    /**
     * 创建时间
     */
    private Date dateCreated;
    /**
     * 更新时间
     */
    private Date dateUpdated;

}
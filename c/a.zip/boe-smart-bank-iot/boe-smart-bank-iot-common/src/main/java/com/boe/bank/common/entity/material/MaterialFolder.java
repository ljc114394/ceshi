package com.boe.bank.common.entity.material;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
* @Description:素材文件夹中间表
* @author: zhaohaixia
* @date: 2020年10月21日 下午5:29:37
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MaterialFolder extends BaseEntity implements Serializable{
	
	private static final long serialVersionUID = 1L;
	/**
	 * 主键id
	 */
	private Integer id;
	/**
	 *一级或者二级文件夹id
	 */
    private Integer folderId;
    /**
	 * 素材id
	 */
    private Integer materialId;


}
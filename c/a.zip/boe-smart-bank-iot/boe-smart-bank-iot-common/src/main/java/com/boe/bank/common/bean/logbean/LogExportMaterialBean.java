package com.boe.bank.common.bean.logbean;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 素材导出
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:27
 */
@Data
@ApiModel(description = "素材导出bean")
public class LogExportMaterialBean {

    @ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "操作用户", index = 1)
    private String createBy;

    @ExcelProperty(value = "素材所属机构", index = 2)
    private String orgName;

    @ExcelProperty(value = "素材类型", index = 3)
    private String materialType;

    @ExcelProperty(value = "操作内容", index = 4)
    private String operationContent;

    @ExcelProperty(value = "操作时间", index = 5)
    private String createTime;

    @ExcelIgnore
    private Integer orgId;
}

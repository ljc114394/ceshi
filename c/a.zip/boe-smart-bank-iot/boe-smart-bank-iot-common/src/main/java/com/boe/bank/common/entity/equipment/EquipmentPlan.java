package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.*;
import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备计划
 *
 * @author 10183279
 * @date 2020/10/28
 */
@Data
@TableName("t_equipment_plan")
public class EquipmentPlan extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 4281386559322552321L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 计划id
     */
    @TableField(value = "plan_id")
    private Integer planId;
    /**
     * 类型 1：正常计划，2：插播计划
     */
    @TableField(value = "type")
    private Integer type;
    /**
     * 0未删除/1已删除
     */
    @TableField(value = "is_delete")
    @TableLogic
    private Integer isDelete;
}

package com.boe.bank.common.bean.material;

import com.boe.bank.common.annotation.Emoticon;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:素材管理查询条件bean
* @author: zhaohaixia
* @date: 2020年9月28日 下午4:36:09
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材管理查询bean")
public class MaterialFolderConBean {

    @ApiModelProperty(value = "素材名称")
    @Emoticon
    private String title;

    @ApiModelProperty(value = "标签名称")
    @Emoticon
    private String labelTitle;

    @ApiModelProperty(value = "审核状态，0全部 1审批中 2通过 3.拒绝")
    private Integer status;
    
    @ApiModelProperty(value = "页码")
    private Integer pageNum;
    
    @ApiModelProperty(value = "页长度")
    private Integer pageSize;
    
    @ApiModelProperty(value = "机构id")
	private Long orgId;
    
    @ApiModelProperty(value = "父文件夹id 如果不属于文件夹下的素材，则传0即可 必传")
    private Integer parentId;



    
}

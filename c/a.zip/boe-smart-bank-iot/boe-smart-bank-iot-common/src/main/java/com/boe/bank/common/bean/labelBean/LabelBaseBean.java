package com.boe.bank.common.bean.labelBean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
* @Description:
* @author: zhaohaixia
* @date: 2020年10月20日 下午5:17:09
 */
@Data
@ApiModel(description = "标签基本信息")
public class LabelBaseBean{
	
    @ApiModelProperty(value = "标签主键ID")
    private Integer id;

    @ApiModelProperty(value = "标签名称")
    private String title;
    
}

package com.boe.bank.common.bean.userinfobean;

import com.boe.cloud.megarock.security.common.Organization;
import com.boe.cloud.megarock.security.common.Role;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/9/29 14:52
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoByLoginBean implements Serializable {



    @ApiModelProperty("用户id")
    protected Long id;
    @ApiModelProperty("用户名")
    protected String username;
    @ApiModelProperty("密码")
    protected String password;
    @ApiModelProperty("用户名字")
    protected String name;
    @ApiModelProperty("email")
    protected String email;
    @ApiModelProperty("手机号")
    protected String phoneNum;
    @ApiModelProperty("组织id")
    protected Long orgId;
    @ApiModelProperty("上次登陆时间")
    protected LocalDateTime lastLoginTime;
    @ApiModelProperty("角色列表")
    protected List<String> roles;
    @ApiModelProperty("是否启用")
    protected Integer isEnabled;
    @ApiModelProperty("角色列表")
    protected List<Role> roleDTOList;
    @ApiModelProperty("组织")
    protected Organization organization;
    @ApiModelProperty("细节")
    protected Object details;

    @ApiModelProperty("部门id")
    private Integer departmentId;

    @ApiModelProperty("部门名称")
    private String departmentName;

}

package com.boe.bank.common.entity.activiti;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 审批类型
 * @author caoxuhao
 */
@Data
public class ActivitiExamine extends BaseEntity implements Serializable {
	private Integer id;
	private Integer busniessType;//业务类型 类别 1素材 2计划 3设备
	private String examineType;//审批类型 素材有，设备和计划没有
	private Integer status;//0启用 1停用
}

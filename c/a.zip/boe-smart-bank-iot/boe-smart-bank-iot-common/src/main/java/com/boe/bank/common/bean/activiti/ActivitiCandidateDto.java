package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ActivitiCandidateDto {
	
	@ApiModelProperty(value = "候选人id")
	private Long id;
	
	@ApiModelProperty(value = "候选人名称")
	private String name;
	
	@ApiModelProperty(value = "候选人工号")
	private String workNum;
	
	@ApiModelProperty(value = "候选人组织架构id")
	private Long orgId;
	
	@ApiModelProperty(value = "候选人组织架构名称")
	private String orgName;
	
	@ApiModelProperty(value = "候选人所在部门id")
	private Long depId;
	
	@ApiModelProperty(value = "候选人所在部门名称")
	private String depName;

}

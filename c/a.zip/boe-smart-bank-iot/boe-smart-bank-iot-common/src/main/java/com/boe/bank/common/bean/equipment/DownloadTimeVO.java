package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 下载时间
 *
 * @author 10183279
 * @date 2020/11/11
 */
@ApiModel(value = "下载时间")
@Data
public class DownloadTimeVO implements Serializable {

    private static final long serialVersionUID = 7375471500869823683L;

    @ApiModelProperty(value = "下载开始时间")
    private String begin;

    @ApiModelProperty(value = "下载截止时间")
    private String end;
}

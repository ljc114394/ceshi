package com.boe.bank.common.bean.marketLabel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author: lijianglong
 * @Data:2020/10/26
 */

@Data
public class MarketLabelNatureInfoBean {

    @ApiModelProperty(value = "标签属性表主键id")
    private Integer natureId;//标签id

    @ApiModelProperty(value = "父类主键id")
    private Integer labelId;//标签id

    @ApiModelProperty(value = "属性名称")
    private String conditionName;//条件    ：运算符

    @ApiModelProperty(value = "属性条件值：对等的时候使用该字段")
    private String conditionValue;//条件    ：运算符

    @ApiModelProperty(value = "属性条件值：条件运算：小于 或 小于等于（如果是小于等于则用0表示等于并添加至符合前面如：0小于")
    private String conditionMinRange;//条件    ：运算符

    @ApiModelProperty(value = "属性条件值：条件运算：大于或大于等于（如果是大于等于则用0表示等于并添加至大于前面如：0大于）")
    private String conditionMaxRange;//条件    ：运算符

    @ApiModelProperty(value = "行为标签属性名称")
    private Integer behaviorCondition;//条件   前置时间条件范围 0:无 1:全部时段 2:近一个月 3:近一周 4:近三天

}

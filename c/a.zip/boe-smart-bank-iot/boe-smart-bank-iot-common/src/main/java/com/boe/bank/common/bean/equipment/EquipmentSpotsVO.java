package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备插播记录
 *
 * @author 10183279
 * @date 2020/10/13
 */
@ApiModel(value = "设备插播记录")
@Data
public class EquipmentSpotsVO implements Serializable {

    private static final long serialVersionUID = 1705848178330549498L;

    @ApiModelProperty(value = "记录id")
    private Integer id;

    @ApiModelProperty(value = "mac地址")
    private String mac;

    @ApiModelProperty(value = "计划名称")
    private String planName;

    @ApiModelProperty(value = "计划开始时间")
    private String beginTime;

    @ApiModelProperty(value = "计划结束时间")
    private String endTime;

    @ApiModelProperty(value = "计划时间")
    private String planTime;

    @ApiModelProperty(value = "所属机构id")
    private Long orgId;

    @ApiModelProperty(value = "所属机构名称")
    private String orgName;

    @ApiModelProperty(value = "插播人")
    private String createBy;

    @ApiModelProperty(value = "插播时间")
    private String createTime;
}

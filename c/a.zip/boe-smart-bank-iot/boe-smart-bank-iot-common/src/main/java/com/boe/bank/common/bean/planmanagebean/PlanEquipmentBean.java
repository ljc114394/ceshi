package com.boe.bank.common.bean.planmanagebean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/12/11 16:53
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "计划关联设备bean")
public class PlanEquipmentBean {

    @ApiModelProperty(value = "设备Mac列表")
    private List<String> equipMac;

    @ApiModelProperty(value = "删除的设备Mac列表")
    private List<String> delEquipMac;


}

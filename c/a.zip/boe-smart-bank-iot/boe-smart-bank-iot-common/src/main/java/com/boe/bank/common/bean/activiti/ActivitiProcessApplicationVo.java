package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Map;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/12/11
 */
@Data
public class ActivitiProcessApplicationVo extends ActivitiProcessOrgVo {
	
	@ApiModelProperty(value = "应用产品信息")
    String applicationName;
}

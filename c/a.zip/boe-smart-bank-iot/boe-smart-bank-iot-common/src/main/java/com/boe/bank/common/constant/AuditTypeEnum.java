package com.boe.bank.common.constant;

/**
* @Description:部门审批类型
* @author: zhaohaixia
* @date: 2020年9月28日 下午3:05:07
 */
public enum AuditTypeEnum {

    NO_AUDIT(0, "没有审批权限"),
    IS_AUDIT(1, "有审批权限");

    private int code;

    private String name;

    AuditTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}

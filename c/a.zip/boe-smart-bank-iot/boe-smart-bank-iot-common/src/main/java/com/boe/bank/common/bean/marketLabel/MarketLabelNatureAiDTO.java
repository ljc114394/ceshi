package com.boe.bank.common.bean.marketLabel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description:用于ai传过来的属性值
 * @Author: lijianglong
 * @Data:2020/10/30
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MarketLabelNatureAiDTO {

    @ApiModelProperty(value = "属性名称",example = "sex")
    private String conditionName;//条件    ：运算符

    @ApiModelProperty(value = "属性条件值：对等的时候使用该字段",example = "1")
    private String conditionValue;//条件    ：运算符

    @ApiModelProperty(value = "操作行为对应的产品id")
    private Integer actionProductId;

}

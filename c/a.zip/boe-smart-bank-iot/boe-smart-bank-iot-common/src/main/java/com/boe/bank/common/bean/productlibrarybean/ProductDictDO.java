package com.boe.bank.common.bean.productlibrarybean;

import lombok.Data;

/**
 * @Description:获取行为标签所对应的词典表code、codeValue
 * @Author: lijianglong
 * @Data:2020/11/12
 */

@Data
public class ProductDictDO {

    private String code;//字典表code

    private  String codeVlaue;//字典表codeValue

    private String remark;//备注
}

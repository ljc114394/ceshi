package com.boe.bank.common.constant;

/**
 * redis 常量key
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/11 14:09
 */
public class RedisPrefix {

    public static final String USER_ID = "user-id-";
    public static final String DICT_MAP ="dict_map";

    public static final String DICT_ALL_MAP ="all_dict_map";

    public static final String PRODUCT_PORTRAIT_MARKET ="product_portrait_market";
    public static final String PRODUCT_PORTRAIT_MARKET_KEY ="product_portrait_market_key";
    public static final String PRODUCT_FACE ="product_face_";
    public static final String PRODUCT_FACE_KEY ="product_face_key_";

    public static final String ACTIVITI_PROCESS_ID = "activiti_process_id:";
    public static final String ACTIVITI_EXAMIN_ID = "activiti_examine_id:";
    
    public static final String ACCESS_INTERFACE_DATE = "access_interface_date";

    public static final String APPLIED_ID ="applied_id";

    public static final String EQU_MAC = "mac_";

    public static final String PLAN_KEY = "plan_key";

    public static final String Material_KEY = "material_key";
    
}

package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * activiti流程返回结果
 * @author caoxuhao
 */
@Data
public class ActivitiProcessOrgVo {
	
	/**单据状态*/
	@ApiModelProperty(value = "单据状态")
	private String activitiStatus;
	
	/**处理状态*/
	@ApiModelProperty(value = "处理状态")
	private String processStatus;
	
	/**审批单号*/
	@ApiModelProperty(value = "审批单号")
	private String processInstanceId;
	
	/**提交时间*/
	@ApiModelProperty(value = "提交时间")
	private String createTime;
	
	/**创建人*/
	@ApiModelProperty(value = "创建人")
	private String creator;
	
	/**备注*/
	@ApiModelProperty(value = "备注")
	private String remark;
	
	/**外部表id*/
	@ApiModelProperty(value = "外部表id")
	private Integer outerId;

	@ApiModelProperty(value = "二级类型")
	private Integer outerType;

	@ApiModelProperty(value = "展示用id")
	private String showId;

	@ApiModelProperty(value = "任务id")
	private String taskId;

}

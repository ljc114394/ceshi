package com.boe.bank.common.entity.activiti;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 审批流程
 * @author caoxuhao
 */
@Data
public class ActivitiProcess  extends BaseEntity implements Serializable {
	private Integer id;
	private String name;//流程名称
	private String procdefId;//act_procdef表的id
	private String resourceData;//前端传入的流程图的json	 List<ActivitiUserTaskDto>
	private Integer examineId;//activiti_examine表id
	private Integer status;//0启用 1停用
}

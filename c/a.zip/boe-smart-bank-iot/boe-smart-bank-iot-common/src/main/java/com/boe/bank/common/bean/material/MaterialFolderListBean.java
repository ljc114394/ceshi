package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:素材列表bean
* @author: zhaohaixia
* @date: 2020年10月13日 下午3:31:13
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材管理列表bean")
public class MaterialFolderListBean {

	@ApiModelProperty(value = "素材或者文件夹主键id")
    private Integer id;
	
    @ApiModelProperty(value = "素材名称或者文件夹名称")
    private String title;

    @ApiModelProperty(value = "标签名称")
    private String labelTitle;
    
    @ApiModelProperty(value = "类型，1图片资源，2视频资源 3web资源 4文本信息 5文档管理 6.应用程序")
    private Integer type;
    
    @ApiModelProperty(value = "type为1或者2，表示缩略图；type为3，表示文本内容；type为4，表示web地址；type为6，表示程序参数")
    private String content;
  
    @ApiModelProperty(value = "审核状态，1待审核 2通过 3拒绝")
    private Integer status;
    
    @ApiModelProperty(value = "文件类型，1文件夹，2素材")
    private Integer fileType;

    @ApiModelProperty(value = "素材过期状态 0过期，1是正常，2是长期")
    private Integer valStatus;

    
}

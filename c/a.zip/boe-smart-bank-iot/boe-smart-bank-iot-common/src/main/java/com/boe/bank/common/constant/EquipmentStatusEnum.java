package com.boe.bank.common.constant;

/**
 * 设备状态枚举
 *
 * @author 10183279
 * @date 2020/10/19
 */
public enum EquipmentStatusEnum {

    ONLINE(1, "在线"),
    OFFLINE(2, "离线");

    private Integer code;

    private String message;

    EquipmentStatusEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}

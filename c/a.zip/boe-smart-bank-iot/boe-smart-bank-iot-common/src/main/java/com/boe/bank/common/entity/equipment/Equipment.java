package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.*;
import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Data
@TableName("t_equipment")
public class Equipment extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 3762286244177888583L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 设备名称
     */
    @TableField(value = "name")
    private String name;
    /**
     * ip地址
     */
    @TableField(value = "address_ip")
    private String addressIp;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 机构id
     */
    @TableField(value = "org_id")
    private Long orgId;
    /**
     * 区域id
     */
    @TableField(value = "area_id")
    private Integer areaId;
    /**
     * 审核状态
     */
    @TableField(value = "audit_status")
    private Integer auditStatus;
    /**
     * 设备类型id
     */
    @TableField(value = "type_id")
    private Integer typeId;
    /**
     * 厂商信息
     */
    @TableField(value = "equip_info")
    private String equipInfo;
    /**
     * 0未删除/1已删除
     */
    @TableField(value = "is_delete")
    @TableLogic
    private Integer isDelete;
}

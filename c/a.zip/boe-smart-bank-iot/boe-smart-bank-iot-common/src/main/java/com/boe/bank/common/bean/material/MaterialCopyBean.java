package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: 005
 * @Description:
 * @Date Created in 2020-11-26 9:00
 * @Modified By:
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材copy的bean")
public class MaterialCopyBean {
    @ApiModelProperty(value = "复制的当前素材的id")
    private Integer fromId;

    @ApiModelProperty(value = "粘贴到位置的id")
    private Integer toId;

    @ApiModelProperty(value = "粘贴到的机构orgid")
    private Integer orgId;
}

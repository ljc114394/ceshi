package com.boe.bank.common.bean.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 10507807
 * @version 1.0
 * @Description TODO
 * @date 2020/11/17 10:15
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材统计bean")
public class MaterialStatsBean {
    @ApiModelProperty(value = "图片")
    private Integer picture=0;
    @ApiModelProperty(value = "视频")
    private Integer video=0;
    @ApiModelProperty(value = "文本")
    private Integer text=0;
    @ApiModelProperty(value = "web")
    private Integer web=0;
    @ApiModelProperty(value = "文档")
    private Integer document=0;
    @ApiModelProperty(value = "总数")
    private Integer total=0;
}

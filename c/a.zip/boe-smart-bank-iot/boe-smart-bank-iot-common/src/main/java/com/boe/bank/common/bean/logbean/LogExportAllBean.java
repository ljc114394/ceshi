package com.boe.bank.common.bean.logbean;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 素材导出
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:27
 */
@Data
@ApiModel(description = "操作导出bean")
public class LogExportAllBean {

    @ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "操作用户", index = 1)
    private String createBy;

    @ExcelProperty(value = "所属机构", index = 2)
    private String orgName;

    @ExcelProperty(value = "类型", index = 3)
    private String materialType;

    @ExcelProperty(value = "操作内容", index = 4)
    private String operationContent;

    @ExcelProperty(value = "操作时间", index = 5)
    private String createTime;

    @ExcelIgnore
    private Integer orgId;
}

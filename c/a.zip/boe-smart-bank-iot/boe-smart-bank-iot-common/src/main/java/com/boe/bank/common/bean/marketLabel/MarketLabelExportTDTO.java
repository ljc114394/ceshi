package com.boe.bank.common.bean.marketLabel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.util.StringUtils;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Description:精准营销-标签表  导出  区分标签级别
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@ApiModel(description = "标签库别表返回值")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MarketLabelExportTDTO {

    @ExcelProperty(value = "标签名称", index = 0)
    private String labelName;

    @ExcelProperty(value = "标签属性", index = 1)
    private String labelType;//标签属性区分：0属性标签、1行为标签

    @ExcelProperty(value = "启用状态", index = 2)
    private String enable;//启用状态：0否  1是

    @ExcelProperty(value = "备注", index = 3)
    private String remark;

    @ExcelProperty(value = "启用时间", index = 4)
    private Date enableTime;

    @ExcelProperty(value = "创建时间", index = 5)
    private Date createTime;

    @ExcelProperty(value = "标签人数分布", index = 6)
    private Integer personNums;

    @ExcelProperty(value = "用户群画像使用该标签", index = 7)
    private Integer labelNums;//用户群画像使用该标签

    @ExcelProperty(value = "启用时长(小时)", index = 8)
    private Integer hourLength;//启用时长hourLength

}

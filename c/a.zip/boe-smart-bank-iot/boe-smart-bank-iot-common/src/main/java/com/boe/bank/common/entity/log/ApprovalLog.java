package com.boe.bank.common.entity.log;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/29 17:01
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalLog extends BaseEntity implements Serializable {

    //主键id
    private Integer id;

    //机构id
    private Integer orgId;

    //机构名称
    private String  orgName;

    //操作内容(新增《》/删除《》/编辑《》)
    private String operationContent;

    //审批单号
    private String approvalNo;

    //审批类型
    private String approvalType;

    //审批结果 a11待处理/a12同意/a13拒绝
    private String approvalResult;

    //审批业务类型： a21素材 a22计划 a23设备
    private String busniessType;
    //创建时间的时间戳
    private Long createAt;

}

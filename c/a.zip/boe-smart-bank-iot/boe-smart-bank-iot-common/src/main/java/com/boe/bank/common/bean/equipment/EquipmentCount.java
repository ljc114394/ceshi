package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * 设备在线离线的数量
 *
 * @author lvjiacheng
 * @date 2020/12/17
 */
@ApiModel(value = "设备在线离线的数量")
@Data
public class EquipmentCount implements Serializable {

    private static final long serialVersionUID = -134593343441244758L;

    @ApiModelProperty(value = "设备状态")
    private String name ;

    @ApiModelProperty(value = "设备数量")
    private Integer value;


}

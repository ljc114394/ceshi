package com.boe.bank.common.bean.activiti;

import com.boe.bank.common.constant.ActivitiConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 流程图的节点(前端传入的参数)
 * @author caoxuhao
 */
@Data
public class ActivitiUserTaskDto {
	
	/**节点名称*/
	@ApiModelProperty(value = "节点名称")
	private String name;
	
	/**审核人的类型 1按选定的人或组织架构 2按角色。 默认1*/
	@ApiModelProperty(value = "审核人的类型: 1按选定的人或组织架构， 2按角色。 默认1")
	private Integer reviewerType = ActivitiConstants.ReviewerType.userOrGroup;
	
	/**审批通过规则 1任意一人通过，2所有人都通过，3每个部门任意一人通过。默认1*/
	@ApiModelProperty(value = "审批通过规则: 1任意一人通过，2所有人都通过，3每个部门任意一人通过。默认1")
	private Integer passType = ActivitiConstants.PassType.any;
	
	/**候选人ids*/
	@ApiModelProperty(value = "候选人ids")
	private List<ActivitiCandidateDto> candidates;
	
	/**候选部门ids*/
	@ApiModelProperty(value = "候选部门ids")
	private List<Long> departments;
	
	/**候选组织ids*/
	@ApiModelProperty(value = "候选组织ids")
	private List<Long> organizations;
	
	/**角色ids*/
	@ApiModelProperty(value = "角色ids")
	private List<Integer> roles;
	
	@ApiModelProperty(value = "选角色后的附加条件： 1与发起人同一部门，2与发起人同一机构，3发起人的上级机构，4发起人的上级机构 ")
	private Integer roleAdditional;
	
}

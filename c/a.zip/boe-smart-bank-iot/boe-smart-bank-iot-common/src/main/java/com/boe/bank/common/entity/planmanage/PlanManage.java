package com.boe.bank.common.entity.planmanage;

import com.boe.bank.common.base.BaseEntity;
import com.boe.bank.common.bean.planmanagebean.PlanMaterialManageBean;
import com.boe.bank.common.entity.material.MaterialManage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanManage extends BaseEntity implements Serializable {

    //用户id
    private Integer id;

    //计划名称
    private String title;

    //机构id
    private Integer orgId;

    //机构名称
    private String orgName;

    //计划开始时间
    private LocalDateTime beginTime;

    //计划结束时间
    private LocalDateTime endTime;

    //计划时间 周一,周二
    private String planTime;

    //备注
    private String remark;

    //是否删除
    private  Integer isDeleted;

    //审核状态
    private  Integer state;

    //审核状态名称
    private  String auditState;

    //播放状态
    //private  String playStatus;

    //添加的素材id集合
    private List<PlanMaterialManageBean> list;

}

package com.boe.bank.common.bean.logbean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/5 18:10
 */
@Data
@ApiModel(description = "接口日志bean")
public class InterfacelogSearchBean extends PageBean {

    @ApiModelProperty(value = "接口名称")
    @Emoticon
    private String  title;

    @ApiModelProperty(value = "登录ip")
    @Emoticon
    private String  ip;

    @ApiModelProperty(value = "机构id")
    private Integer  orgId;

    @JsonIgnore
    private List<String> orgIdList;

    //限定导出的时间戳
    @JsonIgnore
    private Long exportTime;
}

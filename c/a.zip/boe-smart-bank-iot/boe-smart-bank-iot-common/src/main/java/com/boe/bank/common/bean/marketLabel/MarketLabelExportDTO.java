package com.boe.bank.common.bean.marketLabel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.util.StringUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Description:精准营销-标签表  导出
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@ApiModel(description = "标签库别表返回值")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MarketLabelExportDTO {

    /*@ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "父类id", index = 1)
    private Integer parentId;*/

    @ExcelProperty(value = "标签名称", index = 0)
    private String labelName;

    @ExcelProperty(value = "标签属性", index = 1)
    private String labelType;//标签属性区分：0属性标签、1行为标签

    @ExcelProperty(value = "启用状态", index = 2)
    private String enable;//启用状态：0否  1是

    @ExcelProperty(value = "备注", index = 3)
    private String remark;

    @ExcelProperty(value = "启用时间", index = 4)
    private Date enableTime;

    @ExcelProperty(value = "创建时间", index = 5)
    private Date createTime;

    @ExcelProperty(value = "标签人数分布", index = 6)
    private Integer personNums;

    @ExcelProperty(value = "用户群画像使用该标签", index = 7)
    private Integer labelNums;//用户群画像使用该标签

    @ExcelProperty(value = "启用时长(小时)", index = 8)
    private Integer hourLength;//启用时长hourLength

    @ExcelProperty(value = "用户属性", index = 9)
    private String conditionName;

    @ExcelProperty(value = "对等条件", index = 10)
    private String conditionValue;

    @ExcelProperty(value = "小于条件", index = 11)
    private String conditionMinRange;

    @ExcelProperty(value = "大于条件", index = 12)
    private String conditionMaxRange;

   /* public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }*/

    public String getLabelName() {
        return labelName;
    }

    public void setLabelName(String labelName) {
        this.labelName = labelName;
    }

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getEnableTime() {
        return enableTime;
    }

    public void setEnableTime(Date enableTime) {
        this.enableTime = enableTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getPersonNums() {
        return personNums;
    }

    public void setPersonNums(Integer personNums) {
        this.personNums = personNums;
    }

    public Integer getLabelNums() {
        return labelNums;
    }

    public void setLabelNums(Integer labelNums) {
        this.labelNums = labelNums;
    }

    public Integer getHourLength() {
        return hourLength;
    }

    public void setHourLength(Integer hourLength) {
        this.hourLength = hourLength;
    }

    public String getConditionName() {
        return conditionName;
    }

    public void setConditionName(String conditionName) {
        this.conditionName = conditionName;
    }

    public String getConditionValue() {
        return conditionValue;
    }

    public void setConditionValue(String conditionValue) {
        this.conditionValue = conditionValue;
    }

    public String getConditionMinRange() {
        return conditionMinRange;
    }

    public void setConditionMinRange(String conditionMinRange) {
        if(!StringUtils.isEmpty(conditionMinRange)){
            if(conditionMinRange.substring(0,1).equals("0")){
                conditionMinRange = "小于等于： "+conditionMinRange.substring(1);
            }
        }
        this.conditionMinRange = conditionMinRange;
    }

    public String getConditionMaxRange() {
        return conditionMaxRange;
    }

    public void setConditionMaxRange(String conditionMaxRange) {
        if(!StringUtils.isEmpty(conditionMaxRange)){
            if(conditionMaxRange.substring(0,1).equals("0")){
                conditionMaxRange = "大于等于： "+conditionMaxRange.substring(1);
            }
        }
        this.conditionMaxRange = conditionMaxRange;
    }

}

package com.boe.bank.common.bean.labelBean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * TODO
 * 标签管理-查询条件
 * @author lijianglong
 * @data 2020/10/13
 */

@Data
@ApiModel(description = "标签管理-查询")
public class LabelSearchBean extends PageBean {

    @ApiModelProperty(value = "标签名称")
    @Emoticon
    private String title;
}

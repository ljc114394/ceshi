package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 审批类型分页查询数据库查出给前端页面用的
 * @author caoxuhao
 */
@Data
public class ActivitiExamineVo {
	
	@ApiModelProperty(value = "业务类型")
	private String busniessType;
	
	@ApiModelProperty(value = "审批类型")
	private String examineType;
	
	@ApiModelProperty(value = "审批类型编码")
	private Integer id;
	
	@ApiModelProperty(value = "制定人员")
	private String createBy;
	
	@ApiModelProperty(value = "审批类型状态")
	private String status;
}

package com.boe.bank.common.bean.labelBean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 * 标签管理-添加、修改数据
 * @author lijianglong
 * @data 2020/10/13
 */

@Data
@ApiModel(description = "标签管理-添加、修改")
public class LabelInfoBean{
    @ApiModelProperty(value = "标签主键ID")
    private Integer id;

    @ApiModelProperty(value = "标签名称")
    private String title;

    @ApiModelProperty(value = "备注")
    private String remark;
}

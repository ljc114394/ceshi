package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 设备升级DTO
 *
 * @author 10183279
 * @date 2020/10/29
 */
@ApiModel(value = "设备升级DTO")
@Data
public class EquipmentUpgradeDTO implements Serializable {

    private static final long serialVersionUID = 3003812306337091613L;

    @ApiModelProperty(value = "mac")
    @NotBlank(message = "mac不能为空")
    private String mac;

    @ApiModelProperty(value = "升级包", dataType = "file")
    @NotNull(message = "升级包不能为空")
    private MultipartFile file;
}

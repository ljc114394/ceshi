package com.boe.bank.common.bean.activiti;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 前端传入部署流程图的bean
 * @author caoxuhao
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ActivitiProcessUpdateBean {
	
	@ApiModelProperty(value = "流程编号")
	private Integer processId;
	
	@ApiModelProperty(value = "流程名称")
	private String processName;
	
	@ApiModelProperty(value = "业务类型： 1素材 2计划 3设备")
	private Integer busniessType;
	
	@ApiModelProperty(value = "审批类型id")
	private Integer examineId;
	
	@ApiModelProperty(value = "更新人名称")
	private String updateBy;
	
	@ApiModelProperty(value = "节点列表（只需要给用户配置的节点，必须按顺序给）")
	private List<ActivitiUserTaskDto> list;
}

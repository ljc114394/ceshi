package com.boe.bank.common.bean.logbean;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 权限导出
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:27
 */
@Data
@ApiModel(description = "权限导出bean")
public class LogExportPowerBean {

    @ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "操作用户", index = 1)
    private String createBy;

    @ExcelIgnore
    private Integer orgId;

    @ExcelProperty(value = "所属机构", index = 2)
    private String orgName;

    @ExcelProperty(value = "操作内容", index = 3)
    private String operationContent;

    @ExcelProperty(value = "操作时间", index = 4)
    private String createTime;
}

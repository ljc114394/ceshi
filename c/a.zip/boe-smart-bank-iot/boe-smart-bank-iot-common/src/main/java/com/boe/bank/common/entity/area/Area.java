package com.boe.bank.common.entity.area;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Area extends BaseEntity implements Serializable {

    //主键id
    private Integer id;

    //区域名称
    private String title;

    //备注
    private String remark;

    //机构id
    private Integer orgId;

    //部门id
    private Integer departmentId;

    private String orgName;//机构名称

    private String departmentName;//部门名称

}

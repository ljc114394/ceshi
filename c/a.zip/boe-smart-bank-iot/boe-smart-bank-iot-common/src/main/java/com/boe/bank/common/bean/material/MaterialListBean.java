package com.boe.bank.common.bean.material;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:素材列表bean
* @author: zhaohaixia
* @date: 2020年10月13日 下午3:31:13
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "素材列表bean")
public class MaterialListBean {

	@ApiModelProperty(value = "素材主键id")
    private Integer id;
	
    @ApiModelProperty(value = "素材名称")
    private String title;

    @ApiModelProperty(value = "标签名称")
    private String labelTitle;
    
    @ApiModelProperty(value = "类型，1图片资源，2视频资源 3文本信息 4web资源  5文档管理 6.应用程序")
    private Integer type;
    
    @ApiModelProperty(value = "type为1或者2，表示缩略图；type为3，表示文本内容；type为4，表示web；type为6，表示程序参数")
    private String content;
  
    @ApiModelProperty(value = "审核状态，1待审核 2通过 3拒绝")
    private Integer status;
    
    @ApiModelProperty(value = "type为6时，表示程序参数")
    private String programEntry;
    
    @ApiModelProperty(value = "创建人名称")
    private String createBy;

    @ApiModelProperty(value = "修改人名称")
    private String updateBy;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    
    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;

    @ApiModelProperty(value = "素材过期状态 0过期，1是正常，2是长期")
    private Integer valStatus;
    
}

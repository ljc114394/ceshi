package com.boe.bank.common.bean.dictbean;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SysDictionariesSearchBean  extends PageBean{

	@ApiModelProperty(value = "字典id")
	private Integer id;


	@ApiModelProperty(value = "字典名称")
	private String title;

	@ApiModelProperty(value = "判断数据字典树 当前节点是否有子节点 类型 1：id 作为父节点 2：作为根节点")
	private Integer type;



}

package com.boe.bank.common.bean.marketLabel;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:精准营销-标签表 数据库交互
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Data
public class MarketLabelSearchBean extends PageBean {

    @ApiModelProperty(value = "父类标签id")
    private Integer id;

    @ApiModelProperty(value = "标签名称")
    @Emoticon
    private String labelName;

    @ApiModelProperty(value = "标签类型分类：0属性标签、1行为标签")
    private Integer labelType;

    @ApiModelProperty(value = "标签状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "标签级别：1 一级，2二级，3三级")
    private Integer level;
}

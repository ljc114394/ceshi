package com.boe.bank.common.utils;

/**
 * redis中查不到时候，可以运行的代码
 * @author caoxuhao
 */
@FunctionalInterface
public interface BaseFuncionHelper {
	
	//需要运行的代码
	public Object run();

}

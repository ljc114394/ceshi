package com.boe.bank.common.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/27 9:43
 */
@Data
public class PageBean {
    @ApiModelProperty(value = "页码 默认1")
    private Integer pageNum = 1;
    @ApiModelProperty(value = "页长度 默认长度10")
    private Integer pageSize = 10;
    @ApiModelProperty(value = "排序字段")
    private String orderBy;
    @ApiModelProperty(value = "排序降序")
    private Boolean orderDesc;
}

package com.boe.bank.common.entity.material;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
* @Description:素材管理
* @author: zhaohaixia
* @date: 2020年10月13日 上午11:25:10
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MaterialManage extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 7622078465822535364L;

    /**
	 * 主键id
	 */
    private Integer id;
    /**
     * 标签id
     */
    private Integer lableId;
    /**
     * 素材名称
     */
    private String title;
    /**
     * 审核状态，1已通过 2审批中 （默认）3审查中 4已拒绝
     */
    private Integer status;
    /**
     * 类型，1图片资源，2视频资源 3web资源 4文本信息 5文档管理 6.应用程序
     */
    private Integer type;
    /**
     * type为6时，表示程序序参数
     */
    private String programEntry;
    /**
     * 审批类型id
     */
    private Integer approvalType;
    /**
     * 机构id
     */
    private Long orgId;
    /**
     * 是否删除 0 否 1 是
     */
    private Boolean isDelete;
    /**
     * 是否在文件夹下，0不在 1在
     */
    private Boolean flag;
    /**
     * 文件夹级别，1一级，2二级
     */
    private Integer level;
    /**
     * 父文件夹id，一级文件夹或者素材默认为0
     */
    private Integer parentId;
    /**
     * 文件类型，1文件夹，2素材
     */
    private Integer fileType;
    /**
     * type为1或者2，表示缩略图名称，前台不需要传；type为3，表示web地址；type为4，表示文本内容；type为5，表示文档名称；type为6，表示程序入口，即文件名
     */
    private String content;
    /**
	 * 文件大小
	 */
    private Integer size;
    /**
     * 文件md5值
     */
    private String md5;
    /**
     * 过期时间
     */
    private String valTime;
}
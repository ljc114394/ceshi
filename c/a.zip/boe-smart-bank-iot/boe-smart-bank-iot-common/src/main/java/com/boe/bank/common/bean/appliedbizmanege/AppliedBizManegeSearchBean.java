package com.boe.bank.common.bean.appliedbizmanege;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "应用管理-查询bean")
public class AppliedBizManegeSearchBean extends PageBean {

    @ApiModelProperty(value = "应用业务名称")
    @Emoticon
    private String bizName;

}

package com.boe.bank.common.bean.equipment;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备播放日志查询对象
 *
 * @author 10183279
 * @date 2020/10/28
 */
@ApiModel(value = "设备播放日志查询对象")
@Data
public class EquipmentPlayLogQO extends PageBean implements Serializable {

    private static final long serialVersionUID = -5288631386650436793L;

    @ApiModelProperty(value = "设备id", hidden = true)
    private Integer equId;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "修改人")
    private String updateBy;

    @ApiModelProperty(value = "计划名称")
    private String planName;

    @ApiModelProperty(value = "类型 1：正常计划，2：插播计划", hidden = true)
    private Integer type;
}

package com.boe.bank.common.bean.appliedbizmanege;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppliedBizManegeSaveBean {
    @ApiModelProperty(value = "应用名称",required = true)
    private String bizName;
    @ApiModelProperty(value = "组件功能列表; 查询数据字典<应用菜单组件>",required = true)
    private List<String> bizComponents;
    @ApiModelProperty(value = "字段信息列表",required = true)
    private List<AppliedBizManegeFieldBean> bizFieldList;
    @ApiModelProperty(value = "审批类型id")
    private Integer examineId;
    @ApiModelProperty(value = "备注")
    private String remark;

}

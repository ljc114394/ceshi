package com.boe.bank.common.base;

import com.boe.bank.common.constant.MsgReturnEnum;
import lombok.Data;

import java.io.Serializable;

/**
 * TODO
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/27 15:28
 */
@Data
public class BusinessException extends RuntimeException implements Serializable {

    private Integer exceptionCode = null;
    private Object[] variables;

    public BusinessException() {
        exceptionCode = 0;
    }

    public BusinessException(String msg) {
        super(msg);
    }

    public BusinessException(Integer exceptionCode, String msg) {
        super(msg);
        this.exceptionCode = exceptionCode;
    }




    public BusinessException(String msg, Throwable e) {
        super(msg, e);
    }


    public BusinessException(MsgReturnEnum msg) {
        super(msg.message());
        this.exceptionCode = msg.code();
    }

    /**
     * @param exceptionCode
     * @param e
     * @param variables
     */
    public BusinessException(Integer exceptionCode, Throwable e, Object[] variables) {
        super(e);
        this.exceptionCode = exceptionCode;
        this.variables = variables;
    }

    public BusinessException(Throwable e) {
        super(e);
        exceptionCode = 0;
    }



    public Object[] getVariables() {
        return variables;
    }


    public void setVariables(Object[] variables) {
        this.variables = variables;
    }


}

package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 设备插播记录
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Data
@TableName("t_equipment_spots")
public class EquipmentSpots implements Serializable {

    private static final long serialVersionUID = 6116413089272164543L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 计划名称
     */
    @TableField(value = "plan_name")
    private String planName;
    /**
     * 计划开始时间
     */
    @TableField(value = "begin_time")
    private LocalDateTime beginTime;
    /**
     * 计划结束时间
     */
    @TableField(value = "end_time")
    private LocalDateTime endTime;
    /**
     * 计划时间
     */
    @TableField(value = "plan_time")
    private String planTime;
    /**
     * 所属机构
     */
    @TableField(value = "org_id")
    private Long orgId;
    /**
     * 插播人
     */
    @TableField(value = "create_by")
    private String createBy;
    /**
     * 插播时间
     */
    @TableField(value = "create_time")
    private LocalDateTime createTime;
}

package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用户群画像关联标签dto
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Data
public class UserPortraitLabelInfoBean {

    @ApiModelProperty(value = "用户群画像关联标签标主键ID")
    private Integer portraitLabelId;//用户群画像关联标签标主键ID

    @ApiModelProperty(value = "标签id")
    private Integer labelId;//标签id

    @ApiModelProperty(value = "父类标签id")
    private Integer labelParentId;//父类标签id

    @ApiModelProperty(value = "标签名称")
    private String labelName;
}

package com.boe.bank.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
/**
* @Description:自定义注解     针对字段，不能含有表情符
* @author: zhaohaixia
* @date: 2020年12月4日 下午5:09:48
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EmoticonValidator.class)
public @interface Emoticon {
    String message() default "不能含有表情符或特殊字符哦！";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}

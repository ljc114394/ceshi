package com.boe.bank.common.utils;

import com.boe.bank.common.constant.Const;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 对象工具类
 *
 * @author 10183279
 * @date 2020/10/15
 */
public class ObjectUtil {

    /**
     * 如果pageNum或pageSize为null，则设置默认值
     *
     * @param obj
     * @return
     */
    public static Object setPageNumAndPageSizeDefault(Object obj) {
        List<Field> fieldList = getAllFields(obj);
        for (Field field : fieldList) {
            if (Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            // 得到此属性的名
            String name = field.getName();
            if (!"pageNum".equals(name) && !"pageSize".equals(name)) {
                continue;
            }
            // 设置此属性是可以访问的
            field.setAccessible(true);
            try {
                // 得到此属性的值
                Object val = field.get(obj);
                if (val == null && "pageNum".equals(name)) {
                    field.set(obj, Const.PAGE_NUM_DEFAULT);
                } else if (val == null && "pageSize".equals(name)) {
                    field.set(obj, Const.PAGE_SIZE_DEFAULT);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return obj;
    }

    /**
     * 获取当前类及父类属性
     *
     * @param object
     * @return
     */
    public static List<Field> getAllFields(Object object) {
        Class clazz = object.getClass();
        List<Field> fieldList = new ArrayList<>();
        while (clazz != null) {
            fieldList.addAll(new ArrayList<>(Arrays.asList(clazz.getDeclaredFields())));
            clazz = clazz.getSuperclass();
        }
        return fieldList;
    }
}

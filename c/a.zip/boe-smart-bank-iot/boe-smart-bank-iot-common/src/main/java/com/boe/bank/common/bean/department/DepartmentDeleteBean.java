package com.boe.bank.common.bean.department;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* @Description:批量删除部门
* @author: zhaohaixia
* @date: 2020年11月2日 下午3:44:30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "部门批量删除bean")
public class DepartmentDeleteBean {

	@ApiModelProperty(value = "多个部门id")
    private List<Long> ids;
	
}

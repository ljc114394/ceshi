package com.boe.bank.common.bean.planmanagebean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PlanMaterialManageSaveBean  {


    @ApiModelProperty(value = "素材id -添加")
    private Integer id;

    @ApiModelProperty(value = "播放次数或时间 -添加")
    private Integer playOperation;

    @ApiModelProperty(value = "屏幕区域 1,2,3,4 -添加")
    private Integer screenArea;
}

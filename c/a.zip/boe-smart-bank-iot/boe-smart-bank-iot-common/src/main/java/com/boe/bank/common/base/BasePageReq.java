package com.boe.bank.common.base;

import lombok.Data;

/**
 * @ClassName BasePageReq
 * @Description TODO
 * @Author shaozhenjun
 * @Date 19-7-10 下午7:19
 * @Version 1.0
 */
@Data
public class BasePageReq {
    private int pageNum = 1;
    private int pageSize = 10;
}

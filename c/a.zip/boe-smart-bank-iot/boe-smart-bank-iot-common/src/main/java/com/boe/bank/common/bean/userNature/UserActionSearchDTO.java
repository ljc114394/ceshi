package com.boe.bank.common.bean.userNature;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:数据统计-页面交互
 * @Author: lijianglong
 * @Data:2020/12/16
 */
@Data
public class UserActionSearchDTO extends PageBean {

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("属性行为：1:访问网点数 2:查看应用累计时间 3:点击应用二维码次数   暂定值为3")
    private Integer conditionType;

}

package com.boe.bank.common.bean.appliedbizmanege;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "应用模块-查询bean")
public class AppliedModuleSearchBean extends PageBean {

    @ApiModelProperty(value = "应用业务ID",required=true)
    private Integer bizId;
    @ApiModelProperty(value = "查询条件,使用查询字段code作为查询条件,多个查询条件以逗号分隔，格式：查询字段code=条件1,查询字段code=条件")
    private String searchConditions;

}

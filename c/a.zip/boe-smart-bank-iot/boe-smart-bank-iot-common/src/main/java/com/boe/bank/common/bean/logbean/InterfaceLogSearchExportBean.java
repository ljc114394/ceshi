package com.boe.bank.common.bean.logbean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:18
 */
@Data
@ApiModel(description = "登录和接口导出-查询bean")
public class InterfaceLogSearchExportBean {

    @ApiModelProperty(value = "接口名称")
    private String  title;

    @ApiModelProperty(value = "登录ip")
    private String  ip;

    @ApiModelProperty(value = "机构id")
    private Integer  orgId;

    //限定导出的时间戳
    @JsonIgnore
    private Long exportTime;

    @JsonIgnore
    private List<String> orgIdList;
}

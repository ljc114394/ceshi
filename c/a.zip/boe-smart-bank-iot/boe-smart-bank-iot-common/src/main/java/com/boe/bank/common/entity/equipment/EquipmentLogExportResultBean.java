package com.boe.bank.common.entity.equipment;

import java.io.Serializable;

import com.alibaba.excel.annotation.ExcelProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @author 10085188
 * @data 2020/11/06
 */
@Data
@ApiModel(description = "设备日志-显示bean")
public class EquipmentLogExportResultBean implements Serializable {
	private static final long serialVersionUID = 4475095357727825759L;
	
	@ApiModelProperty(value = "设备mac地址")
	@ExcelProperty("MAC地址")
	private String mac;
	
	@ApiModelProperty(value = "日志级别；0:Debug 1:Info 2:Warn 3:Error 4:Fatal")
	@ExcelProperty("日志级别")
	private String level;
	
	@ApiModelProperty(value = "日志内容")
	@ExcelProperty("日志内容")
	private String message;
	
	@ApiModelProperty(value = "日志时间")
	@ExcelProperty("日志时间")
	private String time;
	
}

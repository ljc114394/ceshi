package com.boe.bank.common.entity.userNatureInfo;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserNatureInfo extends BaseEntity implements Serializable {

    private Integer id;//主键id

    private String faceId;//人脸id
    
    private String faceFeature;//人脸特征向量

    private Integer recoAge;//年龄
    
    private Integer recoSex;//性别 1:男 2:女
    
    private Boolean firstVisit;//是否首次访问 0:否 1:是
    
}
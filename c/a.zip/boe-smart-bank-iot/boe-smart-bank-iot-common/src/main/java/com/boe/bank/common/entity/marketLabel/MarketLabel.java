package com.boe.bank.common.entity.marketLabel;

import com.boe.bank.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description:精准营销-标签表
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MarketLabel extends BaseEntity implements Serializable {

    private Integer id; // 主键id

    private Integer parentId;//父类id

    private String labelName;//标签名称

    private Integer labelType;//标签属性区分：0属性标签、1行为标签

    private Integer enable;//启用状态：0否  1是

    private String remark;//备注

    private Date enableTime;//启用时间  当前系统时间-启用时间获取时长

    private String personNums;//标签人数分布

    private Integer isDelete;//删除 0 否 1 是

    private String labelNums;//用户群画像使用该标签

    private Integer hourLength;//时长

    private Integer level;//标签级别：1 一级，2 二级，3 三级 以此类推
}

package com.boe.bank.common.utils;

import com.boe.cloud.megarock.javabean.TreeNode;
import com.boe.cloud.megarock.javabean.TreeNodePre;
import com.boe.cloud.megarock.javabean.util.TransformUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author 10191921
 * @version 1.0
 * @data 2020/9/25 9:27
 */
public class TreeUtil {

    public static <T extends TreeNode> T toTree(List<? extends TreeNodePre> list, Class<T> clazz, Long pid) throws NullPointerException {
        if (pid == null) {
            pid = 0L;
        }

        if (list.size() == 0) {
            return null;
        } else {
            ArrayList<T> nodeList = new ArrayList();
            list.stream().forEach((treeNodePre) -> {
                nodeList.add(TransformUtil.map(treeNodePre, clazz));
            });
            Map<Long, List<T>> nodeByParentIdMap = new HashMap();
            nodeList.forEach((treeNodePre) -> {
                List<T> children = (List)nodeByParentIdMap.getOrDefault(treeNodePre.getParentId(), new ArrayList());
                children.add(treeNodePre);
                nodeByParentIdMap.put(treeNodePre.getParentId(), children);
            });
            nodeList.forEach((node) -> {
                node.setChildren((List)nodeByParentIdMap.get(node.getId()));
            });
            Long prarentId = pid;
            return (T) ((List)nodeList.stream().filter((v) -> {
                return v.getParentId().equals(prarentId);
            }).collect(Collectors.toList())).get(0);
        }
    }
}

package com.boe.bank.common.bean.datarolebean;

import com.boe.bank.common.entity.material.MaterialManage;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/15 17:33
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataRoleBean {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "角色id")
    private Integer roleId;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;


}

package com.boe.bank.common.bean.productlibrarybean;

import lombok.Data;

import java.util.Date;

/**
 * @Description:领域对象：存储具体数据值做缓存
 * @Author: lijianglong
 * @Data:2020/11/9
 */

@Data
public class ProductNatureDO {

    private String faceId;//人脸id

    private Integer productId;//产品id

    private Integer labelId;//标签id

    private Integer portraitId;//用户画像id

    private Integer LabelType;//标签属性区分：0属性标签、1行为标签

    private Integer weight;//权重

    private Date createTime;//用户画像创建时间

    private Integer conditionType;//条件判断：0或  1且

    private String conditionName;//属性名称

    private String conditionValue;//条件    ：对等运算符

    private String conditionMinRange;//条件 属性条件值：条件运算：小于 或 小于等于（如果是小于等于则用0表示等于并添加至符合前面如：0小于

    private String conditionMaxRange;//条件  属性条件值：条件运算：大于或大于等于（如果是大于等于则用0表示等于并添加至大于前面如：0大于）

    private Integer behaviorCondition;//条件    ：前置时间条件范围 0:无 1:全部时段 2:近一个月 3:近一周 4:近三天

}

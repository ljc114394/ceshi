package com.boe.bank.common.bean.logbean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:18
 */
@Data
@ApiModel(description = "操作和审批日志导出-查询bean")
public class LogSearchExportBean {

    @ApiModelProperty(value = " 模块类型-1素材/2计划/3设备/4权限/5审批类型  必填项)")
    private Integer moduleType;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "操作类型1新增/2修改/3删除")
    private Integer operationType;

    @ApiModelProperty(value = "审批业务类型： a21素材 a22计划 a23设备")
    private String busniessType;

    @ApiModelProperty(value = "审批结果 a11待处理/a12同意/a13拒绝")
    private String approvalResult;

    //限定导出的时间戳
    @JsonIgnore
    private Long exportTime;

    @JsonIgnore
    private List<String> orgIdList;


}

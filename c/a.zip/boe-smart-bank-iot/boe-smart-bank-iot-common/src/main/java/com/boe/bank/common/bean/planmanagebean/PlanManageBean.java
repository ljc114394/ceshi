package com.boe.bank.common.bean.planmanagebean;

import com.boe.bank.common.entity.material.MaterialManage;
import com.boe.bank.common.entity.planmanage.PlanMaterialManage;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/9/29 14:52
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "计划管理bean")
public class PlanManageBean {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "计划名称")
    private String title;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "机构名称")
    private String orgName;

    @ApiModelProperty(value = "计划开始时间")
    private String beginTime;

    @ApiModelProperty(value = "计划结束时间")
    private String endTime;

    @ApiModelProperty(value = "计划时间")
    private String planTime;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "修改人")
    private String updateBy;

    @ApiModelProperty(value = "修改时间")
    private String updateTime;

    @ApiModelProperty(value = "审核状态")
    private  Integer state;

    @ApiModelProperty(value = "审核状态名称")
    private  String auditState;

//    @ApiModelProperty(value = "播放状态")
//    private  String playStatus;

    @ApiModelProperty(value = "素材集合")
    private List<PlanMaterialManageBean> list;

    @ApiModelProperty(value = "设备关联该计划，null或0：否，1：是")
    private Integer isSelected;

}

package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 流程节点详情
 * @author caoxuhao
 */
@Data
public class ActivitiDetailVo {
	
	@ApiModelProperty(value = "节点名称")
	String name;
	
	@ApiModelProperty(value = "操作")
	String opt;
	
	@ApiModelProperty(value = "操作人")
	String opter;
	
	@ApiModelProperty(value = "审批时间")
	String time;
	
	@ApiModelProperty(value = "备注")
	String comment;
}

package com.boe.bank.common.entity.userPortrait;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.boe.bank.common.base.BaseEntity;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @Description:用户画像
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPortrait extends BaseEntity implements Serializable {

    private Integer id;//主键id

    private String portraitName;//画像名称

    private String remark;//备注

    private Integer enable;//启用状态：0否  1是

    private Integer personNums;//画像人数分布

    private Integer hourLength;//启用时间

    private Integer portraitLabelNums;//用户画像关联标签数量

    private Integer portraitProductNums;//用户画像关联产品数量

    private Integer conditionType;//条件判断：0或  1且

    private Integer weight;//权重
    private String labelTrees;//关联标签数
    private String labelTreesFrom;//关联标签数

    @TableField(fill = FieldFill.INSERT)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime enableTime;
}

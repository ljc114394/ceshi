package com.boe.bank.common.bean.marketLabel;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description:精准营销-标签表  数据库交互
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Data
@ApiModel(description = "标签库别表返回值")
public class MarketLabelBean {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "父类id")
    private Integer parentId;

    @ApiModelProperty(value = "标签名称")
    private String labelName;

    @ApiModelProperty(value = "标签属性区分：0属性标签、1行为标签")
    private Integer labelType;//标签属性区分：0属性标签、1行为标签

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "启用时间")
    private Date enableTime;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "标签人数分布")
    private String personNums;

    @ApiModelProperty(value = "用户群画像使用该标签")
    private String labelNums;//用户群画像使用该标签

    @ApiModelProperty(value = "启用时长（小时）")
    private Integer hourLength;//启用时长hourLength

}

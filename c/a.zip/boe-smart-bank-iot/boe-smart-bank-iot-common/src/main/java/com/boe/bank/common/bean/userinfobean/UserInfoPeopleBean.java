package com.boe.bank.common.bean.userinfobean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/9/29 14:52
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoPeopleBean {

    @ApiModelProperty(value = "userid")
    private Integer uid;

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "账号")
    private String username;

    @ApiModelProperty(value = "所属角色")
    private String role;

    @ApiModelProperty(value = "所属角色id")
    private String roleId;

    @ApiModelProperty(value = "部门名称")
    private String departmentName;

    @ApiModelProperty(value = "部门id")
    private Integer  departmentId;

    @ApiModelProperty(value = "岗位")
    private String postName;

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "机构名称")
    private String orgName;

    @ApiModelProperty(value = "手机号码")
    private String  phoneNum;

    @ApiModelProperty(value = "状态")
    private Integer isEnabled;

    @ApiModelProperty(value = "工号")
    private String  workNum;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "是否是该角色的有的用户 0不是 1 是")
    private Integer whether ;

}

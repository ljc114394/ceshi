package com.boe.bank.common.bean.datarolebean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/3 10:33
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataRoleOrgListBean {

    @ApiModelProperty(value = "机构id")
    private Integer orgId;

    @ApiModelProperty(value = "机构name")
    private String name;

    @ApiModelProperty(value = "parentId")
    private Integer parentId;

    @ApiModelProperty(value = "是否具有权限 1有权限 0无权限 ")
    private Integer permission;

    @ApiModelProperty(value = "id ")
    private Integer id;

    @ApiModelProperty(value = "type")
    private Integer type;

}

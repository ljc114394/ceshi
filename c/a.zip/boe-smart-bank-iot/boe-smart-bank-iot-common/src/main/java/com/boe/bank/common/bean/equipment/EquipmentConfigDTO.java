package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;
import java.util.List;

/**
 * 设备配置DTO
 *
 * @author 10183279
 * @date 2020/10/19
 */
@ApiModel(value = "设备配置DTO")
@Data
public class EquipmentConfigDTO implements Serializable {

    private static final long serialVersionUID = -750449755598014010L;

    @ApiModelProperty(value = "开机时间，格式：HH:mm:ss")
    private String onTime;

    @ApiModelProperty(value = "关机时间，格式：HH:mm:ss")
    private String offTime;

    @ApiModelProperty(value = "刷新间隔")
    private Integer refreshInterval;

    @ApiModelProperty(value = "音量")
    @Max(value = 100, message = "音量不能大于100")
    @Min(value = 0, message = "音量不能小于0")
    private Integer volume;

    @ApiModelProperty(value = "下载时间段，格式：HH:mm:ss-HH:mm:ss")
    private String downloadTime;

    @ApiModelProperty(value = "日志回传时间段，格式：HH:mm:ss-HH:mm:ss")
    private String logReturnTime;

    @ApiModelProperty(value = "日志保存时间")
    @Max(value = 100, message = "日志保存时间不能大于100")
    @Min(value = 0, message = "日志保存时间不能小于0")
    private Integer logRetentionTime;

    @ApiModelProperty(value = "下载速度，kb/s")
    private Integer downloadSpeed;

    @ApiModelProperty(value = "屏幕区域布局")
    private List<ScreenLayout> layoutList;
}

package com.boe.bank.common.bean.planmanagebean;

import com.boe.bank.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanMaterialManageBean  {


    @ApiModelProperty(value = "素材id ")
    private Integer id;

    @ApiModelProperty(value = "播放次数或时间 ")
    private Integer playOperation;

    @ApiModelProperty(value = "屏幕区域 1,2,3,4 ")
    private Integer screenArea;

    @ApiModelProperty(value = "素材名称")
    private String title;

    @ApiModelProperty(value = "type为1或者2，表示缩略图名称，前台不需要传；type为3，表示文本内容；type为4，表示web地址；type为5，表示文档名称；type为6，表示程序入口，即文件名")
    private String content;

    @ApiModelProperty(value = "type为6时，表示程序序参数")
    private String programEntry;

    @ApiModelProperty(value = "类型，1图片资源，2视频资源 3web资源 4文本信息 5文档管理 6.应用程序\n")
    private Integer type;

    @ApiModelProperty(value = "文件类型，1文件夹，2素材")
    private Integer fileType;

    @ApiModelProperty(value = "文件大小")
    private Integer fileSize;

    @ApiModelProperty(value = "素材md5")
    private String md5;

    @ApiModelProperty(value = "父id")
    private Integer parentId;

    @ApiModelProperty(value = "标签id")
    private Integer lableId;

    @ApiModelProperty(value = "标签名称")
    private String lableName;

    @ApiModelProperty(value = "类型名称")
    private String typeName;

    @ApiModelProperty(value = "计划id")
    private Integer planId;

    @ApiModelProperty(value = "过期时间")
    private String valTime;




}

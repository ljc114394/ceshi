package com.boe.bank.common.entity.label;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * TODO
 * 标签管理
 * @author lijianglong
 * @data 2020/10/13
 */

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Label extends BaseEntity implements Serializable {

    private Integer id; // 主键id

    private String title; // 标签名称

    private String remark; // 备注

    private Integer isDelete; // 是否删除 0 否 1 是
}

package com.boe.bank.common.bean.dictbean;

import lombok.Data;

@Data
public class SysDictionariesListBean {

    private Integer id;

	private String code;

	private String codeValue;

	private String childCode;

	private String childCodeValue;
}

package com.boe.bank.common.bean.logbean;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 登录导出
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/30 10:27
 */
@Data
@ApiModel(description = "登录导出bean")
public class LogExportInterfaceBean {

    @ExcelProperty(value = "序号", index = 0)
    private Integer id;

    @ExcelProperty(value = "接口名称", index = 1)
    private String  title;

    @ExcelProperty(value = "调用时间", index = 2)
    private String createTime;

    @ExcelProperty(value = "调用ip", index = 3)
    private String  ip;

    @ExcelProperty(value = "接口关键参数", index = 4)
    private String  param;


}

package com.boe.bank.common.entity.equipment;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @author 10085188
 * @data 2020/11/06
 */
@Data
@ApiModel(description = "设备日志-显示bean")
public class EquipmentLogResultBean implements Serializable {
	private static final long serialVersionUID = 4475095357727825759L;

	@ApiModelProperty(value = "设备mac地址")
	private String mac;
	
	@ApiModelProperty(value = "日志等级")
	private Integer level;
	
	@ApiModelProperty(value = "日志内容")
	private String message;
	
	@ApiModelProperty(value = "日志时间")
	private String time;
	
}

package com.boe.bank.common.bean.appliedbizmanege;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppliedBizManegeListBean {
    @ApiModelProperty(value = "主键")
    private Integer id;
    @ApiModelProperty(value = "菜单名称")
    private String bizName;
    @ApiModelProperty(value = "表名称")
    private String bizTableName;
//    @ApiModelProperty(value = "字段信息")
//    private String bizFields;
//    @ApiModelProperty(value = "组件名称")
//    private List<AppliedBizManegeComponentBean> bizComponents;
    @ApiModelProperty(value = "业务URL")
    private String bizUri;
    @ApiModelProperty(value = "备注")
    private String remark;
    @ApiModelProperty(value = "创建人")
    private String createBy;
    @ApiModelProperty(value = "更新人")
    private String updateBy;
    @ApiModelProperty(value = "创建时间")
    private String createTime;
    @ApiModelProperty(value = "更新时间")
    private String updateTime;


}
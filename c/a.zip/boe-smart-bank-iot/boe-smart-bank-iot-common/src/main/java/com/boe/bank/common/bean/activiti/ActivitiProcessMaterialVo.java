package com.boe.bank.common.bean.activiti;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 流程图结合素材业务的类
 * @author caoxuhao
 */
@Data
public class ActivitiProcessMaterialVo extends ActivitiProcessOrgVo {
	
	@ApiModelProperty(value = "名称/标题")
	private String materiaName;

	@ApiModelProperty(value = "素材标签")
	private String materialTag;
	
	@ApiModelProperty(value = "素材类型，1图片资源，2视频资源 3web资源 4文本信息 5文档管理 6.应用程序")
	private Integer materialType;
}

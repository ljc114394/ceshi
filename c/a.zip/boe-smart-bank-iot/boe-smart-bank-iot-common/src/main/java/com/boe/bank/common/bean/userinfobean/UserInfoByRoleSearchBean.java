package com.boe.bank.common.bean.userinfobean;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/13 9:31
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoByRoleSearchBean {

    @ApiModelProperty(value = "姓名")
    @Emoticon
    private String name;

    @ApiModelProperty(value = "账号")
    @Emoticon
    private String username;

    @ApiModelProperty(value = "机构id ")
    private Integer orgId;

    @ApiModelProperty(value = "角色id 必填")
    private Integer roleId;

    @ApiModelProperty(value = "部门id ")
    private Integer departmentId;
}

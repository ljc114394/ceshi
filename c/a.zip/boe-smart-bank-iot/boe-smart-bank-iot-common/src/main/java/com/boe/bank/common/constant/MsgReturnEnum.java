package com.boe.bank.common.constant;

import com.boe.bank.common.base.BaseEnum;

import java.util.HashMap;
import java.util.Map;

/**
 *  返回值常量对应表
 */
public enum MsgReturnEnum implements BaseEnum<Integer, String> {

    SUCCESS(0, "request success"),
    FAILURE(9999, "request failure"),
    NOT_FOUND(4001, "resource not found"),
    FORBIDDEN(4002, "forbidden access"),
    VERSION_NOT_MATCH(4003, "record is not exist or version not match"),
    PARAMETER_NOT_NULL(2001, "parameter cannot be null"),
    PARAMETER_INVALID(2002, "parameter invalid"),
    PARAMETER_EMPTY(2003, "参数为空"),
    LOCK_FALSE(2004, "加锁失败,60秒自动解锁"),
    PARAMETER_TYPE_ERROR(2005, "参数类型错误"),
    FILE_EMPTY(2006, "文件不能为空"),
    FILE_EXCEP(2007, "上传文件失败"),




    DEPART_AUDIT_ADD(10001,"保存部门审批权限失败"),
    DEPART_ADD(10002,"保存部门信息失败"),
    DEPART_UPDATE(10003,"更新部门信息失败"),
    DEPART_AUDIT_UPDATE(10004,"更新部门审批权限失败"),
    DEPART_AUDIT_DELETE(10005,"删除部门审批权限失败"),
    DEPART_AUDIT_NULL(10006,"部门不存在"),
    DEPART_AUDIT_Dub(10007,"组织名称重复"),
    DEPART_USER(10008,"部门下存在人员,不能删除"),
    DEPART_TYPE(10009,"部门类型必填,请添加部门类型"),

    UPDATE_FAILURE(8888, "update or add failure"),

    VALUE_NOTGET(8890,"value is not get"),
    ID_NOFAND(8889,"获取id失败"),

    AREA_TITLE(6001, "区域名称不能为空"),
    AREA_ORGNAME(6002, "机构名称不能为空"),
    AREA_DEPTMENTNAME(6003, "部门名称不能为空"),
    AREA_DEPTMENTNAMEREPEAT(6004, "区域名称不能重复"),
    DICT_ID(7001,"字典ID称不为空"),
    DICT_TITLE(7002,"字典名称不为空"),
    DICT_CODE(7003,"编码不为空"),
    DICT_CODE_VALUE(7004,"字典编码含义值不能为空"),
    DICT_CODE_REPEAT(7005,"字典CODE不能重复"),
    DICT_CODE_PARENT(7006,"字典对应的有子节点不能删除!"),
    DICT_CODE_DISABLE(7007,"字典对应的有子节点不能禁用!"),



    USER_NAME(8001, "用户账号不能为空"),
    USER_PASSWORD(8002, "用户密码不能为空"),
    USER_ORG(8003, "用户所在机构不能为空"),
    USER_DEPARTMENT(8004, "用户所在部门不能为空"),
    USER_DELETE(8005, "用户删除失败"),
    USER_USERNAME(8006, "账号已存在,不能重复添加"),
    USER_ORGCHILDREN(8007, "用户所在机构的子机构不能为空"),
    USER_ORGCHILDREN_DEPARTMENT(8008, "用户所在机构的部门不能为空"),



    PLAN_NAME(9001, "计划名称不能为空"),
    PLAN_BEGIN_TIME(9002, "计划开始时间不能为空"),
    PLAN_END_TIME(9003, "计划结束时间不能为空"),
    PLAN_TIME(9004, "计划时间不能为空"),
    PLAN_DELETE(9005, "计划删除失败"),
    PLAN_START_TIME(9006, "计划开始时间不能大于结束时间"),
    PLAN_SCREE_AREA(9007, "屏幕区域必填"),
    PLAN_SUBMIT_ACTIVITI(9008, "计划提交审批流失败"),
    PLAN_STATE_FAIL(9009, "添加计划审批状态失败"),
    PLAN_ADD_FAILS(9010, "新增计划失败"),
    PLAN_UPDATE_FAILS(9011, "编辑计划失败"),
    PLAN_PLAY_TIMES(9012, "播放次数或时间必传"),
    PLAN_EQUIPMENT_FAILS(9013, "播放次数或时间必传"),
    PLAN_EQUIPMENT_DELETE_FAILS(9014, "计划关联设备删除失败"),
    EQUIPMENT_PLAN_DELETE_FAILS(9015, "设备关联计划删除失败"),
    EQUIPMENT_NULL(9016, "设备不存在"),
    EQUIPMENT_NOT_BATCH(9017, "所选设备屏幕区域数不一致，无法批量设置"),
    EQUIPMENT_ID_NULL(9018, "设备id不能为空"),
    PLAN_PLAY_MATERIAL(9019, "添加计划时素材不能为空,请添加素材"),
    PLAN_SCREE_AREA_NULL(9020, "没有查询到计划对应的屏幕区域"),
    PLAN_Material_NULL(9021, "计划没有对应的素材或者素材已失效"),










    MATERIAL_FILE_EMPTY(11001, "文件不能为空"),
    MATERIAL_FILE_PDF(11002, "只支持PDF文件"),
    MATERIAL_FILE_EXCEP(11003, "上传文件失败"),
    MATERIAL_FILE_CONTENT(11004, "上传的文件名称不能重复"),
    MATERIAL_DELETE(11005, "有节目正在使用此素材，请删除节目中的素材后再删除"),
    MATERIAL_NOT_EXIST(11006, "素材不存在"),
    MATERIAL_SUBMIT_ACTIVITI(11007, "素材提交审批流失败"),
    MATERIAL_FOLDER_NOTEXIST(11008, "文件夹不存在"),
    MATERIAL_FOLDER_LEVEL(11009, "文件夹级数不符合"),
    MATERIAL_FOLDER_FAIL(11010, "删除文件夹失败"),
    MATERIAL_FILE_TXT(11011, "只支持TXT文件"),
    MATERIAL_FILE_COPYEMPTY(11012, "只能复制到文件夹"),
    MATERIAL_FILE_COPYFAIL(11013, "复制粘贴失败"),
    MATERIAL_FILE_COPYERROR(11014, "目标文件夹不能是源文件夹"),
    MATERIAL_NOT_USE_DELETE(11015, "暂无权限删除"),
    MATERIAL_NOT_USE_UPDATE(11016, "暂无权限编辑"),
    MATERIAL_ORGID_NOT_IN(11017, "本人机构不在数据授权里面"),
    MATERIAL_DOWNLOAD_ERROR(11018, "素材下载失败"),

    
    LABEL_TITLE(10001,"标签名称不能为空"),
    LABEL_TITLE_HAS(10002,"标签名称已存在，不能重复添加"),
    LABEL_TITLE_DETEDE(10003,"此标签名称在素材管理模块中有用到，不能删除"),
    LABEL_TITLE_UPDATE(10004,"此标签名称在素材管理模块中有用到，不能编辑"),
    LABEL_TITLE_ID(10005,"标签ID无效，请确认"),
    LABEL_TITLE_TYPE(10006,"标签类型区分不能为空"),
    LABEL_TITLE_LEVEL(10007,"标签级别不能为空"),


    DATA_ROLE_ROLE_ID(12001, "数据权限角色id不能为空"),
    DATA_ROLE_POWER(12002, "权限不足无法访问"),
    DATA_ROLE_LIST_NULL(12003, "数据为空或者不能添加"),
    DATA_ROLE_NULL(12004, "当前用户没有对应角色"),
    DATA_ROLE_ORG_NULL(12005, "当前用户角色没有对应的机构"),


    ACTIVITI_EXAMINE_NOT_EXIST(13001, "审批类型不存在，请先建立审批类型"),
    ACTIVITI_PROCESS_INSERT_ERROR(13002, "审批流创建失败，插入错误"),
    ACTIVITI_PROCESS_LIST_EMPTY(13003, "审批流创建失败，没有有效的节点"),
    ACTIVITI_PROCESS_UPDATE_ERROR(13004, "审批流更新错误"),
    ACTIVITI_PROCESS_NOT_EXIST(13005, "审批流不存在"),
    ACTIVITI_PROCESS_DELETE_ERROR(13006, "审批流删除失败"),
    ACTIVITI_PROCESS_SUSPEND_ERROR(13007, "审批流停用失败"),
    ACTIVITI_PROCESS_ACTIVE_ERROR(13008, "审批流启用失败"),
    ACTIVITI_PROCESS_SUBMIT_ERROR(13009, "审批流提交失败"),
    ACTIVITI_PROCESS_REJECT_ERROR(13010, "审批流拒绝失败"),
    ACTIVITI_PROCESS_REJECT_OTHER_DEP_ERROR(13011, "审批流拒绝错误"),
    ACTIVITI_PROCESS_HAVE_NO_TASK_ERROR(13012, "该任务不存在，可能已经被其他人审批了"),
    ACTIVITI_PROCESS_PASS_ERROR(13013, "审批流通过失败"),
    ACTIVITI_PROCESS_TRANSFER_ERROR(13014, "审批流转办失败"),
    ACTIVITI_PROCESS_NOT_FOUND_ERROR(13015, "没有查到对应的审批流"),
    ACTIVITI_PROCESS_UNFINISHED_ERROR(13016, "此流程下有未完成的审批流程，请完成所有审批后再删除此流程。"),
    ACTIVITI_EXAMINE_INSERT_ERROR(13017, "审批类型创建失败"),
    ACTIVITI_EXAMINE_DUPLICATE_ERROR(13018, "审批类型创建失败,存在重复类型"),
    ACTIVITI_TASK_IS_RUNNING_ERROR(13019, "有未完成的审批流程，请完成所有审批后再操作。"),
    ACTIVITI_EXAMINE_UPDATE_ERROR(13020, "审批类型更新失败"),
    ACTIVITI_PROCESS_IS_RUNNING_ERROR(13021, "操作失败，请先停用关联的审批流。"),
    ACTIVITI_EXAMINE_DELETE_ERROR(13022, "审批类型删除失败。"),
    ACTIVITI_PROCESS_NOT_SUSPEND(13023, "请先停用审批流后再操作"),
    ACTIVITI_EXAMINE_ALREADY_RELATED(13024, "审批流创建失败，该审批类型已经关联过其他审批流"),
    ACTIVITI_PROCESS_ALREADY_ACTIVE(13025, "该审批流已经被启用，不能重复启用"),
    ACTIVITI_PROCESS_ALREADY_SUSPEND(13026, "该审批流已经被停用，不能重复停用"),
    ACTIVITI_PROCESS_ALREADY_SUSPEND_NO_CREATE(13027, "该审批流已经被停用，不能提交新的审批申请"),
    ACTIVITI_CAN_NOT_TRANSFER_SELF(13028, "审批流不能转发给自己"),

    MARKET_LABEL_NATURE(14001,"标签属性不能为空"),
    MARKET_LABEL_NATURE_HAS(14002,"此标签下已有相同名称的标签，请重新命名"),

    USER_PORTRAIT_NAME(15001,"画像名称不能为空"),
    USER_PORTRAIT_ENABLE(15002,"标签状态无效"),
    USER_PORTRAIT_NAME_HAS(15003,"画像名称已存在"),
    USER_PORTRAIT_IS_ID(15004,"id无效，请确认"),
    USER_PORTRAIT_IS_NOT(15005,"无效的数据"),
    USER_PORTRAIT_IS_LABEL(15006,"此标签在用户画像模块中有用到，不能删除"),
    IS_LABEL_SON(15007,"此标签有对应的子标签，不能删除"),
    USER_PORTRAIT_WEIGTH_NULL(15008,"权重值不能为空"),
    USER_PORTRAIT_PRODUCT_IS(15009,"此用户画像有关联的产品，无法删除"),
    USER_PORTRAIT_CONDITION_TYPE_NULL(15010,"条件判断不能为空"),
    USER_PORTRAIT_LABEL_ID_NULL(15011,"用户画像关联标签id不能为空"),
    USER_PORTRAIT_LABEL_PARENT_ID_NULL(15012,"用户画像关联标签父类标签id不能为空"),


    MARKETINT_STRATEGY_WEIGTH(16001,"营销策略授权失败"),
    MARKETINT_STRATEGY_FILE_EMPTY(16002, "产品库上传文件不能为空"),
    MARKETINT_STRATEGY_FILE_CONTENT(16003, "产品库上传的文件名称不能重复"),
    MARKETINT_STRATEGY_FILE_EXCEP(16004, "产品库上传文件失败"),

    APPLIED_BIZ_MANEGE_DELETE_FAILURE(17001,"应用管理删除错误，请联系管理员"),
    APPLIED_BIZ_MANEGE_SAVE_FAILURE(17002,"应用管理保存错误，请联系管理员"),
    APPLIED_BIZ_MANEGE_BIZ_NAME(17003,"业务菜单名称数据不正确，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_URI(17004,"业务URI路径数据不正确，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COMPONENTS(17005,"业务组件数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_FIELD(17006,"业务字段列表数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_CODE(17008,"字段code数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_TYPE(17009,"字段类型数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_NAME(17010,"字段名称数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_COMMENT(17011,"字段注释数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_LENGTH(17012,"字段长度数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_REQUIRED(17013,"字段是否必填数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_DELETE_EXISTS_DATA(17014,"应用业务数据已经存在，不可删除,不可修改"),
    APPLIED_BIZ_MANEGE_UPDATE_FAILURE(17015,"应用管理更新错误，请联系管理员"),
    APPLIED_BIZ_MANEGE_CHECK_MESSAGE(17016,""),
    APPLIED_BIZ_MANEGE_CHECK_SQL_INJECTION(17017,"请求参数中存在sql注入问题"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_LISTSHOW(17018,"字段是否列表显示,数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_QUERY_CRITERIA(17019,"字段是否为查询条件数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_BIZ_COLUMN(17020,"应用名称数据长度超过100个字符"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_URI(17021,"应用URI数据长度超过100个字符"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_COMPONENT(17022,"组件功能数据长度超过200个字符"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELDLIST(17023,"所有业务字段数据总长度超过12000个字符"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_REMARK(17023,"备注数据长度超过300个字符"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_SIZE(17024,"动态表单字段个数大于20个字段"),
    APPLIED_BIZ_MANEGE_CHECK_LENGTH_FIELD_LENGTH(17025,"动态表单字段大于50个字符"),
    APPLIED_BIZ_MANEGE_CHECK_USER_LOGIN(17026,"请先登录系统"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_ISIMAGE(17013,"是否图片，必填数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_COLUMN_ISVIDEO(17014,"是否视频，必填数据不可为空，请重新录入"),
    APPLIED_BIZ_MANEGE_BIZ_ID(17015,"应用业务数据不存在"),
    APPLIED_BIZ_MANEGE_BIZ_APP_ID(17016,"应用产品数据不存在"),
    APPLIED_BIZ_MANEGE_BIZ_EXAMINE_STATUS(17017,"应用审批结果更新失败"),
    APPLIED_BIZ_MANEGE_BIZ_EXAMINE_STATUS_NO_OPERATE(17018,"数据已审批通过，不可修改，不可删除"),
    APPLIED_BIZ_MANEGE_BIZ_EXAMINE_STATUS_NULL(17019,"数据审批状态不正确，状态为空"),
    APPLIED_SUBMIT_ACTIVITI(17020, "应用产品提交审批流失败"),
    APPLIED_BIZ_MANEGE_BIZ_APP_NAME_EXIST(17021,"应用名称已存在"),
    APPLIED_BIZ_MANEGE_BIZ_APP_SQL_KEYWORDS(17022,"字段code或备注数据存在sql关键字"),


    LOGS_MANAGE_MODULE(18001, "模块类型不能为空"),
    MARKET_LOGS_PARAMS(19001, "logs日志属性无效"),
    EQUMENT_MAC(20000,"设备mac地址不能重复"),


    WEIGHT_SORT_MESSAGE(21000,"权重排序需要传对应的值：0升序，1降序")
    ;

    private static Map<Integer, String> allMap = new HashMap<Integer, String>();
    private Integer code;
    private String message;

    MsgReturnEnum(Integer code, String message){
        this.code = code;
        this.message = message;
    }

    static {
        for (MsgReturnEnum baseEnums:MsgReturnEnum.values ()) {
            allMap.put(baseEnums.code, baseEnums.message);
        }
    }

    @Override
    public Integer code() {
        return this.code;
    }

    @Override
    public String message() {
        return this.message;
    }

    public String message(String code){
        return allMap.get(code);
    }
}

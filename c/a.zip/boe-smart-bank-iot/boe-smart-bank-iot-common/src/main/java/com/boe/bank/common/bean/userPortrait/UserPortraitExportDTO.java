package com.boe.bank.common.bean.userPortrait;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Description:用户画像-导出
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserPortraitExportDTO {

    @ExcelProperty(value = "id", index = 0)
    private Integer id;

    @ExcelProperty(value = "启用状态", index = 1)
    private String enable;

    @ExcelProperty(value = "画像名称", index = 2)
    private String portraitName;

    @ExcelProperty(value = "备注", index = 3)
    private String remark;

    @ExcelProperty(value = "画像人数分布", index = 4)
    private Integer personNums;

    @ExcelProperty(value = "启用时长/小时", index = 5)
    private Integer hourLength;//启用时间

    @ExcelProperty(value = "用户画像关联标签数量", index = 6)
    private Integer portraitLabelNums;//用户画像关联标签数量

    @ExcelProperty(value = "用户画像关联产品数量", index = 7)
    private Integer portraitProductNums;//用户画像关联产品数量

    @ExcelProperty(value = "创建时间", index = 8)
    private Date createTime;

    @ExcelProperty(value = "权重", index = 9)
    private Integer weight;//权重

}

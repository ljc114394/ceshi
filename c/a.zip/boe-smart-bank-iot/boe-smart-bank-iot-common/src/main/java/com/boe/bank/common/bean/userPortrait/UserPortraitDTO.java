package com.boe.bank.common.bean.userPortrait;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用户画像-页面交互
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Data
public class UserPortraitDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "画像名称")
    private String portraitName;

    @ApiModelProperty(value = "备注")
    private String remark;
}

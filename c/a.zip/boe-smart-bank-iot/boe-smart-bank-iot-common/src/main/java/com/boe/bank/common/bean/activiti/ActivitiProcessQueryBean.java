package com.boe.bank.common.bean.activiti;

import com.boe.bank.common.base.PageBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 审批流部署情况查询
 * @author caoxuhao
 */
@Data
public class ActivitiProcessQueryBean extends PageBean{
	
	@ApiModelProperty(value = "审批流程编码")
	private Integer id;
	
	@ApiModelProperty(value = "流程名称")
	private String name;
	
	@ApiModelProperty(value = "业务类型:  1素材 2计划 3设备")
	private Integer busniessType;
	
	@ApiModelProperty(value = "审批流状态： 0启用 1停用")
	private Integer status;
}

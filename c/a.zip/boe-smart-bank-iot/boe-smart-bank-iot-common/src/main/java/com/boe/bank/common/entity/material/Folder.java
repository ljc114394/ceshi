package com.boe.bank.common.entity.material;

import java.io.Serializable;

import com.boe.bank.common.base.BaseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Folder extends BaseEntity implements Serializable{
	
	private static final long serialVersionUID = 1L;
	/**
	 * 主键id
	 */
	private Integer id;
	/**
	 * 文件夹名称
	 */
    private String title;
    /**
	 * 是否删除 0 否 1 是
	 */
    private Boolean isDelete;
    /**
	 * 文件夹级别，1一级，2二级
	 */
    private Integer level;
    /**
	 * 父文件夹id，一级文件夹该字段默认为0
	 */
    private Integer parentId;

}
package com.boe.bank.common.entity.activiti;

import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 审批转办
 * @author caoxuhao
 */
@Data
public class ActivitiTransfer extends BaseEntity implements Serializable {
	private Integer id;
	private Long fromUserId;//转办发起人
	private Long toUserId;//转办接受者
	private String comment;//转办理由
	private String TASK_ID_;//activiti流程task_id
	private String PROC_INST_ID_;//activiti流程proc_inst_id
}

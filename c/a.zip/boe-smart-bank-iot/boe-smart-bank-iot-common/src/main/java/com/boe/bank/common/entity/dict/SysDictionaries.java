package com.boe.bank.common.entity.dict;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
public class SysDictionaries extends BaseEntity implements Serializable{
	

	/**
	 * 主键ID
	 */
	private Integer id;

	/**
	 * 字典名称
	 */
	private String title;
	/**
	 * 编码
	 */
	private String code;
	/**
	 * 值
	 */
	private String codeValue;

	/**
	  * 父级ID
	  */
	private Integer parentId;
	 /**
	  * 备注
	  */
	private String remark;

	/**
	 * 禁用启用
	 */
	private Integer isEnabled;

}

package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备安装包版本
 *
 * @author 10183279
 * @date 2020/10/23
 */
@ApiModel(value = "设备安装包版本")
@Data
public class EquipmentVersionVO implements Serializable {

    private static final long serialVersionUID = 4174153517700519590L;

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "版本")
    private String version;

    @ApiModelProperty(value = "url")
    private String url;

    @ApiModelProperty(value = "md5")
    private String md5;
}

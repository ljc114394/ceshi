package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * socket配置
 *
 * @author 10183279
 * @date 2020/11/11
 */
@ApiModel(value = "socket配置")
@Data
public class SocketVO implements Serializable {

    private static final long serialVersionUID = 5519720407807506742L;

    @ApiModelProperty(value = "host")
    private String host;

    @ApiModelProperty(value = "port")
    private Integer port;
}

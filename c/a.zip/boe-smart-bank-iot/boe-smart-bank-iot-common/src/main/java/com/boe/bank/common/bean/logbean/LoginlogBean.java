package com.boe.bank.common.bean.logbean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/5 18:10
 */
@Data
@ApiModel(description = "日志bean")
public class LoginlogBean {

    @ApiModelProperty(value = "登录ip")
    private String  ip;

    @ApiModelProperty(value = "登录时间")
    private String createTime;

    @ApiModelProperty(value = "登录用户")
    private String  userName;

    @ApiModelProperty(value = "操作结果")
    private String  jsonResult;

    @ApiModelProperty(value = "所属机构")
    private String  orgName;

    @ApiModelProperty(value = "类型（0其它 1后台用户 2手机端用户）")
    private String operatorTypeName;


}

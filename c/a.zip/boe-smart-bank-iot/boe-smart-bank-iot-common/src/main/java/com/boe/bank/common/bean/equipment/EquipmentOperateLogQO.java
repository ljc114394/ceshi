package com.boe.bank.common.bean.equipment;

import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备操作日志查询对象
 *
 * @author 10183279
 * @date 2020/10/28
 */
@ApiModel(value = "设备操作日志查询对象")
@Data
public class EquipmentOperateLogQO extends PageBean implements Serializable {

    private static final long serialVersionUID = -8271343209999940950L;

    @ApiModelProperty(value = "mac地址", hidden = true)
    private String mac;

    @ApiModelProperty(value = "操作用户")
    private String operateUser;

    @ApiModelProperty(value = "操作类型")
    private String type;
}

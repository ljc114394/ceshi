package com.boe.bank.common.bean.activiti;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ActivitiStatisticsBusniessVo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6040433856766992745L;

	@ApiModelProperty(value = "业务类型： 1素材 2计划 3设备")
	private Integer busniessType;

	@ApiModelProperty(value = "已审核数量")
	private Integer examinedCount;
	
	@ApiModelProperty(value = "待审核数量")
	private Integer toDoCount;
}

package com.boe.bank.common.entity.appliedbizmanege;

import com.boe.bank.common.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
/**
 * @author chenchenghu
 * @version 1.0
 * @date 2020/10/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppliedBizManege extends BaseEntity implements Serializable {
    private Integer id;

    private String bizName;

    private String bizTableName;

    private String bizFields;

    private String bizComponents;

    private String bizUri;

    private Integer examineId;

    private String remark;

}
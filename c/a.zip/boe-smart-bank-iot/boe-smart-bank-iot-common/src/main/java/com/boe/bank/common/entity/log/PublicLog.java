package com.boe.bank.common.entity.log;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 公共日志
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/11/5 17:52
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PublicLog  implements Serializable {

    //主键id
    private Integer id;

    //操作类别名称
    private String operatorTypeName;

    //用户id
    private Integer userId;

    //姓名
    private String  userName;

    //账号
    private String  userUsername;

    //机构id
    private Integer  orgId;

    //机构id
    private String  orgName;
    //ip
    private String  ip;

    //接口名称
    private String  title;

    //参数
    private String  param;

    //查询参数
    private String  querying;

    //返回结果
    private String  jsonResult;

    //创建时间
    private LocalDateTime createTime;

    //操作状态 1异常 0正常
    private Integer  status;






}

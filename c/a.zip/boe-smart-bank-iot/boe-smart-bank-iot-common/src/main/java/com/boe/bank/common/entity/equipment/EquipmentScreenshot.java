package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.boe.bank.common.base.BaseEntity;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备截图
 *
 * @author 10183279
 * @date 2020/10/13
 */
@Data
@TableName("t_equipment_screenshot")
public class EquipmentScreenshot extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -3224415448396470682L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String mac;
    /**
     * 设备类型，对应sys_dictionaries中的code
     */
    @TableField(value = "url")
    private String url;
}

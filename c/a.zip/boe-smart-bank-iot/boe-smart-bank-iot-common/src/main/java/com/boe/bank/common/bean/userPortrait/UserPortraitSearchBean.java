package com.boe.bank.common.bean.userPortrait;

import com.boe.bank.common.annotation.Emoticon;
import com.boe.bank.common.base.PageBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:用户画像搜索
 * @Author: lijianglong
 * @Data:2020/10/21
 */

@Data
public class UserPortraitSearchBean extends PageBean {

    @ApiModelProperty(value = "启用状态：0否  1是")
    private Integer enable;

    @ApiModelProperty(value = "画像名称")
    @Emoticon
    private String portraitName;

    @ApiModelProperty(value = "权重排序：0升序 ，1降序，2时间排序")
    private Integer weightSort;
}

package com.boe.bank.common.bean.dictbean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SysDictionariesValueBean {


	/**
	 * 编码
	 */
	@ApiModelProperty(value = "编码")
	private String code;
	/**
	 * 值
	 */
	@ApiModelProperty(value = "值")
	private String codeValue;

	@ApiModelProperty(value = "字典名称")
	private String title;

}

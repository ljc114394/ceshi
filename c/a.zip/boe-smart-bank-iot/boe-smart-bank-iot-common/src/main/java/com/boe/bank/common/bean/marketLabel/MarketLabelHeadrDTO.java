package com.boe.bank.common.bean.marketLabel;

import com.boe.bank.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description:精准营销-标签表-首页统计数据
 * @Author: lijianglong
 * @Data:2020/10/19
 */

@Data
public class MarketLabelHeadrDTO{

    @ApiModelProperty(value = "标签名称")
    private String name;//标签名称

    @ApiModelProperty(value = "标签人数分布")
    private String value;//标签人数分布
}

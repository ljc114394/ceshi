package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 上传时间
 *
 * @author 10183279
 * @date 2020/11/11
 */
@ApiModel(value = "上传时间")
@Data
public class UploadTimeVO implements Serializable {

    private static final long serialVersionUID = 8625539458838382851L;

    @ApiModelProperty(value = "上传开始时间")
    private String begin;

    @ApiModelProperty(value = "上传截止时间")
    private String end;
}

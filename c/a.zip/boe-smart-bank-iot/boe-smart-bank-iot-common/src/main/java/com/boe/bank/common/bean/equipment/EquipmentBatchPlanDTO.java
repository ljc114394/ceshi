package com.boe.bank.common.bean.equipment;

import com.boe.bank.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * 批量设备计划DTO
 *
 * @author lvjiacheng
 * @date 2020/12/15
 */
@ApiModel(value = "批量设备计划DTO")
@Data
public class EquipmentBatchPlanDTO extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -134593343441244758L;

    @ApiModelProperty(value = "计划id列表")
    private List<Integer> planIds;

    @ApiModelProperty(value = "类型 1：正常计划，2：插播计划")
    @NotNull(message = "类型不能为空")
    @Min(value = 1, message = "类型不正确")
    @Max(value = 2, message = "类型不正确")
    private Integer type;

    @ApiModelProperty(value = "mac集合")
    List<String> mac;

}

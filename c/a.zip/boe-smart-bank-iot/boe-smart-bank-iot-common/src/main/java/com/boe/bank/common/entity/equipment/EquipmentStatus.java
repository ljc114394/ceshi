package com.boe.bank.common.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 设备状态
 *
 * @author 10183279
 * @date 2020/10/19
 */
@Data
@TableName("t_equipment_status")
public class EquipmentStatus implements Serializable {

    private static final long serialVersionUID = -850704879262168882L;

    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 1在线 2离线
     */
    @TableField(value = "is_online")
    private Integer isOnline;
    /**
     * mac地址
     */
    @TableField(value = "mac")
    private String  mac;
    /**
     * 最后在线时间
     */
    @TableField(value = "last_online_time")
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime lastOnlineTime;
}

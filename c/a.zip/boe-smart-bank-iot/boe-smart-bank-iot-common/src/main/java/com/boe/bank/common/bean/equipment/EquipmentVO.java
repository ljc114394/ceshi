package com.boe.bank.common.bean.equipment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备VO
 *
 * @author 10183279
 * @date 2020/10/13
 */
@ApiModel(value = "设备VO")
@Data
public class EquipmentVO implements Serializable {

    private static final long serialVersionUID = -3082465434943060388L;

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "设备名称")
    private String name;

    @ApiModelProperty(value = "ip地址")
    private String addressIp;

    @ApiModelProperty(value = "MAC地址")
    private String mac;

    @ApiModelProperty(value = "机构id")
    private Long orgId;

    @ApiModelProperty(value = "机构名称")
    private String orgName;

    @ApiModelProperty(value = "区域id")
    private Integer areaId;

    @ApiModelProperty(value = "区域名称")
    private String areaName;

    @ApiModelProperty(value = "设备类型id")
    private Integer typeId;

    @ApiModelProperty(value = "设备类型名称")
    private String typeName;

    @ApiModelProperty(value = "厂商信息")
    private String equipInfo;

    @ApiModelProperty(value = "审核状态 1:审核中 2:已通过 3:已拒绝")
    private Integer auditStatus;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "修改人")
    private String updateBy;

    @ApiModelProperty(value = "修改时间")
    private String updateTime;

    @ApiModelProperty(value = "在线状态 1在线 2离线")
    private Integer isOnline;

    @ApiModelProperty(value = "设备关联该计划，null或0：否，1：是")
    private Integer isSelected;

}

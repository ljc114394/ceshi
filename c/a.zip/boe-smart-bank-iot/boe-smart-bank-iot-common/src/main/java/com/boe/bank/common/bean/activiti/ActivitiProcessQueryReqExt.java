package com.boe.bank.common.bean.activiti;

import java.util.List;

import com.boe.bank.common.entity.activiti.ActivitiOuterRelation;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 查询activiti流程的请求参数
 * @author caoxuhao
 */
@Data
public class ActivitiProcessQueryReqExt  extends ActivitiProcessQueryReq{
	
	@ApiModelProperty(value = "业务类型： 1素材 2计划 3设备")
	private Integer busniessType;
	
}

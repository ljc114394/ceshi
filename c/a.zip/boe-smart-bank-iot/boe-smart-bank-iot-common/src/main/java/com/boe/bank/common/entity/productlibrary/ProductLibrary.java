package com.boe.bank.common.entity.productlibrary;

import com.boe.bank.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * TODO
 *
 * @author lvjiacheng
 * @version 1.0
 * @data 2020/10/21 15:32
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductLibrary extends BaseEntity implements Serializable {

    //主键id
    private Integer id;

    //产品名称
    private String productName;

    //启用状态 0禁用 1启用
    private Integer enable;

    //启用状态名称
    private String  enableName;

    //产品类型：p001信用卡 p002借记卡
    private String productType;

    //产品编号
    private String productNo;

    //产品推荐策略  0智能算法推荐  1手动关联推荐
    private Integer productTactics;

    //产品图片
    private String portraitImgUrl;

    //是否删除
    private Integer isDeleted;

    //产品关联画像数
    private Integer portraitCount;


}
